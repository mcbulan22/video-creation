# video-studio v4.2 - Sound layer + automatic checks + Freeform mode + Motion Kit: kinetic text, morphs, drawing icons, charts, flows; eight looks; Mac AND Windows PC

## NEW in v4.2: sound effects and automatic checks (read SOUND_AND_QA.md)
- `make` adds made-from-maths sound effects (scene whooshes, beat pops, opening swell, closing chime) under your voice. No files or licences. `--sfx off` / `--sfx-level 0.6` to change. Per-scene control: `@scene(..., sfx="off")` or a cue list.
- Loudness is now matched in two passes (about -16 LUFS).
- After every `make` / `render`, the video is checked automatically (frozen picture, black gaps, flashes and pops, loudness, silences, length): see `output/qa_report.txt`, or run `python studio.py qa`.
- `CRITIC_PROMPT.md`: paste into a fresh chat with the contact sheets for an independent review before you publish.

## v4.1: Freeform mode (read FREEFORM.md)
Claude can now write custom animation code for a single video: its own look (`set_look`), per-scene backgrounds / overlays / transitions, particles, flow fields,
networks, camera moves, per-letter text animation and SVG drawings that draw themselves (`fx` toolbox). Example: `examples/freeform_example.py`.
Also fixed: a `THEME = "..."` line in your scenes file is now honoured when you do not type `--theme`.

## v4.0: Motion Kit and two modern looks (same workflow)
Nothing about how you make a video changes: same `sh make.sh --draft` (Mac) or `make.bat --draft` (PC), same `inbox/scenes.py`, same narration script.
What is new:
- **Two new looks**: `aurora` (dark glass, drifting colour, gradient headings) and `editorial` (paper, ink outlines, colour blocks, marker highlights).
  Try them: `sh make.sh --theme aurora --draft`, `sh make.sh --theme editorial --draft`. Big headings in both now arrive word by word with no change to your scenes.
- **Motion Kit** (`scripts/motion_kit.py`, cheat sheet in **KIT.md**): kinetic text (6 styles), gradient and shimmer text, marker highlights, text morphs,
  shape morphs (circle to star to blob), card morphs, 28 icons that draw themselves, bars / rings / donuts / line charts / steppers / stat cards that build and count up,
  flowing diagram lines, spotlight, ripple, confetti, camera push, Ken Burns photos, and new scene-change wipes.
- `inbox/scenes.py` now holds a short **showcase deck** so your first test shows everything. The earlier MAAP-SEAS deck is saved as `examples/maap_seas_familiarization.py`.
- Everything from v3.3 still works (six older looks, quality levels, own voice, Mac and PC). Ocean still renders exactly as before.

To make your own video: replace `inbox/scenes.py` (Claude writes it from your material), then run the same commands.

## NEW in v3.3: faster rendering and quality levels
Frames now go straight into ffmpeg (no PNG files): about 3 times faster. New `--quality` levels: draft, standard (default), smooth (1080p60),
cinema (motion blur), ultra (4K). Render workers are chosen from your processor AND free memory. `benchmark` estimates times for your computer.
See PERFORMANCE.md.

## NEW in v3.2: one pack, two computers
The launcher detects whether you are on a Mac or a Windows PC (or say `--computer mac` / `--computer windows`).
Mac: `sh setup_mac.sh` once, then `sh make.sh`.   Windows PC: double-click `setup.bat` once, then `make.bat`.
Not sure what to type? Double-click `start.bat` (PC) or `start.command` (Mac): it asks a few questions and makes the video.
Everything is explained in COMPUTERS.md (side-by-side commands, voices, office PC without admin rights).

## NEW in v3: choose a look
Same scenes, same narration, six designs. The default is **clean**. Pick another only when you want to:

    sh make.sh --theme ocean        the original look: deep-sea blues, sunrise horizon, dive underwater
    sh make.sh --theme techno       dark neon grid, glowing HUD cards, typewriter text, synthwave title
    sh make.sh --theme classroom    chalkboard, handwriting, hand-drawn boxes and chalk doodles
    sh make.sh --theme formal       ivory and navy with gold rules, serif type, calm fades
    sh make.sh --theme playful      bright colours, bouncy pop-ins, sticker cards, confetti, cartoon ship
    sh make.sh --list-themes        list them
    sh preview_themes.sh            see ALL looks as still images in under a minute (output/theme_preview/overview.png)

Add `--draft` to any of them for a quick 720p test. `reference/theme_overview.png` shows what each look is like.
More detail, and how to make your own look: see THEMES.md.

NEW in v3.1: **every theme now moves differently** (clean = calm and decisive, techno = fast snap, classroom = hand-placed with chalk that boils,
formal = slow and elegant, playful = springy). See MOTION.md. Check it without rendering: `sh motion_check.sh`.

IMPORTANT: the default look changed from ocean to clean. To get exactly what you rendered before, use `--theme ocean`.

## What's in this pack
- Narrated video in one command: picture + voice-over + whoosh/splash sounds + optional music (ducks under the voice).
- NEW: the title scene is a sunrise **horizon**; at its end the camera **dives into the sea** (bubbles, light rays, splash sound) and the rest of the deck plays underwater.
- NEW: **your own voice**: record per-beat clips, run `sh make.sh --own-voice`.
- `narration_script.txt` lists every beat with the file name to record under. It is rebuilt every time you run make.sh.
- The finished Class 2030 deck (12 scenes, about 3 minutes) is in `inbox/scenes.py`.

## Install (once)
(v3 adds a `themes` folder and extra fonts: copy the WHOLE pack over your folder, do not pick files.)
1. Unzip the pack. Drag everything inside its `video-studio` folder into your existing `video-studio` folder.
2. Choose **Replace** for each item. Keep your hidden `.venv` folder (the pack doesn't contain one).
   Do NOT replace the whole `scripts` folder with a partial one: always use the complete pack.
3. No new setup is needed.

## Make the video
Terminal: type `cd ` (with a space), drag your `video-studio` folder into the window, press Enter. Then:

    sh make.sh --draft        quick test (720p)
    sh make.sh                final 1080p
    sh make.sh --fx off       faster, calmer background (the dive still plays)

Result: `output/final_with_audio.mp4`.

## Use your own voice
1. Open `narration_script.txt`. Each line starts with a file name such as `[s02_b01]`, followed by the exact words.
2. Record each beat as its own file with that name. Quiet room, phone 20-30 cm from your mouth, natural pace.
   WAV, M4A (iPhone Voice Memos), MP3 and AIFF all work.
3. Put all the files in the `my_voice` folder (23 files for the Class 2030 deck).
4. Run `sh make.sh --own-voice`. If any file is missing, it tells you exactly which ones.
Tip: re-recording one line? Replace just that file and run again.

## Options
- Music: save a royalty-free MP3 as `inbox/music.mp3` (picked up automatically), or `sh make.sh --music pad`.
- Logo: save `logo.png` in `inbox/`; it appears on the title scene (top right).
- Other Mac voice: `sh make.sh --voice-name Daniel`. Better voices: System Settings > Accessibility > Spoken Content > System Voice > Manage Voices.
- Silent picture only: `sh render.sh --draft`.

## Using Claude Code (optional)
Run `ollama launch claude` in the folder and paste the text from `CLAUDE_CODE_PROMPT.txt`. The plain commands above cost no credits.

## A new video
Use `CHAT_PROMPT.md` in Claude chat. Put the new `scenes.py` into `inbox/` and run `sh make.sh --draft`.
For a horizon-and-dive title, the first scene is written with `sky=True` (see CHAT_PROMPT.md).
