# Prompt to paste into Claude chat (with the scene-video-studio skill) for a NEW video
(Attach the video-studio pack zip you already have, so Claude uses the same engine.)

Use the scene-video-studio skill. Make a new scenes.py for my video-studio v2 pack from the material I attach.
- About ___ minutes, about 12 scenes, audience: ___.
- Beat text = the exact narration (read aloud by a computer voice or by me).
- Scene 1 = horizon title (sky=True) that dives into the sea; the rest are underwater scenes.
- Use S.num count-ups, S.glow and springy reveals. Check every scene for overlapping or overflowing text.
- Deliver the full pack as a zip (scenes.py + narration_script.txt + the engine), not a rendered video.
- Sound (SOUND_AND_QA.md): effects are automatic. Use `sfx="off"` on a scene to silence its pops, or `sfx=[(beat, offset, "chime")]` for specific cues. After a draft, ask the user to run `python studio.py qa` and share `output/qa_report.txt`; for important videos suggest the CRITIC_PROMPT.md independent review.
- Freeform mode (FREEFORM.md): when the user asks for "freeform", "custom" or "something unique", write a deck-specific look with set_look, scene hooks (bg / fg / trans / live),
  the fx toolbox, S.text_anim and S.svg. All effects must be pure functions of time. Keep one hero effect per scene and stay inside the performance budgets.
- Motion Kit (KIT.md): use it. Kinetic or gradient titles, S.icon on every card row, S.stat / S.ring / S.bars / S.linechart for any numbers, S.flow for processes,
  S.morph_shape or S.morph_text for one change-over-time moment per video, S.spotlight to focus the key point, S.burst on the final scene. Spread over beats.
- Themes: the pack has eight looks (v4 adds aurora and editorial) (clean default, ocean, techno, classroom, formal, playful, aurora, editorial) chosen with `--theme`. Write scenes that work in all of them:
  use the colour roles (white = text, teal = accent, amber = second accent), no hard-coded colours, no delay longer than 0.3 s per item
  (themes tighten cascades), put the hero element on the first beat, and check contact sheets for at least clean and one dark theme.
- Motion rules are in MOTION.md. Run the motion report before delivering and mention any WARN.
- The pack runs on a Mac and on a Windows PC through `studio.py`; scenes must not depend on the computer (no absolute paths, no OS-specific fonts or commands). The user may render on either machine.
