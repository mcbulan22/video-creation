"""motion_kit (v4): extra motion-graphics tools for scenes. Imported by engine.py, which adds these methods to S.

Every tool takes a progress value p (0..1) from S.p(beat, dur, delay) exactly like the older primitives, so the
workflow does not change: the beat decides WHEN, the tool decides HOW. Colour arguments are palette roles
("white", "teal", "amber", "edge", ...), so every theme restyles them.  Cheat sheet: KIT.md
"""
import math, random, contextlib
import skia
import engine as E
from engine import hexc


# ------------------------------------------------------------------ small helpers
def _c01(x): return max(0.0, min(1.0, x))
def _lerp(a, b, t): return a + (b - a) * t
def _col(name): return E.C.get(name, name)
_out = E.ease_out_cubic
_expo = E.ease_out_expo
_io = E.ease_in_out_sine
def _back(x, s=1.5): return E.ease_back(x, s)


def method(fn):
    setattr(E.Ctx, fn.__name__, fn)
    return fn


def _path(pts, close=False):
    pa = skia.Path(); pa.moveTo(*pts[0])
    for q in pts[1:]: pa.lineTo(*q)
    if close: pa.close()
    return pa


def _cut(pts, frac):
    """First `frac` of a polyline -> (points, head_x, head_y, heading_angle)."""
    if len(pts) < 2: return pts, pts[0][0], pts[0][1], 0.0
    segs = [math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:])]
    target = sum(segs) * _c01(frac); out = [pts[0]]; acc = 0.0
    for (a, b), L in zip(zip(pts, pts[1:]), segs):
        if acc + L >= target - 1e-9:
            u = (target - acc) / L if L > 0 else 0.0
            hx, hy = a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u
            out.append((hx, hy)); return out, hx, hy, math.atan2(b[1] - a[1], b[0] - a[0])
        out.append(b); acc += L
    a, b = pts[-2], pts[-1]
    return out, b[0], b[1], math.atan2(b[1] - a[1], b[0] - a[0])


def _smooth(pts, n=16):
    """Catmull-Rom curve through the points, sampled as a polyline."""
    if len(pts) < 3: return list(pts)
    P = [pts[0]] + list(pts) + [pts[-1]]; out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(n):
            t = k / n; t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * ((2 * p1[j]) + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2
                                    + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3) for j in (0, 1)))
    out.append(pts[-1]); return out


def _circle(cx, cy, r, a0=0.0, a1=2 * math.pi, n=40):
    return [(cx + r * math.cos(a0 + (a1 - a0) * k / n), cy + r * math.sin(a0 + (a1 - a0) * k / n)) for k in range(n + 1)]


def _rrect(x, y, w, h, r, n=8):
    pts = []
    for (cx, cy, a0) in ((x + r, y + r, math.pi), (x + w - r, y + r, 1.5 * math.pi), (x + w - r, y + h - r, 0.0), (x + r, y + h - r, 0.5 * math.pi)):
        pts += _circle(cx, cy, r, a0, a0 + 0.5 * math.pi, n)
    pts.append(pts[0]); return pts


def _txt(self, s, x, y, size, color="white", w="r", al="l", a=1.0, maxw=None, lh=1.25):
    """Plain text with no theme slide / lag / typing: for labels inside charts that must stay in sync."""
    if a <= 0.003: return 0
    f = E.font(w, size); E._check_glyphs(s, w)
    lines = self.wrap(s, f, maxw) if maxw else [s]
    for i, ln in enumerate(lines):
        tw = f.measureText(ln); xx = x if al == "l" else (x - tw / 2 if al == "c" else x - tw)
        self.c.drawString(ln, xx, y + i * size * lh, f, self.paint(color, a))
    return len(lines) * size * lh
E.Ctx._txt = _txt


# ================================================================== TEXT
@method
def kinetic(self, s, x, y, size=64, color="white", w="b", al="c", p=1, mode=None, maxw=None, lh=1.2,
            spread=0.55, grad=None, shimmer=False, _deco=True):
    """Kinetic text: the words (or letters) arrive one after another inside ONE reveal.
    mode: rise (words slide up out of a mask), pop (scale-in), drop (fall in with a bounce), blur (focus in),
          zoom (shrink in), chars (letters rise one by one).   grad=("teal","sky") fills with a gradient;
    shimmer=True sweeps a light glint across the finished text.  Returns the text height."""
    if p <= 0.001: return 0
    TH = E.TH; c = self.c; mode = mode or getattr(TH, "kin_mode", "rise")
    if TH.text_lag != 1.0: p = p ** TH.text_lag
    pp = _c01(p); f = E.font(w, size); E._check_glyphs(s, w)
    lines = self.wrap(s, f, maxw) if maxw else [s]
    per_char = (mode == "chars"); spread = min(spread, 0.9)
    total = max(1, sum((len(l.replace(" ", "")) if per_char else len(l.split())) for l in lines)); u = 0; info = []
    colors = [_col(k) for k in grad] if grad else None

    def mk(x0, tw, a):
        pt = skia.Paint(AntiAlias=True)
        if colors:
            pos = [i / (len(colors) - 1) for i in range(len(colors))]
            pt.setShader(skia.GradientShader.MakeLinear([skia.Point(x0, 0), skia.Point(x0 + max(tw, 1), 0)], [hexc(k) for k in colors], pos))
        else: pt.setColor(hexc(_col(color)))
        pt.setAlphaf(_c01(a)); return pt

    for li, ln in enumerate(lines):
        tw = f.measureText(ln); x0 = x if al == "l" else (x - tw / 2 if al == "c" else x - tw); base = y + li * size * lh
        units = []
        if per_char:
            for i, ch in enumerate(ln):
                if ch != " ": units.append((ch, f.measureText(ln[:i])))
        else:
            idx = 0
            for wd in ln.split():
                j = ln.index(wd, idx); units.append((wd, f.measureText(ln[:j]))); idx = j + len(wd)
        masked = mode in ("rise", "chars")
        if masked: c.save(); c.clipRect(skia.Rect.MakeXYWH(x0 - size, base - size * 1.08, tw + 2 * size, size * 1.55))
        for (txt, xo) in units:
            q = _c01((pp - (u / total) * spread) / (1 - spread)); u += 1
            if q <= 0: continue
            ux = x0 + xo; uw = f.measureText(txt)
            if mode in ("rise", "chars"):
                c.drawString(txt, ux, base + (1 - _expo(q)) * size * 1.05, f, mk(x0, tw, q * 4))
            elif mode == "drop":
                c.drawString(txt, ux, base - (1 - _back(q, 1.2)) * size * 1.4, f, mk(x0, tw, q * 4))
            elif mode == "blur":
                dy = (1 - _out(q)) * size * 0.25
                if q < 1:
                    bp = mk(x0, tw, (1 - q) * 0.9); bp.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, size * 0.12))
                    c.drawString(txt, ux, base + dy, f, bp)
                c.drawString(txt, ux, base + dy, f, mk(x0, tw, q))
            else:                                         # pop / zoom: scale about the word centre
                k = (0.4 + 0.6 * _back(q, 1.8)) if mode == "pop" else 1 + (1 - _expo(q)) * 0.9
                c.save(); c.translate(ux + uw / 2, base - size * 0.3); c.scale(k, k); c.translate(-(ux + uw / 2), -(base - size * 0.3))
                c.drawString(txt, ux, base, f, mk(x0, tw, q * 3)); c.restore()
        if masked: c.restore()
        if shimmer and pp >= 0.999:
            band = size * 3.0; pos = x0 + ((self.t * 0.45) % 1.6 - 0.3) * (tw + band)
            gp = skia.Paint(AntiAlias=True)
            gp.setShader(skia.GradientShader.MakeLinear([skia.Point(pos - band / 2, 0), skia.Point(pos + band / 2, 0)],
                         [hexc("#FFFFFF", 0), hexc("#FFFFFF", .8), hexc("#FFFFFF", 0)], [0, .5, 1]))
            c.drawString(ln, x0, base, f, gp)
        info.append((x0, base, tw))
    if _deco: TH.after_text(self, info, size, color, pp)
    return len(lines) * size * lh


@method
def grad_text(self, s, x, y, size=64, colors=("teal", "sky"), w="b", al="c", p=1, maxw=None, shimmer=True, mode="blur"):
    """Gradient-filled text with an optional shimmer glint."""
    return self.kinetic(s, x, y, size, "white", w, al, p, mode=mode, maxw=maxw, grad=colors, shimmer=shimmer)


@method
def outline_text(self, s, x, y, size=96, color="teal", w="b", al="c", p=1, sw=3, fill_after=True):
    """Stroke-only lettering that fills in once drawn (big section numbers and words)."""
    if p <= 0.001: return
    f = E.font(w, size); tw = f.measureText(s); xx = x if al == "l" else (x - tw / 2 if al == "c" else x - tw)
    pp = _c01(p); yy = y + (1 - _out(pp)) * size * 0.2
    st = self.paint(color, _c01(pp * 2), sw); st.setStrokeWidth(sw)
    self.c.drawString(s, xx, yy, f, st)
    if fill_after and pp > 0.55:
        fp = self.paint(color, _c01((pp - 0.55) / 0.45)); self.c.drawString(s, xx, yy, f, fp)


@method
def marker(self, x, y, w, h, color="amber", p=1, a=0.55, r=10, multiply=False):
    """Highlighter swipe. Draw it BEFORE the text it sits behind (or use multiply=True after)."""
    if p <= 0.001: return
    q = _out(_c01(p)); pt = self.paint(color, a * _c01(p * 3))
    if multiply: pt.setBlendMode(skia.BlendMode.kMultiply)
    self.c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w * q, h), r, r, pt)


@method
def underline(self, x, y, w, color="teal", p=1, sw=6, wave=0.0):
    """Animated underline (straight, or wavy with wave = amplitude in px)."""
    if p <= 0.001: return
    n = max(2, int(w / 10)); pts = [(x + w * i / n, y + (wave * math.sin(i * 0.9) if wave else 0)) for i in range(n + 1)]
    part, *_ = _cut(pts, _out(_c01(p)))
    if len(part) > 1: self.c.drawPath(_path(part), self.paint(color, 1, sw))


@method
def morph_text(self, a, b, x, y, size=64, color="white", w="b", al="c", m=0.0, p=1, color_b=None, spread=0.5):
    """Slot-machine morph from text a to text b. m = morph position 0..1 (use S.p of a later beat), p = overall appear."""
    if p <= 0.001: return
    f = E.font(w, size); E._check_glyphs(a, w); E._check_glyphs(b, w); m = _c01(m); pa = _c01(p)
    N = max(len(a), len(b))

    def lay(s):
        tw = f.measureText(s); return x if al == "l" else (x - tw / 2 if al == "c" else x - tw)
    xa, xb = lay(a), lay(b); wide = max(f.measureText(a), f.measureText(b))
    c = self.c; c.save()
    c.clipRect(skia.Rect.MakeXYWH(min(xa, xb) - size * .5, y - size * 1.08, wide + size, size * 1.6))
    for i in range(N):
        q = _c01((m - (i / max(1, N)) * spread) / (1 - spread)); e = _out(q)
        if i < len(a) and a[i] != " " and q < 1:
            c.drawString(a[i], xa + f.measureText(a[:i]), y - e * size * 0.9, f, self.paint(color, pa * _c01(1 - q * 1.6)))
        if i < len(b) and b[i] != " " and q > 0:
            c.drawString(b[i], xb + f.measureText(b[:i]), y + (1 - e) * size * 0.9, f, self.paint(color_b or color, pa * _c01(q * 1.6)))
    c.restore()


# ================================================================== MORPHS
_SH = {"tri": (3, [1.15], -math.pi / 2), "diamond": (4, [1.05], -math.pi / 2), "square": (4, [1.22], -math.pi / 4),
       "pent": (5, [1.08], -math.pi / 2), "hex": (6, [1.05], 0.0), "star": (10, [1.1, 0.48], -math.pi / 2),
       "star8": (16, [1.1, 0.62], -math.pi / 2), "burst": (24, [1.05, 0.85], -math.pi / 2)}
SHAPES = ["circle", "squircle", "blob"] + list(_SH)
_RAD = {}


def _radii(kind, N=180):
    if kind in _RAD: return _RAD[kind]
    out = []
    for i in range(N):
        th = 2 * math.pi * i / N
        if kind == "circle": r = 1.0
        elif kind == "squircle": r = 0.95 * (abs(math.cos(th)) ** 4 + abs(math.sin(th)) ** 4) ** -0.25
        elif kind == "blob": r = 0.9 + 0.09 * math.sin(3 * th + 0.7) + 0.05 * math.sin(5 * th + 2)
        else:
            m, rads, rot = _SH[kind]; step = 2 * math.pi / m; t = (th - rot) % (2 * math.pi); k = int(t / step) % m
            a0 = rot + k * step; a1 = a0 + step; r0 = rads[k % len(rads)]; r1 = rads[(k + 1) % m % len(rads)]
            v0 = (r0 * math.cos(a0), r0 * math.sin(a0)); v1 = (r1 * math.cos(a1), r1 * math.sin(a1))
            d = (math.cos(th), math.sin(th)); e = (v1[0] - v0[0], v1[1] - v0[1]); den = d[0] * e[1] - d[1] * e[0]
            r = abs((v0[0] * e[1] - v0[1] * e[0]) / den) if abs(den) > 1e-9 else 1.0
        out.append(r)
    _RAD[kind] = out; return out


@method
def morph_shape(self, kinds, cx, cy, r, m=0.0, p=1, fill="teal", stroke=None, sw=6, a=1.0, glow=0.0, spin=0.0, rot=0.0):
    """A solid shape that flows from one outline to the next. kinds = e.g. ["circle", "square", "star"];
    m = position along the list (0 = first, 1 = second ...), eased between neighbours; p = appear. Shapes: """ + ", ".join(SHAPES)
    if p <= 0.001: return
    n = len(kinds); m = max(0.0, min(max(0.0, n - 1.0), m)); seg = min(int(m), max(0, n - 2)); f = _io(m - seg) if n > 1 else 0.0
    ra = _radii(kinds[seg]); rb = _radii(kinds[min(seg + 1, n - 1)]); k = 0.55 + 0.45 * min(_back(_c01(p), 1.4), 1.25); alpha = _c01(p * 2) * a
    ang = rot + spin * m; N = len(ra)
    pts = [(cx + r * k * _lerp(ra[i], rb[i], f) * math.cos(2 * math.pi * i / N + ang),
            cy + r * k * _lerp(ra[i], rb[i], f) * math.sin(2 * math.pi * i / N + ang)) for i in range(N)]
    path = _path(pts, True); c = self.c
    if glow and fill:
        gp = E.blur_paint(fill, .55 * alpha * glow, r * 0.18); gp.setStyle(skia.Paint.kFill_Style); c.drawPath(path, gp)
    if fill:
        fp = self.paint(fill, alpha)
        try: fp.setPathEffect(skia.CornerPathEffect.Make(r * 0.05))
        except Exception: pass
        c.drawPath(path, fp)
    if stroke: c.drawPath(path, self.paint(stroke, alpha, sw))


@method
def morph_rr(self, a, b, t, fill="card", stroke="edge", sw=3, p=1):
    """A card that glides and reshapes from box a to box b. a, b = (x, y, w, h, radius); t = 0..1 (use S.p of a later beat)."""
    t = _io(_c01(t)); v = [_lerp(a[i], b[i], t) for i in range(5)]
    self.rr(v[0], v[1], v[2], v[3], v[4], fill, stroke, sw, p)
    return v


# ================================================================== ICONS (draw themselves on)
def _poly(*pts): return list(pts)


def _gear():
    pts = []
    for k in range(8):
        a = k * math.pi / 4
        for da, rr in ((-0.2, 31), (-0.13, 40), (0.13, 40), (0.2, 31)):
            pts.append((50 + rr * math.cos(a + da), 50 + rr * math.sin(a + da)))
    pts.append(pts[0]); return pts


def _star(n=5, ro=40, ri=17):
    pts = [(50 + (ro if k % 2 == 0 else ri) * math.cos(-math.pi / 2 + k * math.pi / n),
            54 + (ro if k % 2 == 0 else ri) * math.sin(-math.pi / 2 + k * math.pi / n)) for k in range(2 * n)]
    pts.append(pts[0]); return pts


_ICONS = {
    "check": ([[(22, 52), (42, 70), (78, 30)]], []),
    "clock": ([_circle(50, 50, 36), [(50, 28), (50, 50), (66, 60)]], []),
    "lock": ([_rrect(24, 44, 52, 40, 8), [(32, 44), (32, 34)] + _circle(50, 34, 18, math.pi, 2 * math.pi, 16) + [(68, 34), (68, 44)]], [(50, 64, 4)]),
    "shield": ([[(50, 12), (80, 24), (80, 50), (50, 88), (20, 50), (20, 24), (50, 12)], [(36, 48), (47, 60), (66, 38)]], []),
    "user": ([_circle(50, 32, 16), _circle(50, 88, 36, math.pi, 2 * math.pi, 24)], []),
    "book": ([[(50, 26), (50, 82)], [(50, 26), (18, 20), (18, 74), (50, 82)], [(50, 26), (82, 20), (82, 74), (50, 82)]], []),
    "laptop": ([_rrect(20, 28, 60, 40, 4), [(10, 74), (16, 82), (84, 82), (90, 74), (10, 74)]], []),
    "warning": ([[(50, 14), (88, 82), (12, 82), (50, 14)], [(50, 38), (50, 60)]], [(50, 71, 3.5)]),
    "globe": ([_circle(50, 50, 36), [(50 + 16 * math.cos(2 * math.pi * k / 40), 50 + 36 * math.sin(2 * math.pi * k / 40)) for k in range(41)],
               [(14, 50), (86, 50)], [(20, 32), (80, 32)], [(20, 68), (80, 68)]], []),
    "gear": ([_gear(), _circle(50, 50, 12)], []),
    "bulb": ([_circle(50, 40, 24, 0.8 * math.pi, 2.2 * math.pi, 30) + [(60, 70), (40, 70), (40, 62)], [(41, 78), (59, 78)], [(43, 88), (57, 88)],
              [(42, 52), (50, 42), (58, 52)]], []),
    "chart": ([[(16, 16), (16, 84), (86, 84)], _rrect(28, 56, 12, 28, 2), _rrect(48, 40, 12, 44, 2), _rrect(68, 24, 12, 60, 2)], []),
    "doc": ([[(26, 10), (60, 10), (78, 28), (78, 90), (26, 90), (26, 10)], [(60, 10), (60, 28), (78, 28)], [(36, 50), (68, 50)], [(36, 64), (68, 64)], [(36, 78), (56, 78)]], []),
    "wifi": ([_circle(50, 76, 44, 1.25 * math.pi, 1.75 * math.pi, 14), _circle(50, 76, 30, 1.25 * math.pi, 1.75 * math.pi, 12), _circle(50, 76, 16, 1.25 * math.pi, 1.75 * math.pi, 10)], [(50, 78, 4)]),
    "anchor": ([_circle(50, 22, 8), [(50, 30), (50, 86)], [(36, 44), (64, 44)], _circle(50, 58, 34, 0.05 * math.pi, 0.95 * math.pi, 24), [(12, 52), (16, 64), (26, 58)], [(88, 52), (84, 64), (74, 58)]], []),
    "target": ([_circle(50, 50, 36), _circle(50, 50, 22), _circle(50, 50, 8)], []),
    "star": ([_star()], []),
    "mail": ([_rrect(12, 24, 76, 52, 6), [(12, 28), (50, 56), (88, 28)]], []),
    "search": ([_circle(42, 42, 24), [(60, 60), (84, 84)]], []),
    "play": ([[(34, 22), (34, 78), (80, 50), (34, 22)]], []),
    "ship": ([[(8, 60), (92, 60), (80, 82), (22, 82), (8, 60)], _rrect(24, 38, 40, 22, 3), _rrect(66, 24, 14, 36, 3), [(40, 38), (40, 26), (52, 26), (52, 38)]], []),
    "cap": ([[(50, 22), (94, 42), (50, 62), (6, 42), (50, 22)], [(26, 54), (26, 74), (50, 84), (74, 74), (74, 54)], [(90, 46), (90, 70)]], []),
    "compass": ([_circle(50, 50, 36), [(50, 22), (60, 50), (50, 78), (40, 50), (50, 22)]], []),
    "calendar": ([_rrect(14, 20, 72, 66, 8), [(14, 42), (86, 42)], [(32, 10), (32, 28)], [(68, 10), (68, 28)]], []),
    "pencil": ([[(18, 84), (24, 62), (68, 18), (82, 32), (38, 76), (18, 84)], [(60, 26), (74, 40)]], []),
    "phone": ([_rrect(30, 10, 40, 80, 8), [(44, 78), (56, 78)]], []),
    "camera": ([_rrect(10, 28, 80, 56, 8), _circle(50, 56, 16), [(34, 28), (40, 18), (60, 18), (66, 28)]], []),
    "heart": ([[(50 + 38 * math.sin(t) ** 3, 42 - (30 * math.cos(t) - 12 * math.cos(2 * t) - 5 * math.cos(3 * t) - 2 * math.cos(4 * t)) * 1.0)
                for t in [i * 2 * math.pi / 60 for i in range(61)]]], []),
}
ICON_NAMES = sorted(_ICONS)


@method
def icon(self, name, cx, cy, size=72, color="teal", p=1, sw=None, bg=None, bg_fill=None):
    """Line icon that draws itself on. bg = "circle" or "squircle" adds a soft badge behind it (bg_fill = its colour).
    Names: """ + ", ".join(ICON_NAMES)
    if p <= 0.001: return
    if name not in _ICONS: raise ValueError(f"unknown icon {name!r}; choose from {', '.join(ICON_NAMES)}")
    c = self.c; pp = _c01(p); q = _out(pp); sc = size / 100.0; sw = sw or max(3.0, size * 0.075)
    if bg:
        k = 0.7 + 0.3 * min(_back(pp, 1.6), 1.2); bs = size * 1.55 * k; col = bg_fill or color
        if bg == "circle": c.drawCircle(cx, cy, bs / 2, self.paint(col, .16 * _c01(pp * 3))); c.drawCircle(cx, cy, bs / 2, self.paint(col, .5 * _c01(pp * 3), 2))
        else: c.drawRoundRect(skia.Rect.MakeXYWH(cx - bs / 2, cy - bs / 2, bs, bs), bs * .3, bs * .3, self.paint(col, .16 * _c01(pp * 3)))
    lines, dots = _ICONS[name]; c.save(); c.translate(cx - size / 2, cy - size / 2); c.scale(sc, sc)
    st = self.paint(color, _c01(pp * 4), sw / sc)
    for pl in lines:
        part, *_ = _cut(pl, q)
        if len(part) > 1: c.drawPath(_path(part), st)
    if q > 0.75:
        for (dx, dy, dr) in dots: c.drawCircle(dx, dy, dr, self.paint(color, _c01((q - 0.75) * 4)))
    c.restore()


# ================================================================== CHARTS
@method
def bars(self, items, x, y, w, h, p=1, color="teal", size=26, vmax=None, fmt="{:,.0f}", gap=0.4, radius=12, axis=True):
    """Vertical bar chart whose bars grow one after another and count up. items = [(label, value)] or [(label, value, colour)].
    The box x, y, w, h is the plot area; labels sit under it, so leave about 60 px below."""
    if p <= 0.001 or not items: return
    n = len(items); pp = _c01(p); vmax = vmax or max(i[1] for i in items) or 1.0
    bw = w / (n * (1 + gap)); step = bw * (1 + gap); st = min(0.6 / n, 0.14); base = y + h
    if axis: self.c.drawLine(x - 10, base, x + w + 10, base, self.paint("edge", .9 * _c01(pp * 3), 3))
    for i, it in enumerate(items):
        lab, v = it[0], it[1]; col = it[2] if len(it) > 2 else color
        q = _c01((pp - i * st) / (1 - (n - 1) * st)); e = _back(q, 1.1) if q < 1 else 1.0
        bh = max(0.0, h * (v / vmax) * min(e, 1.08)); bx = x + gap * bw / 2 + i * step
        if q > 0:
            gp = skia.Paint(AntiAlias=True)
            gp.setShader(skia.GradientShader.MakeLinear([skia.Point(0, base - bh), skia.Point(0, base)], [hexc(_col(col)), hexc(_col(col), .55)]))
            self.c.save(); self.c.clipRect(skia.Rect.MakeXYWH(bx - 2, base - bh - 4, bw + 4, bh + 4))      # flat bottom, rounded top
            self.c.drawRoundRect(skia.Rect.MakeXYWH(bx, base - bh, bw, bh + radius), radius, radius, gp); self.c.restore()
            self._txt(fmt.format(v * _out(q)), bx + bw / 2, base - bh - size * 0.35, size, "white", E.TH.num_w, "c", _c01(q * 2))
            self._txt(lab, bx + bw / 2, base + size * 1.35, size * 0.85, "mute", "m", "c", _c01(q * 2), maxw=step * 1.1)


@method
def hbars(self, items, x, y, w, p=1, color="teal", size=28, vmax=None, fmt="{:,.0f}", row=64, label_w=300, unit=""):
    """Horizontal bars: label on the left, bar grows right, value counts up at its end."""
    if p <= 0.001 or not items: return
    n = len(items); pp = _c01(p); vmax = vmax or max(i[1] for i in items) or 1.0; st = min(0.6 / n, 0.14)
    for i, it in enumerate(items):
        lab, v = it[0], it[1]; col = it[2] if len(it) > 2 else color; q = _c01((pp - i * st) / (1 - (n - 1) * st)); e = _out(q)
        yy = y + i * row; bw = (w - label_w - 150) * (v / vmax) * e
        self._txt(lab, x, yy + size * 0.35, size, "white", "m", "l", _c01(q * 3), maxw=label_w - 20)
        self.c.drawRoundRect(skia.Rect.MakeXYWH(x + label_w, yy - size * 0.55, w - label_w - 150, size * 1.1), size * .55, size * .55, self.paint("edge", .35 * _c01(q * 3)))
        if bw > 1: self.c.drawRoundRect(skia.Rect.MakeXYWH(x + label_w, yy - size * 0.55, max(bw, size * 1.1), size * 1.1), size * .55, size * .55, self.paint(col, _c01(q * 3)))
        self._txt(fmt.format(v * e) + unit, x + w - 130, yy + size * 0.35, size, "white", E.TH.num_w, "l", _c01(q * 2))


@method
def ring(self, cx, cy, r, value, p=1, color="teal", sw=None, track="edge", fmt="{:.0f}%", size=None, label=None, vmax=100.0):
    """Progress ring that sweeps round while its number counts up."""
    if p <= 0.001: return
    c = self.c; sw = sw or max(10.0, r * 0.2); q = _out(_c01(p)); a = _c01(p * 3); size = size or r * 0.6
    c.drawCircle(cx, cy, r, self.paint(track, .5 * a, sw))
    sweep = 360.0 * _c01(value / vmax) * q; oval = skia.Rect.MakeXYWH(cx - r, cy - r, 2 * r, 2 * r)
    if sweep > 0.5:
        c.drawArc(oval, -90, sweep, False, E.blur_paint(color, .45 * a, sw * .8, sw))
        c.drawArc(oval, -90, sweep, False, self.paint(color, a, sw))
    self._txt(fmt.format(value * q), cx, cy + size * (0.34 if not label else 0.1), size, "white", E.TH.num_w, "c", a)
    if label: self._txt(label, cx, cy + size * 0.75, size * 0.42, "mute", "m", "c", a, maxw=r * 1.5)


@method
def donut(self, parts, cx, cy, r, p=1, sw=None, gap=2.5, center=None, size=None):
    """Donut chart. parts = [(label, value, colour)]. center = ("72%", "passed") shows a big figure in the hole."""
    if p <= 0.001: return
    c = self.c; sw = sw or r * 0.32; tot = sum(v for _, v, _ in parts) or 1.0; q = _out(_c01(p)); ang = -90.0
    oval = skia.Rect.MakeXYWH(cx - r, cy - r, 2 * r, 2 * r); c.drawCircle(cx, cy, r, self.paint("edge", .3 * _c01(p * 3), sw))
    for lab, v, col in parts:
        sw_a = 360.0 * v / tot
        vis = max(0.0, min(sw_a, (360.0 * q) - (ang + 90.0)))
        if vis > gap: c.drawArc(oval, ang + gap / 2, vis - gap, False, self.paint(col, 1, sw))
        ang += sw_a
    if center:
        size = size or r * 0.5
        self._txt(center[0], cx, cy + size * 0.2, size, "white", E.TH.num_w, "c", _c01(p * 2))
        if len(center) > 1: self._txt(center[1], cx, cy + size * 0.75, size * 0.42, "mute", "m", "c", _c01(p * 2))


@method
def linechart(self, values, x, y, w, h, p=1, color="teal", labels=None, size=24, vmin=None, vmax=None, fill=True, dots=True, grid=4):
    """Line chart that draws itself left to right, with an area fill, dots and optional x labels."""
    if p <= 0.001 or len(values) < 2: return
    c = self.c; pp = _c01(p); lo = vmin if vmin is not None else min(values); hi = vmax if vmax is not None else max(values)
    span = (hi - lo) or 1.0; n = len(values)
    pts = [(x + w * i / (n - 1), y + h - h * (v - lo) / span) for i, v in enumerate(values)]
    for g in range(grid + 1): c.drawLine(x, y + h * g / grid, x + w, y + h * g / grid, self.paint("edge", .35 * _c01(pp * 3), 2))
    curve = _smooth(pts, 14); part, hx, hy, _ = _cut(curve, _out(pp))
    if fill and len(part) > 1:
        fp = _path(part + [(hx, y + h), (x, y + h)], True); gp = skia.Paint(AntiAlias=True)
        gp.setShader(skia.GradientShader.MakeLinear([skia.Point(0, y), skia.Point(0, y + h)], [hexc(_col(color), .35), hexc(_col(color), 0)]))
        c.drawPath(fp, gp)
    if len(part) > 1:
        c.drawPath(_path(part), E.blur_paint(color, .45, 8, 10)); c.drawPath(_path(part), self.paint(color, 1, 6))
    for i, (px, py) in enumerate(pts):
        if dots and px <= hx + 1:
            c.drawCircle(px, py, 11, self.paint("bg1", 1)); c.drawCircle(px, py, 11, self.paint(color, 1, 4))
        if labels and px <= hx + 1: self._txt(labels[i], px, y + h + size * 1.5, size, "mute", "m", "c", 1.0)


@method
def stepper(self, labels, x0, x1, y, p=1, color="teal", size=26, r=28, maxw=None):
    """Horizontal step tracker: the line draws along, numbered dots light up one by one, labels sit underneath."""
    if p <= 0.001 or not labels: return
    n = len(labels); pp = _c01(p); c = self.c; span = (x1 - x0) / max(1, n - 1); maxw = maxw or max(120.0, span * 0.9)
    c.drawLine(x0, y, x1, y, self.paint("edge", .7, 6)); c.drawLine(x0, y, x0 + (x1 - x0) * _out(pp), y, self.paint(color, 1, 6))
    for i, lab in enumerate(labels):
        px = x0 + span * i; q = _c01((pp - (i / max(1, n - 1)) * 0.8) / 0.2)
        if q <= 0: continue
        k = 0.5 + 0.5 * min(_back(q, 1.8), 1.3)
        c.drawCircle(px, y, r * k, self.paint(color, _c01(q * 2))); c.drawCircle(px, y, r * k + 7, self.paint(color, .35 * q, 3))
        self._txt(str(i + 1), px, y + size * 0.36, size, "dark", E.TH.num_w, "c", _c01(q * 2))
        self._txt(lab, px, y + r + size * 1.5 + (1 - q) * 16, size * 0.95, "white", "m", "c", q, maxw=maxw)


@method
def stat(self, value, label, x, y, w=420, h=240, p=1, color="teal", fmt="{:,.0f}", unit="", icon=None, p_num=None):
    """Big-number card: soft glow, count-up figure, caption, optional icon name in the corner."""
    if p <= 0.001: return
    pn = _c01(p if p_num is None else p_num); self.glow(x + w / 2, y + h / 2, w * 0.7, color, .2, p)
    self.rr(x, y, w, h, 28, "card", "edge", 2, p)
    q = _out(pn); size = h * 0.34
    self._txt(fmt.format(value * q) + unit, x + w / 2, y + h * 0.52, size, color, E.TH.num_w, "c", _c01(p * 2))
    self._txt(label, x + w / 2, y + h * 0.78, 28, "white", "m", "c", _c01(p * 2), maxw=w - 50)
    if icon: self.icon(icon, x + w - 46, y + 46, 40, color, p)


# ================================================================== FLOW, EMPHASIS, EFFECTS
@method
def flow(self, pts, p=1, color="teal", sw=6, dot=True, head=True, smooth=True, dash=None, glow=True):
    """A line (or curve through several points) that draws itself with a glowing dot at its tip and an arrow head.
    After it finishes, a pulse keeps travelling along it."""
    if p <= 0.001 or len(pts) < 2: return
    c = self.c; path = _smooth(pts) if (smooth and len(pts) > 2) else list(pts); q = _c01(p)
    part, hx, hy, ang = _cut(path, _out(q))
    if len(part) > 1:
        if glow: c.drawPath(_path(part), E.blur_paint(color, .4, 8, sw + 4))
        c.drawPath(_path(part), self.paint(color, 1, sw, dash))
    if head and q >= 0.98:
        hl = sw * 3.2; pa = skia.Path(); pa.moveTo(hx, hy)
        pa.lineTo(hx - hl * math.cos(ang - 0.45), hy - hl * math.sin(ang - 0.45)); pa.lineTo(hx - hl * math.cos(ang + 0.45), hy - hl * math.sin(ang + 0.45)); pa.close()
        c.drawPath(pa, self.paint(color))
    if dot:
        if q < 1: tx, ty = hx, hy
        else: _, tx, ty, _ = _cut(path, (self.t * 0.4) % 1.0)
        c.drawCircle(tx, ty, sw * 2.2, E.blur_paint(color, .9, sw * 1.2)); c.drawCircle(tx, ty, sw * 1.2, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF")))
        c.drawCircle(tx, ty, sw * 1.2, self.paint(color, 1, 2))


@method
def ripple(self, x, y, r=90, color="teal", p=1, n=3, sw=4):
    """Expanding rings from a point (pulse, signal, 'you are here'). Keeps looping while p > 0."""
    if p <= 0.001: return
    for k in range(n):
        u = ((self.t * 0.5) + k / n) % 1.0
        self.c.drawCircle(x, y, r * (0.25 + 0.75 * u), self.paint(color, .7 * (1 - u) * _c01(p * 2), sw))


@method
def burst(self, x, y, p=1, colors=("teal", "amber", "sky", "red", "green"), n=34, spread=300.0, size=11, seed=1, gravity=0.5):
    """Confetti / particle burst from a point. Give it a long reveal, e.g. S.p(k, 1.1)."""
    if p <= 0.001 or p >= 1.0: return
    rnd = random.Random(seed); u = _c01(p); c = self.c
    for i in range(n):
        a = rnd.uniform(0, 2 * math.pi); v = rnd.uniform(.35, 1.0) * spread; col = colors[i % len(colors)]; rot = rnd.uniform(0, 6.28) + u * rnd.uniform(-8, 8)
        px = x + math.cos(a) * v * _expo(u); py = y + math.sin(a) * v * _expo(u) + gravity * spread * u * u; s = size * rnd.uniform(.6, 1.3) * (1 - 0.5 * u)
        c.save(); c.translate(px, py); c.rotate(math.degrees(rot))
        pt = self.paint(col, _c01(1 - u * u))
        if i % 3 == 0: c.drawCircle(0, 0, s * .6, pt)
        else: c.drawRoundRect(skia.Rect.MakeXYWH(-s, -s * .45, s * 2, s * .9), 2, 2, pt)
        c.restore()


@method
def sparkle(self, x, y, s=34, color="white", p=1):
    """A four-point twinkle."""
    if p <= 0.001: return
    k = s * (0.65 + 0.35 * math.sin(self.t * 4 + x * 0.01)) * min(_back(_c01(p), 1.5), 1.2); pa = skia.Path()
    for j in range(8):
        a = -math.pi / 2 + j * math.pi / 4; rr = k if j % 2 == 0 else k * 0.2
        (pa.moveTo if j == 0 else pa.lineTo)(x + rr * math.cos(a), y + rr * math.sin(a))
    pa.close(); self.c.drawPath(pa, self.paint(color, _c01(p * 2)))


@method
def spotlight(self, x, y, w, h, p=1, r=26, dim=0.6, color="teal"):
    """Dims everything drawn so far except the box x, y, w, h. Call it AFTER the background items and BEFORE the one in focus."""
    if p <= 0.001: return
    q = _out(_c01(p)); grow = 14 * (1 - q); rect = skia.Rect.MakeXYWH(x - grow, y - grow, w + 2 * grow, h + 2 * grow)
    pa = skia.Path(); pa.addRect(skia.Rect.MakeXYWH(-50, -50, E.W + 100, E.H + 100)); pa.addRRect(skia.RRect.MakeRectXY(rect, r, r))
    pa.setFillType(skia.PathFillType.kEvenOdd); self.c.drawPath(pa, skia.Paint(AntiAlias=True, Color=hexc("#000000", dim * q)))
    self.c.drawRoundRect(rect, r, r, self.paint(color, q, 3))


@contextlib.contextmanager
def _focus(self, cx, cy, k=1.0, dx=0.0, dy=0.0):
    c = self.c; c.save(); c.translate(cx + dx, cy + dy); c.scale(k, k); c.translate(-cx, -cy)
    try: yield
    finally: c.restore()
E.Ctx.focus = _focus
E.Ctx.focus.__doc__ = "with S.focus(cx, cy, k): ...  camera move: everything drawn inside is scaled by k about (cx, cy). Animate k with S.p()."


@method
def image_kb(self, path, x, y, w, h, p=1, r=20, zoom=0.10):
    """Photo with a slow Ken Burns zoom while the scene plays."""
    if p <= 0.001: return
    if path not in E.Ctx._imgs: E.Ctx._imgs[path] = skia.Image.open(path)
    im = E.Ctx._imgs[path]; iw, ih = im.width(), im.height(); k = max(w / iw, h / ih) * (1 + zoom * _c01(self.t / 12.0))
    dw, dh = iw * k, ih * k; y += (1 - _c01(p)) * 26; c = self.c
    c.save(); c.clipRRect(skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r), doAntiAlias=True)
    pt = skia.Paint(AntiAlias=True); pt.setAlphaf(_c01(p))
    c.drawImageRect(im, skia.Rect.MakeXYWH(x + (w - dw) / 2, y + (h - dh) / 2, dw, dh), skia.SamplingOptions(skia.FilterMode.kLinear), pt); c.restore()


# ================================================================== TRANSITIONS (themes call these from Theme.transition)
def _panel(c, x0, x1, skew, color, a=1.0):
    pa = skia.Path(); pa.moveTo(x0 + skew, -10); pa.lineTo(x1 + skew, -10); pa.lineTo(x1 - skew, E.H + 10); pa.lineTo(x0 - skew, E.H + 10); pa.close()
    c.drawPath(pa, skia.Paint(AntiAlias=True, Color=hexc(color, a)))


def tr_wipe(c, t, colors, dur=0.8, skew=170, lag=0.09):
    """Slanted colour panels sweep across and away (the last colour is the lead panel)."""
    W = E.W
    for i, col in enumerate(colors):
        u = _c01((t - i * lag) / dur); front = _io(_c01(u / 0.55)); back = _io(_c01((u - 0.35) / 0.65))
        if u <= 0 or back >= 1: continue
        lo = _lerp(-W * .3, W * 1.3, back); hi = _lerp(-W * .3, W * 1.3, front); _panel(c, lo, hi, skew, col)


def tr_iris(c, t, color, dur=0.8):
    """A coloured screen with a circular hole that opens from the centre."""
    u = _io(_c01(t / dur))
    if u >= 1: return
    R = math.hypot(E.W, E.H) / 2 * 1.05 * u; pa = skia.Path(); pa.addRect(skia.Rect.MakeXYWH(-20, -20, E.W + 40, E.H + 40)); pa.addCircle(E.W / 2, E.H / 2, max(1.0, R))
    pa.setFillType(skia.PathFillType.kEvenOdd); c.drawPath(pa, skia.Paint(AntiAlias=True, Color=hexc(color, 1 - u * 0.2)))
    c.drawCircle(E.W / 2, E.H / 2, max(1.0, R), skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .6 * (1 - u)), Style=skia.Paint.kStroke_Style, StrokeWidth=5))


def tr_shutters(c, t, color, bars=9, dur=0.7, stagger=0.045):
    """Horizontal blinds that shrink away one after another."""
    h = E.H / bars
    for i in range(bars):
        u = _out(_c01((t - i * stagger) / dur))
        if u < 1: c.drawRect(skia.Rect.MakeXYWH(-10, i * h, E.W + 20, h * (1 - u) + 1), skia.Paint(Color=hexc(color)))


def tr_glitch(c, t, colors, dur=0.5, seed=7):
    """Short digital glitch: coloured slices flicker and vanish."""
    if t > dur: return
    rnd = random.Random(seed + int(t * 24)); fade = 1 - t / dur
    for _ in range(int(14 * fade) + 2):
        y = rnd.uniform(0, E.H); hh = rnd.uniform(8, 70); x = rnd.uniform(-200, E.W * .5); ww = rnd.uniform(300, E.W)
        c.drawRect(skia.Rect.MakeXYWH(x, y, ww, hh), skia.Paint(Color=hexc(rnd.choice(colors), .55 * fade)))


def tr_burst(c, t, color, dur=0.7):
    """A ring expands from the centre with a soft flash."""
    u = _c01(t / dur)
    if u >= 1: return
    R = _out(u) * E.W * 0.75
    c.drawCircle(E.W / 2, E.H / 2, R, skia.Paint(AntiAlias=True, Color=hexc(color, .8 * (1 - u)), Style=skia.Paint.kStroke_Style, StrokeWidth=40 * (1 - u) + 3))
