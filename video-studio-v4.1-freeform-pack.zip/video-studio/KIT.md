# Motion Kit (v4): cheat sheet

New scene tools. They work exactly like the old ones: you pass a progress value from `S.p(beat, dur, delay)`, so the
narration decides WHEN something happens and the tool decides HOW. Colours are palette roles (`white`, `teal`, `amber`,
`sky`, `red`, `green`, `edge`, `mute`, `card`), so every look restyles them. Both Mac and PC.

## Text styles
| Tool | What it does |
|---|---|
| `S.kinetic(s, x, y, size, color, w, al, p, mode=, maxw=, grad=, shimmer=)` | words or letters arrive one after another. `mode`: rise (out of a mask), pop, drop, blur, zoom, chars |
| `S.grad_text(s, x, y, size, ("teal","amber"), w, al, p, shimmer=True)` | gradient fill with a moving glint |
| `S.outline_text(s, x, y, size, color, w, al, p)` | outlined lettering that fills once drawn (big section numbers) |
| `S.marker(x, y, w, h, color, p)` | highlighter swipe: draw it BEFORE the text it sits behind |
| `S.underline(x, y, w, color, p, sw, wave=0)` | underline that draws itself (wavy if `wave` > 0) |
| `S.morph_text("Draft", "Final", x, y, size, color, w, al, m, p)` | slot-machine morph. `m` = morph progress (0..1), `p` = appear |

In **aurora** and **editorial**, every `S.text(...)` of size 52 or more already uses kinetic reveal on its own. No change to your scenes.

## Morphs
| Tool | What it does |
|---|---|
| `S.morph_shape(["circle","square","star"], cx, cy, r, m, p, fill, stroke, sw, a, glow, spin)` | one solid shape flows through the list. `m` runs 0 to len-1 (e.g. `m = 2*min(S.p(k,3),1)`). Shapes: circle, squircle, blob, tri, diamond, square, pent, hex, star, star8, burst |
| `S.morph_rr(box_a, box_b, t, fill, stroke, sw, p)` | a card glides and reshapes from box a to box b. Boxes are `(x, y, w, h, radius)`. Returns the current box so you can place text in it |

## Icons that draw themselves
`S.icon(name, cx, cy, size, color, p, bg="circle"|"squircle")`. Names: check, clock, lock, shield, user, book, laptop, warning, globe,
gear, bulb, chart, doc, wifi, anchor, target, star, mail, search, play, ship, cap, compass, calendar, pencil, phone, camera, heart.

## Charts (all build and count up on their own)
| Tool | Notes |
|---|---|
| `S.bars([(label, value[, colour])], x, y, w, h, p, color, size, vmax, fmt)` | vertical bars; leave about 60 px below for labels |
| `S.hbars([(label, value)], x, y, w, p, color, size, vmax, row, label_w, unit)` | horizontal ranking |
| `S.ring(cx, cy, r, value, p, color, label=)` | progress ring, number counts up |
| `S.donut([(label, value, colour)], cx, cy, r, p, center=("100","cadets"))` | parts of a whole |
| `S.linechart(values, x, y, w, h, p, color, labels, size, vmin, vmax)` | draws left to right with area fill |
| `S.stepper(["Prepare","Take exam",...], x0, x1, y, p, color)` | process tracker |
| `S.stat(value, label, x, y, w, h, p, color, fmt, unit, icon, p_num)` | big-number card. `p_num` = a longer reveal for the count-up |

## Flow and emphasis
| Tool | What it does |
|---|---|
| `S.flow([(x0,y0),(x1,y1),...], p, color)` | a line or curve that draws itself, glowing tip, arrow head, then a travelling pulse |
| `S.spotlight(x, y, w, h, p, r, dim, color)` | dims everything drawn before it except the box. Put a caption card AFTER it (so it stays readable) |
| `S.ripple(x, y, r, color, p)` | expanding rings (ping, signal, "you are here") |
| `S.burst(x, y, p, colors, n, spread, size)` | confetti burst. Give it a long reveal, e.g. `S.p(k, 1.3)` |
| `S.sparkle(x, y, s, color, p)` | four-point twinkle |
| `with S.focus(cx, cy, k): ...` | camera push: everything inside is scaled by `k` about a point |
| `S.image_kb(path, x, y, w, h, p)` | photo with a slow Ken Burns zoom |

## Looks (themes)
Eight now. New: **aurora** (dark glass, drifting colour glow, gradient headings, light-sweep transitions) and **editorial**
(warm paper, ink outlines, hard shadows, colour blocks, marker highlights, snappy colour wipes).
Transition helpers for your own look: `K.tr_wipe`, `K.tr_iris`, `K.tr_shutters`, `K.tr_glitch`, `K.tr_burst` (in `scripts/motion_kit.py`).

## Rules that keep it looking good
- Spread tools over beats: about a third of the screen moving at once is plenty.
- Hero element on the first beat of its scene; supporting items on later beats.
- Body text stays 26 px or larger. Keep to about 7 items per scene.
- Use palette roles, never hard-coded colours, so all looks work.
- `--fx off` freezes time-based extras (shimmer, ripple, pulse), but everything driven by the beat still plays.

## Freeform (v4.1)
Need something no tool here does? See FREEFORM.md: `fx.*` effects, `S.text_anim`, `S.svg`, `set_look`, per-scene `bg` / `fg` / `trans` hooks, and raw Skia through `S.c`.
