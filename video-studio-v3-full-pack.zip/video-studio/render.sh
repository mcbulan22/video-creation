#!/bin/sh
# Picture only (no sound).   sh render.sh --draft      fast 720p preview
#                            sh render.sh              full 1080p
#                            sh render.sh --fx off     faster, no drifting light
cd "$(dirname "$0")"
[ -f inbox/scenes.py ] || { echo "No inbox/scenes.py found. Put the scenes file from Claude chat there."; exit 1; }
[ -d .venv ] || { echo "Run setup first:  sh setup_mac.sh"; exit 1; }
. .venv/bin/activate
python scripts/make_script.py inbox/scenes.py --out narration_script.txt >/dev/null
python scripts/contact_sheet.py inbox/scenes.py --out output/qa --beats 2>&1 | tail -3
python scripts/build_video.py inbox/scenes.py --out output --captions "$@"
echo ""; echo "Done. Open the 'output' folder -> full_video_silent.mp4"
open output 2>/dev/null
