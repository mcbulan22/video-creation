"""Class 2030 Applicant Cognitive Test Results - 3-minute summary video for the Vice President (v2 engine).
12 scenes. Beat text = exact narration. All figures come from the CCA report dated 7 October 2026.
Optional: put logo.png (transparent or white-on-dark works best) next to this file to show it on the title and closing scenes.
"""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
from engine import *
import skia

DECK_TITLE = "Class 2030 Applicant Cognitive Test Results  |  Center for Competency Assessment"
LOGO = os.path.join(HERE, "logo.png")


# ------------------------------------------------------------------ helpers
def chips_row(S, items, cy, size, color, pfun, gap=22, cx=960):
    f = font("m", size)
    ws = [f.measureText(t) + 68 for t in items]
    x = cx - (sum(ws) + gap * (len(items) - 1)) / 2
    for i, (t, w) in enumerate(zip(items, ws)):
        col = color[i] if isinstance(color, (list, tuple)) else color
        S.pill(t, x + w / 2, cy, size, col, None, pfun(i), w="m")
        x += w + gap

def hbar(S, x, y, w, h, color, p, r=12):
    if p > 0.02:
        S.rr(x, y, max(w * p, 6), h, r, color, None, 3, 1, dy=0)

def card(S, x, y, w, h, p, stroke="edge", sw=3, dashed=False, fill="card"):
    S.rr(x, y, w, h, 26, fill, stroke, sw, p, dash=[14, 12] if dashed else None)

def words_in(S, text, cy, size, color, weight, k, d0=0.0, step=0.12):
    """Kinetic title: each word pops in one after another, centered on x=960."""
    f = font(weight, size); sp = f.measureText(" ")
    words = text.split(); ws = [f.measureText(w) for w in words]
    x = 960 - (sum(ws) + sp * (len(words) - 1)) / 2
    for i, (w, wd) in enumerate(zip(words, ws)):
        S.text(w, x, cy, size, color, weight, "l", S.p(k, .7, d0 + i * step), dy=44)
        x += wd + sp


# ------------------------------------------------------------------ 1. title
@scene("CLASS 2030", [
    "Class 2030 applicant results: how the cognitive test performed, how well it ranks applicants, and how testing centers differ."], sky=True)
def s_title(S):
    # Horizon scene: sunrise sky above, sea below. When it ends the camera dives into the water (engine does that).
    p0 = S.p(0, 1.0)
    if os.path.exists(LOGO):
        S.image(LOGO, 1500, 110, 260, 260, p0, 24, "contain")
    S.ship(1390, HY - 34, .85, "dark", p0)
    words_in(S, "Class 2030 Applicant", 215, 88, "white", "b", 0, .3)
    words_in(S, "Cognitive Test Results", 322, 88, "teal", "b", 0, .8)
    S.line(760, 362, 1160, 362, "amber", 6, S.p(0, .8, 1.5))
    S.text("Summary for the Vice President", 960, 430, 42, "white", "m", "c", S.p(0, .8, 1.8))
    S.text("Center for Competency Assessment  ·  7 October 2026", 960, 800, 32, "white", "r", "c", S.p(0, .8, 2.1))
    chips_row(S, ["How they did", "How well it ranks", "How centers differ"], 890, 30,
              ["sky", "amber", "teal"], lambda i: S.p(0, .5, 3.0 + i * .5))


# ------------------------------------------------------------------ 2. the data
@scene("THE DATA", [
    "9,259 applicants took the test, across 48 testing centers.",
    "528 of them have no center on record, so they are scored but left out of the center comparisons."])
def s_data(S):
    title(S, "Who is in the analysis", 190, p=S.p(0))
    for x, v, lab, col, d in [(300, 9259, "applicants", "teal", 0.2), (1100, 48, "testing centers", "sky", 0.9)]:
        p = S.p(0, 1.6, d)
        S.glow(x + 260, 410, 330, col, .16, p)
        S.num(v, x + 260, 450, 150, col, "b", "c", p)
        S.text(lab, x + 260, 515, 40, "white", "m", "c", S.p(0, .6, d + .8))
    S.text("7 subtests:", 960, 612, 28, "mute", "m", "c", S.p(0, .5, 2.0))
    r1 = ["Arithmetic Reasoning", "Math Problems", "Reasoning", "Spatial Reasoning"]
    r2 = ["Mechanical IQ", "Science", "English"]
    chips_row(S, r1, 675, 28, "sky", lambda i: S.p(0, .5, 2.2 + i * .25))
    chips_row(S, r2, 750, 28, "sky", lambda i: S.p(0, .5, 3.2 + i * .25))
    pg = S.p(1, .6)
    card(S, 360, 810, 1200, 110, pg, "amber", 3)
    S.num(528, 520, 888, 72, "amber", "b", "c", S.p(1, 1.1, .1))
    S.text("no center or date: scored, but not compared", 700, 877, 32, "white", "r", "l", pg, maxw=830)


# ------------------------------------------------------------------ 3. overall results
def _g(u, k=2.75, th=0.08):
    umax = k * th
    peak = umax ** k * math.exp(-umax / th)
    return (u ** k) * math.exp(-u / th) / peak

@scene("OVERALL RESULTS", [
    "The average Total Score is 57 and the median is 54. A smaller group scored far above the rest.",
    "The top 25 percent scored 69 or higher, the top 10 percent 85, and the top 5 percent 99."])
def s_overall(S):
    title(S, "How applicants performed overall", 190, p=S.p(0))
    for i, (v, fmt, lab, col) in enumerate([(57.0, "{:.1f}", "Average Total Score", "teal"), (54, "{:.0f}", "Median Total Score", "sky"),
                                            (23.4, "{:.1f}", "Spread (standard deviation)", "amber")]):
        x = 120 + i * 580; p = S.p(0, .5, .15 + i * .2); pn = S.p(0, 1.3, .3 + i * .2)
        card(S, x, 250, 520, 175, p)
        S.num(v, x + 260, 352, 84, col, "b", "c", pn, fmt)
        S.text(lab, x + 260, 400, 28, "mute", "r", "c", p)
    X0, X1, BASE, HGT, SMAX = 300, 1620, 800, 330, 190.0
    xs = lambda sc: X0 + sc * (X1 - X0) / SMAX
    yc = lambda sc: BASE - _g(sc / SMAX) * HGT
    pp = S.p(0, 1.8, 1.0)
    if pp > 0.01:
        pts = [(X0 + (X1 - X0) * i / 200, BASE - _g(i / 200) * HGT) for i in range(201)]
        fill = skia.Path(); fill.moveTo(X0, BASE)
        for x, y in pts: fill.lineTo(x, y)
        fill.lineTo(X1, BASE); fill.close()
        edge = skia.Path(); edge.moveTo(*pts[0])
        for x, y in pts[1:]: edge.lineTo(x, y)
        S.c.save(); S.c.clipRect(skia.Rect.MakeLTRB(0, 0, X0 + (X1 - X0) * min(pp, 1) + 1, H))
        S.c.drawPath(fill, S.paint("sky", .22)); S.c.drawPath(edge, S.paint("sky", 1, 5))
        S.c.restore()
        S.line(X0, BASE, X1, BASE, "edge", 3, S.p(0, .5, 1.0))
    S.text("Total Score", X1, BASE + 100, 28, "mute", "r", "r", S.p(0, .6, 1.8))
    pm = S.p(0, .5, 2.6)
    S.line(xs(54), BASE, xs(54), yc(54) - 8, "white", 4, pm, dash=[10, 8])
    S.line(xs(57), BASE, xs(57), yc(57) - 8, "teal", 4, pm, dash=[10, 8])
    S.text("median 54", xs(54) - 8, BASE + 44, 28, "white", "m", "r", pm)
    S.text("average 57", xs(57) + 8, BASE + 44, 28, "teal", "m", "l", pm)
    fade = S.p(0, .8, 4.0) * (1 - S.p(1, .3))
    S.text("A smaller group scored far above the rest", 1330, 640, 32, "amber", "m", "c", fade, maxw=480)
    S.arrow(1250, 725, 1170, 778, "amber", 5, fade)
    S.text("Illustrative shape, not to scale", 120, BASE + 100, 26, "mute", "r", "l", S.p(0, .6, 1.8))
    cuts = [("Top 25%: 69 or higher", 69, "sky", 560), ("Top 10%: 85 or higher", 85, "amber", 650), ("Top 5%: 99 or higher", 99, "teal", 740)]
    for i, (lab, sc, col, py) in enumerate(cuts):
        pc = S.p(1, .5, i * .7)
        S.line(xs(sc), BASE, xs(sc), yc(sc), col, 5, pc)
        S.pill(lab, 1560, py, 30, col, "card", pc)
        lw = font("m", 30).measureText(lab) + 68
        S.line(1560 - lw / 2, py, xs(sc) + 6, yc(sc), col, 3, pc, dash=[8, 8])


# ------------------------------------------------------------------ 4. hardest subtests
@scene("SUBTESTS", [
    "Math Problems and Mechanical IQ were the hardest. In Math, 35 percent scored two or lower and 13 percent scored zero.",
    "When many applicants sit near zero, a subtest has less room to tell them apart, and that deserves a second look."])
def s_hard(S):
    title(S, "Two subtests were very hard", 190, sub="Average score by subtest", p=S.p(0))
    rows = [("Arithmetic Reasoning", 6.9), ("Math Problems", 4.8), ("Reasoning", 10.3), ("Spatial Reasoning", 9.5),
            ("Mechanical IQ", 5.3), ("Science", 9.8), ("English", 10.3)]
    for i, (n, v) in enumerate(rows):
        y = 305 + i * 76; hard = n in ("Math Problems", "Mechanical IQ")
        pr = S.p(0, .9, .3 + i * .15)
        S.text(n, 520, y + 34, 30, "white" if hard else "mute", "m" if hard else "r", "r", pr)
        w = v * 60
        hbar(S, 560, y, w, 44, "amber" if hard else "sky", pr)
        S.num(v, 560 + w + 16, y + 34, 30, "white", "m", "l", S.p(0, 1.0, .3 + i * .15), "{:.1f}")
        if hard:
            S.pill("HARDEST", 560 + w + 16 + 70 + 100, y + 22, 26, "amber", None, S.p(0, .5, 1.8))
    c1 = S.p(0, .6, 3.2)
    card(S, 1330, 340, 470, 150, c1, "amber", 3)
    S.num(35, 1365, 405, 34, "white", "b", "l", S.p(0, 1.0, 3.3), "{:.0f}% scored 2 or lower")
    S.num(13, 1365, 458, 34, "amber", "b", "l", S.p(0, 1.0, 3.6), "{:.0f}% scored zero")
    c2 = S.p(0, .6, 5.2)
    card(S, 1330, 598, 470, 100, c2, "amber", 3)
    S.text("27% scored 2 or lower", 1365, 662, 34, "white", "b", "l", c2)
    S.pill("Near-zero scores leave less room to separate applicants", 960, 880, 30, "amber", None, S.p(1))


# ------------------------------------------------------------------ 5. ranking ability
@scene("RANKING", [
    "Reliability is 0.80, which is acceptable for ranking.",
    "But a score can move about 10 points on another day, so applicants near a cut score are practically tied."])
def s_rank(S):
    title(S, "How well can the test rank applicants?", 190, p=S.p(0))
    pa = S.p(0, .6, .2); pb = S.p(0, .6, 1.2)
    card(S, 120, 245, 860, 230, pa)
    S.glow(330, 365, 260, "teal", .18, pa)
    S.num(0.80, 330, 400, 112, "teal", "b", "c", S.p(0, 1.4, .3), "{:.2f}")
    S.text("Reliability (alpha)", 560, 360, 34, "white", "m", "l", pa)
    S.check(570, 410, 26, "green", pa); S.text("Acceptable for ranking", 610, 420, 30, "green", "m", "l", pa)
    card(S, 1020, 245, 780, 230, pb)
    S.text("One general ability", 1410, 345, 48, "white", "b", "c", pb)
    S.text("The Total Score is a sound basis for ranking", 1410, 405, 30, "mute", "r", "c", pb, maxw=700)
    cx = 960; ppx = 20
    p1 = S.p(1, .7)
    S.rr(cx - 20 * ppx, 635, 40 * ppx, 100, 18, None, "sky", 3, S.p(1, .6, 1.2), dy=0, dash=[12, 10])
    S.rr(cx - 10 * ppx, 645, 20 * ppx, 80, 14, "amber", "amber", 3, p1, dy=0, fa=.28)
    S.line(cx, 598, cx, 770, "white", 5, p1)
    S.text("Cut score", cx, 588, 30, "white", "b", "c", p1)
    for pts, off in [("-20", -20), ("-10", -10), ("+10", 10), ("+20", 20)]:
        S.text(pts, cx + off * ppx, 808, 28, "amber" if abs(off) == 10 else "sky", "m", "c", S.p(1, .5, .5 if abs(off) == 10 else 1.4))
    S.text("Points above or below the cut score (typical error: 10; wide 95% range: 20)", cx, 852, 26, "mute", "r", "c", S.p(1, .6, 1.6))
    p2 = S.p(1, .5, 3.0)
    S.circ(cx - 30, 685, 15, "white", None, 0, p2); S.circ(cx + 26, 685, 15, "teal", None, 0, p2)
    S.pill("Applicants a few points apart are practically tied", cx, 905, 30, "amber", None, S.p(1, .5, 3.6))


# ------------------------------------------------------------------ 6. centers
@scene("TESTING CENTERS", [
    "Where applicants tested matters. The testing center explains about 15 percent of score variation, island group less than 4 percent.",
    "General Santos City averages 80.7 and Cebu City 77.0, while Panglima Sugala in Tawi-Tawi averages 28.4. These describe applicants, not school quality."])
def s_centers(S):
    title(S, "Where applicants tested matters", 190, p=S.p(0))
    pa = S.p(0, .6, .3); pb = S.p(0, .6, 1.5)
    card(S, 120, 250, 810, 210, pa, "teal", 4)
    S.glow(310, 370, 230, "teal", .16, pa)
    S.num(15, 310, 400, 112, "teal", "b", "c", S.p(0, 1.4, .5), "{:.0f}%")
    S.text("of the variation in Total Score is explained by the testing center", 500, 345, 30, "white", "r", "l", pa, maxw=400)
    card(S, 990, 250, 810, 210, pb, "edge", 3)
    S.text("<4%", 1180, 400, 112, "mute", "b", "c", pb)
    S.text("explained by island group alone", 1370, 365, 30, "white", "r", "l", pb, maxw=400)
    # dot plot of centers (scores 20 to 90)
    AX0, AX1, AY = 300, 1620, 730
    sx = lambda v: AX0 + (v - 20) * (AX1 - AX0) / 70.0
    p1 = S.p(1, .6)
    S.line(AX0, AY, AX1, AY, "edge", 4, p1)
    for v in range(20, 100, 10):
        S.line(sx(v), AY - 8, sx(v), AY + 8, "edge", 3, p1)
        S.text(str(v), sx(v), AY + 48, 26, "mute", "r", "c", p1)
    S.line(sx(57), AY - 90, sx(57), AY + 12, "white", 4, S.p(1, .5, .3), dash=[8, 8])
    S.text("National average 57.0", sx(57), AY - 104, 28, "white", "m", "c", S.p(1, .5, .3))
    pts = [("Panglima Sugala", 28.4, "amber", -1, 0.9), ("Masbate City", 41.0, "amber", 1, 1.3),
           ("Cebu City", 77.0, "teal", 1, 1.7), ("General Santos City", 80.7, "teal", -1, 2.1)]
    for n, v, col, side, d in pts:
        pd = S.p(1, .6, d)
        S.circ(sx(v), AY, 17, col, "white", 3, pd)
        ty = AY - 70 if side < 0 else AY + 100
        S.text(n, sx(v), ty, 28, "white", "m", "c", pd)
        S.text(f"{v:.1f}", sx(v), ty + 34, 30, col, "b", "c", pd)
    S.text("These describe applicants who took the test at each center, not school or regional quality.", 960, 935, 26, "mute", "r", "c", S.p(1, .6, 3.0))


# ------------------------------------------------------------------ 7. cut scores by island group
@scene("SELECTION", [
    "Raise the cut score and Mindanao's share of qualifiers climbs from 18 percent to 51 percent."])
def s_cuts(S):
    title(S, "Who qualifies at different cut scores", 190, sub="Share of qualifiers by island group", p=S.p(0))
    chips_row(S, ["Luzon", "Visayas", "Mindanao", "No center on record"], 315, 26,
              ["sky", "amber", "teal", "mute"], lambda i: S.p(0, .5, .3 + i * .25))
    data = [("50th percentile", 54, 4777, [60.4, 16.2, 17.9, 5.6]), ("70th percentile", 66, 2808, [55.1, 17.0, 22.8, 5.1]),
            ("80th percentile", 73, 1895, [49.5, 17.6, 28.4, 4.5]), ("90th percentile", 85, 953, [36.5, 20.4, 40.0, 3.1]),
            ("95th percentile", 99, 475, [30.9, 16.4, 51.4, 1.3])]
    cols = ["sky", "amber", "teal", "mute"]
    BX, BW = 520, 1040
    S.text("Qualifiers", 1620, 385, 26, "mute", "r", "l", S.p(0, .5, 1.0))
    for i, (lab, cs, n, shares) in enumerate(data):
        y = 410 + i * 88; pr = S.p(0, .6, .6 + i * .2)
        S.text(lab, 120, y + 24, 30, "white", "m", "l", pr)
        S.text(f"cut score {cs}", 120, y + 54, 26, "mute", "r", "l", pr)
        pg = S.p(0, 1.0, 1.6 + i * .35)
        if pg > 0.01:
            x = BX
            S.c.save(); S.c.clipRect(skia.Rect.MakeLTRB(0, 0, BX + BW * min(pg, 1) + 1, H))
            for v, col in zip(shares, cols):
                w = BW * v / 100
                S.c.drawRect(skia.Rect.MakeXYWH(x + 1, y, w - 2, 56), S.paint(col))
                if w > 100: S.text(f"{v:.0f}%", x + w / 2, y + 38, 28, "dark", "b", "c", 1)
                x += w
            S.c.restore()
        S.num(n, 1620, y + 40, 34, "white", "b", "l", S.p(0, 1.0, 1.6 + i * .35))
    S.pill("Mindanao share of qualifiers: 18% at the 50th percentile, 51% at the 95th", 960, 900, 30, "teal", None, S.p(0, .5, 4.2))


# ------------------------------------------------------------------ 8. top 1,000 concentration
@scene("SELECTION", [
    "Mindanao is 14 percent of applicants but 39 percent of the top 1,000, driven mostly by General Santos City, Koronadal City and Mariveles."])
def s_top1000(S):
    title(S, "Who is in the top 1,000?", 190, p=S.p(0))
    for i, (name, a, b, col) in enumerate([("MINDANAO", 14, 39, "teal"), ("LUZON", 63, 38, "sky")]):
        x = 120 + i * 870; p = S.p(0, .6, i * .5)
        card(S, x, 250, 810, 270, p, col, 4)
        S.glow(x + 610, 420, 220, col, .14, S.p(0, .8, i * .5 + 1.0))
        S.text(name, x + 405, 315, 38, col, "b", "c", p)
        S.num(a, x + 210, 440, 100, "mute", "b", "c", S.p(0, 1.2, i * .5 + .3), "{:.0f}%")
        S.text("of all applicants", x + 210, 485, 28, "mute", "r", "c", p)
        S.arrow(x + 360, 410, x + 450, 410, col, 6, S.p(0, .5, i * .5 + 1.2))
        S.num(b, x + 610, 440, 100, col, "b", "c", S.p(0, 1.2, i * .5 + 1.4), "{:.0f}%")
        S.text("of the top 1,000", x + 610, 485, 28, "white", "r", "c", S.p(0, .6, i * .5 + 1.4))
    S.text("Top-1,000 qualifiers by center", 120, 590, 32, "mute", "m", "l", S.p(0, .5, 3.4))
    rows = [("General Santos City", 217, "of 477 applicants"), ("Koronadal City", 144, ""), ("Mariveles", 136, "")]
    for i, (n, v, lab) in enumerate(rows):
        y = 625 + i * 85; pr = S.p(0, .9, 3.8 + i * .5)
        S.text(n, 520, y + 34, 30, "white", "m", "r", pr)
        hbar(S, 560, y, v * 3.2, 44, "teal", pr)
        S.num(v, 560 + v * 3.2 + 16, y + 34, 30, "white", "b", "l", S.p(0, 1.0, 3.8 + i * .5))
        if lab: S.text(lab, 560 + v * 3.2 + 100, y + 34, 28, "mute", "r", "l", pr)


# ------------------------------------------------------------------ 9. scoring rules and stability
@scene("SELECTION", [
    "A cut at the 70th percentile, 66 points, qualifies 2,808 applicants. Extra minimum-score rules only filter that list; they add no one.",
    "The ranking is stable: leaving out any single subtest keeps 87 to 93 percent of the top 1,000, and equal weighting keeps 98 percent."])
def s_rules(S):
    title(S, "How the scoring rule shapes the list", 190, p=S.p(0))
    p0 = S.p(0, .6, .2)
    card(S, 120, 250, 600, 330, p0, "teal", 4)
    S.glow(420, 400, 280, "teal", .15, p0)
    S.num(2808, 420, 405, 112, "teal", "b", "c", S.p(0, 1.5, .3))
    S.text("applicants qualify", 420, 460, 34, "white", "m", "c", p0)
    S.text("at the 70th percentile cut (66 points)", 420, 510, 28, "mute", "r", "c", p0, maxw=520)
    for i, (txt, v) in enumerate([("Minimum 25th percentile in both Arithmetic Reasoning and Math Problems", 269),
                                  ("Every subtest at least at the 10th percentile", 251)]):
        y = 250 + i * 190; p = S.p(0, .6, 2.6 + i * 1.0)
        card(S, 780, y, 1020, 160, p)
        S.text(txt, 815, y + 70, 30, "white", "r", "l", p, maxw=620)
        S.cross(1490, y + 80, 28, "red", p)
        S.num(v, 1530, y + 92, 36, "red", "b", "l", S.p(0, 1.0, 2.8 + i * 1.0), "{:.0f} removed")
    S.text("These rules only filter the list. They do not add anyone.", 780, 650, 28, "mute", "r", "l", S.p(0, .6, 5.0))
    S.text("The ranking is fairly stable", 120, 690, 38, "teal", "b", "l", S.p(1, .5))
    for i, (v, fmt, cap) in enumerate([(None, "87-93%", "of the top 1,000 stay the same if any single subtest is left out"),
                                       (98, "{:.0f}%", "stay the same if all subtests are weighted equally")]):
        x = 120 + i * 870; p = S.p(1, .6, .3 + i * .8)
        card(S, x, 715, 810, 180, p, "green", 3)
        S.check(x + 50, 805, 30, "green", p)
        if v is None: S.text(fmt, x + 262, 822, 76, "green", "b", "c", p)
        else: S.num(v, x + 262, 822, 76, "green", "b", "c", S.p(1, 1.1, .3 + i * .8), fmt)
        S.text(cap, x + 430, 788, 28, "white", "r", "l", p, maxw=350)


# ------------------------------------------------------------------ 10. dates and data quality
@scene("DATA CHECK", [
    "Please confirm the four exam dates I read from the applicant ID codes. 46 of 48 centers tested on a single date, so dates and centers cannot be separated.",
    "236 applicants, 2.5 percent, scored below 20, with the largest shares at Panglima Sugala and Masbate City. Please check conditions there. The records are otherwise clean."])
def s_quality(S):
    title(S, "Test dates and data quality", 190, p=S.p(0))
    S.line(330, 335, 1650, 335, "edge", 4, S.p(0, 1.2, .2))
    for i, (d, n) in enumerate([("29 Oct 2025", 1039), ("5 Nov 2025", 689), ("5 Jan 2026", 6194), ("7 Jan 2026", 809)]):
        x = 330 + i * 440; p = S.p(0, .5, .6 + i * .45)
        S.circ(x, 335, 14, "sky", None, 0, p)
        S.text(d, x, 295, 32, "sky", "b", "c", p)
        S.num(n, x, 425, 46, "white", "b", "c", S.p(0, 1.0, .7 + i * .45))
        S.text("applicants", x, 462, 26, "mute", "r", "c", p)
    S.pill("Average scores across dates: 54.6 to 57.5", 960, 535, 30, "teal", None, S.p(0, .5, 2.8))
    S.text("Please confirm these are the actual exam dates", 960, 600, 30, "amber", "m", "c", S.p(0, .5, 3.3))
    pa = S.p(0, .6, 5.0)
    card(S, 120, 645, 520, 225, pa, "sky", 3)
    S.text("46 of 48", 380, 725, 70, "sky", "b", "c", pa)
    S.text("centers tested on one date only, so date and center effects cannot be separated", 380, 768, 27, "white", "r", "c", pa, maxw=470, lh=1.2)
    pb = S.p(1, .6, .3); pc = S.p(1, .6, 1.6)
    card(S, 700, 645, 520, 225, pb, "amber", 3)
    S.num(236, 960, 725, 70, "amber", "b", "c", S.p(1, 1.1, .4))
    S.text("applicants (2.5%) scored below 20 in total; 2 scored zero", 960, 768, 27, "white", "r", "c", pb, maxw=470, lh=1.2)
    card(S, 1280, 645, 520, 225, pc, "amber", 3)
    S.num(32, 1540, 725, 70, "amber", "b", "c", S.p(1, 1.1, 1.7), "{:.0f}%")
    S.text("of Panglima Sugala applicants scored below 20", 1540, 768, 27, "white", "r", "c", pc, maxw=470, lh=1.2)
    S.text("Masbate City: 11%", 1540, 842, 27, "mute", "r", "c", pc)
    for i, (t, x) in enumerate([("No duplicate reference numbers", 300), ("Subtest scores add up to the Total Score", 1000)]):
        pi = S.p(1, .5, 4.5 + i * .5)
        S.check(x, 915, 28, "green", pi); S.text(t, x + 40, 925, 30, "white", "m", "l", pi)


# ------------------------------------------------------------------ 11. recommendations
@scene("FOR YOUR CONSIDERATION", [
    "Five points for your consideration. One: treat applicants within about 10 points of a cut score as close calls.",
    "Two: decide whether minimum subtest scores are needed.",
    "Three: look at the geographic effect before fixing a single national cut score.",
    "Four: review Math Problems, Mechanical IQ and the role of Spatial Reasoning for the next cycle.",
    "Five: check the records and testing conditions, including the 528 applicants with no center."])
def s_recs(S):
    title(S, "Points for your consideration", 190, p=S.p(0))
    items = [("Treat close scores as close calls", "Within about 10 points of a cut score: consider an interview or second review.", "amber"),
             ("Decide on minimum subtest scores", "Protects against very uneven profiles, if the program needs a baseline.", "sky"),
             ("Look at the geographic effect first", "One national cut score draws more qualifiers from higher-scoring centers.", "teal"),
             ("Review the test for the next cycle", "Math Problems, Mechanical IQ, and the role of Spatial Reasoning.", "amber"),
             ("Check the records and conditions", "528 applicants with no center or date, the exam dates, and low-average centers.", "sky")]
    for i, (h, sub, col) in enumerate(items):
        y = 250 + i * 128; p = S.p(i, .7)
        card(S, 120, y, 1680, 108, p, col, 3)
        S.circ(190, y + 54, 34, col, None, 0, p)
        S.text(str(i + 1), 190, y + 68, 40, "dark", "b", "c", p)
        S.text(h, 260, y + 48, 38, "white", "b", "l", p)
        S.text(sub, 260, y + 90, 28, "mute", "r", "l", p, maxw=1480)


# ------------------------------------------------------------------ 12. close
@scene("THANK YOU", [
    "Thank you. I am happy to expand on any part of this report, or walk you through the results."])
def s_close(S):
    p0 = S.p(0, .9)
    S.glow(960, 330, 520, "teal", .2, p0)
    if os.path.exists(LOGO):
        S.image(LOGO, 810, 110, 300, 300, p0, 24, "contain")
    else:
        S.ship(960, 270, 1.1, "teal", p0)
        S.waves(560, 1360, 358, 10, "sky", .5 * p0, 3, 24)
    words_in(S, "Thank you", 600, 100, "white", "b", 0, .3, .2)
    S.text("Marlon Bulan", 960, 700, 52, "teal", "b", "c", S.p(0, .8, 1.0))
    S.text("Acting Director, Center for Competency Assessment", 960, 765, 34, "white", "r", "c", S.p(0, .8, 1.3))
    S.text("Maritime Academy of Asia and the Pacific", 960, 815, 34, "mute", "r", "c", S.p(0, .8, 1.6))
