"""scene-video-studio engine: Skia drawing primitives + scene registry + timeline.
Scenes are plain Python functions registered with @scene(...). All drawing coordinates are for a
1920x1080 (16:9) canvas. Every primitive takes a progress value p (0..1) that fades/slides it in.
"""
import skia, math, sys, random
W, H = 1920, 1080
import os
FD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts", "Poppins-")  # bundled font, works on Mac/Linux/Windows
_tf = {k: skia.Typeface.MakeFromFile(FD + v + ".ttf") for k, v in
       {"l": "Light", "r": "Regular", "m": "Medium", "b": "Bold"}.items()}
_fc = {}
def font(w, size):
    k = (w, size)
    if k not in _fc:
        f = skia.Font(_tf[w], size); f.setSubpixel(True); _fc[k] = f
    return _fc[k]

def hexc(h, a=1.0):
    h = h.lstrip('#'); r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return skia.ColorSetARGB(int(max(0, min(1, a)) * 255), r, g, b)

C = dict(bg1="#0A1A2F", bg2="#103250", card="#14304D", edge="#2B5A87", white="#F4F7FA", mute="#8FA6BF",
         teal="#2EC4B6", amber="#FFB703", red="#EF476F", green="#06D6A0", sky="#4CC9F0", dark="#08121F")

def ease(x):
    x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3

def ease_back(x, s=1.3):
    """Ease-out with a small overshoot (springy pop). Can return slightly more than 1."""
    x = max(0.0, min(1.0, x)); u = x - 1
    return 1 + (s + 1) * u ** 3 + s * u ** 2

_warned = set()
def _check_glyphs(s, w):
    for ch in s:
        if ch.isspace() or ch in _warned: continue
        if _tf[w].unicharToGlyph(ord(ch)) == 0:
            _warned.add(ch)
            print(f"WARNING: font has no glyph for {ch!r} (U+{ord(ch):04X}) in text {s[:40]!r}. "
                  "Draw it with arrow()/check()/cross() or use another character.", file=sys.stderr)

class Ctx:
    def __init__(self, canvas, t, bs):
        self.c = canvas; self.t = t; self.bs = bs

    def p(self, k, dur=0.55, delay=0.0):
        if k >= len(self.bs): return 0.0
        return ease_back((self.t - self.bs[k] - delay) / dur)

    def paint(self, color, a=1.0, stroke=0, dash=None):
        pt = skia.Paint(AntiAlias=True, Color=hexc(C.get(color, color), a))
        if stroke:
            pt.setStyle(skia.Paint.kStroke_Style); pt.setStrokeWidth(stroke)
            pt.setStrokeCap(skia.Paint.kRound_Cap); pt.setStrokeJoin(skia.Paint.kRound_Join)
        if dash: pt.setPathEffect(skia.DashPathEffect.Make(dash, 0))
        return pt

    def rr(self, x, y, w, h, r=24, fill=None, stroke=None, sw=3, p=1, dy=26, dash=None, fa=1.0):
        if p <= 0.001: return
        y += (1 - p) * dy
        rect = skia.Rect.MakeXYWH(x, y, w, h)
        k = 0.965 + 0.035 * min(p, 1.2)          # gentle grow-in
        self.c.save(); self.c.translate(x + w / 2, y + h / 2); self.c.scale(k, k); self.c.translate(-(x + w / 2), -(y + h / 2))
        if fill: self.c.drawRoundRect(rect, r, r, self.paint(fill, p * fa))
        if stroke: self.c.drawRoundRect(rect, r, r, self.paint(stroke, p, sw, dash))
        self.c.restore()

    def glow(self, x, y, r, color="teal", a=0.25, p=1):
        """Soft radial light behind a number or card."""
        if p <= 0.001: return
        col = C.get(color, color); pt = skia.Paint()
        pt.setShader(skia.GradientShader.MakeRadial(skia.Point(x, y), r, [hexc(col, a * min(p, 1)), hexc(col, 0)], [0, 1]))
        self.c.drawCircle(x, y, r, pt)

    def num(self, v, x, y, size=40, color="white", w="b", al="l", p=1, fmt="{:,.0f}", dy=22):
        """Count-up number: shows v * progress, formatted with fmt. Give it a long reveal, e.g. S.p(k, 1.4)."""
        q = max(0.0, min(1.0, p))
        return self.text(fmt.format(v * q), x, y, size, color, w, al, min(1.0, p * 2.5), dy=dy)

    def circ(self, x, y, r, fill=None, stroke=None, sw=3, p=1):
        if p <= 0.001: return
        if fill: self.c.drawCircle(x, y, r * (0.6 + 0.4 * p), self.paint(fill, p))
        if stroke: self.c.drawCircle(x, y, r * (0.6 + 0.4 * p), self.paint(stroke, p, sw))

    def line(self, x0, y0, x1, y1, color="mute", sw=4, p=1, dash=None):
        if p <= 0.001: return
        p = min(p, 1.0)
        self.c.drawLine(x0, y0, x0 + (x1 - x0) * p, y0 + (y1 - y0) * p, self.paint(color, 1, sw, dash))

    def arrow(self, x0, y0, x1, y1, color="mute", sw=5, p=1, head=18):
        if p <= 0.001: return
        p = min(p, 1.0)
        self.line(x0, y0, x1, y1, color, sw, p)
        if p > 0.9:
            a = math.atan2(y1 - y0, x1 - x0); path = skia.Path()
            path.moveTo(x1, y1)
            path.lineTo(x1 - head * math.cos(a - 0.45), y1 - head * math.sin(a - 0.45))
            path.lineTo(x1 - head * math.cos(a + 0.45), y1 - head * math.sin(a + 0.45)); path.close()
            self.c.drawPath(path, self.paint(color))

    def wrap(self, s, f, maxw):
        out, cur = [], ""
        for wd in s.split():
            t2 = (cur + " " + wd).strip()
            if f.measureText(t2) <= maxw or not cur: cur = t2
            else: out.append(cur); cur = wd
        if cur: out.append(cur)
        return out

    def text(self, s, x, y, size=40, color="white", w="r", al="l", p=1, dy=22, maxw=None, lh=1.28, strike=0.0):
        """y = baseline of first line. returns total height."""
        f = font(w, size)
        _check_glyphs(s, w)
        lines = self.wrap(s, f, maxw) if maxw else [s]
        if p > 0.001:
            for i, ln in enumerate(lines):
                tw = f.measureText(ln)
                xx = x if al == "l" else (x - tw / 2 if al == "c" else x - tw)
                yy = y + i * size * lh + (1 - p) * dy
                self.c.drawString(ln, xx, yy, f, self.paint(color, p))
                if strike > 0:
                    sy = yy - size * 0.32
                    self.c.drawLine(xx - 10, sy, xx - 10 + (tw + 20) * strike, sy, self.paint("red", 1, max(5, size // 12)))
        return len(lines) * size * lh

    def check(self, x, y, s=22, color="green", p=1):
        if p <= .001: return
        pa = skia.Path(); pa.moveTo(x - s * .55, y); pa.lineTo(x - s * .1, y + s * .45); pa.lineTo(x + s * .6, y - s * .45)
        self.c.drawPath(pa, self.paint(color, p, max(5, s // 4)))

    def cross(self, x, y, s=20, color="red", p=1):
        if p <= .001: return
        pt = self.paint(color, p, max(5, s // 4))
        self.c.drawLine(x - s * .5, y - s * .5, x + s * .5, y + s * .5, pt)
        self.c.drawLine(x + s * .5, y - s * .5, x - s * .5, y + s * .5, pt)

    def ship(self, cx, cy, sc=1.0, color="teal", p=1):
        if p <= .001: return
        c = self.c; c.save(); c.translate(cx, cy + (1 - p) * 30); c.scale(sc, sc)
        pt = self.paint(color, p)
        hull = skia.Path(); hull.moveTo(-170, 0); hull.lineTo(170, 0); hull.lineTo(130, 55); hull.lineTo(-135, 55); hull.close()
        c.drawPath(hull, pt)
        c.drawRoundRect(skia.Rect.MakeXYWH(-120, -50, 190, 50), 6, 6, pt)
        c.drawRoundRect(skia.Rect.MakeXYWH(70, -90, 60, 90), 6, 6, pt)
        c.drawRoundRect(skia.Rect.MakeXYWH(-30, -95, 36, 45), 5, 5, self.paint("amber", p))
        for i in range(6):
            c.drawRect(skia.Rect.MakeXYWH(-105 + i * 26, -35, 14, 14), self.paint("bg1", p))
        c.restore()

    def waves(self, x0, x1, y, amp=12, color="sky", a=0.5, n=3, gap=26, ph=0.0):
        for k in range(n):
            pa = skia.Path(); pa.moveTo(x0, y + k * gap)
            xx = x0
            while xx <= x1:
                pa.lineTo(xx, y + k * gap + amp * math.sin((xx + k * 60) / 55.0 + ph)); xx += 8
            self.c.drawPath(pa, self.paint(color, a, 4))

    _imgs = {}
    def image(self, path, x, y, w, h, p=1, r=20, fit="cover"):
        """Draw a user-supplied PNG/JPG (logo, photo, screenshot) into the box x,y,w,h with rounded corners."""
        if p <= .001: return
        if path not in Ctx._imgs: Ctx._imgs[path] = skia.Image.open(path)
        im = Ctx._imgs[path]; iw, ih = im.width(), im.height()
        k = max(w / iw, h / ih) if fit == "cover" else min(w / iw, h / ih)
        dw, dh = iw * k, ih * k; y += (1 - p) * 26
        self.c.save(); self.c.clipRRect(skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r), doAntiAlias=True)
        pt = skia.Paint(AntiAlias=True); pt.setAlphaf(p)
        self.c.drawImageRect(im, skia.Rect.MakeXYWH(x + (w - dw) / 2, y + (h - dh) / 2, dw, dh), skia.SamplingOptions(skia.FilterMode.kLinear), pt)
        self.c.restore()

    def pill(self, s, cx, cy, size=30, color="teal", fill=None, p=1, w="m", padx=34):
        f = font(w, size); tw = f.measureText(s)
        self.rr(cx - tw / 2 - padx, cy - size * 0.95, tw + 2 * padx, size * 1.9, size, fill=fill, stroke=color, sw=3, p=p, dy=18)
        self.text(s, cx, cy + size * 0.35, size, color, w, "c", p, dy=18)

def background(c):
    pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
    c.drawRect(skia.Rect.MakeWH(W, H), pt)
    ctx = Ctx(c, 0, [])
    ctx.waves(0, W, 1010, 8, "sky", 0.07, 3, 22)


# ---------------------------------------------------------------- scene registry + timeline
SCENES = []
DECK_TITLE = "Presentation"

def scene(chapter, beats, ext=None, sky=False):
    """Register a scene. beats = list of script strings (what the narrator says while each visual
    appears). ext = {beat_index: seconds} to keep re-rendering a beat that has continuous motion.
    sky=True makes this a HORIZON scene (sunrise sky above, sea below). When it ends, the camera DIVES into the
    water and the next scene starts underwater. Use it for the title scene only."""
    def deco(fn):
        SCENES.append(dict(chapter=chapter, beats=beats, draw=fn, ext=ext or {}, sky=sky)); return fn
    return deco

def title(S, s, y=190, sub=None, p=1, color="white", size=64):
    S.text(s, W / 2, y, size, color, "b", "c", p)
    if sub: S.text(sub, W / 2, y + 58, 34, "mute", "r", "c", p)

FPS = 30; LEAD = 0.3; TAIL = 0.55; FADE_IN = 0.45; FADE_OUT = 0.4; WIN = 1.7; GAP = 0.35
DIVE = 1.9; HY = 640   # dive length (s) and horizon height (px) for sky scenes
FX = True   # drifting light, particles, slow camera push, slide transitions (every frame is unique, so renders take longer)

def build_timeline(scenes, wps=2.45, scale=1.0, durs=None):
    """Beat duration = words / wps (min 1.2 s) * scale, unless durs[(scene, beat)] gives it exactly
    (used for per-beat voice-over). Returns (timeline, total_seconds)."""
    tl, t0 = [], 0.0
    for i, s in enumerate(scenes):
        bs, t = [], LEAD
        for k, b in enumerate(s["beats"]):
            bs.append(t)
            d = durs.get((i, k)) if durs else None
            t += d if d is not None else max(1.2, len(b.split()) / wps) * scale
        tail = TAIL + (DIVE - TAIL + 0.1 if s.get("sky") else 0.0)
        dur = t + tail
        tl.append(dict(i=i, t0=t0, dur=dur, bs=bs, s=s, tail=tail, dive_in=bool(i and scenes[i - 1].get("sky")))); t0 += dur
    return tl, t0

_bg = {}
def bg_image():
    if "i" not in _bg:
        s = skia.Surface(W, H); c = s.getCanvas(); background(c); _bg["i"] = s.makeImageSnapshot()
    return _bg["i"]

_PART = []
def _particles():
    if not _PART:
        rnd = random.Random(7)
        for _ in range(36):
            _PART.append((rnd.random() * W, rnd.random() * H, rnd.uniform(14, 36), rnd.uniform(1.6, 4.0),
                          rnd.uniform(.07, .18), rnd.random() * 6.28))
    return _PART

def fx_background(c, T):
    """Slow drifting light blobs + rising particles, driven by absolute video time T."""
    for cx, cy, r, col, a in [(W * (.22 + .10 * math.sin(.17 * T)), H * (.30 + .08 * math.cos(.13 * T)), 760, "teal", .13),
                              (W * (.80 + .08 * math.cos(.11 * T)), H * (.70 + .10 * math.sin(.15 * T)), 820, "sky", .11),
                              (W * (.55 + .12 * math.sin(.09 * T + 1)), H * (.15 + .06 * math.cos(.2 * T)), 520, "amber", .05)]:
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(C[col], a), hexc(C[col], 0)], [0, 1]))
        c.drawCircle(cx, cy, r, pt)
    for x0, y0, v, rad, a, ph in _particles():
        y = (y0 - T * v) % (H + 60) - 30; x = x0 + 18 * math.sin(.4 * T + ph)
        c.drawCircle(x, y, rad, skia.Paint(AntiAlias=True, Color=hexc(C["sky"], a)))

def _stars():
    rnd = random.Random(11)
    return [(rnd.random() * W, rnd.random() * (HY - 120), rnd.uniform(1.0, 2.6), rnd.random() * 6.28) for _ in range(70)]
_STARS = []

def sky_bg(c, T):
    """Horizon scene: dawn sky, sun, drifting clouds, sea with sun glitter. Sea gradient extends far below the
    horizon so the camera can dive down through it."""
    if not _STARS: _STARS.extend(_stars())
    pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, HY)],
        [hexc("#06121F"), hexc("#12406A"), hexc("#3E78A8"), hexc("#F2A07B"), hexc("#FFD08A")], [0, .38, .66, .9, 1]))
    c.drawRect(skia.Rect.MakeXYWH(0, -400, W, HY + 400), pt)
    for x, y, r, ph in _STARS:
        c.drawCircle(x, y, r, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .25 + .45 * (.5 + .5 * math.sin(1.3 * T + ph)) * (1 - y / HY))))
    sx, sy = W * .5, HY + 6
    g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(sx, sy), 640, [hexc("#FFC46B", .55), hexc("#FFC46B", 0)], [0, 1]))
    c.drawCircle(sx, sy, 640, g)
    c.save(); c.clipRect(skia.Rect.MakeXYWH(0, 0, W, HY))
    c.drawCircle(sx, sy + 24 - 6 * math.sin(.4 * T), 105, skia.Paint(AntiAlias=True, Color=hexc("#FFE7B0")))
    c.restore()
    for k, (cx0, cy, w, sp) in enumerate([(300, 250, 520, 9), (1400, 190, 640, 6), (900, 400, 460, 12), (1650, 470, 380, 8)]):
        x = (cx0 + T * sp) % (W + 700) - 350
        c.drawRoundRect(skia.Rect.MakeXYWH(x - w / 2, cy, w, 34), 17, 17, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .07 + .02 * k)))
        c.drawRoundRect(skia.Rect.MakeXYWH(x - w / 3, cy - 20, w * .55, 30), 15, 15, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .06)))
    sea = skia.Paint(); sea.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HY), skia.Point(0, HY + H + 500)],
        [hexc("#2F95A6"), hexc("#17587A"), hexc(C["bg2"]), hexc(C["bg1"])], [0, .22, .6, 1]))
    c.drawRect(skia.Rect.MakeXYWH(0, HY, W, H + 500), sea)
    for j in range(15):                                   # sun glitter on the water
        y = HY + 14 + j * 24; w = 330 * (1 - j / 17.0) * (.75 + .25 * math.sin(1.9 * T + j * 1.3))
        c.drawRoundRect(skia.Rect.MakeXYWH(sx - w / 2 + 14 * math.sin(T + j), y, w, 5), 2.5, 2.5, skia.Paint(AntiAlias=True, Color=hexc("#FFE2A0", .55 * (1 - j / 16.0))))
    for k in range(5):
        pa = skia.Path(); y0 = HY + 70 + k * 95; pa.moveTo(0, y0)
        for xx in range(0, W + 8, 8): pa.lineTo(xx, y0 + (5 + 2 * k) * math.sin(xx / (70 + 18 * k) + T * (.7 + .15 * k) + k))
        st = skia.Paint(AntiAlias=True, Color=hexc("#BFEFFF", .12 - .015 * k)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(3); c.drawPath(pa, st)
    hz = skia.Paint(); hz.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, 0)], [hexc("#FFFFFF", 0), hexc("#FFF1CF", .7), hexc("#FFFFFF", 0)], [0, .5, 1]))
    c.drawRect(skia.Rect.MakeXYWH(0, HY - 1, W, 3), hz)

_DB = []
def dive_bubbles(c, tau):
    """Burst of bubbles that races upward after the dive. tau = seconds since the dive began."""
    if not _DB:
        rnd = random.Random(5)
        for _ in range(90): _DB.append((rnd.random() * W, rnd.uniform(5, 34), rnd.uniform(0, 1.5), rnd.uniform(520, 1250), rnd.random() * 6.28))
    for x0, r, d, v, ph in _DB:
        u = tau - (DIVE - 1.0) - d
        if u <= 0: continue
        y = H + 60 - u * v + 0.0 * u; x = x0 + 24 * math.sin(2.2 * u + ph)
        if y < -60: continue
        a = min(1.0, u * 4)
        st = skia.Paint(AntiAlias=True, Color=hexc("#DFF6FF", .55 * a)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(max(1.5, r / 9))
        c.drawCircle(x, y, r, st); c.drawCircle(x, y, r, skia.Paint(AntiAlias=True, Color=hexc("#BFEFFF", .07 * a)))
        c.drawCircle(x - r * .35, y - r * .35, max(1.2, r * .16), skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .75 * a)))

def surface_light(c, t):
    """Right after the dive: bright light from the surface fades out above us."""
    k = max(0.0, 1 - ease(t / 1.8))
    if k <= 0: return
    g = skia.Paint(); g.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, 760)], [hexc("#9FE8F2", .55 * k), hexc("#9FE8F2", 0)]))
    c.drawRect(skia.Rect.MakeXYWH(0, 0, W, 760), g)
    for i in range(7):
        x = 160 + i * 270 + 40 * math.sin(.8 * t + i); w = 70 + 40 * (i % 3)
        pa = skia.Path(); pa.moveTo(x, 0); pa.lineTo(x + w, 0); pa.lineTo(x + w * 2.4 + 120, 900); pa.lineTo(x + 120, 900); pa.close()
        c.drawPath(pa, skia.Paint(AntiAlias=True, Color=hexc("#CFF6FF", .09 * k)))

def render_frame(tl, i, t, deck_title=None):
    sc = tl[i]; s = skia.Surface(W, H); c = s.getCanvas(); T = sc["t0"] + t
    sky = sc["s"].get("sky")
    q = max(0.0, min(1.0, (t - (sc["dur"] - DIVE)) / DIVE)) if sky else 0.0          # dive progress (sky scene only)
    if sky:
        c.save(); c.translate(0, -(q * q * (3 - 2 * q)) * (HY + 150)); sky_bg(c, T)
        a = min(ease(t / FADE_IN), 1 - ease(q * 2.4)); dx = 0
    else:
        c.drawImage(bg_image(), 0, 0)
        if FX: fx_background(c, T)
        a = min(ease(t / FADE_IN), ease((sc["dur"] - t) / FADE_OUT))
        dx = (1 - ease(t / (FADE_IN + .25))) * 90 - (1 - ease((sc["dur"] - t) / (FADE_OUT + .1))) * 70
        if sc["dive_in"]: dx = 0; a = ease(t / (FADE_IN + .6)) * ease((sc["dur"] - t) / FADE_OUT)
    pt = skia.Paint(); pt.setAlphaf(a); c.saveLayer(None, pt)
    if FX and not sky:
        k = 1.0 + 0.03 * (t / sc["dur"])
        c.translate(W / 2 + dx, H / 2); c.scale(k, k); c.translate(-W / 2, -H / 2)
    else:
        c.translate(dx, 0)
    sc["s"]["draw"](Ctx(c, t, sc["bs"])); c.restore()
    if sky:
        c.restore()
        if q > .45:                                                         # blend into the underwater look
            ov = skia.Paint(); ov.setAlphaf(ease((q - .45) / .55)); c.drawImage(bg_image(), 0, 0, skia.SamplingOptions(), ov)
        if q > .3: dive_bubbles(c, (q * DIVE))
    elif sc["dive_in"] and t < 2.6:
        surface_light(c, t); dive_bubbles(c, DIVE + t)
    if FX and t < 0.75 and not sc["dive_in"] and not sky:                   # accent sweep
        x = -520 + (W + 520) * ease(t / 0.75); sp = skia.Paint()
        sp.setShader(skia.GradientShader.MakeLinear([skia.Point(x, 0), skia.Point(x + 520, 0)], [hexc(C["teal"], 0), hexc(C["teal"], .95)]))
        c.drawRect(skia.Rect.MakeXYWH(x, 0, 520, 7), sp)
    ch = Ctx(c, 0, [])
    ch.text(sc["s"]["chapter"], 70, 70, 24, "teal", "m", "l", a * .9)
    ch.text(f"{i+1:02d} / {len(tl)}", W - 70, 70, 24, "mute", "m", "r", a * .8)
    ch.text(deck_title or DECK_TITLE, 70, 1050, 20, "mute", "m", "l", .55 * (1 - ease(q * 2.4)))
    return s

def dyn_windows(sc):
    if sc["s"].get("sky"): return [(0, sc["dur"])]
    w = [(0, FADE_IN + .05), (sc["dur"] - FADE_OUT - .05, sc["dur"])]
    for k, b in enumerate(sc["bs"]):
        w.append((b, b + sc["s"]["ext"].get(k, WIN)))
    return w

def png_bytes(surface):
    return surface.makeImageSnapshot().encodeToData().bytes()
