#!/usr/bin/env python3
"""Storyboard / QA sheets WITHOUT rendering video.

  python contact_sheet.py SCENES.py --out qa [--beats] [--only 3,7]

Default: one frame per scene at its fully-built state, tiled 2x2 per sheet (qa/sheet_01.png ...).
--beats: also one sheet per scene showing the state at the end of every beat (finds overlaps that only
exist mid-scene). View the sheets with the image viewer and fix overlaps/clipping BEFORE rendering.
"""
import argparse, os, sys, importlib.util
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E
from PIL import Image

def tile(paths, cols, cell_w, out):
    rows = (len(paths) + cols - 1) // cols; cell_h = cell_w * 9 // 16
    m = Image.new("RGB", (cols * cell_w, rows * cell_h), (8, 18, 31))
    for j, p in enumerate(paths):
        m.paste(Image.open(p).resize((cell_w, cell_h), Image.LANCZOS), ((j % cols) * cell_w, (j // cols) * cell_h))
    m.save(out)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--out", default="qa")
    ap.add_argument("--beats", action="store_true"); ap.add_argument("--only"); ap.add_argument("--wps", type=float, default=2.45)
    a = ap.parse_args()
    spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    tl, _ = E.build_timeline(E.SCENES, a.wps); os.makedirs(a.out, exist_ok=True)
    deck = getattr(m, "DECK_TITLE", E.DECK_TITLE)
    idx = [int(x) - 1 for x in a.only.split(",")] if a.only else range(len(tl)); finals = []
    for i in idx:
        sc = tl[i]; t = sc["dur"] - 0.9 - (E.DIVE if sc["s"].get("sky") else 0)   # just before the scene fades out: everything has been revealed
        p = os.path.join(a.out, f"scene_{i+1:02d}_final.png"); open(p, "wb").write(E.png_bytes(E.render_frame(tl, i, t, deck))); finals.append(p)
        if a.beats:
            ps = []
            for k in range(len(sc["bs"])):
                end = (sc["bs"][k + 1] - 0.05) if k + 1 < len(sc["bs"]) else t
                q = os.path.join(a.out, f"scene_{i+1:02d}_beat_{k+1:02d}.png"); open(q, "wb").write(E.png_bytes(E.render_frame(tl, i, max(0.1, end), deck))); ps.append(q)
            tile(ps, 3, 640, os.path.join(a.out, f"scene_{i+1:02d}_beats.png"))
    for n in range(0, len(finals), 4):
        tile(finals[n:n + 4], 2, 960, os.path.join(a.out, f"sheet_{n//4+1:02d}.png"))
    print(f"{len(finals)} scenes -> {a.out}/sheet_*.png")

if __name__ == "__main__":
    main()
