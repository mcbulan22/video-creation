"""Motion Kit showcase (ships in inbox/ so the first test shows the new motion). Replace this file with your own scenes.py.
    sh make.sh --theme aurora --draft          sh make.sh --theme editorial --draft
Every colour is a palette role, so all looks work. Cheat sheet of every tool: KIT.md"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *
import engine as E

DECK_TITLE = "Motion Kit Showcase"


def heading(S, s, p, y=215):
    S.text(s, 960, y, 62, "white", "b", "c", p, maxw=1600)


# 1 ------------------------------------------------------------ title (horizon in Ocean, the look's own hero in the others)
@scene("MOTION KIT", [
    "Welcome to the motion kit showcase.",
    "Text that moves, icons that draw themselves, charts that build, and shapes that morph.",
    "Every tool works in every look.",
], sky=True)
def s_title(S):
    S.glow(960, 300, 420, "teal", 0.18, S.p(0, 1.2))
    S.grad_text("Motion Kit", 960, 300, 132, ("teal", "amber"), "b", "c", S.p(0, 1.0), shimmer=True)
    S.kinetic("Kinetic text, charts, morphs and flows", 960, 392, 46, "mute", "m", "c", S.p(1, 0.9), mode="blur")
    S.ship(960, 640 - 34, 0.85, "dark", S.p(2))
    S.text("Same workflow, new motion", 960, 880, 32, "white", "r", "c", S.p(2, 0.6, 0.3))


# 2 ------------------------------------------------------------ text styles
@scene("TEXT STYLES", [
    "Text can move in many ways.",
    "Words can rise into place, or pop in.",
    "They can drop and bounce, or come into focus.",
    "Add a gradient with a glint of light, or a marker highlight.",
    "And a word can morph into another word.",
])
def s_text(S):
    heading(S, "Text that moves", S.p(0))
    rows = [("RISE", "Words rise into place", "rise", 1, 340), ("POP", "Words pop in", "pop", 1, 430),
            ("DROP", "Words drop and bounce", "drop", 2, 520), ("BLUR", "Words come into focus", "blur", 2, 610)]
    for lab, txt, mode, beat, y in rows:
        p = S.p(beat, 0.9, 0.0 if y in (340, 520) else 0.2)
        S.text(lab, 140, y, 26, "mute", "m", "l", p)
        S.kinetic(txt, 980, y, 50, "white", "b", "c", p, mode=mode)
    f = E.font("b", 60); w = f.measureText("and a marker")
    S.marker(1330 - 10, 700, w + 20, 40, "amber", S.p(3, 0.7, 0.4), 0.55)
    S.grad_text("Add a gradient", 760, 735, 60, ("teal", "amber"), "b", "c", S.p(3, 1.0), shimmer=True)
    S.text("and a marker", 1330, 735, 60, "white", "b", "l", S.p(3, 0.6, 0.2))
    S.text("MORPH", 140, 860, 26, "mute", "m", "l", S.p(4))
    S.morph_text("Draft", "Final", 980, 870, 76, "white", "b", "c", S.p(4, 1.3, 0.8), S.p(4, 0.5), color_b="teal")


# 3 ------------------------------------------------------------ icons + stat cards
@scene("ICONS AND NUMBERS", [
    "Icons draw themselves on, line by line.",
    "Pick from more than thirty built-in icons, each with an optional badge.",
    "Big numbers count up inside their cards.",
])
def s_icons(S):
    heading(S, "Icons and numbers", S.p(0))
    names = [("shield", "Safe"), ("clock", "On time"), ("lock", "Secure"), ("cap", "Learning"), ("anchor", "Maritime")]
    for i, (n, lab) in enumerate(names):
        x = 360 + i * 300; p = S.p(0 if i == 0 else 1, 0.9, 0.0 if i == 0 else 0.15 * (i - 1))
        S.icon(n, x, 400, 96, ["teal", "amber", "sky", "green", "red"][i], p, bg="circle")
        S.text(lab, x, 530, 30, "white", "m", "c", p)
    for i, (v, lab, ic, col, unit) in enumerate([(1250, "Cadets assessed", "user", "teal", ""), (98, "Items validated", "check", "green", "%"), (24, "Exam sessions", "calendar", "amber", "")]):
        S.stat(v, lab, 120 + i * 600, 640, 480, 250, S.p(2, 0.6, 0.15 * i), col, "{:,.0f}", unit, ic, S.p(2, 1.5, 0.15 * i))


# 4 ------------------------------------------------------------ charts
@scene("CHARTS", [
    "Charts build themselves as you talk.",
    "Bars grow one after another.",
    "A ring sweeps round to its figure.",
    "And a donut splits a whole into parts.",
])
def s_charts(S):
    heading(S, "Charts that build themselves", S.p(0))
    S.bars([("Term 1", 62), ("Term 2", 71), ("Term 3", 84), ("Term 4", 93)], 140, 330, 700, 400, S.p(1, 1.4), "teal", 28, vmax=100, fmt="{:.0f}")
    S.ring(1180, 500, 130, 87, S.p(2, 1.6), "amber", label="pass rate")
    S.donut([("A", 45, "teal"), ("B", 30, "amber"), ("C", 25, "sky")], 1560, 500, 130, S.p(3, 1.4), center=("100", "cadets"))
    for i, (lab, col) in enumerate([("Deck", "teal"), ("Engine", "amber"), ("Other", "sky")]):
        p = S.p(3, 0.5, 0.15 * i); S.circ(1430 + i * 130, 740, 10, col, None, 0, p); S.text(lab, 1450 + i * 130, 750, 26, "white", "m", "l", p)


# 5 ------------------------------------------------------------ more charts + steps
@scene("TRENDS AND STEPS", [
    "Lines draw themselves left to right.",
    "Horizontal bars compare categories.",
    "And a stepper walks through a process.",
])
def s_more(S):
    heading(S, "Trends, rankings and steps", S.p(0))
    S.linechart([40, 52, 49, 66, 74, 91], 1000, 330, 740, 330, S.p(0, 1.8, 0.2), "teal", ["J", "F", "M", "A", "M", "J"], 26, vmin=0, vmax=100)
    S.hbars([("Seamanship", 91), ("Navigation", 84), ("Engineering", 77), ("Safety", 95)], 140, 360, 760, S.p(1, 1.5), "amber", 28, vmax=100, row=88, label_w=240, unit="%")
    S.stepper(["Prepare", "Take exam", "Review", "Certify"], 300, 1620, 840, S.p(2, 2.0), "teal", 26, 28)


# 6 ------------------------------------------------------------ morphs
@scene("MORPHS", [
    "Shapes flow from one outline into the next.",
    "A circle becomes a square, a star, a hexagon, and a soft blob.",
    "Cards glide and reshape from one box into another.",
])
def s_morph(S):
    heading(S, "Shapes and cards that morph", S.p(0))
    m = 4 * min(S.p(1, 4.2), 1.0)
    S.morph_shape(["circle", "square", "star", "hex", "blob"], 480, 590, 190, m, S.p(0, 0.9, 0.3), "teal", None, 6, 1.0, 1.0, spin=0.35)
    S.morph_shape(["blob", "burst", "circle", "star8", "squircle"], 480, 590, 80, 4 * min(S.p(1, 4.2, 0.3), 1.0), S.p(1, 0.6), "amber")
    t = min(S.p(2, 1.2), 1.0)
    v = S.morph_rr((960, 470, 280, 150, 26), (1010, 360, 710, 400, 40), t, "card", "teal", 4, S.p(2, 0.5))
    S.text("Cards reshape", v[0] + v[2] / 2, v[1] + v[3] / 2 - 10, 52, "white", "b", "c", S.p(2, 0.6, 0.7), maxw=v[2] - 60)
    S.text("while they glide", v[0] + v[2] / 2, v[1] + v[3] / 2 + 60, 36, "mute", "m", "c", S.p(2, 0.6, 0.9), maxw=v[2] - 60)


# 7 ------------------------------------------------------------ flow + spotlight
@scene("FLOWS AND FOCUS", [
    "Diagrams can flow. Lines draw from step to step with a glowing pulse.",
    "Then a spotlight dims the rest, and a ripple marks the one that matters.",
])
def s_flow(S):
    heading(S, "Diagrams that flow and focus", S.p(0))
    steps = [("doc", "Plan", "teal"), ("gear", "Build", "amber"), ("check", "Check", "green")]
    for i, (ic, lab, col) in enumerate(steps):
        x = 140 + i * 610; p = S.p(0, 0.7, 0.3 * i)
        S.rr(x, 360, 420, 230, 28, "card", "edge", 2, p)
        S.icon(ic, x + 210, 440, 76, col, p, bg="circle"); S.text(lab, x + 210, 548, 40, "white", "b", "c", p)
    S.flow([(570, 475), (750, 475)], S.p(0, 0.9, 0.9), "teal")
    S.flow([(1180, 475), (1360, 475)], S.p(0, 0.9, 1.3), "amber")
    S.spotlight(1370, 360, 420, 230, S.p(1, 0.8), 28, 0.35, "green")
    S.ripple(1740, 396, 46, "green", S.p(1, 0.8, 0.2)); S.circ(1740, 396, 9, "green", None, 0, S.p(1, 0.5, 0.2))
    S.rr(420, 720, 1080, 130, 26, "card", "green", 3, S.p(1, 0.6, 0.4))
    S.text("Focus the viewer on the one that matters", 960, 800, 40, "white", "m", "c", S.p(1, 0.6, 0.5), maxw=1000)


# 8 ------------------------------------------------------------ closing
@scene("THANK YOU", [
    "That is the motion kit.",
    "Give me your material and pick a look, and I will build the video.",
])
def s_end(S):
    S.glow(960, 470, 480, "teal", 0.2, S.p(0, 1.2))
    S.grad_text("Thank you", 960, 500, 140, ("teal", "amber"), "b", "c", S.p(0, 1.0), shimmer=True)
    S.burst(960, 440, S.p(0, 1.3, 0.5), ("teal", "amber", "sky", "red", "green"), 40, 420, 12)
    S.kinetic("Choose a look. Send the material.", 960, 640, 48, "mute", "m", "c", S.p(1, 0.9), mode="rise")
    S.sparkle(640, 360, 36, "amber", S.p(1, 0.6)); S.sparkle(1330, 420, 30, "teal", S.p(1, 0.6, 0.2)); S.sparkle(1180, 330, 22, "sky", S.p(1, 0.6, 0.4))
