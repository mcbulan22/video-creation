# Instructions for Claude Code (read this first)

This folder makes narrated motion-graphics videos. The scenes file is ready-made in `inbox/scenes.py`.
**Do NOT rewrite scenes.py or the files in scripts/.** Only run the commands below and report what happens.

## Commands (run from this folder)
- First time only: `sh setup_mac.sh`
- Quick test: `sh make.sh --draft`
- Final: `sh make.sh`
- With the user's own recordings (folder `my_voice`, names listed in `narration_script.txt`): `sh make.sh --own-voice`
- Picture only: `sh render.sh --draft`
- Slow Mac: add `--fx off`
- Music: `inbox/music.mp3` is used automatically, or `sh make.sh --music pad`
- Another voice: `sh make.sh --voice-name Daniel` (list: `say -v '?'`)

## Result
`output/final_with_audio.mp4` (also `full_video_with_captions.mp4`, `script_cues.srt`, `output/qa/` review sheets).

## If something fails
Show the last 15 lines of the error in plain words, fix only the obvious cause (missing ffmpeg: `brew install ffmpeg`; missing `.venv`: `sh setup_mac.sh`; missing recordings: tell the user the file names printed), then re-run. If a scene looks wrong, tell the user to ask Claude chat to fix `inbox/scenes.py`.


## Themes and motion
- Looks live in `themes/` (see THEMES.md); choose with `--theme NAME` (default clean). Motion rules and tuning: MOTION.md.
- Never edit `scripts/engine.py` to change one theme's look: put it in that theme's file. Ocean must keep rendering exactly as before.
- After changing motion, run `sh motion_check.sh`; every non-Ocean theme should show PASS on all lines.

## Computers (Mac, Windows PC, Linux)
- Everything goes through `studio.py` (standard library only). `.sh` files are Mac wrappers, `.bat` files are Windows wrappers (keep CRLF line endings, ASCII only).
- Never call `sh`, `say`, `rm`, `open` or hard-coded paths from the scripts. Use `platform_utils` (PU) for ffmpeg lookup, path escaping and folder removal; write text files as UTF-8.
- Each computer has its own `.venv-<computer>`. Test paths with spaces and with Windows-style paths (`PU.filter_path`, `PU.concat_path`).
- Details for the user: COMPUTERS.md.

## Rendering
- Frames are drawn in 1920x1080 units and scaled to the output size (`E.SCALE`); use `E.draw_bg(c)`, never `c.drawImage(E.bg_image(), ...)`.
- build_video sends raw BGRA frames to ffmpeg (`--frames pipe`, default). `--frames png` is the old fallback.
- Ocean must stay byte-identical at standard size.
