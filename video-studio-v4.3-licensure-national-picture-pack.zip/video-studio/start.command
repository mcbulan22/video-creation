#!/bin/sh
# Double-click in Finder: asks a few questions, then makes the video.
cd "$(dirname "$0")"
python3 studio.py wizard
echo
printf "Press Enter to close this window..."; read x
