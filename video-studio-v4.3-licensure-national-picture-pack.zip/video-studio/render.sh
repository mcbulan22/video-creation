#!/bin/sh
# Picture only (no sound).   sh render.sh --draft
# (Same tool as on a Windows PC: python3 studio.py render)
cd "$(dirname "$0")"
exec python3 studio.py render "$@"
