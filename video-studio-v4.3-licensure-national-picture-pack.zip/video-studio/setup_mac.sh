#!/bin/sh
# Run ONCE on a Mac:  sh setup_mac.sh      (Linux: python3 studio.py setup)
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Python 3 missing. In Terminal run: xcode-select --install   then run this script again."; exit 1; }
if ! command -v ffmpeg >/dev/null && [ ! -x bin/ffmpeg ]; then
  command -v brew >/dev/null || { echo "Homebrew missing. Install it from https://brew.sh (copy the one-line command), then run this script again."; exit 1; }
  brew install ffmpeg
fi
exec python3 studio.py setup "$@"
