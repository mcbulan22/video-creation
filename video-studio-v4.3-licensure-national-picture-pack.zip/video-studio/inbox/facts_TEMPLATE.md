# Facts for the video  (copy to inbox/facts.md)
Every number, name, date and claim that will appear on screen or in the narration goes here, copied exactly from your source.
One fact per line:   F1 | the fact, with its numbers exactly as they will appear | source: document, page or link | status: verified / UNVERIFIED
Mark anything you are unsure about as UNVERIFIED; the checker (python studio.py facts) warns if the video uses it.
Lines that start with # are ignored, so the examples below do nothing. Delete them and write your own.

# F1 | The pass mark for professional courses is 75 | source: CCA Manual, p.12 | status: verified
# F2 | 1,250 cadets were assessed in 2025 | source: CCA annual report, table 3 | status: UNVERIFIED
