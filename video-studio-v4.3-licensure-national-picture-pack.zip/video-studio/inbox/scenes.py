"""Are Our Graduates Failing the Licensure Exam? MAAP in the National Picture.
Narration = exact beat text. Charts are drawn from MAAP_licensure_analysis_v2.xlsx (numbers embedded below).
Works in every look (clean, ocean, techno, classroom, formal, playful): colour NAMES are roles, not literal colours.
Colour roles used: teal = MAAP, amber = all other schools / emphasis, white = text, mute = secondary, sky = chance limits."""
import os, sys, math, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *

DECK_TITLE = "MAAP Licensure Results: The National Picture"

D = json.loads('''{"years":[2020,2021,2022,2023,2024,2025],"DOIC":{"maap":[96.4,91.5,71.5,63.7,57.1,34.2],"others":[83.7,74.7,58.9,55.6,41.5,27.7],"gap":[12.7,16.8,12.6,8.1,15.6,6.5],"n":[55,153,172,190,191,199]},"DM":{"maap":[100.0,95.7,60.5,60.0,45.6,25.4],"others":[89.7,80.3,47.9,44.2,27.3,17.5],"gap":[10.3,15.3,12.5,15.8,18.3,7.9],"n":[11,69,81,45,57,67]},"EOIC":{"maap":[65.2,64.5,69.4,73.9,66.7,42.2],"others":[66.6,57.8,61.4,62.6,52.1,31.9],"gap":[-1.4,6.7,8.1,11.3,14.6,10.3],"n":[46,211,170,230,174,187]},"EM":{"maap":[57.9,62.2,59.9,61.0,60.0,40.0],"others":[54.9,40.6,52.1,50.0,43.3,31.7],"gap":[2.9,21.7,7.7,11.0,16.7,8.3],"n":[19,143,152,41,65,100]},"fun_whole":[[261,0.858],[10,0.7],[258,0.674],[159,0.629],[21,0.619],[144,0.618],[165,0.594],[196,0.592],[1189,0.585],[65,0.585],[1458,0.578],[51,0.569],[552,0.563],[133,0.556],[27,0.556],[128,0.555],[631,0.555],[85,0.553],[78,0.551],[31,0.548],[53,0.547],[128,0.547],[412,0.546],[11,0.545],[285,0.544],[244,0.541],[122,0.541],[343,0.539],[197,0.538],[145,0.538],[188,0.537],[54,0.537],[69,0.536],[148,0.534],[34,0.529],[640,0.527],[86,0.523],[695,0.519],[180,0.517],[93,0.516],[165,0.515],[180,0.511],[359,0.51],[146,0.507],[160,0.5],[48,0.5],[129,0.496],[166,0.494],[73,0.493],[64,0.484],[221,0.484],[87,0.483],[247,0.482],[147,0.476],[30,0.467],[48,0.458],[55,0.455],[75,0.453],[337,0.451],[606,0.45],[76,0.447],[85,0.447],[90,0.444],[272,0.441],[51,0.431],[82,0.427],[71,0.408],[64,0.406],[72,0.403],[112,0.402],[98,0.398],[28,0.393],[164,0.39],[29,0.379],[59,0.373],[157,0.369],[22,0.364],[69,0.362],[39,0.359],[289,0.349],[18,0.333],[35,0.314],[23,0.304],[77,0.286],[22,0.273]],"scatter":[[0.858,0.985],[0.674,0.884],[0.629,0.824],[0.618,0.896],[0.594,0.812],[0.592,0.857],[0.585,0.813],[0.585,0.8],[0.578,0.816],[0.569,0.765],[0.563,0.792],[0.556,0.812],[0.555,0.797],[0.555,0.813],[0.553,0.765],[0.551,0.782],[0.548,0.677],[0.547,0.736],[0.547,0.805],[0.546,0.752],[0.544,0.828],[0.541,0.791],[0.541,0.779],[0.539,0.822],[0.538,0.843],[0.538,0.752],[0.537,0.771],[0.537,0.741],[0.536,0.696],[0.534,0.784],[0.529,0.735],[0.527,0.787],[0.523,0.709],[0.519,0.786],[0.517,0.811],[0.516,0.785],[0.515,0.752],[0.511,0.794],[0.51,0.788],[0.507,0.808],[0.5,0.781],[0.5,0.729],[0.496,0.767],[0.494,0.843],[0.493,0.781],[0.484,0.766],[0.484,0.742],[0.483,0.724],[0.482,0.789],[0.476,0.707],[0.467,0.733],[0.458,0.667],[0.455,0.782],[0.453,0.72],[0.451,0.751],[0.45,0.815],[0.447,0.724],[0.447,0.776],[0.444,0.689],[0.441,0.724],[0.431,0.706],[0.427,0.72],[0.408,0.746],[0.406,0.703],[0.403,0.694],[0.402,0.732],[0.398,0.612],[0.39,0.652],[0.373,0.712],[0.369,0.694],[0.362,0.681],[0.359,0.615],[0.349,0.654],[0.314,0.657],[0.286,0.649]],"maap_scatter":[0.64,0.896],"fun_year":{"2020":[[63,0.81],[10,0.7],[12,0.833],[28,0.75],[10,0.7],[8,0.75],[9,0.667],[13,0.692],[10,0.9],[11,0.818],[5,0.6],[7,0.857],[7,0.857],[6,1.0],[8,1.0],[8,0.75],[7,0.857],[37,0.919],[43,0.814],[9,0.556],[16,0.812],[19,0.947],[20,0.8],[9,0.889],[50,0.86],[7,0.857],[9,0.778],[9,0.778],[18,0.889],[61,0.852],[26,1.0],[5,0.8],[6,0.667],[23,0.913],[5,0.8],[8,0.875],[6,0.667],[5,0.6],[34,0.912],[6,1.0],[6,0.833],[11,1.0]],"2021":[[118,0.72],[9,0.778],[13,0.846],[54,0.741],[71,0.648],[32,0.719],[11,0.636],[31,0.581],[31,0.484],[24,0.833],[32,0.5],[20,0.75],[47,0.787],[8,0.625],[31,0.645],[5,0.6],[7,0.571],[25,0.48],[16,0.688],[6,0.667],[14,0.643],[16,0.688],[5,0.8],[13,0.846],[74,0.716],[17,0.647],[93,0.656],[37,0.757],[11,0.818],[41,0.927],[37,0.784],[8,0.75],[12,0.75],[8,0.75],[28,0.75],[37,0.676],[9,0.889],[21,0.762],[9,0.444],[48,0.75],[173,0.85],[24,0.708],[5,0.8],[12,0.75],[18,0.778],[16,0.812],[21,0.667],[65,0.8],[11,0.909],[276,0.815],[105,0.8],[45,0.822],[20,0.85],[48,0.896],[16,0.875],[27,0.704],[28,0.821],[25,0.76],[13,0.846],[5,1.0],[6,0.833],[44,0.682],[117,0.803],[41,0.829],[17,0.706],[51,0.529],[10,0.8],[34,0.618],[20,0.75]],"2022":[[134,0.537],[12,0.667],[8,0.75],[12,0.5],[65,0.508],[85,0.624],[19,0.737],[15,0.533],[47,0.298],[46,0.283],[31,0.742],[41,0.634],[29,0.586],[33,0.606],[12,0.833],[58,0.586],[11,0.364],[10,0.4],[13,0.308],[27,0.704],[26,0.769],[10,0.7],[16,0.438],[28,0.607],[7,0.143],[13,0.615],[24,0.75],[87,0.586],[25,0.4],[107,0.551],[15,0.733],[19,0.526],[19,0.947],[44,0.568],[17,0.824],[12,0.583],[29,0.448],[14,0.643],[52,0.692],[58,0.707],[5,0.6],[20,0.35],[5,0.8],[27,0.222],[85,0.624],[204,0.632],[33,0.576],[24,0.708],[11,0.545],[53,0.585],[18,0.556],[27,0.741],[5,0.2],[85,0.647],[27,0.593],[15,0.667],[281,0.655],[87,0.609],[40,0.575],[41,0.512],[43,0.814],[11,0.727],[22,0.636],[47,0.468],[40,0.75],[8,1.0],[20,0.55],[18,0.444],[9,0.333],[25,0.6],[111,0.577],[33,0.636],[21,0.476],[57,0.474],[14,0.214],[35,0.4],[16,0.625]],"2023":[[149,0.53],[8,0.625],[10,0.4],[72,0.472],[67,0.507],[20,0.75],[15,0.133],[40,0.55],[38,0.395],[70,0.629],[44,0.591],[48,0.458],[13,0.692],[30,0.7],[14,0.571],[58,0.655],[16,0.438],[6,0.833],[14,0.643],[14,0.5],[29,0.586],[27,0.519],[14,0.429],[6,0.5],[23,0.609],[5,0.4],[5,0.4],[39,0.564],[81,0.494],[28,0.464],[134,0.59],[34,0.647],[13,0.231],[94,0.936],[31,0.581],[15,0.333],[8,0.625],[13,0.462],[27,0.667],[42,0.452],[40,0.375],[6,0.5],[19,0.526],[5,0.2],[23,0.391],[44,0.568],[225,0.578],[25,0.44],[11,0.636],[8,0.25],[38,0.526],[18,0.444],[6,0.667],[32,0.562],[10,0.7],[102,0.51],[23,0.478],[16,0.438],[246,0.654],[125,0.624],[54,0.481],[25,0.52],[27,0.556],[13,0.846],[26,0.385],[41,0.561],[27,0.593],[9,0.667],[14,0.357],[26,0.577],[13,0.692],[37,0.514],[91,0.615],[36,0.694],[30,0.4],[81,0.383],[21,0.429],[28,0.5],[26,0.346]],"2024":[[110,0.373],[15,0.333],[9,0.0],[7,0.571],[55,0.345],[36,0.278],[22,0.364],[14,0.286],[17,0.176],[17,0.235],[89,0.506],[26,0.423],[23,0.348],[43,0.349],[11,0.455],[48,0.354],[14,0.286],[5,0.0],[16,0.25],[6,0.0],[32,0.531],[14,0.357],[11,0.273],[10,0.5],[28,0.321],[9,0.222],[9,0.111],[32,0.344],[173,0.318],[27,0.259],[152,0.441],[20,0.6],[21,0.429],[70,0.657],[54,0.685],[24,0.292],[11,0.091],[15,0.333],[7,0.429],[15,0.333],[24,0.542],[38,0.474],[18,0.222],[6,0.167],[72,0.458],[246,0.565],[25,0.4],[17,0.176],[9,0.333],[33,0.333],[13,0.077],[29,0.31],[8,0.375],[79,0.418],[13,0.538],[9,0.333],[306,0.477],[90,0.467],[39,0.154],[18,0.444],[37,0.568],[12,0.0],[7,0.286],[68,0.426],[20,0.45],[8,0.125],[10,0.1],[12,0.417],[6,0.167],[21,0.333],[128,0.484],[23,0.261],[13,0.462],[43,0.233],[14,0.214],[38,0.5],[8,0.625]],"2025":[[119,0.261],[22,0.091],[10,0.2],[79,0.203],[72,0.264],[25,0.12],[8,0.25],[20,0.05],[22,0.364],[58,0.241],[27,0.185],[15,0.2],[5,0.2],[30,0.167],[6,0.167],[45,0.089],[11,0.182],[18,0.222],[8,0.0],[43,0.256],[37,0.351],[8,0.0],[26,0.269],[12,0.417],[6,0.0],[18,0.333],[154,0.26],[13,0.154],[111,0.324],[29,0.379],[22,0.227],[92,0.359],[53,0.811],[45,0.311],[9,0.111],[16,0.125],[20,0.15],[6,0.333],[13,0.308],[31,0.29],[51,0.333],[7,0.143],[17,0.059],[10,0.1],[85,0.353],[291,0.371],[33,0.212],[9,0.444],[10,0.1],[29,0.31],[15,0.067],[30,0.367],[5,0.2],[63,0.27],[9,0.222],[14,0.143],[288,0.257],[119,0.235],[38,0.289],[12,0.25],[69,0.42],[11,0.273],[83,0.229],[39,0.487],[15,0.133],[13,0.231],[11,0.182],[16,0.312],[150,0.287],[26,0.231],[5,0.4],[51,0.02],[7,0.0],[19,0.316],[19,0.316]]}}''')
YEARS = D["years"]


# Figures that reach the screen through loops or variables (checked against facts.md by `python studio.py facts`)
FIGURES = dict(
    cold=[96, 34, 65, 74, 42], one=[34, 84, 28, 5, 100, 1000, 85],
    method=[98, 95, 7, 2019, 2025, 386, 0],
    fell=[84, 28, 56, 90, 17.5, 67, 32, 55],
    doic=[64, 52, 12, 76, 89.6],
    others=[59.5, 47, 63.8, 53.8, 57, 45, 93.6, 54, 74, 59],
    summary=[64.0, 52.4, 59.5, 47.0, 63.8, 53.8, 56.9, 44.9, 8, 7],
    recover=[71, 52, 82, 61, 76, 65],
    gaps=[12.7, 16.8, 12.6, 8.1, 15.6, 6.5, 10.3, 15.3, 12.5, 15.8, 18.3, 7.9, 2.9, 21.7, 7.7, 11.0, 16.7, 8.3, -1.4, 6.7, 11.3, 14.6, 46],
    falls=[23, 14, 20, 10, 12, 24],
    leads=[15.6, 6.5, 18.3, 7.9, 16.7, 8.3, 14.6, 10.3],
    bad=[34, 35],
)


# ------------------------------------------------------------------ helpers
def clamp(v, a=0.0, b=1.0): return max(a, min(b, v))


def heading(S, s, p, y=225, size=58):
    S.text(s, 960, y, size, "white", "b", "c", p, maxw=1600)


def card(S, x, y, w, h, p, stroke="edge", r=22):
    S.rr(x, y, w, h, r, "card", stroke, 2, p)


def polyline(S, pts, color, sw, p, dash=None):
    """Draws a polyline progressively: p = 0..1 of its total length."""
    p = clamp(p)
    if p <= 0.001 or len(pts) < 2: return
    segs = [math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1)]
    target = sum(segs) * p; acc = 0.0
    for i, l in enumerate(segs):
        if acc >= target: break
        f = 1.0 if l <= 0 else min(1.0, (target - acc) / l)
        S.line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], color, sw, f, dash)
        acc += l


def hbar(S, x, y, w, h, color, p):
    q = clamp(p); ww = w * q
    if ww >= 4: S.rr(x, y, ww, h, min(h / 2, ww / 2), color, None, 0, min(p, 1.0), dy=0)


def swatch(S, x, y, color, label, p, size=28, w=34):
    S.rr(x, y - 22, w, 22, 6, color, None, 0, p, dy=0)
    S.text(label, x + w + 14, y, size, "white", "m", "l", p)


def linechart(S, x0, y0, w, h, vmin, vmax, ticks, series, pa, ncols=6, fmt="{:.0f}%", xlabels=True, dotr=10, sw=7):
    """series = [(values, color, p_line)]. Returns (gx, gy) mapping functions."""
    gx = lambda i: x0 + 40 + (w - 80) * i / (ncols - 1)
    gy = lambda v: y0 + h * (1 - (v - vmin) / (vmax - vmin))
    for v in ticks:
        y = gy(v)
        S.line(x0, y, x0 + w, y, "edge", 2, pa)
        S.text(fmt.format(v), x0 - 14, y + 9, 26, "mute", "r", "r", pa, dy=6)
    if xlabels:
        for i, yr in enumerate(YEARS):
            S.text(str(yr), gx(i), y0 + h + 42, 26, "mute", "m", "c", pa, dy=6)
    for vals, color, p in series:
        pts = [(gx(i), gy(v)) for i, v in enumerate(vals)]
        polyline(S, pts, color, sw, p)
        for i, (x, y) in enumerate(pts):
            S.circ(x, y, dotr, color, None, 3, clamp((p * (len(pts) - 1) - i) * 4))
    return gx, gy


def funnel(S, x0, y0, w, h, nmin, nmax, p0, pts, maap, pf, pd, pm, ticks=True, lims=((1.96, None),), dotr=6, mr=14, xt=(10, 100, 1000)):
    """Funnel plot: each dot = one school; x = number of takers (log), y = first-time pass rate;
    lines = what chance alone would produce around the national rate p0 for a school of that size."""
    lx = lambda n: x0 + w * (math.log(n) - math.log(nmin)) / (math.log(nmax) - math.log(nmin))
    gy = lambda v: y0 + h * (1 - v)
    S.line(x0, y0 + h, x0 + w, y0 + h, "mute", 3, pf)
    S.line(x0, y0, x0, y0 + h, "mute", 3, pf)
    if ticks:
        for v in (0, 0.5, 1.0):
            S.text(f"{v*100:.0f}%", x0 - 14, gy(v) + 9, 26, "mute", "r", "r", pf, dy=6)
        for n in xt:
            if nmin <= n <= nmax:
                S.text(f"{n:,}", lx(n), y0 + h + 42, 26, "mute", "m", "c", pf, dy=6)
    S.line(x0, gy(p0), x0 + w, gy(p0), "amber", 3, pf, [14, 10])
    steps = 36
    ns = [math.exp(math.log(nmin) + (math.log(nmax) - math.log(nmin)) * i / steps) for i in range(steps + 1)]
    for z, dash in lims:
        up = [(lx(n), gy(min(1.0, p0 + z * math.sqrt(p0 * (1 - p0) / n)))) for n in ns]
        lo = [(lx(n), gy(max(0.0, p0 - z * math.sqrt(p0 * (1 - p0) / n)))) for n in ns]
        polyline(S, up, "sky", 3, pf, dash); polyline(S, lo, "sky", 3, pf, dash)
    for n, r in pts:
        if nmin <= n <= nmax: S.circ(lx(n), gy(r), dotr, "mute", None, 3, pd)
    if maap:
        n, r = maap; x, y = lx(n), gy(r)
        S.glow(x, y, mr * 5, "teal", 0.5, pm)
        S.circ(x, y, mr, "teal", "white", 4, pm)
    return lx, gy


def spread(items, gap):
    """items = [(y, key)] -> {key: y} pushed apart so labels keep at least `gap` px between them."""
    it = sorted(items); ys = [y for y, _ in it]
    for i in range(1, len(ys)):
        if ys[i] - ys[i - 1] < gap: ys[i] = ys[i - 1] + gap
    return {k: ys[i] for i, (_, k) in enumerate(it)}


# ------------------------------------------------------------------ 1  title (horizon + dive in the Ocean look)
@scene("INTRODUCTION", [
    "What is happening?",
    "Are our graduates failing the licensure exam?",
], sky=True)
def s_title(S):
    S.glow(960, 330, 420, "teal", 0.16, S.p(1, 1.2))
    S.text("What is happening?", 960, 190, 46, "amber", "m", "c", S.p(0))
    S.text("Are our graduates failing the licensure exam?", 960, 285, 70, "white", "b", "c", S.p(1), maxw=1500, lh=1.18)
    S.text("MAAP in the national picture", 960, 440, 40, "teal", "m", "c", S.p(1, .6, .3))
    S.ship(960, 640 - 34, 0.85, "dark", S.p(1, .9, .2))
    S.text("Licensure results 2020 to 2025  |  Maritime Academy of Asia and the Pacific", 960, 880, 28, "white", "r", "c", S.p(1, .6, .4))


# ------------------------------------------------------------------ 2  cold open: the alarming numbers
@scene("COLD OPEN", [
    "Look at the Deck Operational Level exam, the one our fresh graduates take to become OICs. In 2020, 96 percent of our first-time examinees passed. By 2025, it was 34 percent.",
    "In the Engine exam, we held between 65 and 74 percent for years, then fell to 42 percent last year.",
    "Those numbers are alarming. So let’s do what we should always do with an alarming number. Let’s look at the full picture.",
])
def s_cold(S):
    heading(S, "Two alarming numbers", S.p(0), y=215)
    pa = S.p(0, .6)
    card(S, 120, 260, 1160, 590, pa)
    swatch(S, 160, 318, "teal", "Deck OIC", S.p(0))
    swatch(S, 420, 318, "amber", "Engine OIC", S.p(1))
    gx, gy = linechart(S, 235, 350, 990, 410, 0, 100, (0, 25, 50, 75, 100),
                       [(D["DOIC"]["maap"], "teal", S.p(0, 1.6)), (D["EOIC"]["maap"], "amber", S.p(1, 1.6))], pa)
    # right-hand cards
    p0, p1 = S.p(0, .6, .2), S.p(1, .6, .1)
    card(S, 1320, 270, 480, 270, p0)
    S.text("Deck OIC, first-time pass rate", 1350, 322, 28, "mute", "m", "l", p0, maxw=420)
    S.num(96, 1350, 430, 64, "teal", "b", "l", S.p(0, 1.3, .2), "{:.0f}%")
    S.arrow(1535, 410, 1585, 410, "mute", 5, p0)
    S.num(34, 1610, 430, 64, "amber", "b", "l", S.p(0, 1.6, .5), "{:.0f}%")
    S.text("2020", 1350, 490, 26, "mute", "m", "l", p0); S.text("2025", 1620, 490, 26, "mute", "m", "l", p0)
    card(S, 1320, 570, 480, 270, p1)
    S.text("Engine OIC, first-time pass rate", 1350, 622, 28, "mute", "m", "l", p1, maxw=420)
    S.text("65-74%", 1350, 730, 44, "teal", "b", "l", p1, _deco=False)
    S.arrow(1560, 712, 1600, 712, "mute", 5, p1)
    S.num(42, 1625, 730, 44, "amber", "b", "l", S.p(1, 1.3, .3), "{:.0f}%")
    S.text("for years", 1350, 790, 26, "mute", "m", "l", p1); S.text("2025", 1625, 790, 26, "mute", "m", "l", p1)
    S.pill("An alarming number needs the full picture", 960, 912, 30, "amber", None, S.p(2))


# ------------------------------------------------------------------ 3  one number is not enough
@scene("WHY ONE NUMBER ISN'T ENOUGH", [
    "Here’s the problem with “34 percent.” It tells us nothing about whether that’s bad.",
    "If every school in the country went from 84 percent to 28, then 34 percent is not a failure of MAAP. It’s a different story entirely.",
    "And if only MAAP dropped, it’s a very different one.",
])
def s_one(S):
    S.glow(960, 360, 380, "amber", 0.14, S.p(0, 1.2))
    S.text("34%", 960, 400, 170, "amber", "b", "c", S.p(0))
    S.text("on its own, it tells us nothing", 960, 470, 40, "white", "m", "c", S.p(0, .6, .3))
    for i, (x, kick, big, sub, col) in enumerate([
            (120, "Every school fell", "84% to 28%", "34% is not a failure of MAAP.\nA different story entirely.", "teal"),
            (980, "Only MAAP fell", "MAAP alone", "A very different story.", "amber")]):
        p = S.p(1 + i)
        card(S, x, 540, 820, 340, p, col)
        S.text(kick, x + 40, 610, 32, col, "b", "l", p)
        S.text(big, x + 40, 705, 70, "white", "b", "l", p)
        for j, ln in enumerate(sub.split("\n")):
            S.text(ln, x + 40, 790 + j * 42, 30, "white", "r", "l", p, maxw=740)


# ------------------------------------------------------------------ 4  comparing schools is hard
@scene("WHY ONE NUMBER ISN'T ENOUGH", [
    "Comparing schools is harder than it looks. Some schools send ten graduates to the exam. Others send a thousand.",
    "Some report only first-time passers, others include those who passed after retaking.",
    "A school with five takers and a perfect score is not “better” than a school with a thousand takers and 85 percent.",
])
def s_hard(S):
    heading(S, "Comparing schools is harder than it looks", S.p(0), y=215, size=54)
    for i, (x, n, lab, fmt) in enumerate([(120, 10, "graduates sent to the exam", "{:,.0f}"), (980, 1000, "graduates sent to the exam", "{:,.0f}")]):
        p = S.p(0, .6, i * .2)
        card(S, x, 270, 820, 230, p)
        S.num(n, x + 410, 425, 100, "teal" if i == 0 else "amber", "b", "c", S.p(0, 1.2, i * .2), fmt)
        S.text("Some schools" if i == 0 else "Others", x + 410, 315, 30, "mute", "m", "c", p)
        S.text(lab, x + 410, 475, 28, "white", "r", "c", p)
    S.pill("First-time passers only", 540, 585, 32, "teal", None, S.p(1))
    S.pill("Includes passed after retaking", 1380, 585, 32, "amber", None, S.p(1, .5, .2))
    p = S.p(2)
    card(S, 120, 660, 1680, 250, p)
    S.text("5 takers", 400, 760, 44, "white", "b", "c", p)
    S.text("perfect score: 100%", 400, 830, 34, "teal", "m", "c", p)
    S.text("is not better than", 960, 800, 34, "mute", "m", "c", p)
    S.text("1,000 takers", 1520, 760, 44, "white", "b", "c", p)
    S.text("85% pass", 1520, 830, 34, "amber", "m", "c", p)


# ------------------------------------------------------------------ 5  how we did it properly
@scene("HOW WE DID IT", [
    "So we did it properly. We took the national tables: 98 schools for Deck, 95 for Engine, every exam year from 2019 to 2025.",
    "We checked every school’s yearly rows against the totals in the file, and they matched.",
    "Then we used methods built for this problem. One is a funnel plot, which shows whether a school’s result is better or worse than chance alone would produce for a school of that size.",
    "The other is a size-adjusted ranking, so that tiny schools can’t win on luck.",
])
def s_method(S):
    heading(S, "So we did it properly", S.p(0), y=215)
    for i, (n, lab, fmt) in enumerate([(98, "schools, Deck", "{:,.0f}"), (95, "schools, Engine", "{:,.0f}"), (7, "exam years, 2019 to 2025", "{:,.0f}")]):
        p = S.p(0, .6, i * .2); x = 120 + i * 570
        card(S, x, 270, 540, 190, p)
        S.num(n, x + 270, 385, 96, "teal", "b", "c", S.p(0, 1.1, i * .2), fmt)
        S.text(lab, x + 270, 435, 28, "white", "r", "c", p)
    p = S.p(1)
    card(S, 120, 490, 1680, 110, p, "green")
    S.check(185, 548, 30, "green", p)
    S.text("386 yearly-row checks against the file totals: 0 mismatches", 235, 560, 34, "white", "m", "l", p, maxw=1500)
    p = S.p(2)
    card(S, 120, 630, 820, 290, p, "sky")
    S.text("Funnel plot", 160, 690, 36, "sky", "b", "l", p)
    S.text("Better or worse than chance alone, for a school of that size", 160, 745, 28, "white", "r", "l", p, maxw=420)
    funnel(S, 640, 665, 260, 220, 10, 1000, .52, [(30, .4), (50, .6), (80, .5), (150, .55), (300, .45), (500, .6), (60, .3), (200, .7)],
           (900, .74), p, p, p, ticks=False, dotr=5, mr=10)
    p = S.p(3)
    card(S, 980, 630, 820, 290, p, "amber")
    S.text("Size-adjusted ranking", 1020, 690, 36, "amber", "b", "l", p)
    S.text("Tiny schools can't win on luck", 1020, 745, 28, "white", "r", "l", p, maxw=740)
    for j, (nm, w_) in enumerate([("A", 560), ("B", 470), ("C", 380)]):
        S.text(nm, 1030, 810 + j * 36, 26, "mute", "m", "l", p)
        hbar(S, 1070, 790 + j * 36, w_ * .65, 22, "amber", p)


# ------------------------------------------------------------------ 6  everyone fell
@scene("THE BIG PICTURE", [
    "First, what happened nationally.",
    "In Deck OIC, the first-time pass rate of all other schools combined dropped from about 84 percent in 2020 to about 28 percent in 2025. That’s a 56-point fall. Roughly one in four first-time takers in the country passed last year.",
    "In Deck Management, it went from 90 percent to 17.5. In Engine OIC, from 67 to 32. In Engine Management, from 55 to 32.",
    "So the first thing to know: what we’re seeing is not a MAAP-only problem.",
    "Something large is happening across the whole country, and the data can’t tell us what. It could be the exam, the cohorts, the training pipeline or something else. What it does tell us is that no school was spared.",
])
def s_fell(S):
    heading(S, "Everyone fell", S.p(0), y=215)
    pa = S.p(0, .6)
    card(S, 120, 260, 1020, 520, pa)
    swatch(S, 150, 312, "teal", "MAAP", S.p(0))
    swatch(S, 420, 312, "amber", "All other schools", S.p(1))
    gx, gy = linechart(S, 230, 345, 860, 350, 0, 100, (0, 25, 50, 75, 100),
                       [(D["DOIC"]["maap"], "teal", S.p(0, 1.4)), (D["DOIC"]["others"], "amber", S.p(1, 1.6))], pa)
    S.text("84%", gx(0), gy(83.7) + 46, 28, "amber", "b", "c", S.p(1))
    S.text("28%", gx(5), gy(27.7) + 46, 28, "amber", "b", "c", S.p(1, .6, .8))
    p = S.p(1, .6, .3)
    card(S, 1180, 260, 620, 250, p, "amber")
    S.text("Deck OIC, all other schools", 1210, 308, 28, "mute", "m", "l", p)
    S.num(56, 1210, 405, 100, "amber", "b", "l", S.p(1, 1.4, .3), "-{:.0f}")
    S.text("points", 1440, 405, 40, "white", "m", "l", p)
    S.text("About one in four first-time takers passed in 2025", 1210, 462, 26, "white", "r", "l", p, maxw=560)
    S.text("Other schools combined, first-time", 1180, 552, 26, "mute", "m", "l", S.p(2))
    for i, (nm, a, b) in enumerate([("Deck Management", "90", "17.5"), ("Engine OIC", "67", "32"), ("Engine Management", "55", "32")]):
        p = S.p(2, .5, i * .25); y = 572 + i * 77
        card(S, 1180, y, 620, 68, p)
        S.text(nm, 1210, y + 45, 29, "white", "m", "l", p)
        S.text(f"{a} to {b}", 1770, y + 46, 34, "amber", "b", "r", p)
    p = S.p(3)
    card(S, 120, 815, 1680, 90, p, "amber")
    S.text("Not a MAAP-only problem. No school was spared.", 960, 875, 40, "amber", "b", "c", p)
    S.text("It could be the exam, the cohorts, the training pipeline or something else. The data cannot say.", 960, 945, 28, "mute", "m", "c", S.p(4), maxw=1600)


# ------------------------------------------------------------------ 7  Deck OIC whole-period funnel
@scene("OUR POSITION", [
    "Now, where does MAAP stand inside that national decline? Start with Deck OIC.",
    "Over the whole period, MAAP’s first-time pass rate is 64 percent. All other schools combined: 52 percent. That’s a gap of nearly 12 points, and statistically it’s far beyond chance.",
    "We rank third out of 76 schools with enough takers to compare fairly.",
    "On the overall pass rate, counting those who passed after a retake, we rank second, at nearly 90 percent.",
])
def s_doic(S):
    heading(S, "Deck OIC, 2020 to 2025", S.p(0), y=215)
    pa = S.p(0, .7)
    card(S, 120, 265, 1020, 650, pa)
    p = S.p(0, .5)
    S.line(150, 312, 205, 312, "amber", 3, p, [14, 10]); S.text("All other schools: 52%", 220, 322, 26, "white", "m", "l", p)
    S.line(590, 312, 645, 312, "sky", 3, p); S.text("Limits of chance alone", 660, 322, 26, "white", "m", "l", p)
    lx, gy = funnel(S, 230, 345, 860, 440, 10, 1200, .524, D["fun_whole"], (961, .64), pa, S.p(0, .8, .2), S.p(1, .6),
                    lims=((1.96, [12, 8]), (3.09, None)))
    my = gy(.64)
    S.text("MAAP", lx(961) - 10, my - 34, 30, "teal", "b", "r", S.p(1), _deco=False)
    S.text("graduates who took the exam (log scale), one dot per school", 660, 880, 26, "mute", "m", "c", pa)
    p = S.p(1, .6, .1)
    card(S, 1180, 265, 620, 235, p, "teal")
    S.text("First-time pass rate", 1210, 312, 28, "mute", "m", "l", p)
    S.num(64, 1210, 410, 96, "teal", "b", "l", S.p(1, 1.2, .1), "{:.0f}%")
    S.text("vs", 1420, 410, 38, "mute", "m", "l", p)
    S.num(52, 1490, 410, 66, "white", "b", "l", S.p(1, 1.2, .3), "{:.0f}%")
    S.text("A gap of nearly 12 points, far beyond chance", 1210, 462, 26, "white", "r", "l", p, maxw=560)
    p = S.p(2)
    card(S, 1180, 520, 620, 180, p, "amber")
    S.text("3rd of 76", 1210, 600, 64, "amber", "b", "l", p, _deco=False)
    S.text("size-adjusted rank, schools with enough takers", 1210, 650, 26, "white", "r", "l", p, maxw=560)
    p = S.p(3)
    card(S, 1180, 720, 620, 195, p, "teal")
    S.num(89.6, 1210, 800, 64, "teal", "b", "l", S.p(3, 1.2), "{:.1f}%")
    S.text("ranks 2nd", 1470, 800, 40, "amber", "b", "l", p)
    S.text("overall pass rate, counting retakes", 1210, 860, 26, "white", "r", "l", p, maxw=560)


# ------------------------------------------------------------------ 8  Deck Management and the Engine exams
@scene("OUR POSITION", [
    "The Deck Management exam gives the same story. We are at 59.5 percent against 47 for everyone else, and after adjusting for school size we rank first of 54.",
    "Now Engine, and here I want to be careful, because an earlier version of this analysis used a faulty Engine summary and told a weaker story. With the raw national tables the picture is clear.",
    "In Engine OIC, MAAP is at 63.8 percent against 53.8 for the others. After adjusting for size we rank fourth of 74, and second on the overall pass rate, which is 93.6 percent.",
    "In Engine Management, we are at 57 percent against 45, ranking fifth of 59.",
])
def s_others(S):
    heading(S, "The other three exams", S.p(0), y=215)
    rows = [("Deck Management", 59.5, 47, "1st of 54", "adjusted for school size", 0, 285),
            ("Engine OIC", 63.8, 53.8, "4th of 74", "adjusted for size; 2nd on overall pass rate, 93.6%", 2, 585),
            ("Engine Management", 57, 45, "5th of 59", "adjusted for school size", 3, 755)]
    for nm, a, b, rk, sub, k, y in rows:
        p = S.p(k)
        card(S, 120, y, 1680, 150, p)
        S.text(nm, 160, y + 62, 38, "white", "b", "l", p)
        S.text("first-time pass rate", 160, y + 112, 28, "mute", "m", "l", p)
        fm = "{:.1f}%" if a != int(a) else "{:.0f}%"
        S.num(a, 700, y + 98, 66, "teal", "b", "l", S.p(k, 1.2), "{:.1f}%" if a != int(a) else "{:.0f}%")
        S.text("vs", 975, y + 98, 32, "mute", "m", "l", p)
        S.num(b, 1040, y + 98, 66, "white", "b", "l", S.p(k, 1.2, .2), "{:.1f}%" if b != int(b) else "{:.0f}%")
        S.text("ranks " + rk, 1330, y + 62, 36, "amber", "b", "l", p)
        S.text(sub, 1330, y + 106, 26, "white", "r", "l", p, maxw=450)
    p = S.p(1)
    card(S, 120, 455, 1680, 105, p, "amber")
    S.text("Engine: an earlier version used a faulty summary and told a weaker story. The raw national tables make the picture clear.",
           160, 500, 30, "amber", "m", "l", p, maxw=1600, lh=1.2)


# ------------------------------------------------------------------ 9  summary bars, comparable-size schools
@scene("OUR POSITION", [
    "So across all four exams, MAAP is significantly above the rest of the country. Not slightly. Significantly.",
    "Is that just because we’re big? No. Among schools of comparable size, in Deck OIC we rank first of eight. In Engine OIC we rank first of seven.",
])
def s_summary(S):
    heading(S, "First-time pass rate, 2020 to 2025", S.p(0), y=215, size=54)
    swatch(S, 560, 290, "teal", "MAAP", S.p(0)); swatch(S, 860, 290, "amber", "All other schools combined", S.p(0))
    data = [("Deck OIC", 64.0, 52.4), ("Deck Management", 59.5, 47.0), ("Engine OIC", 63.8, 53.8), ("Engine Management", 56.9, 44.9)]
    for i, (nm, a, b) in enumerate(data):
        y = 330 + i * 125; p = S.p(0, .6, i * .2)
        S.text(nm, 130, y + 62, 32, "white", "b", "l", p, maxw=400)
        hbar(S, 560, y + 8, a * 11, 42, "teal", S.p(0, 1.0, i * .2))
        S.num(a, 560 + a * 11 + 18, y + 42, 32, "teal", "b", "l", S.p(0, 1.2, i * .2), "{:.1f}%")
        hbar(S, 560, y + 60, b * 11, 42, "amber", S.p(0, 1.0, .1 + i * .2))
        S.num(b, 560 + b * 11 + 18, y + 94, 32, "amber", "b", "l", S.p(0, 1.2, .1 + i * .2), "{:.1f}%")
    S.pill("Deck OIC: 1st of 8 schools of comparable size", 520, 905, 28, "teal", None, S.p(1))
    S.pill("Engine OIC: 1st of 7", 1420, 905, 28, "teal", None, S.p(1, .5, .2))


# ------------------------------------------------------------------ 10  recovery after a first-time failure
@scene("A DETAIL THAT STANDS OUT", [
    "Here’s one of the most striking findings. Look at what happens after a first-time failure.",
    "In Deck OIC, about 71 percent of our graduates who failed their first attempt eventually passed. The typical school sees about 52 percent. In Engine OIC, 82 percent against 61. In Engine Management, 76 against 65.",
    "Whatever MAAP is doing for graduates who fall short the first time is working better than what most schools do. It’s a real strength, and it’s the reason our overall pass rates are so high. It also raises a question we’ll come back to: if our support after a failure is that effective, what would the same effort do before the first attempt?",
])
def s_recover(S):
    heading(S, "How graduates come back", S.p(0), y=215)
    pa = S.p(0, .7)
    card(S, 120, 260, 800, 650, pa)
    S.text("Deck OIC: each dot is a school", 150, 312, 28, "white", "m", "l", pa)
    x0, y0, w, h = 235, 345, 640, 440
    gx = lambda v: x0 + w * v; gy = lambda v: y0 + h * (1 - v)
    S.line(x0, y0 + h, x0 + w, y0 + h, "mute", 3, pa); S.line(x0, y0, x0, y0 + h, "mute", 3, pa)
    for v in (0, .5, 1):
        S.text(f"{v*100:.0f}%", x0 - 14, gy(v) + 9, 26, "mute", "r", "r", pa, dy=6)
        S.text(f"{v*100:.0f}%", gx(v), y0 + h + 42, 26, "mute", "m", "c", pa, dy=6)
    S.line(gx(0), gy(0), gx(1), gy(1), "amber", 3, pa, [14, 10])
    S.text("Across: first-time rate.  Up: overall rate with retakes", 520, 885, 26, "mute", "m", "c", pa, maxw=760)
    pd_ = S.p(0, .8, .2)
    for a, b in D["scatter"]: S.circ(gx(a), gy(b), 6, "mute", None, 3, pd_)
    pm = S.p(1, .6)
    S.glow(gx(D["maap_scatter"][0]), gy(D["maap_scatter"][1]), 70, "teal", .5, pm)
    S.circ(gx(D["maap_scatter"][0]), gy(D["maap_scatter"][1]), 14, "teal", "white", 4, pm)
    S.text("MAAP", gx(D["maap_scatter"][0]), gy(D["maap_scatter"][1]) - 30, 28, "teal", "b", "c", pm, _deco=False)
    S.text("Of those who failed first time, share who eventually passed", 960, 312, 26, "mute", "m", "l", S.p(1), maxw=830)
    swatch(S, 960, 372, "teal", "MAAP", S.p(1)); swatch(S, 1200, 372, "amber", "Typical school", S.p(1))
    for i, (nm, a, b) in enumerate([("Deck OIC", 71, 52), ("Engine OIC", 82, 61), ("Engine Management", 76, 65)]):
        y = 405 + i * 165; p = S.p(1, .6, i * .25)
        S.text(nm, 960, y + 30, 30, "white", "b", "l", p)
        hbar(S, 960, y + 45, a * 6.2, 40, "teal", S.p(1, 1.0, i * .25))
        S.num(a, 960 + a * 6.2 + 16, y + 78, 32, "teal", "b", "l", S.p(1, 1.2, i * .25), "{:.0f}%")
        hbar(S, 960, y + 95, b * 6.2, 40, "amber", S.p(1, 1.0, .1 + i * .25))
        S.num(b, 960 + b * 6.2 + 16, y + 128, 32, "amber", "b", "l", S.p(1, 1.2, .1 + i * .25), "{:.0f}%")
    p = S.p(2)
    S.pill("A real strength behind our high overall pass rates", 1360, 932, 28, "amber", None, p)


# ------------------------------------------------------------------ 11  year by year funnels
@scene("YEAR BY YEAR", [
    "Now the part that answers the question we started with. Not “where are we on average,” but “where have we been each year.”",
    "In 2020, MAAP sits above the line.",
    "In 2021, well above it.",
    "In 2022 and 2023, above.",
    "In 2024, well above again.",
    "And in 2025, with our rate at 34 percent, we’re still above the line, against a national rate of 28.",
])
def s_years(S):
    heading(S, "Deck OIC, year by year", S.p(0), y=205, size=52)
    beat_for = {2020: 1, 2021: 2, 2022: 3, 2023: 3, 2024: 4, 2025: 5}
    for i, yr in enumerate(YEARS):
        px = 120 + (i % 3) * 570; py = 245 + (i // 3) * 345
        pc = S.p(0, .6, i * .12); k = beat_for[yr]; pk = S.p(k, .7)
        card(S, px, py, 540, 325, pc, "teal" if yr == 2025 else "edge")
        S.text(str(yr), px + 30, py + 52, 36, "white", "b", "l", pc)
        mr_, orate = D["DOIC"]["maap"][i], D["DOIC"]["others"][i]
        S.text(f"MAAP {mr_:.0f}%  |  others {orate:.0f}%", px + 512, py + 50, 26, "mute", "m", "r", pk)
        funnel(S, px + 62, py + 78, 440, 215, 5, 400, orate / 100, D["fun_year"][str(yr)], (D["DOIC"]["n"][i], mr_ / 100),
               pc, S.p(k, .8), S.p(k, .7, .15), ticks=False, dotr=4.5, mr=11)
    S.text("Each dot is a school. Blue lines mark what chance alone would produce. Dashed line: national rate.", 960, 960, 27, "mute", "m", "c", S.p(0, .6, .5), maxw=1700)


# ------------------------------------------------------------------ 12  ahead every year (table of gaps)
@scene("YEAR BY YEAR", [
    "Every year, in Deck OIC, we are ahead of the national rate, by between 6.5 and nearly 17 points.",
    "In Deck Management, the same: ahead every year, by 8 to 18 points.",
    "In Engine Management, also ahead every year.",
    "In Engine OIC, ahead in five of six years. The one exception is 2020, when we were about one point behind, and only 46 graduates had taken the exam.",
    "So the answer to “are we falling alone?” is no. We’ve been falling with everyone else, from a higher starting point, and we’ve stayed above the pack.",
])
def s_gaps(S):
    heading(S, "MAAP's lead over all other schools", S.p(0), y=215, size=54)
    ph = S.p(0, .6)
    for i, yr in enumerate(YEARS): S.text(str(yr), 560 + i * 200 + 100, 305, 30, "mute", "b", "c", ph)
    order = [("DOIC", "Deck OIC", 0), ("DM", "Deck Management", 1), ("EM", "Engine Management", 2), ("EOIC", "Engine OIC", 3)]
    for r, (key, nm, k) in enumerate(order):
        y = 330 + r * 112; p = S.p(k)
        S.text(nm, 130, y + 62, 32, "white", "b", "l", p, maxw=420)
        for i, g in enumerate(D[key]["gap"]):
            neg = g < 0; col = "red" if neg else "green"
            pc = S.p(k, .5, i * .08)
            S.rr(560 + i * 200 + 6, y, 188, 96, 16, "card", col if neg else "edge", 3 if neg else 2, pc)
            S.text(f"{g:+.1f}", 560 + i * 200 + 100, y + 63, 38, col, "b", "c", pc)
    S.text("Percentage points above (+) or below (-) all other schools, first-time pass rate", 960, 800, 26, "mute", "m", "c", ph)
    S.pill("2020: only 46 Engine OIC graduates took the exam", 960, 868, 28, "red", None, S.p(3, .5, .4))
    S.text("Falling with everyone else, from a higher starting point", 960, 950, 38, "amber", "b", "c", S.p(4), maxw=1600)


# ------------------------------------------------------------------ 13  the warning: 2025 falls
@scene("THE WARNING INSIDE THE GOOD NEWS", [
    "But a fair story needs the uncomfortable part too.",
    "Look at 2025 alone. In Deck OIC, our rate fell 23 points in one year, from 57 to 34. The rest of the country fell 14.",
    "In Deck Management, we fell 20 points while the others fell 10. In Engine Management, 20 against 12. In Engine OIC, 24 against 20.",
])
def s_warn(S):
    heading(S, "The warning inside the good news", S.p(0), y=215, size=54)
    S.text("How far first-time pass rates fell in 2025 (percentage points)", 960, 285, 30, "mute", "m", "c", S.p(0, .6, .2))
    swatch(S, 560, 345, "teal", "MAAP fell", S.p(0, .6, .3)); swatch(S, 860, 345, "amber", "All other schools fell", S.p(0, .6, .3))
    rows = [("Deck OIC", 23, 14, 1), ("Deck Management", 20, 10, 2), ("Engine Management", 20, 12, 2), ("Engine OIC", 24, 20, 2)]
    sc = 44; n2 = 0
    for i, (nm, a, b, k) in enumerate(rows):
        y = 380 + i * 125; dl = 0 if k == 1 else (i - 1) * .25
        p = S.p(k, .6, dl)
        S.text(nm, 130, y + 62, 32, "white", "b", "l", p, maxw=420)
        hbar(S, 560, y + 8, a * sc, 40, "teal", S.p(k, 1.0, dl))
        S.num(a, 560 + a * sc + 16, y + 42, 32, "teal", "b", "l", S.p(k, 1.1, dl), "{:.0f} pts")
        hbar(S, 560, y + 58, b * sc, 40, "amber", S.p(k, 1.0, dl + .1))
        S.num(b, 560 + b * sc + 16, y + 92, 32, "amber", "b", "l", S.p(k, 1.1, dl + .1), "{:.0f} pts")


# ------------------------------------------------------------------ 14  the lead narrowed
@scene("THE WARNING INSIDE THE GOOD NEWS", [
    "On all four exams, MAAP fell further in 2025 than the national average. And our lead over the rest of the country, the gap between us and everyone else, was narrower in 2025 than in 2024 on every exam.",
    "In Deck OIC, from nearly 16 points down to 6.5.",
])
def s_lead(S):
    heading(S, "The cushion got thinner", S.p(0), y=215)
    S.text("MAAP's lead over all other schools, in percentage points", 960, 285, 30, "mute", "m", "c", S.p(0, .6, .2))
    swatch(S, 560, 345, "teal", "Lead in 2024", S.p(0, .6, .3)); swatch(S, 860, 345, "amber", "Lead in 2025", S.p(0, .6, .3))
    sc = 40
    for i, (key, nm) in enumerate([("DOIC", "Deck OIC"), ("DM", "Deck Management"), ("EM", "Engine Management"), ("EOIC", "Engine OIC")]):
        a, b = D[key]["gap"][4], D[key]["gap"][5]
        y = 380 + i * 125; p = S.p(0, .6, i * .25)
        S.text(nm, 130, y + 62, 32, "white", "b", "l", p, maxw=420)
        hbar(S, 560, y + 8, a * sc, 40, "teal", S.p(0, 1.0, i * .25))
        S.num(a, 560 + a * sc + 16, y + 42, 32, "teal", "b", "l", S.p(0, 1.1, i * .25), "{:.1f} pts")
        hbar(S, 560, y + 58, b * sc, 40, "amber", S.p(0, 1.0, i * .25 + .1))
        S.num(b, 560 + b * sc + 16, y + 92, 32, "amber", "b", "l", S.p(0, 1.1, i * .25 + .1), "{:.1f} pts")
    p = S.p(1)
    S.rr(110, 370, 1700, 118, 20, None, "amber", 4, p, dy=0)
    S.text("from nearly 16 down to 6.5", 1780, 442, 30, "amber", "b", "r", p)


# ------------------------------------------------------------------ 15  signal, not yet a trend
@scene("THE WARNING INSIDE THE GOOD NEWS", [
    "Does that prove a trend? Not yet.",
    "Our lead has bounced around from year to year, 2024 was unusually strong in several exams,",
    "and when we test the trend statistically, only Engine OIC shows a clear pattern, and it’s an improving one.",
    "Six data points are too few to forecast anything.",
    "But here’s how I’d say it. 2025 is the year the cushion got thinner.",
    "One thin year is a signal. Two in a row would be a pattern. That makes 2026 the year to watch.",
])
def s_signal(S):
    heading(S, "A signal, not yet a trend", S.p(0), y=215)
    pa = S.p(0, .6)
    card(S, 120, 255, 1680, 600, pa)
    cols = [("DOIC", "teal", "Deck OIC"), ("DM", "amber", "Deck Management"), ("EOIC", "green", "Engine OIC"), ("EM", "white", "Engine Management")]
    xs = [150, 420, 860, 1190]
    for j, (key, col, nm) in enumerate(cols):
        S.line(xs[j], 308, xs[j] + 40, 308, col, 7, S.p(0, .5, j * .1)); S.text(nm, xs[j] + 52, 318, 27, "white", "m", "l", S.p(0, .5, j * .1))
    x0, y0, w, h = 230, 355, 1300, 400
    gx, gy = linechart(S, x0, y0, w, h, -5, 25, (0, 5, 10, 15, 20, 25),
                       [(D[k]["gap"], c, S.p(0, 1.8, j * .12)) for j, (k, c, _) in enumerate(cols)], pa, ncols=7, fmt="{:.0f}", sw=6, dotr=8)
    S.text("lead in points", x0 + 6, y0 - 12, 24, "mute", "m", "l", pa, dy=0)
    S.text("2026", gx(6), y0 + h + 42, 26, "amber", "b", "c", S.p(5))
    ends = spread([(gy(D[k]["gap"][5]), k) for k, _, _ in cols], 38)
    short = {"DOIC": "Deck OIC", "DM": "Deck Mgmt", "EOIC": "Engine OIC", "EM": "Engine Mgmt"}
    for k, c, _ in cols:
        S.text(short[k], gx(5) + 40, ends[k] + 9, 26, c, "b", "l", S.p(0, .6, 1.5))
    pb = S.p(4)
    S.rr(gx(5) - 62, y0 - 12, 124, h + 24, 18, None, "amber", 4, pb, dy=0)
    p5 = S.p(5)
    S.line(gx(6), y0, gx(6), y0 + h, "amber", 3, p5, [12, 10])
    S.pill("2026?", gx(6), gy(21), 28, "amber", None, p5)
    S.pill("Bounces year to year", 340, 905, 28, "mute", None, S.p(1))
    S.pill("Only Engine OIC shows a clear trend (improving)", 960, 905, 28, "green", None, S.p(2))
    S.pill("Only six data points", 1580, 905, 28, "mute", None, S.p(3))


# ------------------------------------------------------------------ 16  so, are we really that bad?
@scene("SO, ARE WE REALLY THAT BAD?", [
    "No. Over the full period, MAAP is among the strongest schools in the country on every licensure exam we looked at, and ahead of the national rate in nearly every single year.",
    "But “not bad” is not the same as “fine.” Our graduates passed on the first attempt less than 35 percent of the time in Deck OIC last year. Two out of three of them did not pass on the first try.",
    "That’s true even when most of the country did worse, and our graduates, and the families and careers behind them, don’t experience a national average. They experience their own result.",
])
def s_bad(S):
    p = S.p(0)
    S.glow(520, 450, 360, "teal", .16, S.p(0, 1.2))
    S.text("No.", 520, 480, 220, "teal", "b", "c", p)
    S.text("Among the strongest schools on every exam", 520, 570, 36, "white", "m", "c", S.p(0, .6, .3), maxw=820)
    S.pill("Ahead of the national rate in nearly every year", 520, 700, 28, "teal", None, S.p(0, .6, .5))
    p = S.p(1)
    card(S, 1020, 250, 780, 560, p, "amber")
    S.text("Deck OIC, 2025", 1060, 312, 30, "mute", "m", "l", p)
    S.text("first-time pass rate", 1060, 352, 30, "mute", "m", "l", p)
    S.num(34, 1060, 500, 130, "amber", "b", "l", S.p(1, 1.3), "{:.0f}%")
    for i in range(3):
        cx = 1160 + i * 220; pi = S.p(1, .5, .5 + i * .2)
        S.circ(cx, 640, 62, "card", "white", 4, pi)
        if i == 0: S.check(cx, 642, 44, "green", pi)
        else: S.cross(cx, 640, 42, "red", pi)
    S.text("passed", 1160, 748, 26, "green", "m", "c", S.p(1, .5, .7))
    S.text("did not", 1380, 748, 26, "red", "m", "c", S.p(1, .5, .9)); S.text("did not", 1600, 748, 26, "red", "m", "c", S.p(1, .5, 1.0))
    S.text("Two out of three did not pass on the first try", 960, 905, 38, "white", "b", "c", S.p(1, .6, .8), maxw=1600)
    S.text("They experience their own result, not a national average.", 960, 960, 30, "amber", "m", "c", S.p(2), maxw=1600)


# ------------------------------------------------------------------ 17  what this means
@scene("WHAT THIS MEANS", [
    "Three things.",
    "First, we now know where we stand. We’re in front, and the decline is national. That lets us ask a sharper question: not “what’s wrong with MAAP” but “what would make a MAAP graduate more likely to pass on the first attempt, in an exam that has become much harder for everyone?”",
    "Second, we know where our strength is: persistence. Our graduates recover from failure better than most. The opportunity is to bring some of that support forward, earlier and more often, before the first attempt.",
    "Third, we keep watching. We re-run this same analysis when the 2026 results come in. If we stay above the line, we’re holding our position. If the lead keeps shrinking, we’ll see it, and we’ll see it early, instead of discovering it later.",
])
def s_means(S):
    heading(S, "Three things", S.p(0), y=215)
    items = [("First, we know where we stand", "We are in front, and the decline is national. So the sharper question is: what would make a MAAP graduate more likely to pass first time?", 1),
             ("Second, our strength is persistence", "Graduates recover from failure better than most. Bring some of that support forward, before the first attempt.", 2),
             ("Third, we keep watching", "Re-run this analysis when the 2026 results come in. If the lead keeps shrinking, we will see it early.", 3)]
    for i, (t, sub, k) in enumerate(items):
        y = 270 + i * 225; p = S.p(k)
        card(S, 120, y, 1680, 200, p, "teal" if i != 2 else "amber")
        S.icon(["compass", "anchor", "search"][i], 210, y + 100, 84, "amber", p, bg="circle")
        S.text(t, 290, y + 66, 38, "white", "b", "l", p, maxw=1460)
        S.text(sub, 290, y + 120, 29, "white", "r", "l", p, maxw=1460, lh=1.25)


# ------------------------------------------------------------------ 18  closing
@scene("CLOSING", [
    "The decline is real.",
    "The panic isn’t warranted.",
    "The attention is.",
])
def s_close(S):
    S.glow(960, 560, 520, "teal", .14, S.p(0, 1.2))
    S.text("The decline is real.", 960, 400, 100, "white", "b", "c", S.p(0))
    S.text("The panic isn't warranted.", 960, 560, 100, "white", "b", "c", S.p(1))
    S.glow(960, 720, 420, "amber", .2, S.p(2, 1.2))
    S.text("The attention is.", 960, 720, 110, "amber", "b", "c", S.p(2))
