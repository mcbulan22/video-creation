# Director's brief  (copy to inbox/brief.md; fill it in, or let Claude interview you and fill it)
Five minutes here saves redoing scenes later. Short answers are fine.

1. **Topic and source material** (what the video is about, which documents it is based on):
2. **Audience** (who watches, what they already know, how much time they have):
3. **The ONE takeaway** (a sentence the viewer could repeat tomorrow):
4. **After watching, the viewer should** (do / decide / understand / feel):
5. **Length and place**: about ___ minutes. Shown on: meeting-room screen / phone / social media / classroom.
6. **Look and mood**: one of clean, ocean, techno, classroom, formal, playful, aurora, editorial, or "freeform" with colours, logo and three words for the feel:
7. **Voice and tone**: formal or friendly; narrator language; first person ("we") or neutral:
8. **Must include** (points, terms, names, a logo):
9. **Must avoid** (claims, names, images, jargon, anything sensitive):
10. **Accuracy rule** (leave as is): every number, name and date on screen or in narration must be in facts.md. Illustrative numbers are allowed only in a scene that says "Example data" on screen.
11. **Ending**: call to action or what happens next:
12. **References I like** (links, or describe a video or style):
