# Director's brief: "Are Our Graduates Failing the Licensure Exam? MAAP in the National Picture"
1. Topic and source material: declining first-time licensure pass rates, MAAP versus every other Philippine maritime school; source: MAAP_licensure_analysis_v2.xlsx and the author's narration script.
2. Audience: MAAP management, faculty, program heads, academic council. Smart, not statisticians.
3. The ONE takeaway: Pass rates have fallen sharply nationwide; MAAP fell with everyone else but stayed above the national rate in nearly every year; 2025 shows our lead getting thinner, so 2026 is the year to watch.
4. After watching, the viewer should understand: (1) the drop is national, (2) MAAP is among the strongest on all four exams, (3) the 2025 narrowing is a signal, not yet a proven trend, (4) MAAP graduates recover after a first-time failure better than most.
5. Length and place: about 9 to 10 minutes, 18 scenes; shown on a meeting-room screen.
6. Look and mood: chosen by the user at render time with --theme (clean is a safe default; formal or editorial suit management; aurora/ocean for a darker mood).
7. Voice and tone: calm, honest, credible, conversational; data-journalism explainer; first person plural ("we"); not an alarm, not a celebration.
8. Must include: the four takeaways, year-by-year position, the 2025 warning, recovery strength, "2026 is the year to watch".
9. Must avoid: claiming a proven trend; claiming a cause for the national decline (the data cannot say); hype words.
10. Accuracy rule: every number must be in facts.md. F12 and F20 are the author's statements and are marked UNVERIFIED.
11. Ending: "The decline is real. The panic isn't warranted. The attention is."
12. Visual language: MAAP = teal, all other schools = amber; one hero visual per scene (funnel plots, lines, paired bars, gap table).
