# Facts for "Are Our Graduates Failing the Licensure Exam? MAAP in the National Picture"
# Source A = the author's narration script. Source B = MAAP_licensure_analysis_v2.xlsx (sheet named in each line). All checked against both.
F1 | Deck OIC first-time pass rate of MAAP examinees: 96 percent in 2020, 34 percent in 2025 | source: B Yearly Deck-OIC (96.4, 34.2) | status: verified
F2 | Engine OIC first-time pass rate of MAAP held between 65 and 74 percent for years, then fell to 42 percent in 2025 | source: B Yearly Engine-OIC (65.2 to 73.9; 42.2) | status: verified
F3 | National tables: 98 schools for Deck, 95 for Engine, exam years 2019 to 2025 (7 years) | source: B Data checks | status: verified
F4 | 386 total-row checks (190 Engine + 196 Deck) with 0 mismatches | source: B Data checks | status: verified
F5 | All other schools combined, Deck OIC first-time pass rate: 84 percent (83.7) in 2020 to 28 percent (27.7) in 2025, a 56-point fall | source: B Yearly Deck-OIC | status: verified
F6 | All other schools combined, first-time pass rate fell: Deck Management 90 to 17.5, Engine OIC 67 to 32, Engine Management 55 to 32 | source: B Yearly sheets (89.7 to 17.5; 66.6 to 31.9; 54.9 to 31.7) | status: verified
F7 | Deck OIC whole period: MAAP 64 percent first-time vs 52 percent all other schools, gap nearly 12 points (11.56), rank 3 of 76; all other schools 52.4 percent exact | source: B MAAP scorecard | status: verified
F8 | Deck OIC overall pass rate with retakes 89.6 percent (nearly 90), rank 2 of 76 | source: B MAAP scorecard | status: verified
F9 | Deck Management: MAAP 59.5 vs 47 percent, size-adjusted rank 1 of 54 | source: B MAAP scorecard | status: verified
F10 | Engine OIC: MAAP 63.8 vs 53.8 percent, size-adjusted rank 4 of 74, overall pass rate 93.6 percent ranking 2nd | source: B MAAP scorecard | status: verified
F11 | Engine Management: MAAP 57 (56.9) vs 45 (44.9) percent, rank 5 of 59 | source: B MAAP scorecard | status: verified
F12 | Among schools of comparable size, MAAP ranks 1 of 8 in Deck OIC and 1 of 7 in Engine OIC | source: A narration | status: UNVERIFIED (not in the workbook; author's statement)
F13 | Recovery after a first-time failure: Deck OIC MAAP 71 vs typical 52 percent; Engine OIC 82 vs 61; Engine Management 76 vs 65 | source: B Deck-OIC-first / Engine-OIC-first / Engine-Management-first (recovery column, median of eligible schools) | status: verified
F14 | MAAP lead over all other schools in points, by year 2020 to 2025: Deck OIC 12.7, 16.8, 12.6, 8.1, 15.6, 6.5 | source: B Yearly Deck-OIC | status: verified
F15 | Deck Management lead: 10.3, 15.3, 12.5, 15.8, 18.3, 7.9 | source: B Yearly Deck-Management | status: verified
F16 | Engine Management lead: 2.9, 21.7, 7.7, 11.0, 16.7, 8.3 | source: B Yearly Engine-Management | status: verified
F17 | Engine OIC lead: -1.4 (2020, 46 MAAP takers), 6.7, 8.1, 11.3, 14.6, 10.3 | source: B Yearly Engine-OIC | status: verified
F18 | 2025 fall in first-time pass rate, MAAP vs others (points): Deck OIC 23 vs 14 (57 to 34), Deck Management 20 vs 10, Engine Management 20 vs 12, Engine OIC 24 vs 20 | source: B Yearly sheets (Engine OIC MAAP fall is 24.5, narration says 24) | status: verified
F19 | Lead narrowed from 2024 to 2025 on every exam; Deck OIC from 15.6 (nearly 16) to 6.5 | source: B Yearly sheets | status: verified
F20 | Trend test: only Engine OIC shows a clear pattern (improving); six data points | source: A narration | status: UNVERIFIED (the test itself is not in the workbook)
F21 | Deck OIC 2025: MAAP first-time pass rate 34 percent, fewer than 35 percent, two out of three did not pass | source: B Yearly Deck-OIC | status: verified
F22 | Illustrative funnel icon and ranking bars in the method scene are drawings, not data | source: n/a | status: verified
F23 | Example figures on the "Comparing schools" scene: 10 graduates, 1,000 graduates, 5 takers with 100 percent, 1,000 takers with 85 percent | source: A narration (illustrative examples used in the script) | status: verified
F24 | Year-by-year panels: MAAP and others rates 2020 to 2025 (96/84, 92/75, 72/59, 64/56, 57/42, 34/28) | source: B Yearly Deck-OIC | status: verified
F25 | Years 2019, 2020, 2021, 2022, 2023, 2024, 2025 and 2026 as labels | source: n/a | status: verified
