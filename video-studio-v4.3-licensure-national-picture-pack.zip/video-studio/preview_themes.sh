#!/bin/sh
# See every look as still images (no video render).   sh preview_themes.sh
# (Same tool as on a Windows PC: python3 studio.py preview)
cd "$(dirname "$0")"
exec python3 studio.py preview "$@"
