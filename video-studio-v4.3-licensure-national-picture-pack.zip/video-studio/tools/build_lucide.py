#!/usr/bin/env python3
"""Rebuild scripts/lucide_icons.json from the Lucide icon set (you never need this; the converted data ships in the pack).
   npm pack lucide-static   (or download https://registry.npmjs.org/lucide-static/latest), unpack it, then:
   python tools/build_lucide.py path/to/package
Every shape becomes SVG path data on Lucide's 24 x 24 grid; tiny filled circles become 'dots'."""
import json, os, sys

def f(x): return f"{float(x):.3f}".rstrip("0").rstrip(".")

def to_path(tag, a):
    if tag == "path": return a["d"]
    if tag == "circle":
        cx, cy, r = float(a["cx"]), float(a["cy"]), float(a["r"])
        return f"M{f(cx - r)} {f(cy)}a{f(r)} {f(r)} 0 1 0 {f(2 * r)} 0a{f(r)} {f(r)} 0 1 0 {f(-2 * r)} 0Z"
    if tag == "ellipse":
        cx, cy, rx, ry = (float(a[k]) for k in ("cx", "cy", "rx", "ry"))
        return f"M{f(cx - rx)} {f(cy)}a{f(rx)} {f(ry)} 0 1 0 {f(2 * rx)} 0a{f(rx)} {f(ry)} 0 1 0 {f(-2 * rx)} 0Z"
    if tag == "line": return f"M{f(a['x1'])} {f(a['y1'])}L{f(a['x2'])} {f(a['y2'])}"
    if tag in ("polyline", "polygon"):
        nums = a["points"].replace(",", " ").split(); pts = [(nums[i], nums[i + 1]) for i in range(0, len(nums) - 1, 2)]
        return "M" + "L".join(f"{f(x)} {f(y)}" for x, y in pts) + ("Z" if tag == "polygon" else "")
    if tag == "rect":
        x, y, w, h = (float(a[k]) for k in ("x", "y", "width", "height")); rx = float(a.get("rx", a.get("ry", 0))); ry = float(a.get("ry", rx))
        if rx <= 0: return f"M{f(x)} {f(y)}H{f(x + w)}V{f(y + h)}H{f(x)}Z"
        return (f"M{f(x + rx)} {f(y)}H{f(x + w - rx)}A{f(rx)} {f(ry)} 0 0 1 {f(x + w)} {f(y + ry)}V{f(y + h - ry)}A{f(rx)} {f(ry)} 0 0 1 {f(x + w - rx)} {f(y + h)}"
                f"H{f(x + rx)}A{f(rx)} {f(ry)} 0 0 1 {f(x)} {f(y + h - ry)}V{f(y + ry)}A{f(rx)} {f(ry)} 0 0 1 {f(x + rx)} {f(y)}Z")
    raise ValueError(tag)

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "package"; nodes = json.load(open(os.path.join(src, "icon-nodes.json"))); tags = json.load(open(os.path.join(src, "tags.json")))
    ver = json.load(open(os.path.join(src, "package.json")))["version"]; icons = {}
    for name, els in nodes.items():
        paths, dots = [], []
        for tag, a in els:
            if tag == "circle" and a.get("fill") and float(a["r"]) <= 1.0: dots.append([round(float(a["cx"]), 3), round(float(a["cy"]), 3), round(float(a["r"]), 3)])
            else: paths.append(to_path(tag, a))
        icons[name] = [paths, dots]
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts", "lucide_icons.json")
    json.dump(dict(version=ver, source="https://lucide.dev (ISC licence, see LICENSE-lucide.txt)", icons=icons, tags={k: tags.get(k, []) for k in icons}), open(out, "w"), separators=(",", ":"))
    print(f"{len(icons)} icons (Lucide {ver}) -> {os.path.abspath(out)}")

if __name__ == "__main__": main()
