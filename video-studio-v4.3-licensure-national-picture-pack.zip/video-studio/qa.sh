#!/bin/sh
# Check the finished video (frozen picture, black gaps, flashes, loudness).   sh qa.sh
cd "$(dirname "$0")"
exec python3 studio.py qa "$@"
