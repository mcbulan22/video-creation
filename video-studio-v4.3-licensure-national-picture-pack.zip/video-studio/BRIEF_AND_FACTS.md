# Director's brief and facts file (v4.3)

Good videos start before the first scene. Two short files do that work, and a checker keeps every number honest.

1. **Brief** (`inbox/brief.md`, template: `inbox/brief_TEMPLATE.md`): audience, the ONE takeaway, length, look and mood, tone, must-include, must-avoid, ending.
2. **Facts** (`inbox/facts.md`, template: `inbox/facts_TEMPLATE.md`): one line for every number, name, date or claim that will be seen or heard, copied from your source, with where it came from and `verified` or `UNVERIFIED`.
3. **Scenes** (`inbox/scenes.py`): written only after you have corrected the brief and the facts. Numbers come from facts.md. Figures that reach the screen through a loop or variable live in a module-level `FIGURES = {...}` block so the checker can read them.

## How you use it with Claude
Paste CHAT_PROMPT.md. Claude asks at most five questions, then shows you `brief.md` and `facts.md` to correct. Only after you say "go" does it write the scenes.
Claude cannot see your documents unless you attach them. Never let it fill gaps with guesses: an unknown figure should be marked UNVERIFIED or left out.

## The number check
`python studio.py facts` (also runs before every `make` and `render`; `facts.sh` / `facts.bat`) lists any number in the narration, on-screen text, data tools or FIGURES block that is not in facts.md.
- `WARN ... is not in the facts file`: confirm it or remove it.
- `WARN ... only matches an UNVERIFIED fact`: verify the fact, then remove the UNVERIFIED mark.
- Whole numbers 0 to 10 are not checked. A scene that says "Example data" on screen is skipped (made-up numbers must be labelled).
It checks that numbers come from your file, not that your file is correct: you are the one who confirms the source.

## The anti-generic guide
`reference/anti-generic.md`: what to avoid (the same fade-up on everything, three equal cards on every scene, decorative motion) and what to do instead. Claude reads it before writing scenes.
