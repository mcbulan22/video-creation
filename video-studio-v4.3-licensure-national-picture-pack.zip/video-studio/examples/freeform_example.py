"""FREEFORM example: a deck with its OWN look and custom effects, written as code (no theme file needed).
Render it:   sh make.sh --scenes examples/freeform_example.py --draft        (PC: make.bat ... same flags)
It shows: set_look (palette + hooks), per-scene bg / fg / trans hooks, fx.particles / flowfield / network / waveform,
S.text_anim with presets and a custom function, SVG paths that draw themselves, and a keyframed camera.
Read FREEFORM.md for the rules (everything must be a pure function of time).  Cheat sheet of tools: KIT.md"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *
import engine as E
import motion_kit as K

THEME = "aurora"          # base look for cards, headings and chrome; everything below is layered on top of it
DECK_TITLE = "Freeform Motion Demo"


# ------------------------------------------------------------------ this deck's own look
def my_background(c):                       # static (cached once): deep plum gradient
    pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, H)], [hexc(C["bg2"]), hexc(C["bg1"])]))
    c.drawRect(skia.Rect.MakeWH(W, H), pt); fx.vignette(c, 0.5)

def my_fx(c, T):                            # live ambient layer, drawn behind every scene
    fx.mesh_gradient(c, T, ("teal", "sky", "amber"), base="bg1", blobs=4, alpha=0.26, speed=0.10, seed=4)
    fx.stars(c, T, n=70, seed=6, alpha=0.6); fx.light_streaks(c, T, n=5, alpha=0.05)

def my_transition(c, t, sc):                # scene change: pink blinds, then a ring burst
    K.tr_shutters(c, t, C["teal"], bars=8, dur=0.6, stagger=0.04); K.tr_burst(c, t, C["amber"], 0.7)

set_look(
    palette=dict(bg1="#0B0614", bg2="#1E0F36", card="#1E1233", edge="#6B4A9A", white="#FFF6F0", mute="#BFAED0", dark="#0B0614",
                 teal="#FF4D8D", amber="#FFC857", sky="#5CC8FF", green="#7CFFB2", red="#FF7A7A"),
    background=my_background, fx=my_fx, transition=my_transition, transition_dur=0.75,
)


# Figures that reach the screen live in one block, so `python studio.py facts` can check them against inbox/facts.md
FIGURES = dict(assessed=1250, validated=98, sessions=24)


def heading(S, s, p, y=215): S.text(s, 960, y, 62, "white", "b", "c", p, maxw=1600)


# ------------------------------------------------------------------ 1 title: scene-level bg hook with rays and rising sparks
def title_bg(c, t, T):
    fx.sunburst(c, T, 960, 700, rays=20, r0=80, r1=1500, color="amber", alpha=0.07, spin=0.03)
    fx.particles(c, T, region=(0, 700, W, 1080), n=120, seed=3, life=4.0, speed=(50, 140), angle=(-1.85, -1.3), size=(2, 6),
                 colors=("teal", "amber", "sky"), glow=1.0, fade=0.3)

@scene("FREEFORM", [
    "This deck has its own look, built from code instead of a theme file.",
    "Letters, lines, particles and cameras are all written for this one video.",
], sky=True, bg=title_bg, live=True)
def s_title(S):
    S.text_anim("Freeform Motion", 960, 330, 128, "white", "b", "c", S.p(0, 1.4), fn="scatter", spread=0.7)
    S.kinetic("Effects written as code, just for this video", 960, 430, 44, "mute", "m", "c", S.p(1, 0.9), mode="blur")
    S.ship(960, 640 - 34, 0.85, "dark", S.p(1, 0.8))


# ------------------------------------------------------------------ 2 letter by letter
def stretch_drop(i, n, q, ch, t):           # your own function: letters fall in, tilting alternately
    e = fx.ease("out_back", q)
    return dict(dy=-(1 - e) * 300, rot=(1 - e) * 0.7 * (1 if i % 2 else -1), a=fx.clamp(q * 4))

@scene("LETTERS", [
    "Every letter can have its own motion.",
    "Wave, spin, glitch and flip are ready made.",
    "Or write your own rule, and letters fall in tilting left and right.",
])
def s_letters(S):
    heading(S, "Every letter has its own motion", S.p(0))
    rows = [("WAVE", "Letters ride a wave", "wave", 1, 350), ("SPIN", "Letters spin into place", "spin", 1, 450),
            ("GLITCH", "Letters glitch into focus", "glitch", 1, 550), ("FLIP", "Letters flip over", "flip", 1, 650)]
    for lab, txt, fn, beat, y in rows:
        p = S.p(beat, 1.2, 0.18 * rows.index((lab, txt, fn, beat, y)))
        S.text(lab, 140, y, 26, "mute", "m", "l", min(1.0, p * 3))
        S.text_anim(txt, 980, y, 50, "white", "b", "c", p, fn=fn)
    S.text("CUSTOM", 140, 790, 26, "mute", "m", "l", S.p(2))
    S.text_anim("Your own rule, your own motion", 980, 790, 50, "amber", "b", "c", S.p(2, 1.4), fn=stretch_drop, spread=0.8)


# ------------------------------------------------------------------ 3 SVG that draws itself
COMPASS_RING = "M -100 0 A 100 100 0 1 1 100 0 A 100 100 0 1 1 -100 0 Z M 0 -100 L 0 -82 M 100 0 L 82 0 M 0 100 L 0 82 M -100 0 L -82 0"
COMPASS_NEEDLE = "M 0 -68 L 24 0 L 0 68 L -24 0 Z"
WAVE = "M 0 0 C 60 -60 120 60 180 0 S 300 -60 360 0 S 480 60 540 0"
SHIP = "M -130 20 L 130 20 L 96 74 L -96 74 Z M -70 20 L -70 -22 L 24 -22 L 24 20 M 44 20 L 44 -62 L 78 -62 L 78 20 M -30 -22 L -30 -52 L -4 -52 L -4 -22"

@scene("DRAW ANYTHING", [
    "Any shape written as an SVG path can draw itself, line by line.",
    "A compass, a wave line, and a ship, each drawn from a few lines of code.",
])
def s_draw(S):
    heading(S, "Draw anything, line by line", S.p(0))
    p1, p2, p3 = S.p(0, 1.6, 0.3), S.p(1, 1.4), S.p(1, 1.6, 0.25)
    S.svg(COMPASS_RING, 360, 560, 1.15, p1, "sky", 6)
    S.svg(COMPASS_NEEDLE, 360, 560, 1.15, S.p(0, 1.2, 1.1), "teal", 5, fill="teal", fill_a=0.9, glow=1)
    S.svg(WAVE, 960 - 270 * 1.0, 560, 1.0, p2, "teal", 8, glow=1)
    S.svg(SHIP, 1560, 570, 1.2, p3, "amber", 6, fill="amber", fill_a=0.25, glow=1)
    for x, lab, p in ((360, "Compass", p1), (960, "Wave", p2), (1560, "Ship", p3)):
        S.text(lab, x, 800, 32, "white", "m", "c", S.p(0 if x == 360 else 1, 0.6, 0.5))


# ------------------------------------------------------------------ 4 flow-field scene bg, keyframed camera, scene fg and own transition
def field_bg(c, t, T): fx.flowfield(c, T, "teal", n=90, steps=22, alpha=0.30, seed=2, color2="sky")
def scan_fg(c, t, bs): fx.scanlines(c, 0.035)

@scene("CAMERA", [
    "A flow field drifts behind the scene.",
    "The camera glides slowly across the cards.",
    "Everything is a function of time, so every frame is exact.",
], bg=field_bg, fg=scan_fg, live=True)
def s_camera(S):
    heading(S, "Cameras and flow fields", S.p(0))
    cam = fx.cam(S.t, [(0.0, (1.0, 960, 540)), (7.0, (1.08, 990, 545), "in_out_sine")], shake=2.0)       # zoom blends in log space; a little hand-held drift
    with fx.camera(S.c, *cam):
        for i, (v, lab, ic, col) in enumerate([(FIGURES["assessed"], "Cadets assessed", "users", "teal"), (FIGURES["validated"], "Items validated", "shield-check", "green"), (FIGURES["sessions"], "Exam sessions", "calendar-check", "amber")]):
            S.stat(v, lab, 160 + i * 560, 400, 480, 250, S.p(1, 0.9, 0.18 * i, ease="spring_snappy"), col, "{:,.0f}", "%" if v == FIGURES["validated"] else "", ic, S.p(1, 1.5, 0.18 * i))
    S.text("Smooth, exact, repeatable", 960, 860, 36, "mute", "m", "c", S.p(2))


# ------------------------------------------------------------------ 5 network, waveform, particle burst
def net_bg(c, t, T): fx.network(c, T, n=44, seed=5, color="sky", link=210, alpha=0.5)

@scene("YOUR TURN", [
    "Connected networks, signals and bursts all come from the same toolbox.",
    "Give me your material and I will write the effects for it.",
], bg=net_bg, live=True)
def s_end(S):
    S.text_anim("Let us build yours", 960, 420, 104, "white", "b", "c", S.p(0, 1.3, ease="spring_gentle"), fn="wave")
    fx.waveform(S.c, 360, 760, 1200, 170, S.t, bars=60, color="teal", alpha=0.85 * S.p(0, 0.8, 0.5))
    S.kinetic("Send the material and choose the mood", 960, 600, 44, "mute", "m", "c", S.p(1, 0.9), mode="rise")
    fx.particles(S.c, S.t, origin=(960, 470), n=160, seed=9, life=2.2, speed=(180, 520), angle=(-3.14, 0.0), gravity=620, size=(5, 11),
                 colors=("teal", "amber", "sky", "green"), shape="rect", start=S.bs[1], end=S.bs[1] + 0.2, fade=0.12)
