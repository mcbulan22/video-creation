"""MAAP-SEAS Orientation and Assessment Familiarization - explainer scenes.
Narration is the exact beat text. Visuals appear with the beat they belong to."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *

DECK_TITLE = "MAAP-SEAS Familiarization"


def heading(S, s, p):
    S.text(s, 960, 230, 60, "white", "b", "c", p, maxw=1600)


def rows(S, labels, beat_for, y0=300, gap=110, numbered=True, stagger=0.0, color="edge", h=96):
    """Stacked cards, each revealed on its own beat (beat_for[i])."""
    for i, lab in enumerate(labels):
        y = y0 + i * gap
        p = S.p(beat_for[i], 0.6, stagger * i)
        S.rr(120, y, 1680, h, 18, "card", color, 2, p)
        base = y + h / 2 + 11
        tx = 170
        if numbered:
            S.text(str(i + 1), 165, base, 36, "teal", "b", "l", p)
            tx = 225
        S.text(lab, tx, base, 32, "white", "m", "l", p, maxw=1620 - (tx - 120))


# 1 -------------------------------------------------------------- horizon title
@scene("INTRODUCTION", [
    "Welcome to the MAAP-SEAS Orientation and Assessment Familiarization.",
    "This video is for students who were not able to attend the classroom orientation.",
    "It explains what MAAP-SEAS is, how exams are set up, and what Safe Exam Browser does. Then it walks you through the course and the practice activities.",
], sky=True)
def s_intro(S):
    S.glow(960, 300, 380, "teal", 0.18, S.p(0, 1.2))
    S.text("MAAP-SEAS", 960, 300, 120, "white", "b", "c", S.p(0))
    S.text("Orientation and Assessment Familiarization", 960, 380, 44, "teal", "m", "c", S.p(1))
    S.ship(960, 640 - 34, 0.85, "dark", S.p(2))
    S.text("Maritime Academy of Asia and the Pacific", 960, 880, 30, "white", "r", "c", S.p(2, 0.6, 0.3))


# 2 -------------------------------------------------------------- what is it
@scene("WHAT IS MAAP-SEAS", [
    "MAAP-SEAS stands for MAAP Student's Electronic Assessment System. It is the official online platform the Academy uses to deliver examinations and assessments.",
    "You will meet it in term examinations, course outcome assessments, continuous assessments, and comprehensive examinations.",
    "Its purpose is to make assessment organized, controlled, and fair. It is not meant to make exams harder.",
])
def s_what(S):
    heading(S, "What is MAAP-SEAS?", S.p(0))
    rows(S, ["Term examinations", "Course outcome assessments",
             "Continuous assessments", "Comprehensive examinations"],
         beat_for=[1, 1, 1, 1], y0=320, gap=115, numbered=False, stagger=0.25)
    S.text("Organized, controlled, and fair", 960, 880, 34, "amber", "m", "c", S.p(2))


# 3 -------------------------------------------------------------- five restrictions
@scene("HOW EXAMS ARE SET UP", [
    "There are five restrictions on how an exam is set up. You cannot simply open an exam whenever you want.",
    "First, date and time. An exam can only be accessed during its scheduled period. Once it closes, access is disabled.",
    "Second, the password. Some exams require one from the proctor or instructor. Do not guess it. Wait for instructions.",
    "Third, the time limit. The timer shows the remaining time. When it runs out, the system submits automatically.",
    "Fourth, the number of attempts. Most official exams allow only one. Check the instructions before you click begin.",
    "Fifth, Safe Exam Browser. When SEB is required, the exam must be opened through the secure browser.",
])
def s_setup(S):
    heading(S, "Five restrictions on every exam", S.p(0))
    rows(S, [
        "Date and time: only during the scheduled period",
        "Password: provided by the proctor or instructor",
        "Time limit: the system submits when time runs out",
        "Attempts: most official exams allow only one",
        "Safe Exam Browser: required when the exam calls for it",
    ], beat_for=[1, 2, 3, 4, 5], y0=310, gap=105)


# 4 -------------------------------------------------------------- SEB
@scene("WHAT IS SEB", [
    "Safe Exam Browser, or SEB, is a secure application. It is required for most MAAP-SEAS assessments.",
    "While it is active, it restricts other applications, websites, and certain system functions, so every student works under the same conditions.",
    "If a red screen appears, do not panic. It means SEB has detected an issue that needs attention. Stay calm, inform your proctor immediately, and do not try to fix it yourself.",
])
def s_seb(S):
    heading(S, "Safe Exam Browser (SEB)", S.p(0))
    rows(S, [
        "Required for most MAAP-SEAS assessments",
        "Blocks other applications and websites",
        "Red screen: stay calm and tell your proctor",
    ], beat_for=[0, 1, 2], y0=340, gap=130)


# 5 -------------------------------------------------------------- preparation
@scene("PREPARE IN ADVANCE", [
    "Before any exam that requires SEB, install the correct version on your device and check that it meets MAAP's requirements.",
    "Do not wait until the exam has started to install or troubleshoot. Arrive early, and have your device, password, and required application ready.",
])
def s_prepare(S):
    heading(S, "Prepare before exam day", S.p(0))
    rows(S, [
        "Install the correct SEB version",
        "Check that your device meets MAAP's requirements",
        "Know your username and current password",
        "Arrive early with everything ready",
    ], beat_for=[0, 0, 1, 1], y0=320, gap=115, numbered=False, stagger=0.3)


# 6 -------------------------------------------------------------- two addresses
@scene("ACCESSING MAAP-SEAS", [
    "There are two addresses. Use the inside-campus address when you are connected to the MAAP campus network.",
    "Use the outside-campus address when you are connected from outside campus. Both lead to the same platform, so check which one you are using.",
])
def s_address(S):
    heading(S, "Two addresses, one platform", S.p(0))
    for i, (label, url) in enumerate([
        ("Inside campus network", "http://192.168.1.20/seas/login/index.php"),
        ("Outside campus network", "http://203.177.24.69/seas/login/index.php"),
    ]):
        y = 320 + i * 260
        p = S.p(i)
        S.rr(120, y, 1680, 200, 20, "card", "edge", 2, p)
        S.text(label, 170, y + 75, 32, "teal", "m", "l", p)
        S.text(url, 170, y + 150, 36, "white", "r", "l", p, maxw=1600)


# 7 -------------------------------------------------------------- login
@scene("LOGGING IN", [
    "Open the address that matches your network. This brings you to the MAAP-SEAS login page.",
    "Enter your username. Use the one assigned to you.",
    "For your first login, use the default password provided by MAAP. The system will then ask you to change it.",
    "Create your own password and keep it private. Never use someone else's account.",
])
def s_login(S):
    heading(S, "Logging in", S.p(0))
    S.rr(420, 330, 1080, 110, 16, "card", "edge", 2, S.p(1))
    S.text("Username: the one assigned to you", 470, 398, 32, "white", "m", "l", S.p(1))
    S.rr(420, 480, 1080, 110, 16, "card", "edge", 2, S.p(2))
    S.text("Password: default on first login", 470, 548, 32, "white", "m", "l", S.p(2))
    S.rr(420, 630, 1080, 110, 16, "card", "amber", 2, S.p(3))
    S.text("Change it at once and keep it private", 470, 698, 32, "amber", "m", "l", S.p(3))


# 8 -------------------------------------------------------------- finding the course
@scene("FINDING THE COURSE", [
    "After you log in, go to Home, then CCA courses, and open MAAP-SEAS Orientation and Assessment Familiarization. You do not need an enrollment key.",
    "The course contains three presentations, two practice assessments, the Feedback Questionnaire, and a page with the ten steps for SEB.",
])
def s_course(S):
    S.text("Home  >  CCA courses  >  Orientation course", 960, 230, 40, "teal", "m", "c", S.p(0), maxw=1600)
    rows(S, [
        "Three presentations",
        "Two practice assessments",
        "Feedback Questionnaire",
        "Ten steps to take your exam using SEB",
    ], beat_for=[1, 1, 1, 1], y0=320, gap=115, numbered=False, stagger=0.25)


# 9 -------------------------------------------------------------- practice vs restricted
@scene("PRACTICE AND RESTRICTED", [
    "The Open Assessment, Practice Only, has no password, no time limit, and unlimited attempts. Use it to explore the question types.",
    "The Restricted Assessment follows a normal exam setup. It has a scheduled period, a password, a requirement to use SEB, and one attempt only.",
    "Read the dates on the course page before you start. Do not begin the restricted activity casually, because it can be taken only once.",
])
def s_compare(S):
    heading(S, "Two practice activities", S.p(0))
    p1 = S.p(1)
    S.rr(120, 320, 800, 540, 20, "card", "teal", 3, p1)
    S.text("Open Assessment (Practice Only)", 160, 395, 30, "teal", "b", "l", p1, maxw=720)
    for j, t in enumerate(["No password", "No time limit", "Unlimited attempts"]):
        S.text(t, 160, 490 + j * 80, 32, "white", "r", "l", p1)
    p2 = S.p(2)
    S.rr(980, 320, 820, 540, 20, "card", "amber", 3, p2)
    S.text("Restricted Assessment (Normal Setup)", 1020, 395, 30, "amber", "b", "l", p2, maxw=740)
    for j, t in enumerate(["Scheduled period", "Password required", "SEB required", "One attempt only"]):
        S.text(t, 1020, 490 + j * 80, 32, "white", "r", "l", p2)


# 10 ------------------------------------------------------------- steps 1-5
@scene("TEN STEPS WITH SEB, PART ONE", [
    "The orientation course has a page titled Ten Steps to Take Your Exam in MAAP-SEAS using Safe Exam Browser. Here is the first half.",
    "Step one. Open a regular web browser first, before the secure environment.",
    "Step two. Log in to MAAP-SEAS using the correct address for your network.",
    "Step three. Go to your course and find the exam you are scheduled to take.",
    "Step four. Click the exam to launch SEB, and follow the instructions shown.",
    "Step five. Log in again inside SEB. Autofill may be disabled, so enter your details manually if required.",
])
def s_steps1(S):
    heading(S, "Ten steps using SEB: part one", S.p(0))
    rows(S, [
        "Open a regular web browser",
        "Log in using the correct address",
        "Go to your course",
        "Click the exam to launch SEB",
        "Log in again inside SEB",
    ], beat_for=[1, 2, 3, 4, 5], y0=310, gap=105)


# 11 ------------------------------------------------------------- steps 6-10
@scene("TEN STEPS WITH SEB, PART TWO", [
    "Step six. Confirm the action needed to lock your device. Read the prompt carefully.",
    "Step seven. Click Attempt Quiz and enter the exam password when the proctor provides it.",
    "Step eight. Answer the questions, manage your time, and submit. Confirm that the submission is recorded.",
    "Step nine. Exit SEB using the approved procedure, then complete the feedback form when instructed.",
    "For official exams, arrive early and be ready before the scheduled start time.",
])
def s_steps2(S):
    heading(S, "Ten steps using SEB: part two", S.p(0))
    rows(S, [
        "Lock your device when prompted",
        "Click Attempt Quiz and enter the password",
        "Answer, submit, and confirm the submission",
        "Exit SEB, then complete the feedback form",
    ], beat_for=[1, 2, 3, 4], y0=320, gap=115)
    S.text("Arrive early and be ready on time", 960, 880, 34, "amber", "m", "c", S.p(4))


# 12 ------------------------------------------------------------- troubleshooting
@scene("WHEN SOMETHING GOES WRONG", [
    "Technical issues can happen. You might have trouble logging in, SEB might not open the exam, or the screen might freeze or turn red.",
    "Power or internet interruptions can also happen. If they do, stop interacting with the assessment and tell the proctor as soon as possible.",
    "Stay calm, inform your proctor first, and follow their instructions. Do not bypass the restrictions or force your way out of SEB. Do not assume your answers were saved or submitted.",
])
def s_trouble(S):
    heading(S, "If something goes wrong", S.p(0))
    rows(S, [
        "Difficulty logging in",
        "SEB not opening the exam",
        "Red screen",
        "Frozen or unresponsive screen",
        "Accidental exit from SEB",
        "Power or internet interruption",
    ], beat_for=[0, 0, 0, 0, 0, 1], y0=290, gap=84, numbered=False, stagger=0.1, h=72)
    S.text("Inform your proctor first", 960, 900, 34, "amber", "m", "c", S.p(2))


# 13 ------------------------------------------------------------- closing
@scene("FEEDBACK AND CLOSING", [
    "Complete the Feedback Questionnaire after your practice activities. Rate each item from one to five, with five the highest, and answer honestly.",
    "Check that the system confirms your response has been recorded.",
    "Remember the essentials: know your address, keep your password private, install SEB early, and inform your proctor if something goes wrong. Thank you, and prepare well for your assessments.",
])
def s_close(S):
    heading(S, "Before you finish", S.p(0))
    rows(S, [
        "[ ]  Logged in with the correct address",
        "[ ]  Reviewed the three presentations",
        "[ ]  Completed the practice and restricted activities",
        "[ ]  Submitted the Feedback Questionnaire",
    ], beat_for=[0, 0, 0, 0], y0=320, gap=115, numbered=False, stagger=0.2)
    S.text("Transforming Assessment. Empowering Competence.", 960, 880, 34, "amber", "m", "c", S.p(2))
