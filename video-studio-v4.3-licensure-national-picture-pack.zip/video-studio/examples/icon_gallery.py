"""Icon gallery: every curated Lucide icon drawn the way S.icon draws it. Render: sh make.sh --scenes examples/icon_gallery.py --draft
Pick names here, or search all 1,900 with: python scripts/find_icon.py <word>"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *

DECK_TITLE = "Icon Gallery"

GROUPS = {
 "maritime": [
  "ship",
  "ship-wheel",
  "ship-cargo",
  "anchor",
  "sailboat",
  "life-buoy",
  "lighthouse",
  "compass",
  "navigation",
  "map",
  "map-pin",
  "container",
  "fuel",
  "gauge",
  "thermometer",
  "wind",
  "cloud-lightning",
  "radio",
  "binoculars",
  "bridge",
  "fish",
  "droplets",
  "siren",
  "route"
 ],
 "education": [
  "graduation-cap",
  "book-open",
  "book-check",
  "school",
  "library",
  "notebook-pen",
  "pencil",
  "clipboard-check",
  "clipboard-list",
  "file-check",
  "award",
  "medal",
  "trophy",
  "presentation",
  "brain",
  "lightbulb",
  "target",
  "users",
  "user-check",
  "languages",
  "calculator",
  "microscope",
  "flask-conical",
  "atom"
 ],
 "safety": [
  "shield-check",
  "shield-alert",
  "hard-hat",
  "fire-extinguisher",
  "siren",
  "triangle-alert",
  "octagon-alert",
  "lock",
  "key-round",
  "eye",
  "bell-ring",
  "heart-pulse",
  "life-buoy",
  "badge-check",
  "circle-check",
  "ban",
  "scan-face",
  "bandage",
  "lighthouse",
  "alarm-smoke",
  "flashlight",
  "shield-half"
 ],
 "process": [
  "workflow",
  "git-branch",
  "list-checks",
  "route",
  "repeat",
  "refresh-cw",
  "arrow-right",
  "move-right",
  "play",
  "circle-play",
  "hourglass",
  "timer",
  "calendar-check",
  "flag",
  "rocket",
  "settings",
  "cog",
  "wrench",
  "hammer",
  "puzzle",
  "layers",
  "blocks"
 ],
 "people": [
  "user",
  "users",
  "user-round",
  "user-check",
  "user-plus",
  "contact",
  "handshake",
  "message-circle",
  "messages-square",
  "mic",
  "megaphone",
  "thumbs-up",
  "hand-helping",
  "heart-handshake",
  "face-slightly-smiling"
 ],
 "data": [
  "chart-bar",
  "chart-line",
  "chart-pie",
  "chart-column",
  "trending-up",
  "trending-down",
  "activity",
  "table",
  "database",
  "file-spreadsheet",
  "calculator",
  "percent",
  "sigma",
  "gauge",
  "scale",
  "search",
  "binary",
  "list-filter"
 ],
 "status": [
  "check",
  "circle-check",
  "circle-x",
  "circle-alert",
  "info",
  "clock",
  "loader",
  "bell",
  "star",
  "flag",
  "bookmark",
  "thumbs-up",
  "thumbs-down",
  "badge-question-mark"
 ],
 "documents": [
  "file-text",
  "file-check",
  "folder-open",
  "files",
  "clipboard",
  "scroll-text",
  "stamp",
  "file-badge",
  "archive",
  "paperclip",
  "printer",
  "mail",
  "send",
  "book-bookmark"
 ]
}
TITLES = {"maritime": "Maritime", "education": "Education", "safety": "Safety", "process": "Process", "people": "People", "data": "Data", "status": "Status", "documents": "Documents"}
COLORS = ["teal", "amber", "sky", "green", "red", "teal", "amber", "sky"]

def make_scene(key, idx):
    names = GROUPS[key]
    @scene(TITLES[key].upper(), [f"{TITLES[key]} icons. Every one draws itself, line by line."])
    def draw(S):
        S.text(f"{TITLES[key]} icons", 960, 205, 58, "white", "b", "c", S.p(0), maxw=1600)
        rows = (len(names) + 5) // 6
        for i, n in enumerate(names):
            r, c = divmod(i, 6); x = 220 + c * 296; y = 360 + r * 175
            p = S.p(0, 0.7, 0.15 + i * 0.03)
            S.icon(n, x, y, 70, COLORS[idx], p, bg="circle")
            S.text(n, x, y + 88, 21, "mute", "m", "c", p, maxw=270)
    return draw

for _i, _k in enumerate(GROUPS): make_scene(_k, _i)
