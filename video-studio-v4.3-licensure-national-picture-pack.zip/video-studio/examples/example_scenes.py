"""Minimal 3-scene example. Copy this file, replace the content, keep the structure.

Rules of thumb (see SKILL.md): one idea per beat; the beat text is the exact words the narrator says while
the visual appears; reveal with S.p(k, dur, delay); draw only with engine primitives; keep text >= 26 px.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *

DECK_TITLE = "Example Deck"

@scene("INTRO", [
    "Welcome to this short example of a scene-based explainer.",
    "Every visual appears exactly when the narrator reaches its words."])
def intro(S):
    p0 = S.p(0, .9)
    S.ship(960, 300, 1.2, "teal", p0)
    S.waves(560, 1360, 382, 10, "sky", .5 * p0, 3, 24)
    S.text("Scene-based explainers", 960, 640, 100, "white", "b", "c", S.p(0, .8, .25))
    S.text("Visuals timed to the script", 960, 715, 40, "mute", "r", "c", S.p(0, .8, .5))
    S.text("Each visual appears when its words are spoken.", 960, 870, 46, "white", "m", "c", S.p(1), maxw=1500)

@scene("COMPARE", [
    "Old approach: write the steps down.",
    "New approach: perform them and be observed.",
    "That shifts the evidence from words to performance."])
def compare(S):
    S.text("From writing to performing", 960, 200, 64, "white", "b", "c", S.p(0))
    S.rr(120, 300, 760, 300, 26, "card", "edge", 3, S.p(0)); S.text("WRITE the steps", 500, 430, 48, "mute", "b", "c", S.p(0))
    S.text("what you would do", 500, 485, 30, "mute", "r", "c", S.p(0))
    S.arrow(900, 450, 1020, 450, "amber", 8, S.p(1, .5))
    S.rr(1040, 300, 760, 300, 26, "card", "amber", 4, S.p(1)); S.text("PERFORM them", 1420, 430, 48, "amber", "b", "c", S.p(1))
    S.text("observed, in real time", 1420, 485, 30, "white", "r", "c", S.p(1))
    S.pill("STRONGER EVIDENCE OF COMPETENCE", 960, 780, 36, "teal", None, S.p(2))

@scene("ROADMAP", [
    "Here is a simple three-step roadmap.",
    "First, design the content.",
    "Second, build and review the scenes.",
    "Third, render and share."])
def roadmap(S):
    S.text("A simple roadmap", 960, 200, 64, "white", "b", "c", S.p(0))
    items = [("Design", "Script + scene list", 1), ("Build", "Review sheets, fix overlaps", 2), ("Render", "Clips, video, cues", 3)]
    for i, (a, b, k) in enumerate(items):
        x = 120 + i * 590; pg = S.p(0, .5, i * .15); pf = S.p(k)
        S.rr(x, 320, 540, 330, 28, "card", "teal" if pf > 0 else "edge", 4 if pf > 0 else 2, pg, dash=None if pf > 0 else [14, 12])
        S.circ(x + 70, 395, 38, "teal" if pf > 0 else "edge", None, 0, pg); S.text(str(i + 1), x + 70, 410, 42, "dark", "b", "c", pg)
        S.text(a, x + 130, 410, 42, "white", "b", "l", pf); S.text(b, x + 40, 540, 30, "mute", "r", "l", pf, maxw=470)
