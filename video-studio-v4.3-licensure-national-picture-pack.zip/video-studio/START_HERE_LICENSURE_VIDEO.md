# START HERE: "Are Our Graduates Failing the Licensure Exam?" video pack

This is the COMPLETE video-studio v4.3 pack with the new video already in `inbox/`:
- `inbox/scenes.py` (18 scenes, about 9 to 10 minutes; charts drawn from your workbook numbers)
- `inbox/brief.md` and `inbox/facts.md` (director's brief and the list of every number, with its source)
- `narration_script.txt` (every beat with the file name to record, if you use your own voice)

## Steps
1. Unzip. Drag everything inside the `video-studio` folder into your existing `video-studio` folder (Replace all; keep your hidden `.venv` folder). Or just use the unzipped folder and run setup once (Mac: `sh setup_mac.sh`, Windows: double-click `setup.bat`).
2. Choose the look (YOU pick the theme):
   - Mac: `sh preview_themes.sh` shows all looks as stills (output/theme_preview/overview.png)
   - then test: `sh make.sh --theme formal --draft`   (Windows: `make.bat --theme formal --draft`)
   - final: `sh make.sh --theme formal`
   Looks: clean (default), formal, editorial, aurora, ocean, techno, classroom, playful. For a management audience, formal / editorial / clean fit the calm tone; ocean gives the sunrise-and-dive opening.
3. Your own voice: record each beat named in narration_script.txt into `my_voice/`, then `sh make.sh --own-voice --theme formal`.
Result: `output/final_with_audio.mp4`.

## Notes
- In `inbox/facts.md`, F12 (comparable-size ranks 1st of 8 and 1st of 7) and F20 (trend test result) are marked UNVERIFIED: they come from your narration and are not in the workbook. Everything else was checked against the workbook.
- The computer voice may read "OIC" as a word. If so, use your own voice, or tell Claude to respell it in the beats.
- After a draft: `python3 studio.py qa` (sh qa.sh) writes output/qa_report.txt.
