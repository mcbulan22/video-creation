#!/bin/sh
# Motion report for every look.   sh motion_check.sh   |   sh motion_check.sh 3 1
# (Same tool as on a Windows PC: python3 studio.py motion)
cd "$(dirname "$0")"
exec python3 studio.py motion "$@"
