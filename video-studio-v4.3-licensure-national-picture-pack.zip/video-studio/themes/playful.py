"""PLAYFUL: bright, bouncy and friendly. Sticker-style cards, floating shapes, confetti, a cartoon ship and a smiling sun."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H
from _common import star_path, tri_path

HZ = 650
CONF = ["#FF5C8A", "#6C4BFF", "#FF9F1C", "#14B87A", "#2F9BFF", "#FFC83D"]


def _shapes():
    rnd = random.Random(12); out = []
    for _ in range(22):
        out.append((rnd.choice("ocrtsp"), rnd.random() * W, rnd.random() * H, rnd.uniform(16, 44), rnd.choice(CONF),
                    rnd.uniform(.5, 1.4), rnd.random() * 6.28, rnd.uniform(-40, 40)))
    return out
_SH = _shapes()


class Playful(Theme):
    name = "playful"
    label = "Playful: bright colours, bouncy pop-ins, sticker cards, confetti, cartoon ship"
    palette = dict(bg1="#FFF8E6", bg2="#FFEBC2", card="#FFFFFF", edge="#23284A", white="#23284A", mute="#7B80A6",
                   teal="#6C4BFF", amber="#FF6B35", red="#FF4D6D", green="#14B87A", sky="#2F9BFF", dark="#23284A")
    fonts = dict(l="Fredoka-Light", r="Fredoka-Regular", m="Fredoka-Medium", b="Fredoka-Bold")
    pop = 0.10; slide_in = 140; slide_out = 100; push = 0.02; transition_dur = 1.5
    # motion: Playful. Damped spring (about 15% overshoot, then a small dip), curved arcs, quick exits, background drifts against the slide.
    personality = "Playful: springy, about 15% overshoot, curved arcs"
    dur_scale = 0.85; dy_scale = 1.9; stagger_scale = 0.4; fade_out_scale = 0.6; text_lag = 1.15; arc = 26.0; parallax = 0.3
    def ease(self, x): return E.ease_spring(x, 6.0, 10.0)

    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        dot = skia.Paint(AntiAlias=True, Color=hexc("#FFD98A", .55))
        for row, y in enumerate(range(40, H, 96)):
            for x in range(40 + (48 if row % 2 else 0), W, 96): c.drawCircle(x, y, 13, dot)

    def fx(self, c, T):
        for kind, x0, y0, sz, col, sp, ph, rot in _SH:
            x = x0 + 24 * math.sin(.3 * T * sp + ph); y = y0 + 30 * math.sin(.5 * T * sp + ph * 1.7)
            c.save(); c.translate(x, y); c.rotate(rot * T * .3)
            fill = skia.Paint(AntiAlias=True, Color=hexc(col, .30))
            st = skia.Paint(AntiAlias=True, Color=hexc(col, .38)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(5); st.setStrokeCap(skia.Paint.kRound_Cap)
            if kind == "o": c.drawCircle(0, 0, sz * .6, fill)
            elif kind == "c": c.drawCircle(0, 0, sz * .6, st)
            elif kind == "r": c.drawRoundRect(skia.Rect.MakeXYWH(-sz / 2, -sz / 2, sz, sz), 9, 9, fill)
            elif kind == "t": c.drawPath(tri_path(0, 0, sz * .7), fill)
            elif kind == "s": c.drawPath(star_path(0, 0, sz * .75), fill)
            else: c.drawLine(-sz / 2, 0, sz / 2, 0, st); c.drawLine(0, -sz / 2, 0, sz / 2, st)
            c.restore()

    def _cloud(self, c, x, y, s, a=.95):
        pt = skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", a))
        c.drawRoundRect(skia.Rect.MakeXYWH(x - 90 * s, y, 180 * s, 46 * s), 23 * s, 23 * s, pt)
        c.drawCircle(x - 28 * s, y + 4 * s, 34 * s, pt); c.drawCircle(x + 26 * s, y - 4 * s, 42 * s, pt)

    def hero_bg(self, c, T):
        sky = skia.Paint(); sky.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, HZ)], [hexc("#7FD3FF"), hexc("#C6EEFF"), hexc("#FFF3C9")], [0, .6, 1]))
        c.drawRect(skia.Rect.MakeXYWH(0, 0, W, HZ), sky)
        sx, sy = 1590, 190 + 8 * math.sin(T)                           # smiling sun
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(sx, sy), 260, [hexc("#FFE27A", .6), hexc("#FFE27A", 0)], [0, 1])); c.drawCircle(sx, sy, 260, g)
        for k in range(12):
            a = T * .25 + k * math.pi / 6
            c.drawLine(sx + 118 * math.cos(a), sy + 118 * math.sin(a), sx + 152 * math.cos(a), sy + 152 * math.sin(a),
                       skia.Paint(AntiAlias=True, Color=hexc("#FFC83D"), StrokeWidth=9, StrokeCap=skia.Paint.kRound_Cap))
        c.drawCircle(sx, sy, 92, skia.Paint(AntiAlias=True, Color=hexc("#FFC83D")))
        c.drawCircle(sx, sy, 92, skia.Paint(AntiAlias=True, Color=hexc(C["dark"]), Style=skia.Paint.kStroke_Style, StrokeWidth=5))
        for dx in (-30, 30): c.drawCircle(sx + dx, sy - 14, 8, skia.Paint(AntiAlias=True, Color=hexc(C["dark"])))
        for dx in (-52, 52): c.drawCircle(sx + dx, sy + 18, 12, skia.Paint(AntiAlias=True, Color=hexc("#FF8FA8", .8)))
        sm = skia.Paint(AntiAlias=True, Color=hexc(C["dark"])); sm.setStyle(skia.Paint.kStroke_Style); sm.setStrokeWidth(6); sm.setStrokeCap(skia.Paint.kRound_Cap)
        c.drawArc(skia.Rect.MakeXYWH(sx - 38, sy - 10, 76, 56), 20, 140, False, sm)
        for x0, y0, s, v in ((300, 150, 1.0, 14), (1200, 80, .8, 9), (700, 470, .9, 11), (1700, 430, .7, 8)):
            self._cloud(c, (x0 + T * v) % (W + 400) - 200, y0, s)
        sea = skia.Paint(); sea.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ), skia.Point(0, H)], [hexc("#8BD3FA"), hexc("#5EBBF2")]))
        c.drawRect(skia.Rect.MakeXYWH(0, HZ, W, H - HZ), sea)
        for k, col in enumerate(("#B6E4FC", "#7FCBF6", "#4FB0EC")):
            pa = skia.Path(); y0 = HZ + 30 + k * 85; pa.moveTo(0, H); pa.lineTo(0, y0)
            for xx in range(0, W + 10, 10): pa.lineTo(xx, y0 + 14 * math.sin(xx / (110 + 20 * k) + T * (.9 + .2 * k) + k * 2))
            pa.lineTo(W, H); pa.close(); c.drawPath(pa, skia.Paint(AntiAlias=True, Color=hexc(col, .55)))
        rnd = random.Random(8)
        for _ in range(14):                                            # bubbles
            x0, y0, v, r = rnd.random() * W, HZ + rnd.random() * (H - HZ), rnd.uniform(14, 34), rnd.uniform(6, 16)
            y = HZ + 20 + ((y0 - HZ - T * v) % (H - HZ - 20)); x = x0 + 10 * math.sin(T + r)
            bs = skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .8)); bs.setStyle(skia.Paint.kStroke_Style); bs.setStrokeWidth(3); c.drawCircle(x, y, r, bs)
        for k in range(30):
            c.drawCircle(0, 0, 0, skia.Paint())

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); t = ctx.t
        outline = ctx.paint("dark", pp, 5)
        c.save(); c.translate(cx, cy + 55 * sc + (1 - p) * 30 + 5 * math.sin(1.4 * t)); c.rotate(2.2 * math.sin(1.2 * t)); c.translate(0, -55 * sc); c.scale(sc, sc)
        for u in range(3):                                              # smoke puffs
            q = (t * .55 + u / 3.0) % 1.0
            c.drawCircle(-12 + 22 * q + 8 * u, -102 - 80 * q, 10 + 18 * q, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .9 * (1 - q))))
        c.drawPath(g["hull"], ctx.paint("red", pp))
        c.save(); c.clipPath(g["hull"], doAntiAlias=True); c.drawRect(skia.Rect.MakeXYWH(-180, 16, 360, 14), ctx.paint("#FFFFFF", pp)); c.restore()
        c.drawPath(g["hull"], outline)
        for key, col in (("cabin", "#FFFFFF"), ("bridge", "sky"), ("funnel", "#FFC83D")):
            x, y, w, h, r = g[key]; rect = skia.Rect.MakeXYWH(x, y, w, h)
            c.drawRoundRect(rect, r, r, ctx.paint(col, pp)); c.drawRoundRect(rect, r, r, outline)
        x, y, w, h, r = g["funnel"]; c.drawRect(skia.Rect.MakeXYWH(x + 2, y + 12, w - 4, 9), ctx.paint("red", pp))
        for x, y, w, h in g["windows"]:
            c.drawCircle(x + w / 2, y + h / 2, 8, ctx.paint("sky", pp)); c.drawCircle(x + w / 2, y + h / 2, 8, ctx.paint("dark", pp, 3))
        c.restore(); return True

    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0); off = 7
        if fill:
            c.drawRoundRect(skia.Rect.MakeXYWH(rect.left() + off, rect.top() + off + 1, rect.width(), rect.height()), r, r, ctx.paint("dark", pp * fa))
            c.drawRoundRect(rect, r, r, ctx.paint(fill, p * fa))
        if stroke: c.drawRoundRect(rect, r, r, ctx.paint("dark" if stroke == "edge" else stroke, p, 4, dash))

    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 80:
            xx, yy, tw = info[-1]; q = max(0.0, min(1.0, p))
            n = int(tw * q / 6)
            if n > 2:
                pa = skia.Path()
                for k in range(n + 1):
                    x = xx + k * 6; y = yy + 26 + 6 * math.sin(x / 13.0 - ctx.t * 4)      # ambient: the squiggle wiggles
                    (pa.moveTo if k == 0 else pa.lineTo)(x, y)
                st = ctx.paint("amber", 1, 7); ctx.c.drawPath(pa, st)

    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        f = E.font("b", 22); tw = f.measureText(chapter)
        ch.c.drawRoundRect(skia.Rect.MakeXYWH(62, 40, tw + 44, 46), 23, 23, ch.paint("teal", .95 * a))
        ch.text(chapter, 84, 72, 22, "#FFFFFF", "b", "l", a, _rev=False, _deco=False)
        ch.c.drawCircle(W - 92, 64, 32, ch.paint("amber", a)); ch.text(str(i + 1), W - 92, 74, 26, "#FFFFFF", "b", "c", a, _rev=False, _deco=False)
        ch.text(deck, 70, 1050, 22, "mute", "m", "l", .8 * foot_a, _rev=False, _deco=False)

    def transition(self, c, t, sc):
        rnd = random.Random(sc["i"] * 101 + 7)
        if sc["i"] % 4 == 0:                                            # confetti rain on scenes 1, 5, 9, 13
            for _ in range(34):
                x0, y0 = rnd.uniform(150, W - 150), -30 - rnd.uniform(0, 260); vy, vx = rnd.uniform(520, 900), rnd.uniform(-110, 110)
                col, spin = rnd.choice(CONF), rnd.uniform(-8, 8); a = max(0.0, 1 - (t / 1.5) ** 3)
                c.save(); c.translate(x0 + vx * t, y0 + vy * t); c.rotate(spin * t * 60)
                c.drawRoundRect(skia.Rect.MakeXYWH(-8, -5, 16, 10), 3, 3, skia.Paint(AntiAlias=True, Color=hexc(col, a))); c.restore()
        elif t < 0.9:                                                   # colour ring pops from the centre
            u = E.ease(t / 0.9); st = skia.Paint(AntiAlias=True, Color=hexc(rnd.choice(CONF), .55 * (1 - u))); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(18 * (1 - u) + 2)
            c.drawCircle(W / 2, H / 2, 120 + 900 * u, st)


THEME = Playful()
