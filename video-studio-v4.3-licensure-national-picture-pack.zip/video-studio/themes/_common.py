"""Small drawing helpers shared by several themes (not a theme itself)."""
import math, random
import skia


def rrect_points(x, y, w, h, r, step=14):
    """Points walking clockwise around a rounded rectangle (closed)."""
    pts = []
    def arc(cx, cy, a0, a1):
        n = max(3, int(r * abs(a1 - a0) / step))
        for k in range(n + 1):
            a = a0 + (a1 - a0) * k / n; pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    def edge(x0, y0, x1, y1):
        n = max(1, int(math.hypot(x1 - x0, y1 - y0) / step))
        for k in range(1, n): pts.append((x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n))
    arc(x + r, y + r, math.pi, 1.5 * math.pi); edge(x + r, y, x + w - r, y)
    arc(x + w - r, y + r, 1.5 * math.pi, 2 * math.pi); edge(x + w, y + r, x + w, y + h - r)
    arc(x + w - r, y + h - r, 0, .5 * math.pi); edge(x + w - r, y + h, x + r, y + h)
    arc(x + r, y + h - r, .5 * math.pi, math.pi); edge(x, y + h - r, x, y + r)
    pts.append(pts[0]); return pts


def line_points(x0, y0, x1, y1, step=12):
    n = max(2, int(math.hypot(x1 - x0, y1 - y0) / step))
    return [(x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n) for k in range(n + 1)]


def arc_points(cx, cy, r, a0, a1, step=12):
    n = max(4, int(abs(a1 - a0) * r / step))
    return [(cx + r * math.cos(a0 + (a1 - a0) * k / n), cy + r * math.sin(a0 + (a1 - a0) * k / n)) for k in range(n + 1)]


def wobble(pts, amp, seed, freq=0.03):
    """Hand-drawn jitter along a polyline. Same seed = same wobble every frame (no flicker)."""
    rnd = random.Random(seed); ph = [rnd.random() * 6.28 for _ in range(4)]
    out, s, (px, py) = [], 0.0, pts[0]
    for (x, y) in pts:
        s += math.hypot(x - px, y - py); px, py = x, y
        out.append((x + amp * (math.sin(s * freq + ph[0]) + .5 * math.sin(s * freq * 2.7 + ph[1])),
                    y + amp * (math.sin(s * freq * 1.3 + ph[2]) + .5 * math.sin(s * freq * 3.1 + ph[3]))))
    return out


def stroke_poly(c, pts, paint, frac=1.0):
    """Draw the first `frac` of a polyline (frac<1 = the line is still being drawn)."""
    n = int(len(pts) * max(0.0, min(1.0, frac)))
    if n < 2: return
    pa = skia.Path(); pa.moveTo(*pts[0])
    for q in pts[1:n]: pa.lineTo(*q)
    c.drawPath(pa, paint)


def star_path(cx, cy, r, points=5, inner=0.45, rot=-math.pi / 2):
    pa = skia.Path()
    for k in range(points * 2):
        rr = r if k % 2 == 0 else r * inner; a = rot + k * math.pi / points
        (pa.moveTo if k == 0 else pa.lineTo)(cx + rr * math.cos(a), cy + rr * math.sin(a))
    pa.close(); return pa


def tri_path(cx, cy, r, rot=0.0):
    pa = skia.Path()
    for k in range(3):
        a = rot - math.pi / 2 + k * 2 * math.pi / 3
        (pa.moveTo if k == 0 else pa.lineTo)(cx + r * math.cos(a), cy + r * math.sin(a))
    pa.close(); return pa
