"""OCEAN: the original maritime look. Deep-sea blues, drifting light, rising particles.
The title scene is the sunrise horizon; when it ends the camera dives underwater."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H

_PART = []
def _particles():
    if not _PART:
        rnd = random.Random(7)
        for _ in range(36):
            _PART.append((rnd.random() * W, rnd.random() * H, rnd.uniform(14, 36), rnd.uniform(1.6, 4.0),
                          rnd.uniform(.07, .18), rnd.random() * 6.28))
    return _PART


class Ocean(Theme):
    name = "ocean"
    label = "Ocean: deep-sea blues, sunrise horizon, dive underwater (the original look)"
    horizon = True
    palette = {}          # the engine's built-in palette IS the ocean palette
    personality = "Fluid: floaty, small springy settle (original motion, unchanged)"

    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        ctx = E.Ctx(c, 0, [])
        ctx.waves(0, W, 1010, 8, "sky", 0.07, 3, 22)

    def fx(self, c, T):
        """Slow drifting light blobs + rising particles, driven by absolute video time T."""
        for cx, cy, r, col, a in [(W * (.22 + .10 * math.sin(.17 * T)), H * (.30 + .08 * math.cos(.13 * T)), 760, "teal", .13),
                                  (W * (.80 + .08 * math.cos(.11 * T)), H * (.70 + .10 * math.sin(.15 * T)), 820, "sky", .11),
                                  (W * (.55 + .12 * math.sin(.09 * T + 1)), H * (.15 + .06 * math.cos(.2 * T)), 520, "amber", .05)]:
            pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(C[col], a), hexc(C[col], 0)], [0, 1]))
            c.drawCircle(cx, cy, r, pt)
        for x0, y0, v, rad, a, ph in _particles():
            y = (y0 - T * v) % (H + 60) - 30; x = x0 + 18 * math.sin(.4 * T + ph)
            c.drawCircle(x, y, rad, skia.Paint(AntiAlias=True, Color=hexc(C["sky"], a)))

    def transition(self, c, t, sc):
        x = -520 + (W + 520) * E.ease(t / 0.75); sp = skia.Paint()
        sp.setShader(skia.GradientShader.MakeLinear([skia.Point(x, 0), skia.Point(x + 520, 0)], [hexc(C["teal"], 0), hexc(C["teal"], .95)]))
        c.drawRect(skia.Rect.MakeXYWH(x, 0, 520, 7), sp)


THEME = Ocean()
