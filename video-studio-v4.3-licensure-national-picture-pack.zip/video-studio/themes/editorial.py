"""EDITORIAL: bold print-magazine look. Warm paper, ink outlines, hard shadows, colour blocks, marker highlights, snappy wipes."""
import math, random
import skia
import engine as E
import motion_kit as K
from engine import Theme, hexc, C, W, H

HZ = 640
INK = "#111111"
_SNAP = E.bezier(0.2, 0.9, 0.1, 1)           # quick launch, firm stop


class Editorial(Theme):
    name = "editorial"
    label = "Editorial: warm paper, ink outlines, hard shadows, colour blocks, marker highlights, snappy wipes"
    palette = dict(bg1="#F4EFE6", bg2="#ECE5D6", card="#FFFFFF", edge=INK, white=INK, mute="#5A5A54",
                   teal="#FF4F2B", amber="#1F4BFF", red="#E11D48", green="#0F9D58", sky="#FFC83D", dark=INK)
    fonts = dict(l="Inter-Regular", r="Inter-Regular", m="Inter-Medium", b="PlayfairDisplay-Bold", n="Inter-Bold")   # n = lining figures for numbers
    num_w = "n"; glow_mult = 0.0
    pop = 0.02; slide_in = 40; slide_out = 40; push = 0.015; transition_dur = 0.8
    reveal = "words"; kin_mode = "rise"; kin_min = 52
    personality = "Editorial: snappy launch, firm stop, cards stamp down with a hard shadow"
    dur_scale = 0.7; dy_scale = 0.7; stagger_scale = 0.35; fade_out_scale = 0.6; text_lag = 1.1; parallax = 0.12
    def ease(self, x): return _SNAP(x)

    # ---- backgrounds
    def background(self, c):
        c.drawRect(skia.Rect.MakeWH(W, H), skia.Paint(Color=hexc(C["bg1"])))
        rnd = random.Random(2)
        for _ in range(2200):                                                  # paper grain
            c.drawCircle(rnd.random() * W, rnd.random() * H, rnd.uniform(.5, 1.4), skia.Paint(AntiAlias=True, Color=hexc("#6B5E48", rnd.uniform(.03, .09))))
        fr = skia.Paint(AntiAlias=True, Color=hexc(INK), Style=skia.Paint.kStroke_Style, StrokeWidth=3)
        c.drawRect(skia.Rect.MakeXYWH(36, 36, W - 72, H - 72), fr)              # printed frame
        for (x, y) in ((36, 36), (W - 36, 36), (36, H - 36), (W - 36, H - 36)):   # register marks
            c.drawLine(x - 18, y, x + 18, y, fr); c.drawLine(x, y - 18, x, y + 18, fr)

    def fx(self, c, T):
        def shape(kind, x, y, s, col, rot, filled=True):
            c.save(); c.translate(x, y); c.rotate(rot)
            pt = skia.Paint(AntiAlias=True, Color=hexc(C[col])); 
            if not filled: pt.setStyle(skia.Paint.kStroke_Style); pt.setStrokeWidth(5)
            if kind == "circle": c.drawCircle(0, 0, s, pt)
            elif kind == "square": c.drawRect(skia.Rect.MakeXYWH(-s, -s, 2 * s, 2 * s), pt)
            elif kind == "tri":
                pa = skia.Path(); pa.moveTo(0, -s); pa.lineTo(s, s * .8); pa.lineTo(-s, s * .8); pa.close(); c.drawPath(pa, pt)
            elif kind == "plus":
                pt.setStyle(skia.Paint.kStroke_Style); pt.setStrokeWidth(s * .45); c.drawLine(-s, 0, s, 0, pt); c.drawLine(0, -s, 0, s, pt)
            c.restore()
        shape("circle", 78 + 6 * math.sin(.7 * T), 330, 22, "teal", 0)                                   # margin confetti: kept out of the content area
        shape("tri", 1842, 250 + 8 * math.sin(.6 * T + 1), 24, "amber", 14 * T)
        shape("plus", 80, 790 + 6 * math.sin(.5 * T + 2), 20, "amber", 20 * T)
        shape("circle", 1842, 700, 26, "sky", 0, False)
        shape("square", 1844, 900 + 6 * math.sin(.8 * T), 15, "teal", 25 * T)
        shape("tri", 78, 560, 20, "sky", -18 * T, False)

    def hero_bg(self, c, T):
        E.draw_bg(c)
        c.drawCircle(960, 360, 280 + 6 * math.sin(.8 * T), skia.Paint(AntiAlias=True, Color=hexc(C["sky"])))       # sun disc
        c.drawCircle(960, 360, 280 + 6 * math.sin(.8 * T), skia.Paint(AntiAlias=True, Color=hexc(INK), Style=skia.Paint.kStroke_Style, StrokeWidth=4))
        sea = skia.Paint(AntiAlias=True, Color=hexc("#BDD0FF")); c.drawRect(skia.Rect.MakeXYWH(37, HZ, W - 74, H - HZ - 37), sea)
        c.drawLine(37, HZ, W - 37, HZ, skia.Paint(AntiAlias=True, Color=hexc(INK), StrokeWidth=5))
        for k in range(4):                                                      # scalloped ink waves that slide sideways
            y0 = HZ + 46 + k * 52; off = (T * (22 + 6 * k)) % 80
            pa = skia.Path(); xx = 37 - 80 + off; pa.moveTo(xx, y0)
            while xx < W - 37:
                pa.quadTo(xx + 20, y0 - 18, xx + 40, y0); pa.quadTo(xx + 60, y0 + 18, xx + 80, y0); xx += 80
            st = skia.Paint(AntiAlias=True, Color=hexc(INK, .75)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(3)
            c.save(); c.clipRect(skia.Rect.MakeXYWH(37, HZ + 6, W - 74, H - HZ - 43)); c.drawPath(pa, st); c.restore()
        fr = skia.Paint(AntiAlias=True, Color=hexc(INK), Style=skia.Paint.kStroke_Style, StrokeWidth=3); c.drawRect(skia.Rect.MakeXYWH(36, 36, W - 72, H - 72), fr)
        self.fx(c, T)

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 4 * math.sin(1.2 * ctx.t)
        c.save(); c.translate(cx, cy + (1 - p) * 30 + bob); c.scale(sc, sc)
        ink = ctx.paint("dark", pp)
        c.drawPath(g["hull"], ink)
        for k in ("cabin", "bridge"):
            x, y, w, h, r = g[k]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ink)
        x, y, w, h, r = g["funnel"]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ctx.paint("teal", pp))
        for x, y, w, h in g["windows"]: c.drawRect(skia.Rect.MakeXYWH(x, y, w, h), ctx.paint("sky", pp))
        c.restore(); return True

    # ---- cards: white paper, ink outline, hard offset shadow (coloured when the card has an accent border)
    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0); rr = min(r, 18)
        accent = stroke not in (None, "edge")
        if fill:
            off = 9 * pp; sh = skia.Rect.MakeXYWH(rect.left() + off, rect.top() + off, rect.width(), rect.height())
            c.drawRoundRect(sh, rr, rr, ctx.paint(stroke if accent else "dark", pp))
            c.drawRoundRect(rect, rr, rr, ctx.paint(fill, pp * fa))
            c.drawRoundRect(rect, rr, rr, skia.Paint(AntiAlias=True, Color=hexc(INK, pp), Style=skia.Paint.kStroke_Style, StrokeWidth=3.2))
        elif stroke:
            c.drawRoundRect(rect, rr, rr, skia.Paint(AntiAlias=True, Color=hexc(INK, pp), Style=skia.Paint.kStroke_Style, StrokeWidth=max(2.5, sw),
                                                     PathEffect=skia.DashPathEffect.Make(dash or [14, 10], 0)))

    # ---- big headings get a yellow marker swipe (multiply keeps the ink text black on top)
    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 100:
            xx, yy, tw = info[-1]; q = max(0.0, min(1.0, (p - 0.35) / 0.65))
            if q > 0.01:
                pt = ctx.paint("sky", .85); pt.setBlendMode(skia.BlendMode.kMultiply)
                ctx.c.drawRoundRect(skia.Rect.MakeXYWH(xx - 8, yy - size * .34, (tw + 16) * E.ease(q), size * .36), 6, 6, pt)

    # ---- chrome: numbered block + chapter, segmented page bar
    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        c = ch.c; c.drawRect(skia.Rect.MakeXYWH(70, 46, 54, 40), ch.paint("teal", a))
        c.drawRect(skia.Rect.MakeXYWH(70, 46, 54, 40), skia.Paint(AntiAlias=True, Color=hexc(INK, a), Style=skia.Paint.kStroke_Style, StrokeWidth=3))
        ch.text(f"{i + 1:02d}", 97, 76, 24, "white", "m", "c", a, _rev=False, _deco=False)
        ch.text(chapter.upper(), 140, 76, 24, "white", "m", "l", a, _rev=False, _deco=False)
        ch.text(deck, W - 70, 76, 22, "mute", "m", "r", .9 * foot_a, _rev=False, _deco=False)
        seg = (W - 140) / n
        for k in range(n):
            col = "teal" if k <= i else "edge"
            c.drawRect(skia.Rect.MakeXYWH(70 + k * seg + 2, 1054, seg - 6, 9), ch.paint(col, (a if k <= i else .25 * a)))

    def transition(self, c, t, sc):
        K.tr_wipe(c, t, [INK, C["sky"], C["teal"]], dur=0.62, skew=120, lag=0.06)


THEME = Editorial()
