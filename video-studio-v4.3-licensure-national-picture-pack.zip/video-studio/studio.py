#!/usr/bin/env python3
"""video-studio launcher: ONE tool for every computer (Mac, Windows PC, Linux).

  python studio.py setup              once per computer: private Python environment + checks
  python studio.py doctor             check this computer (Python, ffmpeg, voices, ...) and say what is missing
  python studio.py make  [options]    voice + picture + sound  ->  output/final_with_audio.mp4
  python studio.py render [options]   picture only (no sound)
  python studio.py wizard             asks you a few questions, then makes the video (best for double-clicking)
  python studio.py themes             list the looks          python studio.py voices   list the voices
  python studio.py preview            stills of every look    python studio.py motion   motion report
  python studio.py benchmark          measure THIS computer and estimate render times for every quality level
  python studio.py facts              check that every number in the video is in inbox/facts.md (also runs before every make / render)
  python studio.py qa                 check the finished video: frozen picture, black gaps, flashes, loudness (also runs after make / render)
  python studio.py clean              delete the output folder

Options for make / render:
  --theme NAME        clean (default), ocean, techno, classroom, formal, playful
  --draft             quick 720p test            --fx off      faster, calmer background
  --quality NAME      draft (720p), standard (1080p30, default), smooth (1080p60), cinema (motion blur), ultra (4K + blur)
  --workers N         how many render workers (default: chosen from your processor AND free memory)
  --engine NAME       voice: auto (default), mac, windows, edge (online neural), own, fake
  --voice NAME        voice name (see: python studio.py voices)       --own-voice   use YOUR recordings in my_voice
  --music FILE|pad    background music           --out DIR     output folder (default: output)
  --facts FILE        facts file for the number check (default: inbox/facts.md)
  --sfx rich|on|off   sound effects: rich = made-from-maths pops, whooshes, thuds, chime (default); on = whoosh only; off = none
  --sfx-level 0.6     make all sound effects quieter (1.0 = normal, 1.5 = louder)
  --no-open           do not open the folder at the end
  anything else (for example --only 3 --fps 8 --workers 2) is passed to the video builder.
Global option:  --computer auto|mac|windows|linux   (default auto: the launcher detects the computer it is on)

This file uses only the Python standard library, so it runs with any Python 3.9+ before setup.
"""
import argparse, os, re, shutil, subprocess, sys, urllib.request, zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import platform_utils as PU

SCRIPTS = os.path.join(ROOT, "scripts")
THEMES = os.path.join(ROOT, "themes")
NAMES = {"mac": "Mac", "windows": "Windows PC", "linux": "Linux computer"}


# ------------------------------------------------------------------------------------------------ helpers
def say(msg=""): print(msg, flush=True)

def die(msg, code=1):
    print("\n" + msg, flush=True); sys.exit(code)

def set_computer(choice):
    """Decide which computer we are on. 'auto' detects it; a named choice must match the real machine."""
    real = PU.detected_computer()
    if choice in (None, "", "auto"): comp = real
    else:
        comp = choice.lower()
        if comp not in NAMES: die(f"Unknown computer '{choice}'. Use: auto, mac, windows or linux.", 2)
        if comp != real:
            die(f"You said this is a {NAMES[comp]}, but this machine looks like a {NAMES[real]}.\n"
                f"Run again without --computer (it detects the computer by itself), or use --computer {real}.", 2)
    os.environ["VS_COMPUTER"] = comp
    return comp

def venv_python(comp):
    """Python of this computer's private environment. (A Mac's older single '.venv' from earlier packs is reused.)"""
    for d in [PU.venv_dir(comp)] + ([os.path.join(ROOT, ".venv")] if comp in ("mac", "linux") else []):
        py = os.path.join(d, "Scripts", "python.exe") if comp == "windows" else os.path.join(d, "bin", "python")
        if os.path.exists(py): return py
    return None

def need_venv(comp):
    py = venv_python(comp)
    if not py:
        how = {"windows": "double-click  setup.bat", "mac": "run  sh setup_mac.sh", "linux": "run  python3 studio.py setup"}[comp]
        die(f"This computer ({NAMES[comp]}) is not set up yet.\nOne-time step: {how}")
    return py

def child_env(comp):
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", VS_COMPUTER=comp)
    env["PATH"] = PU.BIN + os.pathsep + env.get("PATH", "")
    return env

def run(py, script, args, comp, check=True):
    cmd = [py, os.path.join(SCRIPTS, script)] + [str(a) for a in args]
    r = subprocess.run(cmd, cwd=ROOT, env=child_env(comp))
    if check and r.returncode != 0: die(f"Step failed: {script} (see the messages above).", r.returncode)
    return r.returncode

def theme_list():
    names = sorted(f[:-3] for f in os.listdir(THEMES) if f.endswith(".py") and not f.startswith("_"))
    return sorted(names, key=lambda n: (n != "clean", n))

def theme_desc(name):
    with open(os.path.join(THEMES, name + ".py"), encoding="utf-8") as fh: line = fh.readline().strip()
    return line.replace('"""', "")

def open_folder(path):
    try:
        if os.name == "nt": os.startfile(path)
        elif sys.platform == "darwin": subprocess.run(["open", path])
        elif shutil.which("xdg-open"): subprocess.run(["xdg-open", path])
    except Exception: pass

def tool_help(comp):
    if comp == "windows":
        return ("ffmpeg is missing. Easiest fix (no admin needed):  setup.bat --get-ffmpeg   (downloads it into the 'bin' folder).\n"
                "Or: winget install Gyan.FFmpeg, or put ffmpeg.exe and ffprobe.exe into the 'bin' folder yourself.")
    if comp == "mac": return "ffmpeg is missing. In Terminal run:  brew install ffmpeg   (Homebrew: https://brew.sh)"
    return "ffmpeg is missing. Install it with your package manager (for example:  sudo apt install ffmpeg)."

def need_tools(comp):
    for t in ("ffmpeg", "ffprobe"):
        if not PU.find_tool(t): die(tool_help(comp))

def pass_args(ns):
    a = []
    if ns.draft: a.append("--draft")
    if ns.quality: a += ["--quality", ns.quality]
    if ns.fx: a += ["--fx", ns.fx]
    return a


# ------------------------------------------------------------------------------------------------ setup / doctor
def get_ffmpeg():
    """Download a Windows ffmpeg build into ./bin (no admin rights needed)."""
    os.makedirs(PU.BIN, exist_ok=True)
    urls = ["https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
            "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"]
    zpath = os.path.join(PU.BIN, "_ffmpeg_download.zip")
    for url in urls:
        try:
            say(f"Downloading ffmpeg from {url.split('/')[2]} (about 100-200 MB, please wait)...")
            def prog(b, bs, total):
                if total > 0 and b % 400 == 0: print(f"   {min(100, b * bs * 100 // total)}%", flush=True)
            urllib.request.urlretrieve(url, zpath, prog)
            if extract_ffmpeg(zpath): os.remove(zpath); return True
        except Exception as e:
            say(f"   did not work ({e}); trying the next source...")
    return False

def extract_ffmpeg(zpath):
    found = 0
    with zipfile.ZipFile(zpath) as z:
        for m in z.namelist():
            base = m.replace("\\", "/").split("/")[-1].lower()
            if base in ("ffmpeg.exe", "ffprobe.exe") and "/bin/" in m.replace("\\", "/"):
                with z.open(m) as src, open(os.path.join(PU.BIN, base), "wb") as dst: shutil.copyfileobj(src, dst)
                found += 1
    return found == 2

def cmd_setup(ns, comp):
    say(f"== Setting up this computer ({NAMES[comp]}) ==")
    if sys.version_info < (3, 9): die(f"Python {sys.version.split()[0]} is too old. Install Python 3.9 or newer from python.org.")
    say(f"Python {sys.version.split()[0]}: OK")
    if not (PU.find_tool("ffmpeg") and PU.find_tool("ffprobe")):
        want = ns.get_ffmpeg
        if comp == "windows" and not want and sys.stdin.isatty():
            want = input("ffmpeg (the video tool) was not found. Download it now into the 'bin' folder? [Y/n]: ").strip().lower() in ("", "y", "yes")
        if comp == "windows" and want:
            if not get_ffmpeg(): say("Could not download ffmpeg automatically.\n" + tool_help(comp))
        else:
            say("WARNING: " + tool_help(comp))
    else:
        say("ffmpeg: OK")
    vdir = PU.venv_dir(comp)
    say(f"\nCreating this computer's private Python environment ({os.path.basename(vdir)}) ...")
    if not os.path.exists(os.path.join(vdir, "Scripts" if comp == "windows" else "bin")):
        subprocess.run([sys.executable, "-m", "venv", vdir], check=True)
    py = PU.venv_python(comp)            # this computer's own environment (never the older shared .venv)
    extra = ns.pip_args.split() if ns.pip_args else []
    pip = [py, "-m", "pip", "--disable-pip-version-check", "install", "--quiet"] + extra
    subprocess.run(pip + ["--upgrade", "pip"], check=False)
    r = subprocess.run(pip + ["skia-python", "pillow"])
    if r.returncode != 0:
        die("Installing the drawing library failed. Common causes: no internet, a company proxy (try:  --pip-args \"--proxy http://host:port\"), "
            "or a Python version newer than the libraries support (3.9 to 3.13 work).")
    r = subprocess.run(pip + ["edge-tts"])
    if r.returncode != 0: say("NOTE: the optional online voice (edge-tts) could not be installed. Everything else works.")
    say("")
    cmd_doctor(ns, comp)
    say("\nSetup finished. Next: put your scenes file in the 'inbox' folder, then run a quick test:")
    say({"windows": "   make.bat --draft", "mac": "   sh make.sh --draft", "linux": "   python3 studio.py make --draft"}[comp])

def cmd_doctor(ns, comp):
    ok = True
    def line(label, good, detail, fix=""):
        nonlocal ok
        say(f"  [{'OK' if good else 'MISSING'}]  {label}: {detail}")
        if not good and fix: say(f"            -> {fix}")
        ok = ok and good
    say(f"This computer: {NAMES[comp]}   (Python {sys.version.split()[0]}, {os.cpu_count()} processor cores)")
    py = venv_python(comp)
    line("private Python environment", bool(py), py or "not created yet",
         {"windows": "double-click setup.bat", "mac": "run: sh setup_mac.sh", "linux": "run: python3 studio.py setup"}[comp])
    if py:
        r = subprocess.run([py, "-c", "import skia, PIL; print('skia', skia.__version__, '/ pillow', PIL.__version__)"], capture_output=True, text=True, env=child_env(comp))
        line("drawing libraries", r.returncode == 0, r.stdout.strip() or "not installed", "run setup again")
        r = subprocess.run([py, "-c", "import edge_tts; print('installed')"], capture_output=True, text=True, env=child_env(comp))
        say(f"  [{'OK' if r.returncode == 0 else 'optional'}]  online neural voice (edge-tts): {'installed' if r.returncode == 0 else 'not installed (only needed for --engine edge)'}")
    for t in ("ffmpeg", "ffprobe"):
        p = PU.find_tool(t)
        line(t, bool(p), p or "not found", tool_help(comp))
    p = PU.find_tool("ffmpeg")
    if p:
        r = subprocess.run([p, "-hide_banner", "-filters"], capture_output=True, text=True)
        line("caption support in ffmpeg", " subtitles " in r.stdout, "subtitles filter present" if " subtitles " in r.stdout else "no 'subtitles' filter (the captioned copy will be skipped; the main video is fine)")
    fonts_ok = all(os.path.exists(os.path.join(ROOT, "fonts", f)) for f in ("Poppins-Bold.ttf", "Inter-Regular.ttf"))
    line("fonts", fonts_ok, "bundled fonts found" if fonts_ok else "fonts folder incomplete", "copy the whole pack folder, not single files")
    voice = {"mac": "macOS 'say' voices", "windows": "Windows built-in voices (PowerShell)", "linux": "no built-in voice: use --engine edge or --own-voice"}[comp]
    has = (comp == "mac" and shutil.which("say")) or (comp == "windows" and shutil.which("powershell"))
    say(f"  [{'OK' if has else 'info'}]  voice-over: {voice}")
    tot, free = PU.memory_info(); w1, why1 = PU.choose_workers(1080); w4, _ = PU.choose_workers(2160)
    if free is not None:
        say(f"  [info]  rendering power: {os.cpu_count()} processor threads, {free:.1f} of {tot:.1f} GB RAM free -> {w1} render workers at 1080p, {w4} at 4K")
        if tot < 6: say("            -> memory is the limit on this computer: close other programs while rendering; 4K will be slow (use standard or smooth).")
    say(f"  [info]  looks available: {', '.join(theme_list())}")
    say("\n" + ("Everything needed is in place." if ok else "Fix the MISSING items above, then run doctor again."))
    return ok


# ------------------------------------------------------------------------------------------------ make / render
def check_inputs(ns):
    if not os.path.exists(os.path.join(ROOT, ns.scenes)): die(f"No {ns.scenes} found. Put the scenes file in the 'inbox' folder.")
    if ns.theme not in theme_list(): die(f"Unknown theme '{ns.theme}'. Available: {', '.join(theme_list())}  (see: python studio.py themes)")

def cmd_make(ns, extra, comp, with_sound=True):
    check_inputs(ns); need_tools(comp); py = need_venv(comp)
    out = ns.out; vdir = os.path.join(out, "voice")
    run(py, "make_script.py", [ns.scenes, "--out", "narration_script.txt"], comp)
    say("== Checking numbers against facts ==" ); os.makedirs(os.path.join(ROOT, out), exist_ok=True); run_facts(py, comp, ns)
    if with_sound:
        PU.rmtree(os.path.join(ROOT, vdir))
        engine = "own" if ns.own_voice else ns.engine
        label = "YOUR recordings (folder: my_voice)" if engine == "own" else f"engine: {engine}"
        say(f"== 1/3 Recording the voice-over ({label}) ==")
        v = [ns.scenes, "--out", vdir, "--engine", engine]
        if engine == "own": v += ["--src", "my_voice"]
        if ns.voice: v += ["--voice", ns.voice]
        run(py, "make_voice.py", v, comp)
    say(f"== {'2/3' if with_sound else '1/2'} Drawing the video (theme: {ns.theme}; this takes a while) ==")
    PU.rmtree(os.path.join(ROOT, out, "clips"))
    b = [ns.scenes, "--out", out, "--captions", "--theme", ns.theme] + pass_args(ns) + extra
    if with_sound: b += ["--voice", os.path.join(vdir, "durations.json")]
    run(py, "build_video.py", b, comp)
    partial = "--only" in extra
    if with_sound and not partial:
        say("== 3/3 Mixing the sound ==")
        music = ns.music or (os.path.join("inbox", "music.mp3") if os.path.exists(os.path.join(ROOT, "inbox", "music.mp3")) else None)
        m = [os.path.join(out, "full_video_silent.mp4"), os.path.join(out, "cues.json"), "--out", os.path.join(out, "final_with_audio.mp4"), "--voice-dir", vdir]
        if music: m += ["--music", music]
        m += ["--sfx", ns.sfx, "--sfx-level", str(ns.sfx_level)]
        run(py, "mix_audio.py", m, comp)
        say("== Checking the result ==")
        run_qa(py, comp, out, "final_with_audio.mp4")
        say(f"\nDONE -> {os.path.join(out, 'final_with_audio.mp4')}")
    elif partial:
        say("\nOnly some scenes were drawn (--only), so the sound mix was skipped. Run again without --only for the full video.")
    else:
        if not partial: say("== Checking the result =="); run_qa(py, comp, out, "full_video_silent.mp4")
        say(f"\nDone. Open the '{out}' folder -> full_video_silent.mp4")
    if not ns.no_open: open_folder(os.path.join(ROOT, out))

def run_facts(py, comp, ns):
    """Cheap check before the long render: is every number in the video in your facts file? Never stops the build."""
    run(py, "check_facts.py", [ns.scenes, ns.facts, "--out", os.path.join(ns.out, "facts_report.txt")], comp, check=False)

def cmd_facts(ns, comp):
    check_inputs(ns); py = need_venv(comp); os.makedirs(os.path.join(ROOT, ns.out), exist_ok=True); run_facts(py, comp, ns)

def run_qa(py, comp, out, name):
    """Automatic checks (frozen picture, black gaps, flashes, loudness). Never stops the build; the report is saved next to the video."""
    vid = os.path.join(out, name)
    if not os.path.exists(os.path.join(ROOT, vid)): return
    cues = os.path.join(out, "cues.json")
    args = [vid, "--out", os.path.join(out, "qa_report.txt")] + (["--cues", cues] if os.path.exists(os.path.join(ROOT, cues)) else [])
    run(py, "qa_check.py", args, comp, check=False)

def cmd_qa(ns, comp):
    need_tools(comp); py = need_venv(comp)
    for name in ("final_with_audio.mp4", "full_video_silent.mp4"):
        if os.path.exists(os.path.join(ROOT, ns.out, name)): return run_qa(py, comp, ns.out, name)
    die(f"No video found in '{ns.out}'. Make the video first (make.sh / make.bat).")

def cmd_render(ns, extra, comp):
    check_inputs(ns); need_tools(comp); py = need_venv(comp)
    run(py, "make_script.py", [ns.scenes, "--out", "narration_script.txt"], comp)
    say("== Checking numbers against facts =="); os.makedirs(os.path.join(ROOT, ns.out), exist_ok=True); run_facts(py, comp, ns)
    run(py, "contact_sheet.py", [ns.scenes, "--out", os.path.join(ns.out, "qa"), "--beats", "--theme", ns.theme], comp, check=False)
    run(py, "build_video.py", [ns.scenes, "--out", ns.out, "--captions", "--theme", ns.theme] + pass_args(ns) + extra, comp)
    if "--only" not in extra: say("== Checking the result =="); run_qa(py, comp, ns.out, "full_video_silent.mp4")
    say(f"\nDone. Open the '{ns.out}' folder -> full_video_silent.mp4")
    if not ns.no_open: open_folder(os.path.join(ROOT, ns.out))


# ------------------------------------------------------------------------------------------------ small commands
def cmd_wizard(ns, comp):
    say("=" * 62); say("  video-studio: a few questions, then it makes your video"); say("=" * 62)
    say(f"\nThis computer looks like a {NAMES[comp]}.")
    ans = input("Press Enter if that is right, or type mac / windows: ").strip().lower()
    if ans in ("mac", "windows", "linux"): comp = set_computer(ans)
    w1, _ = PU.choose_workers(1080); w4, _ = PU.choose_workers(2160)
    say(f"\nHow good should the picture be?   (this computer can run {w1} render workers at 1080p, {w4} at 4K)")
    say("  1. Quick test      720p, fastest\n  2. Standard        1080p, 30 frames/s  (recommended)\n  3. Smooth          1080p, 60 frames/s\n"
        "  4. Cinema          1080p with motion blur (slower)\n  5. Ultra           4K with motion blur (slowest, big files)")
    q = input("Choose 1-5  [Enter = 2]: ").strip()
    ns.quality = {"1": "draft", "3": "smooth", "4": "cinema", "5": "ultra"}.get(q, "standard"); ns.draft = False
    names = theme_list(); say("\nWhich look?")
    for i, n in enumerate(names, 1): say(f"  {i}. {n:10s} {theme_desc(n)[:78]}")
    c = input(f"Number or name  [Enter = {names[0]}]: ").strip().lower()
    ns.theme = names[int(c) - 1] if c.isdigit() and 1 <= int(c) <= len(names) else (c if c in names else names[0])
    default_engine = {"mac": "mac (built-in Mac voice)", "windows": "windows (built-in Windows voice)", "linux": "edge (online voice)"}[comp]
    say("\nWho reads the narration?")
    say(f"  1. This computer's built-in voice  [{default_engine}]\n  2. Online neural voice (Philippine English, needs internet)\n  3. My own recordings (folder: my_voice)")
    c = input("Choose 1, 2 or 3  [Enter = 1]: ").strip()
    ns.engine = {"2": "edge", "3": "own"}.get(c, "auto"); ns.own_voice = c == "3"
    say(f"\nStarting: {NAMES[comp]}, look = {ns.theme}, quality = {ns.quality}, voice = {ns.engine}\n")
    cmd_make(ns, [], comp)

def cmd_themes(ns, comp):
    say("Available looks (use:  --theme NAME):")
    for n in theme_list(): say(f"  {n:10s} {theme_desc(n)}" + ("  (DEFAULT)" if n == "clean" else ""))

def cmd_voices(ns, comp):
    py = need_venv(comp); need_tools(comp)
    run(py, "make_voice.py", [ns.scenes, "--out", os.path.join(ns.out, "voice"), "--engine", ns.engine, "--list-voices"], comp)

def cmd_preview(ns, extra, comp):
    check_inputs(ns); py = need_venv(comp); d = os.path.join(ns.out, "theme_preview")
    run(py, "preview_themes.py", [ns.scenes, "--out", d] + extra, comp)
    if not ns.no_open: open_folder(os.path.join(ROOT, d))

def cmd_motion(ns, extra, comp):
    check_inputs(ns); py = need_venv(comp); d = os.path.join(ns.out, "motion")
    run(py, "motion_curves.py", [ns.scenes, "--out", d], comp)
    if len(extra) >= 1 and extra[0].isdigit():
        run(py, "motion_strip.py", [ns.scenes, "--scene", extra[0], "--beat", extra[1] if len(extra) > 1 else "0", "--out", d], comp)
    if not ns.no_open: open_folder(os.path.join(ROOT, d))

def cmd_benchmark(ns, comp):
    check_inputs(ns); need_tools(comp); py = need_venv(comp)
    say("Measuring this computer (about a minute)...")
    run(py, "benchmark.py", [ns.scenes, "--theme", ns.theme], comp)

def cmd_clean(ns, comp):
    PU.rmtree(os.path.join(ROOT, ns.out)); say(f"Deleted the '{ns.out}' folder.")


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description="video-studio launcher", add_help=True, allow_abbrev=False)
    ap.add_argument("command", nargs="?", default="help",
                    choices=["setup", "doctor", "make", "render", "wizard", "themes", "voices", "preview", "motion", "benchmark", "qa", "facts", "clean", "help"])
    ap.add_argument("--computer", default="auto"); ap.add_argument("--scenes", default=os.path.join("inbox", "scenes.py"))
    ap.add_argument("--theme", default=None); ap.add_argument("--draft", action="store_true"); ap.add_argument("--fx", choices=["on", "off"])
    ap.add_argument("--quality", choices=["draft", "standard", "smooth", "cinema", "ultra"])
    ap.add_argument("--engine", default="auto"); ap.add_argument("--voice", "--voice-name", dest="voice"); ap.add_argument("--own-voice", action="store_true")
    ap.add_argument("--music"); ap.add_argument("--facts", default=os.path.join("inbox", "facts.md")); ap.add_argument("--sfx", choices=["rich", "on", "off"], default="rich"); ap.add_argument("--sfx-level", type=float, default=1.0); ap.add_argument("--out", default="output"); ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--get-ffmpeg", action="store_true"); ap.add_argument("--pip-args", default="")
    ap.add_argument("--list-themes", action="store_true")
    ns, extra = ap.parse_known_args()
    if ns.command == "help": print(__doc__); return
    if not ns.theme:                       # no --theme given: a THEME = "aurora" line in the scenes file wins, else clean
        try: txt = open(os.path.join(ROOT, ns.scenes) if not os.path.isabs(ns.scenes) else ns.scenes, encoding="utf-8").read()
        except OSError: txt = ""
        m = re.search(r"^THEME\s*=\s*[\"']([\w-]+)[\"']", txt, re.M); ns.theme = m.group(1) if m else "clean"
    comp = set_computer(ns.computer)
    if ns.list_themes: return cmd_themes(ns, comp)
    c = ns.command
    if c == "setup": cmd_setup(ns, comp)
    elif c == "doctor": cmd_doctor(ns, comp)
    elif c == "make": cmd_make(ns, extra, comp)
    elif c == "render": cmd_render(ns, extra, comp)
    elif c == "wizard": cmd_wizard(ns, comp)
    elif c == "themes": cmd_themes(ns, comp)
    elif c == "voices": cmd_voices(ns, comp)
    elif c == "preview": cmd_preview(ns, extra, comp)
    elif c == "motion": cmd_motion(ns, extra, comp)
    elif c == "benchmark": cmd_benchmark(ns, comp)
    elif c == "qa": cmd_qa(ns, comp)
    elif c == "facts": cmd_facts(ns, comp)
    elif c == "clean": cmd_clean(ns, comp)

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: die("Stopped.", 130)
