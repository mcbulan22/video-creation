#!/bin/sh
# Check that every number in the video is in inbox/facts.md.   sh facts.sh
cd "$(dirname "$0")"
exec python3 studio.py facts "$@"
