#!/bin/sh
# Asks a few questions, then makes the video.   sh start.sh   (or double-click start.command in Finder)
cd "$(dirname "$0")"
exec python3 studio.py wizard
