"""sfx_cues: turns cues.json (scene and beat times) into a mastered sound-effects track, automatically.

Rules (quiet on purpose; the voice stays in front):
  every scene change      a soft whoosh that lands on the cut, plus a faint low thud
  every beat              a small pop when the beat's content appears (rising notes of a pentatonic scale)
  first scene             a gentle opening swell
  last scene              a chime and a sparkle on the final beat
  horizon (sky) scene     a deep water rush where the camera dives (instead of a whoosh)

Per-scene control, in scenes.py:   @scene("TITLE", [...], sfx="off")                         no pops in this scene
                                   @scene("TITLE", [...], sfx=[(0, 0.2, "pop"), (1, 0.0, "chime", 0.4), (2, 0.1, "typing")])
Each entry = (beat number, seconds after that beat starts, sound name[, gain]). Names: pop tick click whoosh riser chime impact typing shimmer swell splash.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sfx_synth as S

SCALE = [523.25, 587.33, 659.25, 783.99, 880.00, 1046.50]          # C major pentatonic: pops never clash with each other


def _named(name, dur=None, freq=None):
    g = S.GENERATORS[name]
    if name == "typing": return g(chars=max(6, int((dur or 1.2) * 14)), dur=dur or 1.2)
    if name in ("pop", "tick", "chime") and freq: return g(freq)
    return g()


def build(cues, level=1.0):
    """Returns a Mixer holding every sound. level scales all gains (0.5 = half as loud)."""
    m = S.Mixer(cues["total"]); scenes = cues["scenes"]; last = len(scenes) - 1
    for sc in scenes:
        i = sc["i"]; t0 = sc["t0"]; beats = sc["beats"]
        # scene change
        if i == 0:
            m.put(0.05, S.swell(2.4), 0.22 * level)
        elif scenes[i - 1].get("sky"):
            pass                                                         # the dive splash (below) already covers this change
        else:
            m.put(max(0.0, t0 - 0.5), S.whoosh(0.62), 0.42 * level); m.put(t0 - 0.02, S.impact(0.9), 0.16 * level)
        if sc.get("sky"):
            m.put(max(0.0, t0 + sc["dur"] - 1.5), S.splash(2.2), 0.6 * level)
        # this scene's own cues, or the automatic pops
        spec = sc.get("sfx")
        if spec == "off": pass
        elif isinstance(spec, list):
            for e in spec:
                k, off, name = int(e[0]), float(e[1]), e[2]; gain = float(e[3]) if len(e) > 3 else 0.3
                if k >= len(beats) or name not in S.GENERATORS: continue
                b = beats[k]; m.put(b["start"] + off, _named(name, b["end"] - b["start"] - off), gain * level, pan=(-0.2 if k % 2 else 0.2))
        else:
            for k, b in enumerate(beats):
                if b["end"] - b["start"] < 0.9: continue
                m.put(b["start"] + 0.10, S.pop(SCALE[(k + i) % len(SCALE)]), (0.30 if k == 0 else 0.20) * level, pan=(-0.25 if (k + i) % 2 else 0.25))
        if i == last and beats:
            b = beats[-1]; m.put(b["start"] + 0.2, S.chime(784.0, 1.8), 0.34 * level); m.put(b["start"] + 0.35, S.shimmer(1.2), 0.22 * level)
    return m


def render(cues, path, level=1.0):
    return build(cues, level).render(path)


if __name__ == "__main__":
    import json
    ap = sys.argv[1:]
    if not ap: sys.exit("usage: python sfx_cues.py OUT/cues.json [out.wav]")
    c = json.load(open(ap[0])); out = ap[1] if len(ap) > 1 else "sfx_track.wav"; render(c, out); print("wrote", out)
