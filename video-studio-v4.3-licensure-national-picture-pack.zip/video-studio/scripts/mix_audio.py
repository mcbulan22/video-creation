#!/usr/bin/env python3
"""Add sound to the silent video: voice-over + whoosh at each scene change + optional music that ducks under the voice.

  python mix_audio.py OUT/full_video_silent.mp4 OUT/cues.json --out OUT/final_with_audio.mp4
        [--voice-dir OUT/voice]        per-beat voice clips from make_voice.py (exact sync)
        [--voice-file my_voice.mp3]    OR one recording of the whole narration (build with --audio first)
        [--music inbox/music.mp3]      royalty-free music file; or the word  pad  for a simple generated ambient bed
        [--music-vol 0.18] [--sfx rich|on|off] [--sfx-level 1.0] [--ticks on]
        sfx: rich = synthesized pops, whooshes, thuds, chime (default); on = the simple whoosh-only version; off = none
"""
import argparse, json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import platform_utils as PU   # makes ./bin ffmpeg visible

def run(cmd):
    subprocess.run(cmd, check=True, stdin=subprocess.DEVNULL)

def ff(*args):
    run(["ffmpeg", "-y", "-loglevel", "error", *args])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("cues"); ap.add_argument("--out", required=True)
    ap.add_argument("--voice-dir"); ap.add_argument("--voice-file")
    ap.add_argument("--music"); ap.add_argument("--music-vol", type=float, default=0.18)
    ap.add_argument("--sfx", choices=["rich", "on", "off"], default="rich"); ap.add_argument("--sfx-level", type=float, default=1.0); ap.add_argument("--ticks", choices=["on", "off"], default="off")
    a = ap.parse_args()
    cues = json.load(open(a.cues)); total = cues["total"]
    work = os.path.join(os.path.dirname(os.path.abspath(a.out)), "audio_work"); os.makedirs(work, exist_ok=True)
    tracks = []                                              # (path, weight) for the final mix

    # ---- voice
    voice = None
    if a.voice_file:
        voice = a.voice_file
    elif a.voice_dir:
        ins, fl, n = [], [], 0
        for sc in cues["scenes"]:
            for k, b in enumerate(sc["beats"]):
                wav = os.path.join(a.voice_dir, f"s{sc['i']+1:02d}_b{k+1:02d}.wav")
                if not os.path.exists(wav): continue
                ms = int(round(b["start"] * 1000))
                ins += ["-i", wav]; fl.append(f"[{n}:a]adelay={ms}|{ms}[a{n}]"); n += 1
        if n:
            graph = ";".join(fl) + ";" + "".join(f"[a{j}]" for j in range(n)) + f"amix=inputs={n}:normalize=0:dropout_transition=0,apad=whole_dur={total:.2f}[v]"
            voice = os.path.join(work, "voice.wav")
            ff(*ins, "-filter_complex", graph, "-map", "[v]", "-t", f"{total:.2f}", voice)
    # ---- sfx
    sfx = None
    if a.sfx == "rich":
        import sfx_cues
        sfx = os.path.join(work, "sfx_rich.wav"); sfx_cues.render(cues, sfx, a.sfx_level)
    elif a.sfx == "on":
        whoosh = os.path.join(work, "whoosh.wav")
        ff("-f", "lavfi", "-i", "anoisesrc=d=0.8:c=pink:a=0.6", "-af",
           "highpass=f=250,lowpass=f=5000,afade=t=in:d=0.35,afade=t=out:st=0.35:d=0.45,volume=0.55", "-ar", "44100", "-ac", "1", whoosh)
        pts = [(sc["t0"] - 0.05 if sc["i"] else 0.0) for sc in cues["scenes"] if not (sc["i"] and cues["scenes"][sc["i"]-1].get("sky"))]
        ins, fl = [], []
        for j, t in enumerate(pts):
            ms = max(0, int(round(t * 1000))); ins += ["-i", whoosh]; fl.append(f"[{j}:a]adelay={ms}|{ms}[w{j}]")
        extra = ""
        # dive splash: a deep water-rush where a horizon scene hands over to the underwater scenes
        for sc in cues["scenes"]:
            if sc.get("sky"):
                splash = os.path.join(work, "splash.wav")
                ff("-f", "lavfi", "-i", "anoisesrc=d=2.2:c=brown:a=0.9", "-af",
                   "lowpass=f=1400,highpass=f=60,afade=t=in:d=0.5,afade=t=out:st=0.7:d=1.5,volume=1.6", "-ar", "44100", "-ac", "1", splash)
                ms = max(0, int(round((sc["t0"] + sc["dur"] - 1.5) * 1000))); ins += ["-i", splash]; fl.append(f"[{len(fl)}:a]adelay={ms}|{ms}[w{len(fl)}]")
        if a.ticks == "on":
            tick = os.path.join(work, "tick.wav")
            ff("-f", "lavfi", "-i", "sine=f=1400:d=0.07", "-af", "afade=t=out:d=0.06,volume=0.25", "-ar", "44100", "-ac", "1", tick)
            for sc in cues["scenes"]:
                for b in sc["beats"]:
                    m = len(fl); ms = int(round(b["start"] * 1000)); ins += ["-i", tick]; fl.append(f"[{m}:a]adelay={ms}|{ms}[w{m}]")
        graph = ";".join(fl) + ";" + "".join(f"[w{j}]" for j in range(len(fl))) + f"amix=inputs={len(fl)}:normalize=0:dropout_transition=0,apad=whole_dur={total:.2f}[s]"
        sfx = os.path.join(work, "sfx.wav")
        ff(*ins, "-filter_complex", graph, "-map", "[s]", "-t", f"{total:.2f}", sfx)
    # ---- music
    music = None
    if a.music:
        music = os.path.join(work, "music.wav")
        if a.music == "pad":   # simple generated ambient bed (A minor-ish chord with slow tremolo)
            ff("-f", "lavfi", "-i", "sine=f=110:d=%d" % int(total + 2), "-f", "lavfi", "-i", "sine=f=164.81:d=%d" % int(total + 2),
               "-f", "lavfi", "-i", "sine=f=220:d=%d" % int(total + 2), "-f", "lavfi", "-i", "sine=f=261.63:d=%d" % int(total + 2),
               "-filter_complex", "[0][1][2][3]amix=inputs=4:normalize=0,tremolo=f=0.12:d=0.6,lowpass=f=900,aecho=0.8:0.7:700|1100:0.35|0.25,volume=0.9[m]",
               "-map", "[m]", "-t", f"{total:.2f}", "-ar", "44100", "-ac", "2", music)
        else:
            ff("-stream_loop", "-1", "-i", a.music, "-t", f"{total:.2f}", "-ar", "44100", "-ac", "2", music)
    # ---- final mix
    ins, fl, labels = ["-i", a.video], [], []
    idx = 1
    def add(path):
        nonlocal idx
        ins.extend(["-i", path]); idx += 1; return idx - 1
    vi = add(voice) if voice else None
    si = add(sfx) if sfx else None
    mi = add(music) if music else None
    parts = []
    duck_sfx = (a.sfx == "rich" and vi is not None and si is not None)       # effects dip a little while the narrator speaks
    if vi is not None:
        taps = ["vo"] + (["vsc"] if mi is not None else []) + (["vsx"] if duck_sfx else [])
        parts.append(f"[{vi}:a]asplit={len(taps)}" + "".join(f"[{t}]" for t in taps) if len(taps) > 1 else f"[{vi}:a]anull[vo]")
        labels.append("[vo]")
        if mi is not None:
            parts.append(f"[{mi}:a]volume={a.music_vol},afade=t=in:d=1.5,afade=t=out:st={max(0, total-2.5):.2f}:d=2.5[mus]")
            parts.append("[mus][vsc]sidechaincompress=threshold=0.04:ratio=10:attack=30:release=500[duck]")
            labels.append("[duck]")
    elif mi is not None:
        parts.append(f"[{mi}:a]volume={a.music_vol},afade=t=in:d=1.5,afade=t=out:st={max(0, total-2.5):.2f}:d=2.5[duck]"); labels.append("[duck]")
    if si is not None:
        if a.sfx == "rich":
            parts.append(f"[{si}:a]volume=1.0[sx0]")
            parts.append("[sx0][vsx]sidechaincompress=threshold=0.03:ratio=3:attack=8:release=250[sx]" if duck_sfx else "[sx0]anull[sx]")
        else:
            parts.append(f"[{si}:a]volume=0.5[sx]")
        labels.append("[sx]")
    if not labels:
        sys.exit("Nothing to mix: give --voice-dir / --voice-file / --music, or leave --sfx on.")
    parts.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0:dropout_transition=0[pre]")
    core = ";".join(parts); LN = "I=-16:TP=-1.5:LRA=18"
    # two-pass loudness: measure first, then correct exactly (a single pass undershoots on sparse sound)
    fin = f"loudnorm={LN},aformat=channel_layouts=stereo:sample_rates=44100"
    m = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", *ins, "-filter_complex", core + f";[pre]loudnorm={LN}:print_format=json[o]", "-map", "[o]", "-f", "null", "-"],
                       capture_output=True, text=True, stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace")
    try:
        j = json.loads(m.stderr[m.stderr.rindex("{"):m.stderr.rindex("}") + 1])
        fin = (f"loudnorm={LN}:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}"
               f":offset={j['target_offset']}:linear=true,aformat=channel_layouts=stereo:sample_rates=44100")
    except Exception:
        pass                                                   # measuring failed: fall back to the single-pass filter
    ff(*ins, "-filter_complex", core + f";[pre]{fin}[mix]", "-map", "0:v", "-map", "[mix]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
       "-t", f"{total:.2f}", a.out)
    print(f"AUDIO MIXED: {a.out}")

if __name__ == "__main__":
    main()
