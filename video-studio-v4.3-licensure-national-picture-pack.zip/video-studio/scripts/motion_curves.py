#!/usr/bin/env python3
"""Motion report: plots every theme's entrance curve and checks the deck against the motion rules in MOTION.md.

  python motion_curves.py SCENES.py --out DIR [theme ...]

Writes DIR/motion_curves.png and DIR/motion_report.txt (also printed).
"""
import argparse, importlib.util, os, statistics, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E, skia
from PIL import Image, ImageDraw

# What each personality should look like (entrance ~0.6 s in this engine; video pacing is about 2x slower than UI timings).
RULES = {"Corporate": dict(over=(0, 3), dur=(0.4, 0.8)), "Premium": dict(over=(0, 0.5), dur=(0.7, 1.2)),
         "Energetic": dict(over=(0, 30), dur=(0.2, 0.5)), "Playful": dict(over=(8, 22), dur=(0.3, 0.6)),
         "Paper": dict(over=(3, 6), dur=(0.5, 0.9)), "Fluid": dict(over=(3, 8), dur=(0.5, 0.9))}

def stagger_audit(scenes_mod):
    """Run every scene with all beats revealed and record the stagger delays each beat actually uses (after the theme's scaling)."""
    tl, _ = E.build_timeline(E.SCENES, 2.45); rec = []; orig = E.Ctx.p
    def p(self, k, dur=0.55, delay=0.0): rec.append((k, delay * E.TH.stagger_scale)); return orig(self, k, dur, delay)
    E.Ctx.p = p
    worst_total, steps = 0.0, []
    try:
        for sc in tl:
            rec.clear(); surf = skia.Surface(E.W, E.H); sc["s"]["draw"](E.Ctx(surf.getCanvas(), sc["dur"] - 0.3, sc["bs"]))
            by = {}
            for k, d in rec: by.setdefault(k, set()).add(round(d, 4))
            for ds in by.values():
                ds = sorted(ds)
                if len(ds) > 1:
                    worst_total = max(worst_total, ds[-1] - ds[0]); steps += [b - a for a, b in zip(ds, ds[1:]) if b - a > 0]
    finally: E.Ctx.p = orig
    return worst_total, (statistics.median(steps) if steps else 0.0)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--out", default="output/motion"); ap.add_argument("themes", nargs="*")
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    names = a.themes or E.theme_names(); lines = []; cells = []
    for name in names:
        E.set_theme(name); T = E.TH; f = T.ease
        xs = [i / 100 for i in range(101)]; ys = [f(x) for x in xs]
        over = (max(ys) - 1) * 100; dev = max(abs(y - x) for x, y in zip(xs, ys)); dur = 0.6 * T.dur_scale
        wt, step = stagger_audit(m); fo = E.FADE_OUT * T.fade_out_scale; ratio = fo / E.FADE_IN
        key = next((k for k in RULES if T.personality.startswith(k)), None); r = RULES.get(key)
        checks = [("not linear (has a real curve)", dev > 0.10, f"max deviation from linear {dev:.2f}")]
        if r:
            checks += [(f"overshoot fits {key} ({r['over'][0]}-{r['over'][1]}%)", r['over'][0] - 0.05 <= over <= r['over'][1] + 0.05, f"{over:.1f}%"),
                       (f"entrance length fits {key} ({r['dur'][0]}-{r['dur'][1]} s)", r['dur'][0] <= dur <= r['dur'][1], f"{dur:.2f} s")]
        checks += [("cascade total under 0.5 s", wt <= 0.5 + 1e-6, f"{wt:.2f} s (median step {step*1000:.0f} ms)"),
                   ("exit at least 30% shorter than entrance", ratio <= 0.70 + 1e-6, f"exit {fo:.2f} s vs enter {E.FADE_IN:.2f} s ({(1-ratio)*100:.0f}% shorter)")]
        lines.append(f"{name.upper()}  -  {T.personality or '(no personality set)'}")
        for label, ok, val in checks: lines.append(f"   {'PASS' if ok else 'WARN'}  {label}: {val}")
        lines.append(f"   signature curve overshoot {over:.1f}%, entrance {dur:.2f} s, text lag {T.text_lag}, arc {T.arc:g}px, from-side {T.enter_dx:g}px, parallax {T.parallax}"); lines.append("")
        cw, ch = 560, 330; im = Image.new("RGB", (cw, ch), (250, 250, 252)); d = ImageDraw.Draw(im)
        x0, y0, x1, y1 = 60, 62, cw - 24, ch - 70; top = max(1.25, max(ys) + .05)
        px = lambda x: x0 + (x1 - x0) * x; py = lambda y: y1 - (y1 - y0) * (y / top)
        d.rectangle([x0, y0, x1, y1], outline=(200, 200, 205)); d.line([px(0), py(1), px(1), py(1)], fill=(210, 170, 170))
        d.line([px(0), py(0), px(1), py(1)], fill=(190, 190, 195), width=1)
        d.line([(px(x), py(y)) for x, y in zip(xs, ys)], fill=(30, 90, 220), width=4)
        d.text((12, 10), name.upper(), fill=(20, 20, 30)); d.text((12, 28), T.personality[:70], fill=(90, 90, 100))
        d.text((x0, y1 + 8), f"overshoot {over:.1f}%    entrance {dur:.2f}s    cascade step {step*1000:.0f}ms (total {wt:.2f}s)", fill=(60, 60, 70))
        d.text((x0, y1 + 26), f"exit {fo:.2f}s vs enter {E.FADE_IN:.2f}s    text lag {T.text_lag}    arc {T.arc:g}px    from-side {T.enter_dx:g}px", fill=(60, 60, 70))
        d.text((x0 - 40, y0 - 2), "1.0", fill=(150, 90, 90)); d.text((px(1) - 28, y1 + 46), "time ->", fill=(120, 120, 130))
        cells.append(im)
    cols = 2; rows = (len(cells) + 1) // 2; sheet = Image.new("RGB", (560 * cols, 330 * rows), (235, 235, 240))
    for i, im in enumerate(cells): sheet.paste(im, ((i % cols) * 560, (i // cols) * 330))
    sheet.save(os.path.join(a.out, "motion_curves.png")); txt = "\n".join(lines)
    open(os.path.join(a.out, "motion_report.txt"), "w").write(txt); print(txt); print(f"curves -> {os.path.join(a.out, 'motion_curves.png')}")

if __name__ == "__main__":
    main()
