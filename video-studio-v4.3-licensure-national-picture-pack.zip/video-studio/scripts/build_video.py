#!/usr/bin/env python3
"""Render a scenes file to per-scene MP4 clips + one full silent MP4 + SRT + cues.json (+ optional captioned copy).

  python build_video.py SCENES.py --out OUT [--quality standard] [--captions] [--only 1-4]
                        [--quality draft|standard|smooth|cinema|ultra]   (or --draft)   draft 720p20, standard 1080p30,
                                      smooth 1080p60, cinema 1080p30 + motion blur, ultra 4K30 + motion blur
                        [--blur N] [--height 720|1080|1440|2160] [--frames pipe|png]
                        [--voice voice/durations.json]   exact per-beat timing from make_voice.py
                        [--audio recording.mp3]          or scale all timing to one recording's length
                        [--fx off] [--fps 30] [--workers 6] [--wps 2.45]

Frames are rendered on several CPU cores at once. Re-running skips scenes whose clip already exists
(delete a clip, or the whole OUT/clips folder, to redo it).
"""
import argparse, importlib.util, json, multiprocessing as mp, os, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import platform_utils as PU            # makes ./bin ffmpeg visible, path helpers for Windows
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E
import skia

# Quality profiles: picture size, frame rate, motion-blur samples (1 = off) and the video encoder's speed/quality knobs.
QUALITY = {
    "draft":    dict(height=720,  fps=20, blur=1, preset="ultrafast", crf=26),
    "standard": dict(height=1080, fps=30, blur=1, preset="veryfast",  crf=18),
    "smooth":   dict(height=1080, fps=60, blur=1, preset="veryfast",  crf=18),
    "cinema":   dict(height=1080, fps=30, blur=4, preset="faster",    crf=17),
    "ultra":    dict(height=2160, fps=30, blur=3, preset="faster",    crf=19),
}
COLOR = ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv"]

FONTS = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts"))

def load(path):
    spec = importlib.util.spec_from_file_location("deck_scenes", path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m

def parse_range(r, n):
    if not r: return list(range(n))
    out = []
    for part in r.split(","):
        if "-" in part: a, b = part.split("-"); out += list(range(int(a) - 1, int(b)))
        else: out.append(int(part) - 1)
    return [i for i in out if 0 <= i < n]

def ts(x):
    ms = int(round(x * 1000)); h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def beat_end(sc, k):
    return sc["bs"][k + 1] if k + 1 < len(sc["bs"]) else sc["dur"] - sc.get("tail", E.TAIL)

def write_srt(tl, path):
    out, n = [], 1
    for sc in tl:
        for k, b in enumerate(sc["s"]["beats"]):
            words = b.split(); st = sc["t0"] + sc["bs"][k]; d = beat_end(sc, k) - sc["bs"][k] - (E.GAP if getattr(E, "_VOICE", False) else 0)
            chunks = [words[i:i + 11] for i in range(0, len(words), 11)]
            if len(chunks) > 1 and len(chunks[-1]) < 4:
                last = chunks.pop(); chunks[-1] += last
            tot = sum(len(c) for c in chunks); t = st
            for c in chunks:
                dd = d * len(c) / tot
                out.append(f"{n}\n{ts(t)} --> {ts(t + dd)}\n{' '.join(c)}\n"); n += 1; t += dd
    open(path, "w", encoding="utf-8").write("\n".join(out))

def write_cues(tl, total, path):
    data = dict(total=total, fps=E.FPS, scenes=[dict(i=sc["i"], t0=sc["t0"], dur=sc["dur"], chapter=sc["s"]["chapter"], sky=E.is_sky(sc["s"]), sfx=sc["s"].get("sfx"),
                beats=[dict(text=b, start=sc["t0"] + sc["bs"][k], end=sc["t0"] + beat_end(sc, k))
                       for k, b in enumerate(sc["s"]["beats"])]) for sc in tl])
    json.dump(data, open(path, "w"), indent=1)

# ---------------------------------------------------------------- parallel frame rendering
_TL = None; _DECK = None
def _init_worker(scenes_path, wps, scale, durs_items, deck_title, fx, fps, theme, render):
    global _TL, _DECK, _R
    load(scenes_path); E.set_theme(theme); E.FX = fx; E.FPS = fps; E.SCALE = render["height"] / 1080.0
    durs = {tuple(k): v for k, v in durs_items} if durs_items else None
    _TL, _ = E.build_timeline(E.SCENES, wps, scale, durs); _DECK = deck_title; _R = render
    PU.lower_priority()                       # keep the computer usable while rendering

def _render_job(job):                         # legacy PNG route
    i, t, path = job
    with open(path, "wb") as fh: fh.write(E.png_bytes(E.render_frame(_TL, i, t, _DECK)))
    return path

def _bgra(surface):
    return surface.makeImageSnapshot().toarray(colorType=skia.kBGRA_8888_ColorType)

def _frame_bytes(i, t):
    """One finished frame as raw BGRA bytes. With motion blur, several moments inside the shutter time are averaged."""
    n = _R["blur"]
    if n <= 1: return _bgra(E.render_frame(_TL, i, t, _DECK)).tobytes()
    import numpy as np
    dur, shutter, acc = _TL[i]["dur"], 0.5 / E.FPS, None            # 180-degree shutter
    for j in range(n):
        tt = min(max(0.0, t + ((j + 0.5) / n - 0.5) * shutter), dur - 0.001)
        a = _bgra(E.render_frame(_TL, i, tt, _DECK)).astype(np.uint16)
        acc = a if acc is None else acc + a
    return ((acc + n // 2) // n).astype(np.uint8).tobytes()

def _chunk_job(job):
    """Draw frames f0..f1 of scene i and feed them straight into an ffmpeg encoder (no image files). Returns (scene, chunk, path)."""
    i, k, f0, f1, path = job
    sc = _TL[i]; wins = E.dyn_windows(sc); fps = E.FPS; r = _R
    size = f"{round(E.W * E.SCALE)}x{round(E.H * E.SCALE)}"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", size, "-r", str(fps), "-i", "-",
           "-vf", "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p", "-c:v", "libx264", "-preset", r["preset"], "-crf", str(r["crf"]),
           "-threads", str(r["threads"]), *COLOR, "-an", path]
    log = open(path + ".log", "wb")
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=log)
    prev, last = None, None
    try:
        for f in range(f0, f1):
            t = f / fps
            dyn = E.FX or sc["s"].get("sky") or any(a <= t <= b for a, b in wins)
            key = None if dyn else sum(1 for _, b in wins if b < t)
            if key is None or key != prev or last is None: last = _frame_bytes(i, t)       # still moments reuse the previous frame
            prev = key; proc.stdin.write(last)
        proc.stdin.close(); rc = proc.wait()
    except OSError:
        rc = proc.wait() or 1
    finally:
        log.close()
    if rc != 0:
        with open(path + ".log", "rb") as fh: msg = fh.read().decode("utf-8", "replace")[-600:]
        raise RuntimeError(f"ffmpeg could not encode part of scene {i + 1}: {msg or 'unknown error'}")
    os.remove(path + ".log")
    return i, k, path

def render_scene_frames(pool, tl, i, fdir):
    sc = tl[i]; os.makedirs(fdir, exist_ok=True); wins = E.dyn_windows(sc)
    jobs, durs, prev = [], [], None
    for f in range(int(round(sc["dur"] * E.FPS))):
        t = f / E.FPS
        dyn = E.FX or sc["s"].get("sky") or any(a <= t <= b for a, b in wins)
        key = None if dyn else sum(1 for _, b in wins if b < t)
        if key is not None and key == prev:
            durs[-1] += 1.0 / E.FPS
        else:
            jobs.append((i, t, os.path.join(fdir, f"f{len(jobs):05d}.png"))); durs.append(1.0 / E.FPS)
        prev = key
    pool.map(_render_job, jobs, chunksize=3)
    lst = os.path.join(fdir, "list.txt")
    with open(lst, "w", encoding="utf-8") as fh:
        for (_, _, p), d in zip(jobs, durs): fh.write(f"file '{PU.concat_path(p)}'\nduration {d:.5f}\n")
        fh.write(f"file '{PU.concat_path(jobs[-1][2])}'\n")
    return lst, len(jobs)

def encode(lst, out, preset, crf, height):
    vf = f"fps={E.FPS},scale=out_color_matrix=bt709:out_range=tv,format=yuv420p"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-vf", vf,
                    "-c:v", "libx264", "-preset", preset, "-crf", str(crf), *COLOR, "-movflags", "+faststart", "-an", out], check=True)

def render_scenes_pipe(pool, tl, todo, out, n_scenes, t_start):
    """Cut every scene into ~3 second pieces, draw+encode the pieces on all workers, then join each scene's pieces."""
    fps = E.FPS; piece = max(int(fps * 3), 30); tasks, need, dirs = [], {}, {}
    for i in todo:
        clip = os.path.join(out, "clips", f"scene_{i+1:02d}.mp4")
        if os.path.exists(clip): print(f"scene {i+1}: clip exists, skipping", flush=True); continue
        d = os.path.join(out, "frames", f"s{i+1:02d}"); PU.rmtree(d); os.makedirs(d, exist_ok=True); dirs[i] = d
        n = int(round(tl[i]["dur"] * fps)); ks = list(range(0, n, piece)); need[i] = {}
        for k, f0 in enumerate(ks): tasks.append((i, k, f0, min(n, f0 + piece), os.path.join(d, f"part_{k:03d}.mp4")))
        need[i] = dict(total=len(ks), done={}, frames=n)
    for i, k, path in pool.imap_unordered(_chunk_job, tasks, chunksize=1):
        st = need[i]; st["done"][k] = path
        if len(st["done"]) == st["total"]:
            lst = os.path.join(dirs[i], "parts.txt")
            with open(lst, "w", encoding="utf-8") as fh:
                for kk in sorted(st["done"]): fh.write(f"file '{PU.concat_path(st['done'][kk])}'\n")
            clip = os.path.join(out, "clips", f"scene_{i+1:02d}.mp4")
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart",
                            clip + ".tmp.mp4"], check=True)
            os.replace(clip + ".tmp.mp4", clip); PU.rmtree(dirs[i])
            print(f"scene {i+1}/{n_scenes} done: {st['frames']} frames, {tl[i]['dur']:.1f}s, elapsed {time.time()-t_start:.0f}s", flush=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenes"); ap.add_argument("--out", required=True)
    ap.add_argument("--wps", type=float, default=2.45, help="narration pace in words/second (2.45 = ~147 wpm)")
    ap.add_argument("--audio", help="one narration recording; scales all beat timings so the video matches its length")
    ap.add_argument("--voice", help="voice/durations.json from make_voice.py: exact per-beat timing")
    ap.add_argument("--only", help="scene numbers to render, e.g. 1-4,7")
    ap.add_argument("--draft", action="store_true", help="same as --quality draft (fast 720p / 20 fps preview)")
    ap.add_argument("--quality", choices=list(QUALITY), help="draft, standard (default), smooth (1080p60), cinema (motion blur), ultra (4K + motion blur)")
    ap.add_argument("--height", type=int, choices=[720, 1080, 1440, 2160], help="picture height in pixels (overrides the quality profile)")
    ap.add_argument("--blur", type=int, help="motion-blur samples per frame: 1 = off, 3-4 = film look (slower)")
    ap.add_argument("--frames", choices=["pipe", "png"], default="pipe", help="pipe = frames go straight into ffmpeg (fast, default); png = old route via image files")
    ap.add_argument("--captions", action="store_true", help="also make a copy with the script burned in as captions")
    ap.add_argument("--theme", help="look to use: clean (default), ocean, techno, classroom, formal, playful, or your own file in themes/")
    ap.add_argument("--fx", choices=["on", "off"], default="on", help="off = no drifting light / camera push (much faster)")
    ap.add_argument("--fps", type=int, help="frames per second (default 30, draft 20)")
    ap.add_argument("--workers", type=int, help="render workers (default: chosen from your processor threads AND free memory)")
    ap.add_argument("--deck-title", help="footer text (default: DECK_TITLE in the scenes file)")
    a = ap.parse_args()
    m = load(a.scenes); scenes = E.SCENES
    theme = a.theme or getattr(m, "THEME", None) or "clean"; E.set_theme(theme)
    deck_title = a.deck_title or getattr(m, "DECK_TITLE", E.DECK_TITLE)
    prof = dict(QUALITY["draft" if a.draft and not a.quality else (a.quality or "standard")])
    if a.height: prof["height"] = a.height
    if a.blur: prof["blur"] = max(1, a.blur)
    E.FX = a.fx == "on"; E.FPS = a.fps or prof["fps"]; E.SCALE = prof["height"] / 1080.0
    durs, scale = None, 1.0
    if a.voice:
        raw = json.load(open(a.voice)); durs = {}
        for key, v in raw.items():
            i, k = key.split(","); durs[(int(i), int(k))] = max(1.2, v + E.GAP)
        E._VOICE = True
    tl, total = E.build_timeline(scenes, a.wps, 1.0, durs)
    if a.audio and not durs:
        dur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.audio]).decode().strip())
        overhead = len(scenes) * (E.LEAD + E.TAIL)
        scale = max(0.3, (dur - overhead) / (total - overhead)); tl, total = E.build_timeline(scenes, a.wps, scale)
        print(f"audio {dur:.1f}s -> timing scale {scale:.3f}", flush=True)
    os.makedirs(os.path.join(a.out, "clips"), exist_ok=True)
    preset, crf, height = prof["preset"], prof["crf"], 1080         # the picture is drawn at its final size, so no rescaling is needed
    todo = parse_range(a.only, len(scenes)); t_start = time.time()
    why = ""
    if a.workers: workers = a.workers
    else: workers, why = PU.choose_workers(prof["height"])
    prof["threads"] = 1 if workers >= 4 else 2
    qname = "draft" if a.draft and not a.quality else (a.quality or "standard")
    print(f"{len(scenes)} scenes, {total/60:.1f} min, {prof['height']}p {E.FPS} fps (quality {qname}{', motion blur x%d' % prof['blur'] if prof['blur'] > 1 else ''}), "
          f"fx {a.fx}, theme {theme}, {a.frames} mode", flush=True)
    print(f"using {why or str(workers) + ' workers'}", flush=True)
    ctx = mp.get_context("spawn")
    with ctx.Pool(workers, initializer=_init_worker,
                  initargs=(os.path.abspath(a.scenes), a.wps, scale, [[list(k), v] for k, v in durs.items()] if durs else None,
                            deck_title, E.FX, E.FPS, theme, prof)) as pool:
        if a.frames == "png":                                              # old route: image files, one scene at a time
            for i in todo:
                clip = os.path.join(a.out, "clips", f"scene_{i+1:02d}.mp4")
                if os.path.exists(clip): print(f"scene {i+1}: clip exists, skipping", flush=True); continue
                lst, nf = render_scene_frames(pool, tl, i, os.path.join(a.out, "frames", f"s{i+1:02d}"))
                encode(lst, clip + ".tmp.mp4", preset, crf, height); os.replace(clip + ".tmp.mp4", clip)
                PU.rmtree(os.path.join(a.out, "frames", f"s{i+1:02d}"))
                print(f"scene {i+1}/{len(scenes)} done: {nf} frames, {tl[i]['dur']:.1f}s, elapsed {time.time()-t_start:.0f}s", flush=True)
        else:                                                              # new route: every worker feeds its own ffmpeg, all scenes at once
            render_scenes_pipe(pool, tl, todo, a.out, len(scenes), t_start)
    clips = [os.path.join(a.out, "clips", f"scene_{i+1:02d}.mp4") for i in range(len(scenes))]
    write_srt(tl, os.path.join(a.out, "script_cues.srt")); write_cues(tl, total, os.path.join(a.out, "cues.json"))
    with open(os.path.join(a.out, "timing.tsv"), "w", encoding="utf-8") as fh:
        fh.write("scene\tstart_s\tduration_s\tchapter\n")
        for sc in tl: fh.write(f"{sc['i']+1}\t{sc['t0']:.2f}\t{sc['dur']:.2f}\t{sc['s']['chapter']}\n")
    if all(os.path.exists(c) for c in clips):
        lst = os.path.join(a.out, "clips.txt")
        with open(lst, "w", encoding="utf-8") as fh:
            for c in clips: fh.write(f"file '{PU.concat_path(c)}'\n")
        full = os.path.join(a.out, "full_video_silent.mp4")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", full], check=True)
        print(f"FULL VIDEO: {full} ({total:.0f}s)", flush=True)
        if a.captions:
            # run ffmpeg from inside the output folder with simple relative names (avoids quoting problems on Mac)
            cap = "full_video_with_captions.mp4"
            style = "FontName=Poppins,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Alignment=2,MarginV=22"
            style = style.replace(",", "\\,")
            try:
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", "full_video_silent.mp4", "-vf",
                                f"subtitles=script_cues.srt:fontsdir={PU.filter_path(FONTS)}:force_style={style}",
                                "-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-an", cap], check=True, cwd=a.out)
                print(f"CAPTIONED: {os.path.join(a.out, cap)}", flush=True)
            except subprocess.CalledProcessError:
                print("NOTE: the captioned copy could not be made (the main video is fine). Ignore this.", flush=True)
    else:
        print("Not all scene clips exist yet; run again without --only to assemble the full video.", flush=True)
    print("ALL DONE", flush=True)

if __name__ == "__main__":
    main()
