#!/usr/bin/env python3
"""Filmstrip of an entrance: shows how a scene's beat builds up, frame by frame, for every theme (or the ones you name).

  python motion_strip.py SCENES.py --scene 3 --beat 1 --out DIR [--frames 6] [--step 0.09] [theme ...]
  --scene is 1-based (as in the video), --beat is 0-based (the number inside S.p(beat)). step = seconds between frames.
"""
import argparse, importlib.util, io, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E
from PIL import Image, ImageDraw

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--scene", type=int, default=2); ap.add_argument("--beat", type=int, default=0)
    ap.add_argument("--frames", type=int, default=6); ap.add_argument("--step", type=float, default=0.09); ap.add_argument("--out", default="output/motion")
    ap.add_argument("themes", nargs="*"); a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    names = a.themes or E.theme_names(); cw, ch, lab = 320, 180, 110
    sheet = Image.new("RGB", (lab + cw * a.frames, ch * len(names) + 24), (24, 24, 28)); d = ImageDraw.Draw(sheet)
    for j in range(a.frames): d.text((lab + j * cw + 8, 6), f"+{j * a.step:.2f}s", fill=(200, 200, 205))
    for r, name in enumerate(names):
        E.set_theme(name); E.FX = True; tl, _ = E.build_timeline(E.SCENES, 2.45); sc = tl[a.scene - 1]; t0 = sc["bs"][min(a.beat, len(sc["bs"]) - 1)]
        d.text((10, 24 + r * ch + ch // 2 - 6), name.upper(), fill=(235, 235, 240))
        for j in range(a.frames):
            t = min(t0 + j * a.step, sc["dur"] - 0.02)
            im = Image.open(io.BytesIO(E.png_bytes(E.render_frame(tl, a.scene - 1, t, "MAAP-SEAS Familiarization")))).convert("RGB").resize((cw, ch), Image.LANCZOS)
            sheet.paste(im, (lab + j * cw, 24 + r * ch))
    path = os.path.join(a.out, f"strip_scene{a.scene:02d}_beat{a.beat}.png"); sheet.save(path); print("filmstrip ->", path)

if __name__ == "__main__":
    main()
