#!/usr/bin/env python3
"""Measure how fast THIS computer draws and encodes, and estimate the render time of your deck at every quality level.

  python benchmark.py SCENES.py [--theme clean]

It draws and encodes a few real frames per quality profile (takes about a minute), then multiplies by the number of frames
in your deck and divides by the number of render workers your free memory allows. Estimates cover the picture only
(the voice-over and sound mix add a minute or two) and the deck length is the pre-voice estimate.
"""
import argparse, importlib.util, os, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import platform_utils as PU
import engine as E, build_video as BV, skia

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--theme", default="clean"); a = ap.parse_args()
    spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    E.set_theme(a.theme); E.FX = True; BV._DECK = "benchmark"
    probe = [i for i in (2, 0, 8) if i < len(E.SCENES)] or [0]
    tl0, total = E.build_timeline(E.SCENES, 2.45)
    total_s = total; cores = os.cpu_count() or 1; tot_gb, free_gb = PU.memory_info()
    print(f"This computer: {cores} processor threads, " + (f"{free_gb:.1f} of {tot_gb:.1f} GB RAM free" if free_gb else "RAM unknown") + f"; deck length about {total_s / 60:.1f} min (before voice timing)\n")
    print(f"{'quality':9s} {'picture':>10s} {'fps':>4s} {'ms/frame':>9s} {'workers':>8s} {'RAM need':>9s} {'estimated picture render time'}")
    for name, q in BV.QUALITY.items():
        E.SCALE = q["height"] / 1080.0; E.FPS = q["fps"]; E._bg.clear()
        E.set_theme(a.theme); tl, _ = E.build_timeline(E.SCENES, 2.45); BV._TL = tl
        BV._R = dict(blur=q["blur"], preset=q["preset"], crf=q["crf"], threads=1)
        frames = []
        for i in probe: BV._frame_bytes(i, min(tl[i]["dur"] - 0.5, 6.0))               # warm-up
        t0 = time.perf_counter(); n = 0
        for i in probe:
            for k in range(3): frames.append(BV._frame_bytes(i, min(tl[i]["dur"] - 0.5, 6.0 + k * 0.4))); n += 1
        draw_ms = (time.perf_counter() - t0) / n * 1000
        w, h = round(E.W * E.SCALE), round(E.H * E.SCALE)
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{w}x{h}", "-r", str(q["fps"]), "-i", "-", "-vf",
               "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p", "-c:v", "libx264", "-preset", q["preset"], "-crf", str(q["crf"]), "-threads", "1", "-an",
               os.path.join(os.path.dirname(os.path.abspath(a.scenes)), "_bench.mp4")]
        t0 = time.perf_counter(); p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for _ in range(3):
            for fr in frames: p.stdin.write(fr)
        p.stdin.close(); p.wait(); enc_ms = (time.perf_counter() - t0) / (3 * len(frames)) * 1000
        try: os.remove(cmd[-1])
        except OSError: pass
        workers, _ = PU.choose_workers(q["height"]); per = draw_ms + enc_ms
        eff = workers * 0.85 if workers > 1 else 1.0
        minutes = total_s * q["fps"] * per / 1000 / eff / 60
        print(f"{name:9s} {w:>5d}x{h:<4d} {q['fps']:>4d} {per:>9.0f} {workers:>8d} {PU.worker_gb(q['height']) * workers:>7.1f}GB  about {minutes:5.1f} min" + ("   (motion blur x%d)" % q["blur"] if q["blur"] > 1 else ""))
    print("\nThese are estimates from a short test. Real times vary with the look you choose, the voice length and what else the computer is doing.")
    print("Tip: the default (standard) is right for most videos. Use cinema or ultra only for a final copy.")

if __name__ == "__main__":
    main()
