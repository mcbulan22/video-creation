"""sfx_synth: sound effects made from maths. No sample files, no licences, no downloads: Python standard library only.

Generators return a list of float samples (-1..1, mono, 44.1 kHz). A Mixer places them on a timeline and writes a WAV.

    from sfx_synth import *
    m = Mixer(total_seconds)
    m.put(2.0, whoosh(0.6), 0.4)
    m.put(2.6, pop(660), 0.25, pan=-0.3)
    m.render("sfx.wav")

Sounds: pop, tick, click, whoosh, riser, chime, impact, typing, shimmer, swell, splash.   (`python sfx_synth.py` writes a demo WAV.)
Everything is deterministic: the same call always makes the same sound.
"""
import math, random, wave, array, os, sys

SR = 44100
_CACHE = {}


def _cached(fn):
    def wrap(*a, **k):
        key = (fn.__name__, a, tuple(sorted(k.items())))
        if key not in _CACHE: _CACHE[key] = fn(*a, **k)
        return _CACHE[key]
    wrap.__name__ = fn.__name__; wrap.__doc__ = fn.__doc__
    return wrap


def _fade(x, a=0.004, b=0.01):
    n = len(x); na, nb = int(SR * a), int(SR * b)
    for i in range(min(na, n)): x[i] *= i / na
    for i in range(min(nb, n)): x[n - 1 - i] *= i / nb
    return x


@_cached
def pop(freq=620.0, dur=0.16, drop=0.5):
    """Soft rounded 'bloop' (an item appears)."""
    n = int(SR * dur); out = []; ph = 0.0
    for i in range(n):
        t = i / SR; ph += 2 * math.pi * freq * (1 - drop * t / dur) / SR
        out.append(math.sin(ph) * math.exp(-t * 20) * min(1.0, t / 0.002))
    return _fade(out)


@_cached
def tick(freq=1800.0, dur=0.05):
    """Tiny bright tick (counting, typing, small moves)."""
    n = int(SR * dur)
    return _fade([math.sin(2 * math.pi * freq * i / SR) * math.exp(-i / SR * 70) for i in range(n)], 0.001, 0.005)


@_cached
def click(dur=0.035, seed=1):
    """Dry key / button click."""
    r = random.Random(seed); n = int(SR * dur); prev = 0.0; out = []
    for i in range(n):
        x = r.uniform(-1, 1); out.append((x - prev) * 0.55 * math.exp(-i / SR * 260)); prev = x
    return out


def _svf_noise(n, fc_at, env_at, q=0.6, seed=1):
    r = random.Random(seed); low = band = 0.0; out = []
    for i in range(n):
        f = 2 * math.sin(math.pi * min(0.45, fc_at(i / max(1, n - 1)) / SR * 1.0))
        low += f * band; high = r.uniform(-1, 1) - low - q * band; band += f * high
        out.append(band * env_at(i / max(1, n - 1)))
    return out


@_cached
def whoosh(dur=0.65, f0=500.0, f1=3600.0, seed=2):
    """Air sweep for a scene change or a fast move."""
    n = int(SR * dur)
    out = _svf_noise(n, lambda u: f0 * (f1 / f0) ** u, lambda u: math.sin(math.pi * u) ** 1.6, 0.55, seed)
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.8 for v in out])


@_cached
def riser(dur=1.5, f0=250.0, f1=2600.0, seed=3):
    """Tension build that ends right at the reveal."""
    n = int(SR * dur); ph = 0.0
    nz = _svf_noise(n, lambda u: f0 * (f1 / f0) ** u, lambda u: u ** 2.2, 0.7, seed); out = []
    for i, v in enumerate(nz):
        u = i / n; ph += 2 * math.pi * (f0 * (f1 / f0) ** u) * 0.5 / SR
        out.append(v * 0.7 + math.sin(ph) * 0.25 * u ** 2)
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.85 for v in out], 0.02, 0.012)


@_cached
def chime(freq=880.0, dur=1.6):
    """Bell-like ding (success, ending, key point)."""
    parts = [(1.0, 1.0, 3.0), (2.0, 0.55, 4.5), (2.76, 0.32, 6.0), (5.4, 0.16, 8.0), (8.93, 0.08, 11.0)]; n = int(SR * dur); out = [0.0] * n
    for ratio, amp, dec in parts:
        w = 2 * math.pi * freq * ratio / SR
        for i in range(n): out[i] += math.sin(w * i) * amp * math.exp(-i / SR * dec)
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.8 for v in out], 0.002, 0.05)


@_cached
def impact(dur=1.0, freq=58.0, seed=4):
    """Low thud with a short noise hit (a heavy landing)."""
    r = random.Random(seed); n = int(SR * dur); out = []; ph = 0.0; lp = 0.0
    for i in range(n):
        t = i / SR; ph += 2 * math.pi * freq * (1 + 2.2 * math.exp(-t * 18)) / SR
        lp += 0.12 * (r.uniform(-1, 1) - lp)
        out.append(math.sin(ph) * math.exp(-t * 5.5) * 0.9 + lp * math.exp(-t * 30) * 0.8)
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.9 for v in out], 0.001, 0.03)


@_cached
def typing(chars=20, dur=1.2, seed=5):
    """A run of key clicks spread over dur seconds."""
    r = random.Random(seed); n = int(SR * (dur + 0.05)); out = [0.0] * n
    for k in range(chars):
        t = (k + r.uniform(-0.25, 0.25)) / max(1, chars) * dur; s = int(max(0.0, t) * SR); c = click(0.03, r.randint(1, 6)); g = r.uniform(0.6, 1.0)
        for i, v in enumerate(c):
            if s + i < n: out[s + i] += v * g
    return out


@_cached
def shimmer(dur=1.2, seed=6):
    """Sparkle: a few high glassy pings (celebration, magic)."""
    r = random.Random(seed); n = int(SR * dur); out = [0.0] * n
    for k in range(7):
        s = int(r.uniform(0, dur * 0.55) * SR); f = r.choice((1568.0, 1976.0, 2349.0, 2637.0, 3136.0)); g = r.uniform(0.35, 0.8)
        for i in range(min(int(SR * 0.45), n - s)): out[s + i] += math.sin(2 * math.pi * f * i / SR) * math.exp(-i / SR * 9) * g
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.7 for v in out], 0.001, 0.05)


@_cached
def swell(dur=2.5, freq=110.0):
    """Soft pad that breathes in and out (opening or closing bed)."""
    n = int(SR * dur); out = []
    for i in range(n):
        t = i / SR; env = math.sin(math.pi * i / n) ** 2
        v = sum(math.sin(2 * math.pi * freq * m * (1 + d) * t) * a for m, d, a in ((1, 0.0, 1.0), (1, 0.004, 0.7), (1.5, 0.0, 0.5), (2, -0.003, 0.35)))
        out.append(v * env * 0.28)
    return out


@_cached
def splash(dur=2.2, seed=7):
    """Deep water rush (the dive from the sky scene into the sea)."""
    n = int(SR * dur); r = random.Random(seed); lp = 0.0; out = []
    for i in range(n):
        u = i / n; a = 0.02 + 0.25 * (1.0 - u) ** 0.5; lp += a * (r.uniform(-1, 1) - lp)
        env = min(1.0, u / 0.2) * (1.0 - u) ** 1.2; out.append(lp * env * 3.0)
    pk = max(abs(v) for v in out) or 1.0
    return _fade([v / pk * 0.9 for v in out], 0.01, 0.05)


GENERATORS = dict(pop=pop, tick=tick, click=click, whoosh=whoosh, riser=riser, chime=chime, impact=impact, typing=typing, shimmer=shimmer, swell=swell, splash=splash)


class Mixer:
    """Places sounds on a timeline (seconds) and writes a stereo 16-bit WAV."""
    def __init__(self, total):
        self.n = int(total * SR) + SR
        self.L = array.array("f", bytes(4 * self.n)); self.R = array.array("f", bytes(4 * self.n)); self.spans = []

    def put(self, t, snd, gain=1.0, pan=0.0):
        s = int(round(t * SR))
        if s < 0: snd = snd[-s:]; s = 0
        e = min(self.n, s + len(snd))
        if e <= s: return
        a = (max(-1.0, min(1.0, pan)) + 1) * math.pi / 4; gl, gr = gain * math.cos(a), gain * math.sin(a)
        L, R = self.L, self.R
        for i in range(e - s):
            v = snd[i]; L[s + i] += v * gl; R[s + i] += v * gr
        self.spans.append((s, e))

    def render(self, path, ceiling=0.89):
        peak = 0.0
        for s, e in self.spans:
            for i in range(s, e):
                a = abs(self.L[i]); b = abs(self.R[i]); peak = max(peak, a, b)
        k = ceiling / peak if peak > ceiling else 1.0
        secs = {}
        for s, e in self.spans:
            for sec in range(s // SR, (e - 1) // SR + 1): secs[sec] = True
        with wave.open(path, "wb") as w:
            w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
            for sec in range(0, (self.n + SR - 1) // SR):
                s0, s1 = sec * SR, min(self.n, (sec + 1) * SR)
                if not secs.get(sec): w.writeframes(bytes(4 * (s1 - s0))); continue
                buf = array.array("h", bytes(4 * (s1 - s0)))
                for i in range(s1 - s0):
                    buf[2 * i] = int(max(-1.0, min(1.0, self.L[s0 + i] * k)) * 32767); buf[2 * i + 1] = int(max(-1.0, min(1.0, self.R[s0 + i] * k)) * 32767)
                if sys.byteorder == "big": buf.byteswap()
                w.writeframes(buf.tobytes())
        return path


if __name__ == "__main__":
    m = Mixer(9.0); t = 0.3
    for name in ("pop", "tick", "click", "whoosh", "riser", "chime", "impact", "typing", "shimmer", "swell"):
        snd = GENERATORS[name](); m.put(t, snd, 0.6); t += len(snd) / SR + 0.25
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sfx_demo.wav"); m.render(out); print("wrote", os.path.abspath(out))
