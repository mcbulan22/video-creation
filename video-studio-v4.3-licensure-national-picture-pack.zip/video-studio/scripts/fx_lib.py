"""fx_lib (v4.1): the FREEFORM toolbox. Imported by engine.py and available in scenes as `fx`.

Why this exists: Claude can write bespoke animation code for each video (see FREEFORM.md). Everything here is
STATELESS: a pure function of the time `t` (seconds), never of "the previous frame". That matters because frames are
rendered in parallel chunks in any order, so an effect must look the same no matter which frame is drawn first.

Typical use inside a scene or a scene's bg / fg hook:
    fx.mesh_gradient(c, t, ("teal", "sky", "amber"))
    fx.particles(c, t, origin=(960, 540), n=200, gravity=400, colors=("teal", "amber"))
    with fx.camera(S.c, *fx.keyframes(S.t, [(0, (1.0, 960, 540)), (4, (1.2, 1100, 500), "in_out_sine")])): ...
Colours are palette roles ("teal", "white", ...) or "#RRGGBB". Canvas is 1920x1080.
"""
import math, random, re, functools, contextlib
import skia
import engine as E
from engine import hexc

W, H = E.W, E.H


# ================================================================== numbers, easing, keyframes
def clamp(x, a=0.0, b=1.0): return a if x < a else (b if x > b else x)
def lerp(a, b, t): return a + (b - a) * t
def smoothstep(a, b, x):
    u = clamp((x - a) / (b - a)) if b != a else 0.0
    return u * u * (3 - 2 * u)
def remap(x, a0, a1, b0, b1, ease="linear"):
    """Map x from range a0..a1 to range b0..b1 (clamped), with an optional easing name."""
    return lerp(b0, b1, EASE_FN(ease)(clamp((x - a0) / (a1 - a0)))) if a1 != a0 else b0


def _bounce(x):
    x = clamp(x); n, d = 7.5625, 2.75
    if x < 1 / d: return n * x * x
    if x < 2 / d: x -= 1.5 / d; return n * x * x + 0.75
    if x < 2.5 / d: x -= 2.25 / d; return n * x * x + 0.9375
    x -= 2.625 / d; return n * x * x + 0.984375

def _elastic(x):
    x = clamp(x)
    return x if x in (0.0, 1.0) else 2 ** (-10 * x) * math.sin((x * 10 - 0.75) * (2 * math.pi / 3)) + 1

EASE = {
    "linear": lambda x: clamp(x),
    "in_quad": lambda x: clamp(x) ** 2, "out_quad": lambda x: 1 - (1 - clamp(x)) ** 2,
    "in_out_quad": lambda x: 2 * clamp(x) ** 2 if x < .5 else 1 - (-2 * clamp(x) + 2) ** 2 / 2,
    "out_cubic": E.ease_out_cubic, "out_quint": E.ease_out_quint, "out_expo": E.ease_out_expo,
    "in_out_sine": E.ease_in_out_sine, "out_back": lambda x: E.ease_back(x, 1.7), "spring": E.ease_spring,
    "out_elastic": _elastic, "out_bounce": _bounce, "snap": E.bezier(0.2, 0.9, 0.1, 1), "standard": E.bezier(0.2, 0, 0, 1),
    "in_out_cubic": lambda x: 4 * clamp(x) ** 3 if x < .5 else 1 - (-2 * clamp(x) + 2) ** 3 / 2,
    "in_cubic": lambda x: clamp(x) ** 3, "in_expo": lambda x: 0.0 if x <= 0 else 2 ** (10 * clamp(x) - 10),
}
def EASE_FN(e): return e if callable(e) else EASE[e]
def ease(name, x): return EASE_FN(name)(x)


# ---- exact springs (closed-form, so they are stateless and look the same on every frame)
SPRINGS = dict(gentle=(120.0, 20.0, 1.0), snappy=(300.0, 28.0, 1.0), bouncy=(220.0, 12.0, 1.0), wobbly=(150.0, 8.0, 1.0), stiff=(500.0, 40.0, 1.0), slow=(60.0, 14.0, 1.0))


def spring_step(t, k=170.0, c=22.0, m=1.0, v0=0.0):
    """Exact position of a damped spring released at 0 and pulled toward 1, t seconds after release (stiffness k, damping c,
    mass m, optional starting speed v0 in units/second). Under-, critically and over-damped cases are all handled."""
    if t <= 0: return 0.0
    w0 = math.sqrt(k / m); z = c / (2 * math.sqrt(k * m))
    if z < 1 - 1e-6:
        wd = w0 * math.sqrt(1 - z * z); return 1 - math.exp(-z * w0 * t) * (math.cos(wd * t) + ((z * w0 - v0) / wd) * math.sin(wd * t))
    if z <= 1 + 1e-6: return 1 - (1 + (w0 - v0) * t) * math.exp(-w0 * t)
    s = math.sqrt(z * z - 1); r1, r2 = -w0 * (z - s), -w0 * (z + s); c2 = (v0 + r1) / (r2 - r1); c1 = -1 - c2
    return 1 + c1 * math.exp(r1 * t) + c2 * math.exp(r2 * t)


_SETTLE = {}
def spring_settle(k, c, m=1.0, tol=0.002):
    """Seconds until the spring stays within tol of its target."""
    key = (k, c, m, tol)
    if key not in _SETTLE:
        t = 8.0
        while t > 0.02 and abs(spring_step(t, k, c, m) - 1) <= tol: t -= 1 / 240
        _SETTLE[key] = t + 1 / 240
    return _SETTLE[key]


def spring_ease(preset="bouncy", settle=None):
    """An easing function (0..1 in, 0..1+ out, overshoot included) driven by an exact spring and stretched so it SETTLES exactly at x = 1.
    preset = a name from SPRINGS or a tuple (stiffness, damping, mass). Use it anywhere an ease is accepted: S.p(1, 0.9, ease="spring_bouncy")."""
    k, c, m = SPRINGS[preset] if isinstance(preset, str) else preset; T = settle or spring_settle(k, c, m)
    def f(x):
        if x <= 0: return 0.0
        if x >= 1: return 1.0
        return spring_step(x * T, k, c, m)
    return f


def spring(t, preset="bouncy", v0=0.0):
    """Raw spring position at t seconds (real time, not 0..1): spring(t, "bouncy")."""
    k, c, m = SPRINGS[preset] if isinstance(preset, str) else preset; return spring_step(t, k, c, m, v0)


for _n in SPRINGS: EASE["spring_" + _n] = spring_ease(_n)


# ---- camera path in log space, with a focus point that travels at constant apparent speed
def cam(t, kfs, default_ease="in_out_sine", shake=0.0, shake_freq=0.8, seed=1):
    """Camera path. kfs = [(time, (zoom, cx, cy[, rot_degrees])[, easing]), ...]. Returns the arguments for fx.camera:
        with fx.camera(S.c, *fx.cam(S.t, [(0, (1.0, 960, 540)), (6, (2.0, 1300, 400), "in_out_sine")])): ...
    Zoom is blended in LOG space (1x to 2x takes as long to the eye as 2x to 4x), and the focus point is blended so a pan during a zoom
    keeps a constant on-screen speed (a straight dolly, not a swerve). shake > 0 adds a soft hand-held drift (pixels)."""
    def pose(v): return (v[0], v[1], v[2], v[3] if len(v) > 3 else 0.0)
    if t <= kfs[0][0]: z, cx, cy, rot = pose(kfs[0][1])
    elif t >= kfs[-1][0]: z, cx, cy, rot = pose(kfs[-1][1])
    else:
        for a, b in zip(kfs, kfs[1:]):
            if a[0] <= t <= b[0]:
                u = EASE_FN(b[2] if len(b) > 2 else default_ease)((t - a[0]) / (b[0] - a[0])); z0, x0, y0, r0 = pose(a[1]); z1, x1, y1, r1 = pose(b[1])
                z = z0 * (z1 / z0) ** u; w = u if abs(z1 - z0) < 1e-9 else (1 / z - 1 / z0) / (1 / z1 - 1 / z0)
                cx, cy, rot = lerp(x0, x1, w), lerp(y0, y1, w), lerp(r0, r1, u); break
    dx = dy = 0.0
    if shake:
        dx = (noise1(t * shake_freq, seed) - 0.5) * 2 * shake; dy = (noise1(t * shake_freq, seed + 11) - 0.5) * 2 * shake; rot += (noise1(t * shake_freq, seed + 23) - 0.5) * shake * 0.02
    return (z, cx, cy, dx, dy, rot)


def keyframes(t, kfs, default_ease="in_out_sine"):
    """Value at time t from keyframes [(time, value[, easing]), ...]. value = number or tuple of numbers.
    The easing on a keyframe shapes the segment that ARRIVES at it. Holds the first / last value outside the range."""
    if not kfs: return 0.0
    if t <= kfs[0][0]: return kfs[0][1]
    for a, b in zip(kfs, kfs[1:]):
        if t <= b[0]:
            e = EASE_FN(b[2] if len(b) > 2 else default_ease); u = e((t - a[0]) / (b[0] - a[0])) if b[0] > a[0] else 1.0
            va, vb = a[1], b[1]
            if isinstance(va, (tuple, list)): return tuple(lerp(x, y, u) for x, y in zip(va, vb))
            return lerp(va, vb, u)
    return kfs[-1][1]


def sequence(t, items):
    """items = [(start, duration), ...] -> list of eased 0..1 progress for each item at time t (for choreographing a scene)."""
    return [clamp((t - s) / d) if d > 0 else (1.0 if t >= s else 0.0) for s, d in items]


def pulse(t, period=2.0, lo=0.0, hi=1.0, phase=0.0):
    return lo + (hi - lo) * (0.5 + 0.5 * math.sin(2 * math.pi * (t / period + phase)))


def col(name): return E.C.get(name, name)
def mix_color(a, b, t):
    A, B = col(a).lstrip("#"), col(b).lstrip("#"); t = clamp(t)
    return "#%02X%02X%02X" % tuple(round(lerp(int(A[i:i + 2], 16), int(B[i:i + 2], 16), t)) for i in (0, 2, 4))


def _paint(color, a=1.0, stroke=0, cap=True):
    pt = skia.Paint(AntiAlias=True, Color=hexc(col(color), clamp(a)))
    if stroke:
        pt.setStyle(skia.Paint.kStroke_Style); pt.setStrokeWidth(stroke)
        if cap: pt.setStrokeCap(skia.Paint.kRound_Cap); pt.setStrokeJoin(skia.Paint.kRound_Join)
    return pt

def _glow_paint(color, a, sigma, stroke=0):
    pt = _paint(color, a, stroke); pt.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, sigma)); return pt

def _radial(cx, cy, r, color, a):
    pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(col(color), a), hexc(col(color), 0)], [0, 1])); return pt


# ================================================================== noise
def _hash(ix, iy, seed):
    n = (ix * 374761393 + iy * 668265263 + seed * 1274126177) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFFFF) / 16777215.0

def noise2(x, y, seed=0):
    """Smooth value noise, 0..1. Same inputs always give the same output."""
    ix, iy = math.floor(x), math.floor(y); fx_, fy_ = x - ix, y - iy
    u, v = fx_ * fx_ * (3 - 2 * fx_), fy_ * fy_ * (3 - 2 * fy_)
    a, b = _hash(ix, iy, seed), _hash(ix + 1, iy, seed); c_, d = _hash(ix, iy + 1, seed), _hash(ix + 1, iy + 1, seed)
    return lerp(lerp(a, b, u), lerp(c_, d, u), v)

def noise1(x, seed=0): return noise2(x, 0.37, seed)

def fbm(x, y, seed=0, octaves=3):
    tot, amp, fr, norm = 0.0, 1.0, 1.0, 0.0
    for _ in range(octaves): tot += amp * noise2(x * fr, y * fr, seed); norm += amp; amp *= 0.5; fr *= 2.0
    return tot / norm


# ================================================================== ambient backgrounds and effects (call from a scene's bg=, or inside a scene)
def mesh_gradient(c, t, colors=("teal", "sky", "amber"), base="bg1", blobs=5, alpha=0.32, speed=0.12, seed=1, radius=760):
    """Slow-moving soft colour blobs on a base colour (a 'mesh gradient' look)."""
    c.drawRect(skia.Rect.MakeWH(W, H), _paint(base))
    rnd = random.Random(seed)
    for i in range(blobs):
        ph1, ph2, f1, f2 = rnd.random() * 6.28, rnd.random() * 6.28, rnd.uniform(.6, 1.4), rnd.uniform(.6, 1.4)
        cx = W * (0.5 + 0.45 * math.sin(speed * t * f1 + ph1)); cy = H * (0.5 + 0.45 * math.cos(speed * t * f2 + ph2))
        r = radius * rnd.uniform(.7, 1.2); c.drawCircle(cx, cy, r, _radial(cx, cy, r, colors[i % len(colors)], alpha))


@functools.lru_cache(maxsize=16)
def _seeds(n, seed, k=6):
    rnd = random.Random(seed); return [tuple(rnd.random() for _ in range(k)) for _ in range(n)]


def flowfield(c, t, color="teal", n=110, steps=24, step_len=9.0, scale=0.0016, speed=0.07, alpha=0.32, sw=2.0, seed=1, region=(0, 0, W, H), twist=2.0, color2=None):
    """Flowing curves that follow a noise field (calm, silky background). n up to about 160 stays fast."""
    x0, y0, x1, y1 = region
    for i, (a, b, *_r) in enumerate(_seeds(n, seed)):
        x, y = lerp(x0, x1, a), lerp(y0, y1, b); pa = skia.Path(); pa.moveTo(x, y)
        for _ in range(steps):
            ang = fbm(x * scale, y * scale + t * speed, seed, 2) * 6.2832 * twist
            x += math.cos(ang) * step_len; y += math.sin(ang) * step_len; pa.lineTo(x, y)
        cc = mix_color(color, color2, i / n) if color2 else color
        c.drawPath(pa, _paint(cc, alpha * (0.5 + 0.5 * _r[0]), sw))


def particles(c, t, origin=None, region=(0, 0, W, H), n=140, seed=1, life=3.0, speed=(60, 220), angle=(0.0, 6.2832), gravity=0.0,
              size=(3, 9), colors=("teal",), shape="circle", start=0.0, end=None, fade=0.25, glow=0.0, drag=0.0, wind=0.0, alpha=1.0):
    """Stateless particle system. origin=(x, y) emits from a point; otherwise particles spawn inside region (x0, y0, x1, y1).
    angle in radians (0 = right, pi/2 = down, -pi/2 = up). shape: circle, rect, spark, ring.
    start / end limit when emitting. glow adds a soft halo on every third particle. Keep n under about 400."""
    if t < start: return
    for i, (a, b, cc, dd, ee, ff) in enumerate(_seeds(n, seed)):
        off = i / n * life; raw = t - start - off
        if raw < 0: continue
        k = int(raw // life); age = raw - k * life
        if end is not None and start + off + k * life > end: continue
        ra, rb, rc, rd, re_, rf = ((v + k * g) % 1.0 for v, g in zip((a, b, cc, dd, ee, ff), (.618, .414, .732, .236, .317, .577)))
        spd = lerp(speed[0], speed[1], ra); ang = lerp(angle[0], angle[1], rb)
        ox, oy = origin if origin else (lerp(region[0], region[2], rc), lerp(region[1], region[3], rd))
        vx, vy = math.cos(ang) * spd + wind, math.sin(ang) * spd
        f = (1 - math.exp(-drag * age)) / drag if drag > 0 else age
        px, py = ox + vx * f, oy + vy * f + 0.5 * gravity * age * age
        u = age / life; fa = min(1.0, u / fade, (1 - u) / fade) if fade > 0 else 1.0
        if fa <= 0.01: continue
        s = lerp(size[0], size[1], re_) * (1 - 0.4 * u); color = colors[i % len(colors)]; al = alpha * fa
        if glow and i % 3 == 0: c.drawCircle(px, py, s * 3.2, _glow_paint(color, al * 0.6 * glow, s * 1.2))
        if shape == "rect":
            c.save(); c.translate(px, py); c.rotate(math.degrees(rf * 6.28 + age * (rf - .5) * 9)); c.drawRect(skia.Rect.MakeXYWH(-s, -s * .5, s * 2, s), _paint(color, al)); c.restore()
        elif shape == "spark":
            m = math.hypot(vx, vy) or 1.0; c.drawLine(px, py, px - vx / m * s * 3, py - vy / m * s * 3, _paint(color, al, max(1.5, s * .4)))
        elif shape == "ring": c.drawCircle(px, py, s * 1.4, _paint(color, al, max(1.5, s * .25)))
        else: c.drawCircle(px, py, s, _paint(color, al))


def stars(c, t, n=90, seed=3, region=(0, 0, W, H), color="white", twinkle=1.0, size=(1.0, 2.8), alpha=0.8):
    for a, b, cc, dd, ee, ff in _seeds(n, seed):
        tw = 0.5 + 0.5 * math.sin(t * (0.8 + ee * 2.2) * twinkle + ff * 6.28)
        c.drawCircle(lerp(region[0], region[2], a), lerp(region[1], region[3], b), lerp(*size, cc) * (0.7 + 0.3 * tw), _paint(color, alpha * (0.3 + 0.7 * tw)))


def network(c, t, n=46, seed=2, color="teal", link=200.0, speed=1.0, region=(0, 0, W, H), alpha=0.55, node=4.0, sw=1.6):
    """Drifting nodes joined by lines when they are close (data / connection look)."""
    pts = []
    for a, b, cc, dd, ee, ff in _seeds(n, seed):
        bx, by = lerp(region[0], region[2], a), lerp(region[1], region[3], b)
        pts.append((bx + 60 * math.sin(speed * t * (0.2 + cc * 0.4) + ff * 6.28), by + 50 * math.cos(speed * t * (0.2 + dd * 0.4) + ee * 6.28)))
    for i in range(n):
        for j in range(i + 1, n):
            d = math.hypot(pts[i][0] - pts[j][0], pts[i][1] - pts[j][1])
            if d < link: c.drawLine(pts[i][0], pts[i][1], pts[j][0], pts[j][1], _paint(color, alpha * (1 - d / link), sw))
    for x, y in pts: c.drawCircle(x, y, node, _paint(color, min(1.0, alpha + 0.3)))


def rings(c, t, x, y, n=4, color="teal", period=3.0, max_r=520.0, sw=3.0, alpha=0.6):
    for k in range(n):
        u = ((t / period) + k / n) % 1.0; c.drawCircle(x, y, 20 + max_r * u, _paint(color, alpha * (1 - u), sw))


def sunburst(c, t, x, y, rays=22, r0=60.0, r1=1400.0, color="amber", alpha=0.12, spin=0.04):
    """Rotating wedge rays from a point (a hero / celebration backdrop)."""
    for k in range(rays):
        a0 = (k / rays + spin * t) * 6.2832; a1 = a0 + 6.2832 / rays * 0.5; pa = skia.Path(); pa.moveTo(x + r0 * math.cos(a0), y + r0 * math.sin(a0))
        pa.lineTo(x + r1 * math.cos(a0), y + r1 * math.sin(a0)); pa.lineTo(x + r1 * math.cos(a1), y + r1 * math.sin(a1)); pa.lineTo(x + r0 * math.cos(a1), y + r0 * math.sin(a1)); pa.close()
        c.drawPath(pa, _paint(color, alpha))


def perspective_grid(c, t, horizon=560.0, color="teal", alpha=0.35, cols=18, rows=14, speed=0.4):
    """Retro / tech floor grid rushing toward the viewer."""
    for k in range(-cols // 2, cols // 2 + 1): c.drawLine(W / 2 + k * 36, horizon, W / 2 + k * 210, H, _paint(color, alpha * 0.8, 1.6))
    for j in range(rows):
        f = ((j + (t * speed) % 1.0) / rows); y = horizon + (H - horizon) * f ** 2.2
        c.drawLine(0, y, W, y, _paint(color, alpha * (0.3 + 0.7 * f), 1.2 + 2 * f))


def waveform(c, x, y, w, h, t, bars=48, color="teal", seed=4, speed=2.2, alpha=0.9, gap=0.35, center=True):
    """Equalizer bars (decoration for audio / voice / signal topics)."""
    bw = w / (bars * (1 + gap))
    for i in range(bars):
        v = 0.15 + 0.85 * noise2(i * 0.35, t * speed, seed); bh = h * v; bx = x + i * bw * (1 + gap)
        c.drawRoundRect(skia.Rect.MakeXYWH(bx, (y - bh / 2) if center else (y - bh), bw, bh), bw / 2, bw / 2, _paint(color, alpha))


def bokeh(c, t, n=22, seed=5, colors=("teal", "amber", "sky"), alpha=0.16, size=(30, 110), drift=14.0):
    for i, (a, b, cc, dd, ee, ff) in enumerate(_seeds(n, seed)):
        x = a * W + 40 * math.sin(0.12 * t + ff * 6.28); y = (b * (H + 200) - t * drift * (0.4 + ee)) % (H + 200) - 100; r = lerp(*size, cc)
        c.drawCircle(x, y, r, _paint(colors[i % len(colors)], alpha * (0.5 + 0.5 * dd)))


def halftone(c, rect, t, color="teal", cell=28, alpha=0.35, scale=0.004, speed=0.2, max_r=None):
    """Dot grid whose dot size follows moving noise (print / editorial texture)."""
    x0, y0, x1, y1 = rect; mr = max_r or cell * 0.48; yy = y0
    while yy < y1:
        xx = x0
        while xx < x1:
            r = mr * noise2(xx * scale + t * speed, yy * scale, 7)
            if r > 1: c.drawCircle(xx, yy, r, _paint(color, alpha))
            xx += cell
        yy += cell


def light_streaks(c, t, n=7, color="white", alpha=0.07, seed=8, angle=-0.35, speed=0.15):
    for a, b, cc, dd, ee, ff in _seeds(n, seed):
        x = ((a + t * speed * (0.5 + ee)) % 1.4 - 0.2) * W; wdt = 40 + 120 * cc
        c.save(); c.translate(x, H / 2); c.rotate(math.degrees(angle)); c.drawRect(skia.Rect.MakeXYWH(-wdt / 2, -H, wdt, 2 * H), _paint(color, alpha * (0.4 + dd))); c.restore()


def vignette(c, a=0.5, color="#000000"):
    pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(W / 2, H / 2), 1250, [hexc(col(color), 0), hexc(col(color), a)], [0.5, 1])); c.drawRect(skia.Rect.MakeWH(W, H), pt)

def scanlines(c, alpha=0.05, gap=4, color="#000000"):
    for y in range(0, H, gap): c.drawRect(skia.Rect.MakeXYWH(0, y, W, 1.2), _paint(color, alpha))


# ================================================================== camera
@contextlib.contextmanager
def camera(c, zoom=1.0, cx=W / 2, cy=H / 2, dx=0.0, dy=0.0, rot=0.0):
    """with fx.camera(S.c, zoom, cx, cy): ...   Everything drawn inside is viewed through a moving camera:
    zoom about (cx, cy), then shifted by (dx, dy), optionally rotated (degrees). Animate with fx.keyframes()."""
    c.save(); c.translate(W / 2 + dx, H / 2 + dy)
    if rot: c.rotate(rot)
    c.scale(zoom, zoom); c.translate(-cx, -cy)
    try: yield
    finally: c.restore()


# ================================================================== SVG path data -> drawing that draws itself
_NUMRE = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
_SVGC = {}


class _Rd:
    """Character-level reader for SVG path data (handles compact forms such as 'a5 5 0 017.07 0' and '1.5.5')."""
    def __init__(s, d): s.d = d; s.i = 0; s.n = len(d)
    def ws(s):
        while s.i < s.n and s.d[s.i] in " \t\r\n,": s.i += 1
    def end(s): s.ws(); return s.i >= s.n
    def at_cmd(s): s.ws(); return s.i < s.n and s.d[s.i].isalpha()
    def cmd(s): s.ws(); c = s.d[s.i]; s.i += 1; return c
    def num(s):
        s.ws(); m = _NUMRE.match(s.d, s.i)
        if not m: raise ValueError(f"bad SVG path data near {s.d[s.i:s.i + 20]!r}")
        s.i = m.end(); return float(m.group(0))
    def flag(s):
        s.ws()
        if s.i >= s.n or s.d[s.i] not in "01": raise ValueError(f"bad arc flag near {s.d[s.i:s.i + 20]!r}")
        s.i += 1; return int(s.d[s.i - 1])


def _arc_pts(x1, y1, rx, ry, phi_deg, fa, fs, x2, y2, steps):
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2): return [(x2, y2)]
    phi = math.radians(phi_deg); cp, sp = math.cos(phi), math.sin(phi); rx, ry = abs(rx), abs(ry)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2; x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = x1p ** 2 / rx ** 2 + y1p ** 2 / ry ** 2
    if lam > 1: s = math.sqrt(lam); rx *= s; ry *= s
    num = rx ** 2 * ry ** 2 - rx ** 2 * y1p ** 2 - ry ** 2 * x1p ** 2; den = rx ** 2 * y1p ** 2 + ry ** 2 * x1p ** 2
    co = math.sqrt(max(0.0, num / den)) if den else 0.0
    if fa == fs: co = -co
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx; cx, cy = cp * cxp - sp * cyp + (x1 + x2) / 2, sp * cxp + cp * cyp + (y1 + y2) / 2
    def ang(ux, uy, vx, vy): return math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
    th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry); dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dth > 0: dth -= 2 * math.pi
    elif fs and dth < 0: dth += 2 * math.pi
    n = max(4, int(steps * abs(dth) / 1.57)); out = []
    for k in range(1, n + 1):
        a = th1 + dth * k / n; ex, ey = rx * math.cos(a), ry * math.sin(a); out.append((cp * ex - sp * ey + cx, sp * ex + cp * ey + cy))
    return out


def svg_polylines(d, steps=14):
    """SVG path data string -> list of polylines [(x, y), ...]. Supports M L H V C S Q T A Z (absolute and relative)."""
    key = (d, steps)
    if key in _SVGC: return _SVGC[key]
    r = _Rd(d); subs, cur = [], []; x = y = sx = sy = 0.0; cmd = None; lc = lq = None
    def cubic(p0, p1, p2, p3): return [(((1 - u) ** 3) * p0[0] + 3 * ((1 - u) ** 2) * u * p1[0] + 3 * (1 - u) * u * u * p2[0] + u ** 3 * p3[0],
                                        ((1 - u) ** 3) * p0[1] + 3 * ((1 - u) ** 2) * u * p1[1] + 3 * (1 - u) * u * u * p2[1] + u ** 3 * p3[1]) for u in [k / steps for k in range(1, steps + 1)]]
    while not r.end():
        if r.at_cmd():
            cmd = r.cmd()
            if cmd in "Zz":
                if cur: cur.append((sx, sy)); subs.append(cur); cur = []
                x, y = sx, sy; lc = lq = None; continue
        elif cmd is None: raise ValueError("SVG path data must start with M")
        elif cmd in "Zz": raise ValueError(f"unexpected numbers after Z: {d[:60]!r}")
        rel = cmd.islower(); C = cmd.upper(); ox, oy = (x, y) if rel else (0.0, 0.0)
        if C == "M":
            a, b = r.num(), r.num(); x, y = a + ox, b + oy
            if cur: subs.append(cur)
            cur = [(x, y)]; sx, sy = x, y; cmd = "l" if rel else "L"; lc = lq = None
        elif C == "L": a, b = r.num(), r.num(); x, y = a + ox, b + oy; cur.append((x, y)); lc = lq = None
        elif C == "H": x = r.num() + ox; cur.append((x, y)); lc = lq = None
        elif C == "V": y = r.num() + oy; cur.append((x, y)); lc = lq = None
        elif C in "CS":
            if C == "C": x1, y1 = r.num() + ox, r.num() + oy
            x2, y2, nx, ny = r.num() + ox, r.num() + oy, r.num() + ox, r.num() + oy
            if C == "S": x1, y1 = (2 * x - lc[0], 2 * y - lc[1]) if lc else (x, y)
            cur += cubic((x, y), (x1, y1), (x2, y2), (nx, ny)); lc = (x2, y2); lq = None; x, y = nx, ny
        elif C in "QT":
            if C == "Q": x1, y1 = r.num() + ox, r.num() + oy
            nx, ny = r.num() + ox, r.num() + oy
            if C == "T": x1, y1 = (2 * x - lq[0], 2 * y - lq[1]) if lq else (x, y)
            c1 = (x + 2 / 3 * (x1 - x), y + 2 / 3 * (y1 - y)); c2 = (nx + 2 / 3 * (x1 - nx), ny + 2 / 3 * (y1 - ny))
            cur += cubic((x, y), c1, c2, (nx, ny)); lq = (x1, y1); lc = None; x, y = nx, ny
        elif C == "A":
            rx, ry, rot = r.num(), r.num(), r.num(); fa, fs = r.flag(), r.flag(); nx, ny = r.num() + ox, r.num() + oy
            cur += _arc_pts(x, y, rx, ry, rot, fa, fs, nx, ny, steps); x, y = nx, ny; lc = lq = None
        else: raise ValueError(f"unsupported SVG command {cmd!r}")
    if cur: subs.append(cur)
    _SVGC[key] = subs; return subs


def draw_svg(c, d, x=0.0, y=0.0, scale=1.0, p=1.0, color="teal", sw=6.0, fill=None, fill_a=1.0, glow=0.0, steps=14):
    """Draw SVG path data so it DRAWS ITSELF as p goes 0 -> 1 (strokes follow the path in order). With fill=<colour>, the
    shape fills in during the last 20%. (x, y) is where the path's origin lands; scale multiplies its size; sw is in screen px."""
    if p <= 0.001: return
    subs = svg_polylines(d, steps); lens = [sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(s, s[1:])) for s in subs]
    total = sum(lens) or 1.0; target = clamp(p) * total; c.save(); c.translate(x, y); c.scale(scale, scale); acc = 0.0
    st = _paint(color, 1, sw / scale); gl = _glow_paint(color, 0.5, 8 / scale, sw / scale * 1.6) if glow else None
    for s, L in zip(subs, lens):
        if len(s) < 2: continue
        frac = clamp((target - acc) / L) if L > 0 else 1.0
        if frac > 0:
            cut = s
            if frac < 1.0:
                goal = L * frac; cut = [s[0]]; run = 0.0
                for a, b in zip(s, s[1:]):
                    seg = math.hypot(b[0] - a[0], b[1] - a[1])
                    if run + seg >= goal: u = (goal - run) / seg if seg else 0; cut.append((a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u)); break
                    cut.append(b); run += seg
            pa = skia.Path(); pa.moveTo(*cut[0])
            for q in cut[1:]: pa.lineTo(*q)
            if gl: c.drawPath(pa, gl)
            c.drawPath(pa, st)
        acc += L
    if fill and p > 0.8:
        fa = clamp((p - 0.8) / 0.2) * fill_a; fp = _paint(fill, fa)
        for s in subs:
            if len(s) > 2 and math.hypot(s[0][0] - s[-1][0], s[0][1] - s[-1][1]) < 1e-6:
                pa = skia.Path(); pa.moveTo(*s[0])
                for q in s[1:]: pa.lineTo(*q)
                pa.close(); c.drawPath(pa, fp)
    c.restore()


E.Ctx.svg = lambda self, d, x=0.0, y=0.0, scale=1.0, p=1.0, color="teal", sw=6.0, fill=None, fill_a=1.0, glow=0.0: draw_svg(self.c, d, x, y, scale, p, color, sw, fill, fill_a, glow)
E.Ctx.svg.__doc__ = "S.svg(d, x, y, scale, p, color, sw, fill, fill_a, glow): SVG path data that draws itself (see fx.draw_svg)."


# ================================================================== per-letter text animator
def _rng(i, salt=0): return random.Random(i * 7919 + salt).random()

def _preset(name, size):
    def wave(i, n, q, ch, t): e = EASE["out_cubic"](q); return dict(dy=(1 - e) * size * 0.8 + (math.sin(t * 3 + i * 0.5) * size * 0.06 if q >= 1 else 0), a=clamp(q * 3))
    def scatter(i, n, q, ch, t):
        e = EASE["out_expo"](q); return dict(dx=(_rng(i, 1) - .5) * 700 * (1 - e), dy=(_rng(i, 2) - .5) * 500 * (1 - e), rot=(_rng(i, 3) - .5) * 4 * (1 - e), a=clamp(q * 3))
    def bounce(i, n, q, ch, t): return dict(dy=-(1 - _bounce(q)) * size * 1.6, a=clamp(q * 6))
    def spin(i, n, q, ch, t): e = EASE["out_back"](q); return dict(rot=(1 - e) * 6.28, sc=max(0.01, e), a=clamp(q * 4))
    def flip(i, n, q, ch, t): e = EASE["out_cubic"](q); return dict(sx=max(0.02, abs(math.cos((1 - e) * 1.5708))), a=clamp(q * 4))
    def glitch(i, n, q, ch, t):
        if q >= 1: return dict(a=1.0)
        r = random.Random(int(t * 30) * 131 + i); return dict(dx=(r.random() - .5) * 40 * (1 - q), dy=(r.random() - .5) * 14 * (1 - q), a=1.0 if r.random() < 0.4 + q * 0.6 else 0.0, color=r.choice(("teal", "amber", "red", "white")) if q < .9 else None)
    def typewriter(i, n, q, ch, t): return dict(a=1.0 if q > 0 else 0.0)
    return dict(wave=wave, scatter=scatter, bounce=bounce, spin=spin, flip=flip, glitch=glitch, typewriter=typewriter)[name]


def text_anim(self, s, x, y, size=64, color="white", w="b", al="c", p=1, fn="wave", spread=0.6, maxw=None, lh=1.2):
    """Per-letter animation you can fully customise. fn = a preset name (wave, scatter, bounce, spin, flip, glitch, typewriter)
    or your own function  fn(i, n, q, ch, t) -> dict(dx, dy, sc, sx, rot, a, color)  where i = letter number, n = letters,
    q = that letter's own progress 0..1, ch = the character, t = scene time. Missing keys use the resting value."""
    if p <= 0.001: return 0
    f = E.font(w, size); E._check_glyphs(s, w); lines = self.wrap(s, f, maxw) if maxw else [s]; pp = clamp(p)
    if isinstance(fn, str): fn = _preset(fn, size)
    total = max(1, sum(len(l.replace(" ", "")) for l in lines)); u = 0; spread = min(spread, 0.92)
    for li, ln in enumerate(lines):
        tw = f.measureText(ln); x0 = x if al == "l" else (x - tw / 2 if al == "c" else x - tw); base = y + li * size * lh
        for j, ch in enumerate(ln):
            if ch == " ": continue
            q = clamp((pp - (u / total) * spread) / (1 - spread)); u += 1
            if q <= 0: continue
            r = fn(u - 1, total, q, ch, self.t) or {}; a = r.get("a", 1.0)
            if a <= 0.003: continue
            cw = f.measureText(ch); cx = x0 + f.measureText(ln[:j]) + cw / 2 + r.get("dx", 0.0); cy = base - size * 0.3 + r.get("dy", 0.0)
            self.c.save(); self.c.translate(cx, cy); self.c.rotate(math.degrees(r.get("rot", 0.0))); sc = r.get("sc", 1.0); self.c.scale(sc * r.get("sx", 1.0), sc)
            self.c.drawString(ch, -cw / 2, size * 0.3, f, self.paint(r.get("color") or color, a)); self.c.restore()
    return len(lines) * size * lh
E.Ctx.text_anim = text_anim
