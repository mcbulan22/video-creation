#!/usr/bin/env python3
"""Still-image previews of every theme (no video rendering).

  python preview_themes.py SCENES.py --out DIR [theme ...]

Writes DIR/overview.png (one row per theme: title scene, a list scene, a comparison scene) and, for each theme,
DIR/<theme>_sheet_01.png ... showing every scene at its fully-built state.
"""
import argparse, importlib.util, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E
from PIL import Image, ImageDraw

def frame(tl, i, deck):
    sc = tl[i]; t = sc["dur"] - 0.9 - (E.DIVE if E.is_sky(sc["s"]) else 0)
    import io
    return Image.open(io.BytesIO(E.png_bytes(E.render_frame(tl, i, t, deck)))).convert("RGB")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--out", default="output/theme_preview"); ap.add_argument("themes", nargs="*")
    a = ap.parse_args()
    spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    deck = getattr(m, "DECK_TITLE", E.DECK_TITLE); names = a.themes or E.theme_names(); os.makedirs(a.out, exist_ok=True)
    n = len(E.SCENES); pick = sorted({0, min(2, n - 1), min(8, n - 1)}); rows = []
    for name in names:
        E.set_theme(name); E.FX = True; tl, _ = E.build_timeline(E.SCENES, 2.45)
        frames = [frame(tl, i, deck) for i in range(n)]
        cw = 960; ch = cw * 9 // 16
        for k in range(0, n, 4):
            sheet = Image.new("RGB", (cw * 2, ch * 2), (20, 20, 20))
            for j, f in enumerate(frames[k:k + 4]): sheet.paste(f.resize((cw, ch), Image.LANCZOS), ((j % 2) * cw, (j // 2) * ch))
            sheet.save(os.path.join(a.out, f"{name}_sheet_{k // 4 + 1:02d}.png"))
        row = Image.new("RGB", (640 * len(pick), 360 + 34), (24, 24, 28)); d = ImageDraw.Draw(row)
        d.text((12, 10), f"{name.upper()}   {E.TH.label}", fill=(235, 235, 235))
        for j, i in enumerate(pick): row.paste(frames[i].resize((640, 360), Image.LANCZOS), (j * 640, 34))
        rows.append(row); print(f"{name}: done", flush=True)
    ov = Image.new("RGB", (rows[0].width, sum(r.height for r in rows)), (24, 24, 28)); y = 0
    for r in rows: ov.paste(r, (0, y)); y += r.height
    ov.save(os.path.join(a.out, "overview.png")); print(f"overview -> {os.path.join(a.out, 'overview.png')}")

if __name__ == "__main__":
    main()
