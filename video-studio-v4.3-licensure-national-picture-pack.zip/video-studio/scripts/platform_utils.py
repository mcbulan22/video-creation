"""Small helpers that make the pack behave the same on macOS, Windows and Linux.

Importing this module (done by the scripts that call ffmpeg) also puts the pack's own `bin` folder first on PATH,
so a copy of ffmpeg / ffprobe placed in  video-studio/bin  is found even when it is not installed system-wide
(handy on an office PC where you cannot install software).
"""
import os, shutil, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BIN = os.path.join(ROOT, "bin")
EXE = ".exe" if os.name == "nt" else ""

def computer():
    """'mac', 'windows' or 'linux' (the VS_COMPUTER environment variable can override, set by studio.py --computer)."""
    forced = os.environ.get("VS_COMPUTER", "").lower()
    if forced in ("mac", "windows", "linux"): return forced
    return {"darwin": "mac", "win32": "windows", "cygwin": "windows", "msys": "windows"}.get(sys.platform, "linux")

def detected_computer():
    return {"darwin": "mac", "win32": "windows", "cygwin": "windows", "msys": "windows"}.get(sys.platform, "linux")

def use_local_bin():
    if os.path.isdir(BIN) and BIN not in os.environ.get("PATH", "").split(os.pathsep):
        os.environ["PATH"] = BIN + os.pathsep + os.environ.get("PATH", "")

def find_tool(name):
    """Full path of ffmpeg / ffprobe (pack's bin folder first, then PATH), or None."""
    use_local_bin(); return shutil.which(name)

def filter_path(p, _abs=os.path.abspath):
    """A path inside an ffmpeg filter option (e.g. subtitles fontsdir=): forward slashes, drive colon escaped (C\\:/Users/...)."""
    return _abs(p).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")

def concat_path(p, _abs=os.path.abspath):
    """A path inside an ffmpeg concat list file: absolute, forward slashes, single quotes escaped."""
    return _abs(p).replace("\\", "/").replace("'", "'\\''")

def rmtree(p):
    shutil.rmtree(p, ignore_errors=True)

def venv_dir(comp=None):
    return os.path.join(ROOT, ".venv-" + (comp or computer()))

def venv_python(comp=None):
    d = venv_dir(comp)
    return os.path.join(d, "Scripts", "python.exe") if (comp or computer()) == "windows" else os.path.join(d, "bin", "python")

use_local_bin()


# ------------------------------------------------------------------ memory, cores and worker choice
def memory_info():
    """(total_gb, available_gb) of this computer's RAM, or (None, None) if it cannot be read."""
    try:
        if os.name == "nt":
            import ctypes
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong), ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong), ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(MS); ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys / 2 ** 30, m.ullAvailPhys / 2 ** 30
        import subprocess
        if sys.platform == "darwin":
            total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]).decode().strip())
            out = subprocess.check_output(["vm_stat"]).decode(); page = int(out.split("page size of")[1].split("bytes")[0])
            pages = lambda k: int(out.split(k + ":")[1].split("\n")[0].strip().rstrip("."))
            return total / 2 ** 30, (pages("Pages free") + pages("Pages inactive") + pages("Pages speculative")) * page / 2 ** 30
        info = {ln.split(":")[0]: int(ln.split(":")[1].split()[0]) for ln in open("/proc/meminfo") if ":" in ln}
        return info["MemTotal"] / 2 ** 20, info.get("MemAvailable", info["MemFree"]) / 2 ** 20
    except Exception:
        return None, None

def worker_gb(height):
    """RAM one render worker needs (drawing process + its ffmpeg encoder), in GB. Measured: about 0.35 GB at 1080p and 1.2 GB at 4K."""
    return max(0.25, 0.40 * (height / 1080.0) ** 1.7)

def choose_workers(height=1080):
    """How many render workers to start: as many as the processor allows, but never more than the free RAM can hold.
    Returns (count, one-line explanation)."""
    cores = os.cpu_count() or 2; by_cpu = max(1, min(cores - 1, 12))
    total, avail = memory_info()
    if avail is None: return max(1, min(6, cores - 1)), f"{cores} processor threads (memory could not be read, using a cautious count)"
    reserve = 1.5                                            # leave room for Windows/macOS and your other programs
    by_ram = max(1, int((avail - reserve) / worker_gb(height)))
    n = max(1, min(by_cpu, by_ram))
    why = "limited by free memory" if by_ram < by_cpu else "limited by processor threads"
    return n, f"{n} workers ({cores} processor threads, {avail:.1f} of {total:.1f} GB RAM free; {why})"

def lower_priority():
    """Run this process below normal priority so the computer stays usable while rendering."""
    try:
        if os.name == "nt":
            import ctypes; k = ctypes.windll.kernel32; k.SetPriorityClass(k.GetCurrentProcess(), 0x00004000)   # BELOW_NORMAL
        else:
            os.nice(5)
    except Exception:
        pass
