#!/usr/bin/env python3
"""Create one voice clip per beat (so the video can be timed EXACTLY to the voice).

  python make_voice.py inbox/scenes.py --out output/voice [--engine auto] [--voice NAME] [--rate 170]

Engines (default auto = mac on a Mac, windows on a Windows PC):
  mac     - the built-in macOS `say` command (free, offline). Better voices: System Settings > Accessibility >
            Spoken Content > System Voice > Manage Voices, download an "Enhanced" or "Premium" one, then pass its name.
            List voices with:  say -v '?'
  windows - the built-in Windows speech voices (free, offline). Installed voices: see `--list-voices`; more can be added in
            Windows Settings > Time & language > Speech.
  edge    - free online neural voices (needs internet; pip package edge-tts). Default voice en-PH-RosaNeural (Philippine English).
  own     - YOUR recordings, one file per beat (see narration_script.txt)
  fake    - silent placeholder tones of the right length (only for testing the pipeline)
Writes OUT/s01_b01.wav ... and OUT/durations.json.
"""
import argparse, importlib.util, json, os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import platform_utils as PU
import engine as E

def load(path):
    spec = importlib.util.spec_from_file_location("deck_scenes", path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m

def dur(path):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).decode().strip())

DEFAULT_VOICE = {"mac": "Samantha", "windows": "", "edge": "en-PH-RosaNeural"}

def ps_speak(text, out_wav, voice, rate_wpm):
    """Windows built-in voice via PowerShell + System.Speech (text and settings travel in environment variables: no quoting problems)."""
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as fh:
        fh.write(text); txt = fh.name
    script = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
              "if ($env:VS_VOICE) { $s.SelectVoice($env:VS_VOICE) }; $s.Rate = [int]$env:VS_RATE; "
              "$s.SetOutputToWaveFile($env:VS_OUT); $s.Speak([IO.File]::ReadAllText($env:VS_TEXT, [Text.Encoding]::UTF8)); $s.Dispose()")
    env = dict(os.environ, VS_VOICE=voice or "", VS_RATE=str(max(-10, min(10, round((rate_wpm - 170) / 20)))), VS_OUT=os.path.abspath(out_wav), VS_TEXT=txt)
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], check=True, env=env, stdin=subprocess.DEVNULL)
    finally:
        os.remove(txt)

def edge_speak(text, out_mp3, voice):
    """Free online neural voice (edge-tts). Needs internet."""
    subprocess.run([sys.executable, "-m", "edge_tts", "--voice", voice, "--text", text, "--write-media", out_mp3], check=True, stdin=subprocess.DEVNULL)

def list_voices(engine):
    if engine == "mac":
        subprocess.run(["say", "-v", "?"])
    elif engine == "windows":
        subprocess.run(["powershell", "-NoProfile", "-Command", "Add-Type -AssemblyName System.Speech; "
                        "(New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name + '   (' + $_.VoiceInfo.Culture.Name + ')' }"])
    else:
        r = subprocess.run([sys.executable, "-m", "edge_tts", "--list-voices"], capture_output=True, text=True)
        lines = [ln for ln in r.stdout.splitlines() if ln.startswith(("Name", "---")) or ln.split(" ")[0].startswith(("en-PH", "en-US", "en-GB", "en-AU"))]
        print("\n".join(lines) if lines else (r.stdout or r.stderr or "edge-tts is not installed or there is no internet connection."))

EXTS = [".wav", ".m4a", ".mp3", ".aiff", ".aif", ".caf", ".aac", ".flac", ".ogg", ".mp4"]

def own(a):
    """Use YOUR recordings: one file per beat named s01_b01.wav, s01_b02.wav ... (any common audio format).
    Each file is converted to WAV, silence at the start/end is trimmed, and the loudness is evened out."""
    missing, res = [], {}
    for i, s in enumerate(E.SCENES):
        for k in range(len(s["beats"])):
            stem = f"s{i+1:02d}_b{k+1:02d}"
            src = next((os.path.join(a.src, stem + e) for e in EXTS + [x.upper() for x in EXTS] if os.path.exists(os.path.join(a.src, stem + e))), None)
            if not src: missing.append(stem); continue
            wav = os.path.join(a.out, stem + ".wav")
            trim = "silenceremove=start_periods=1:start_threshold=-48dB:start_silence=0.05"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-af",
                            f"{trim},areverse,{trim},areverse,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100", "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
            res[f"{i},{k}"] = dur(wav); print(f"{stem}: {res[f'{i},{k}']:.1f}s", flush=True)
    if missing:
        print("\nMISSING recordings in folder '%s':" % a.src)
        for m in missing: print("  ", m)
        print("Record these (see narration_script.txt for the words), save them with exactly these names, and run again.")
        sys.exit(1)
    json.dump(res, open(os.path.join(a.out, "durations.json"), "w"), indent=1)
    print(f"your voice: total {sum(res.values()):.0f}s -> {os.path.join(a.out, 'durations.json')}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenes"); ap.add_argument("--out", required=True)
    ap.add_argument("--engine", choices=["auto", "mac", "windows", "edge", "own", "fake"], default="auto")
    ap.add_argument("--src", default="my_voice", help="folder with YOUR recordings (engine own)")
    ap.add_argument("--voice", default=None, help="voice name (see --list-voices); default depends on the engine")
    ap.add_argument("--rate", type=int, default=170, help="speaking speed in words per minute (170 = normal)")
    ap.add_argument("--list-voices", action="store_true", help="show the voices available for this engine and exit")
    a = ap.parse_args()
    if a.engine == "auto": a.engine = {"mac": "mac", "windows": "windows"}.get(PU.computer(), "edge")
    if a.list_voices: return list_voices(a.engine)
    if a.voice is None: a.voice = DEFAULT_VOICE.get(a.engine, "")
    load(a.scenes); os.makedirs(a.out, exist_ok=True); res = {}
    if a.engine == "own":
        return own(a)
    for i, s in enumerate(E.SCENES):
        for k, text in enumerate(s["beats"]):
            wav = os.path.join(a.out, f"s{i+1:02d}_b{k+1:02d}.wav")
            if a.engine == "mac":
                tmp = wav + ".aiff"
                subprocess.run(["say", "-v", a.voice, "-r", str(a.rate), "-o", tmp, "--", text], check=True, stdin=subprocess.DEVNULL)
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
                os.remove(tmp)
            elif a.engine == "windows":
                tmp = wav + ".sapi.wav"
                ps_speak(text, tmp, a.voice, a.rate)
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
                os.remove(tmp)
            elif a.engine == "edge":
                tmp = wav + ".mp3"
                try:
                    edge_speak(text, tmp, a.voice)
                except (subprocess.CalledProcessError, FileNotFoundError):
                    sys.exit("The online voice (edge) failed. It needs an internet connection and the edge-tts package "
                             "(run setup again). You can use  --engine windows  or  --own-voice  instead.")
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
                os.remove(tmp)
            else:
                d = len(text.split()) / 2.6
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"sine=f=220:d={d:.2f}",
                                "-af", "volume=0.05", "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
            res[f"{i},{k}"] = dur(wav)
            print(f"scene {i+1} beat {k+1}: {res[f'{i},{k}']:.1f}s", flush=True)
    json.dump(res, open(os.path.join(a.out, "durations.json"), "w"), indent=1)
    print(f"voice total {sum(res.values()):.0f}s -> {os.path.join(a.out, 'durations.json')}")

if __name__ == "__main__":
    main()
