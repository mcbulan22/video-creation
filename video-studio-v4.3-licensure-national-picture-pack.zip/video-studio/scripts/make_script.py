#!/usr/bin/env python3
"""Write narration_script.txt from the scenes file: every beat with the file name to use if you record your own voice.

  python make_script.py inbox/scenes.py [--out narration_script.txt]
"""
import argparse, importlib.util, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E

ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("--out", default="narration_script.txt"); a = ap.parse_args()
spec = importlib.util.spec_from_file_location("deck_scenes", a.scenes); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
tl, total = E.build_timeline(E.SCENES)
n = sum(len(s["beats"]) for s in E.SCENES); words = sum(len(b.split()) for s in E.SCENES for b in s["beats"])
L = [getattr(m, "DECK_TITLE", E.DECK_TITLE).upper() + " - NARRATION SCRIPT", "",
     f"{len(E.SCENES)} scenes, {n} beats (recordings), {words} words, about {words/2.45/60:.1f} minutes at a natural reading pace.",
     "To use YOUR voice: record each beat as its own file with the file name shown, put them in the 'my_voice' folder, then run:  sh make.sh --own-voice",
     "Read each beat exactly as written. Pause briefly before and after (the silence is trimmed automatically).", ""]
for i, s in enumerate(E.SCENES):
    L.append(f"--- Scene {i+1}: {s['chapter'].title()} ---")
    for k, b in enumerate(s["beats"]): L += [f"[s{i+1:02d}_b{k+1:02d}]  {b}", ""]
open(a.out, "w", encoding="utf-8").write("\n".join(L)); print(f"{a.out}: {n} beats")
