#!/usr/bin/env python3
"""Find an icon name for S.icon(...).   python scripts/find_icon.py ship anchor exam
Searches the 28 built-in icons and all 1,900 Lucide icons by name and by tags (for example 'maritime', 'school', 'safety')."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E
if len(sys.argv) < 2: sys.exit(__doc__)
for q in sys.argv[1:]:
    r = E.find_icons(q, 20); print(f"{q}: " + (", ".join(r) if r else "no match"))
