#!/usr/bin/env python3
"""Automatic checks on a finished video (ffmpeg only, nothing to install). Writes a plain report you can read in a minute.

  python qa_check.py output/final_with_audio.mp4 [--cues output/cues.json] [--out output/qa_report.txt]
                     [--freeze 6] [--strict]

Checks
  frozen picture   a stretch longer than --freeze seconds where nothing moves at all (a stuck or forgotten scene)
  black frames     black gaps inside the video (a failed render or a missing scene)
  flashes / pops   single-frame brightness spikes or sudden jumps away from the scene changes (a glitch, not a design choice)
  loudness         integrated loudness and true peak (target about -16 LUFS, peak at or under -1 dBTP)
  long silence     gaps in the sound longer than 4 s (informational: a pause may be intentional)
  length           the video is as long as the plan in cues.json says
Each line starts with PASS, WARN or INFO. WARN means "look at this", not "broken".
"""
import argparse, json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import platform_utils as PU   # makes ./bin ffmpeg visible


def ffrun(args, capture="err"):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", *args], capture_output=True, text=True, stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace")
    return r.stderr if capture == "err" else r.stdout


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type", "-of", "json", path], capture_output=True, text=True, stdin=subprocess.DEVNULL)
    j = json.loads(r.stdout or "{}"); dur = float(j.get("format", {}).get("duration", 0) or 0)
    return dur, any(s.get("codec_type") == "audio" for s in j.get("streams", []))


def scene_at(cues, t):
    if not cues: return None
    for sc in cues["scenes"]:
        if sc["t0"] <= t < sc["t0"] + sc["dur"] + 1e-6: return sc["i"] + 1
    return None


def tc(t): return f"{int(t // 60)}:{t % 60:04.1f}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("--cues"); ap.add_argument("--out"); ap.add_argument("--freeze", type=float, default=6.0); ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    cues = json.load(open(a.cues)) if a.cues and os.path.exists(a.cues) else None
    dur, has_audio = probe(a.video); lines = []; warn = 0

    def add(kind, msg):
        nonlocal warn
        lines.append(f"{kind:5s} {msg}")
        if kind == "WARN": warn += 1

    lines.append(f"QA REPORT  {os.path.basename(a.video)}  ({tc(dur)} long, {'with sound' if has_audio else 'picture only'})\n")

    # ---- length vs plan
    if cues:
        diff = abs(dur - cues["total"])
        add("PASS" if diff <= 0.4 else "WARN", f"length: video {dur:.1f} s, plan {cues['total']:.1f} s" + ("" if diff <= 0.4 else "  (differs by more than 0.4 s; was a scene skipped with --only?)"))

    # ---- frozen picture
    out = ffrun(["-i", a.video, "-an", "-vf", f"freezedetect=n=0.003:d={a.freeze}", "-f", "null", "-"])
    starts = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", out)]; durs = [float(x) for x in re.findall(r"freeze_duration: ([\d.]+)", out)]
    if not starts: add("PASS", f"frozen picture: nothing stands still for more than {a.freeze:g} s")
    for s0, d in zip(starts, durs):
        sn = scene_at(cues, s0 + 0.1); add("WARN", f"frozen picture: {tc(s0)} to {tc(s0 + d)} ({d:.1f} s)" + (f", scene {sn}" if sn else "") + "  (add motion, split the beat, or shorten the narration there)")

    # ---- black frames
    out = ffrun(["-i", a.video, "-an", "-vf", "blackdetect=d=0.2:pix_th=0.08", "-f", "null", "-"])
    blacks = [(float(x), float(y)) for x, y in re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", out)]
    blacks = [(s0, s1) for s0, s1 in blacks if s0 > 0.05 and s1 < dur - 0.05]
    if not blacks: add("PASS", "black frames: none inside the video")
    for s0, s1 in blacks: add("WARN", f"black frames: {tc(s0)} to {tc(s1)}" + (f", scene {scene_at(cues, s0)}" if scene_at(cues, s0) else ""))

    # ---- flashes and pops (brightness of a small copy of every frame)
    out = ffrun(["-i", a.video, "-an", "-vf", "scale=160:90,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-", "-f", "null", "-"], capture="out")
    ts = [float(x) for x in re.findall(r"pts_time:([\d.]+)", out)]; ys = [float(x) for x in re.findall(r"YAVG=([\d.]+)", out)]
    n = min(len(ts), len(ys)); ts, ys = ts[:n], ys[:n]; bounds = [sc["t0"] for sc in cues["scenes"]] if cues else []
    near = lambda t: any(abs(t - b) < 0.8 for b in bounds)
    hits = []
    for i in range(2, n - 2):
        if near(ts[i]): continue
        around = (ys[i - 1] + ys[i + 1]) / 2
        if abs(ys[i] - around) >= 14 and abs(ys[i + 1] - ys[i - 1]) < 6: hits.append((ts[i], "one-frame flash", ys[i] - around))
        elif abs(ys[i] - ys[i - 1]) >= 18 and abs(ys[i - 1] - ys[i - 2]) < 3 and abs(ys[i + 1] - ys[i]) < 3: hits.append((ts[i], "sudden jump", ys[i] - ys[i - 1]))
    if n == 0: add("INFO", "flashes and pops: could not read frame brightness")
    elif not hits: add("PASS", f"flashes and pops: none found in {n} frames")
    for t, kind, d in hits[:12]: add("WARN", f"{kind} at {tc(t)} ({d:+.0f} brightness)" + (f", scene {scene_at(cues, t)}" if scene_at(cues, t) else "") + "  (check that frame)")
    if len(hits) > 12: add("WARN", f"... and {len(hits) - 12} more flashes or pops")

    # ---- sound
    if has_audio:
        out = ffrun(["-i", a.video, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"])
        I = re.findall(r"I:\s+(-?[\d.]+) LUFS", out); LRA = re.findall(r"LRA:\s+([\d.]+) LU", out); TP = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", out)
        if I:
            li = float(I[-1]); tp = float(TP[-1]) if TP else None
            add("PASS" if -18.5 <= li <= -13.5 else "WARN", f"loudness: {li:.1f} LUFS (target about -16, fine between -18 and -14)" + (f", loudness range {LRA[-1]} LU" if LRA else ""))
            if tp is not None: add("PASS" if tp <= -1.0 else "WARN", f"true peak: {tp:.1f} dBTP (should be -1 or lower to avoid distortion)")
        out = ffrun(["-i", a.video, "-vn", "-af", "silencedetect=n=-50dB:d=4", "-f", "null", "-"])
        sil = list(zip([float(x) for x in re.findall(r"silence_start: ([\d.]+)", out)], [float(x) for x in re.findall(r"silence_duration: ([\d.]+)", out)]))
        if not sil: add("PASS", "silence: no gap longer than 4 s")
        for s0, d in sil: add("INFO", f"silence: {tc(s0)} for {d:.1f} s" + (f", scene {scene_at(cues, s0 + 0.1)}" if scene_at(cues, s0 + 0.1) else "") + "  (fine if it is a deliberate pause)")
    else:
        add("INFO", "sound: this file has no audio track, so loudness was not checked")

    lines.append(f"\nSUMMARY: {warn} item(s) to look at." if warn else "\nSUMMARY: all checks passed.")
    text = "\n".join(lines); print(text)
    if a.out: open(a.out, "w", encoding="utf-8").write(text + "\n")
    if a.strict and warn: sys.exit(1)


if __name__ == "__main__":
    main()
