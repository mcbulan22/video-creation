#!/usr/bin/env python3
"""Checks that every number in the video comes from your facts file. Nothing to install; reads text only.

  python check_facts.py inbox/scenes.py inbox/facts.md [--out output/facts_report.txt]

What it reads from scenes.py: the narration lines, every piece of on-screen text that contains a digit, and the numbers handed to
the data tools (S.stat, S.num, S.ring, S.bars, S.hbars, S.donut, S.linechart), and every number inside a module-level
FIGURES = {...} block (also DATA, NUMBERS, STATS): put figures that reach the screen through loops or variables there. A number is OK when it appears in facts.md.
Not checked: whole numbers 0 to 10 (steps, counts), and any scene that carries the words "Example data" or "illustrative"
(deliberately made-up numbers must say so on screen).
facts.md lines marked UNVERIFIED are matched too, but reported as WARN so nothing unconfirmed slips through.
"""
import argparse, ast, os, re, sys

NUM = re.compile(r"(?<![\w.])\d[\d,]*(?:\.\d+)?")
EXEMPT = ("example data", "illustrative", "sample data", "dummy data")


def nums_in(text):
    out = []
    for m in NUM.findall(text):
        try: out.append(float(m.replace(",", "")))
        except ValueError: pass
    return out


def decimals(x):
    s = repr(float(x)); return len(s.split(".")[1].rstrip("0")) if "." in s else 0


def same(a, b):
    """a (shown in the video) matches b (in the facts) if equal, or a is b rounded to fewer decimals."""
    if abs(a - b) < 1e-9: return True
    da = decimals(a)
    return da < decimals(b) and abs(round(b, da) - a) < 1e-9


class Scene:
    def __init__(self, idx, chapter, node): self.idx, self.chapter, self.node = idx, chapter, node; self.items = []; self.exempt = False


def lit(node):
    try: return ast.literal_eval(node)
    except Exception: return None


def collect(path):
    tree = ast.parse(open(path, encoding="utf-8").read()); scenes = []
    figs = Scene(0, "FIGURES", None)                                      # numbers kept in a module-level FIGURES = {...} (or DATA / NUMBERS / STATS)
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", "") in ("FIGURES", "DATA", "NUMBERS", "STATS") for t in node.targets):
            vals = [n.value for n in ast.walk(node.value) if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool)]
            vals += [v for n in ast.walk(node.value) if isinstance(n, ast.Constant) and isinstance(n.value, str) for v in nums_in(n.value)]
            if vals: figs.items.append(("FIGURES block", ", ".join(f"{v:g}" for v in vals), [float(v) for v in vals]))
    if figs.items: scenes.append(figs)
    for fn in [n for n in tree.body if isinstance(n, ast.FunctionDef)]:
        for dec in fn.decorator_list:
            if isinstance(dec, ast.Call) and getattr(dec.func, "id", getattr(dec.func, "attr", "")) == "scene":
                chapter = lit(dec.args[0]) if dec.args else "?"; sc = Scene(sum(1 for q in scenes if q.idx) + 1, chapter, fn)
                beats = lit(dec.args[1]) if len(dec.args) > 1 else []
                for b in beats or []: sc.items.append(("narration", b, nums_in(b)))
                texts = [n.value for n in ast.walk(fn) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
                sc.exempt = any(any(e in t.lower() for e in EXEMPT) for t in texts + [b for b in (beats or [])])
                for t in texts:
                    if re.search(r"\d", t): sc.items.append(("on screen", t, nums_in(t)))
                for call in [n for n in ast.walk(fn) if isinstance(n, ast.Call)]:
                    name = getattr(call.func, "attr", getattr(call.func, "id", ""))
                    kw = {k.arg: k.value for k in call.keywords if k.arg}; arg = lambda i, key=None: (call.args[i] if len(call.args) > i else kw.get(key))
                    vals = []
                    if name in ("stat", "num"): v = lit(arg(0, "value") or ast.Constant(None)); vals = [v] if isinstance(v, (int, float)) else []
                    elif name == "ring": v = lit(arg(3, "value") or ast.Constant(None)); vals = [v] if isinstance(v, (int, float)) else []
                    elif name in ("bars", "hbars", "donut"):
                        data = lit(arg(0, "items" if name != "donut" else "parts") or ast.Constant(None)); vals = [r[1] for r in (data or []) if len(r) > 1 and isinstance(r[1], (int, float))]
                    elif name == "linechart": data = lit(arg(0, "values") or ast.Constant(None)); vals = [v for v in (data or []) if isinstance(v, (int, float))]
                    if vals: sc.items.append((f"S.{name} data", ", ".join(str(v) for v in vals), [float(v) for v in vals]))
                scenes.append(sc)
    return scenes


def where(sc): return "FIGURES block" if sc.idx == 0 else f"scene {sc.idx} ({sc.chapter})"


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("scenes"); ap.add_argument("facts"); ap.add_argument("--out"); ap.add_argument("--strict", action="store_true"); a = ap.parse_args()
    if not os.path.exists(a.facts):
        msg = f"INFO  no facts file at {a.facts}: numbers in the video were NOT checked against a source (copy inbox/facts_TEMPLATE.md to inbox/facts.md)"
        print(msg); open(a.out, "w", encoding="utf-8").write(msg + "\n") if a.out else None; return
    facts = []                                                            # (numbers, line, unverified)
    for line in open(a.facts, encoding="utf-8").read().splitlines():
        if line.strip() and not line.lstrip().startswith("#"): facts.append((nums_in(line), line.strip(), "unverified" in line.lower()))
    scenes = collect(a.scenes); lines = [f"FACT CHECK  {os.path.basename(a.scenes)} against {os.path.basename(a.facts)}  ({len(facts)} fact lines)\n"]; warn = 0; checked = 0; skipped = 0
    for sc in scenes:
        if sc.exempt: skipped += 1; lines.append(f"INFO  scene {sc.idx} ({sc.chapter}): marked as example data, numbers not checked"); continue
        seen = set()
        for kind, text, nums in sc.items:
            for v in nums:
                if (v == int(v) and 0 <= v <= 10) or v in seen: continue
                seen.add(v); checked += 1
                hit = [f for f in facts for n in f[0] if same(v, n)]
                shown = (f"{v:g}")
                if not hit: warn += 1; lines.append(f"WARN  {where(sc)}: {shown} in {kind} is not in the facts file  -> \"{text[:70]}\"")
                elif all(h[2] for h in hit): warn += 1; lines.append(f"WARN  {where(sc)}: {shown} only matches an UNVERIFIED fact  -> \"{hit[0][1][:70]}\"")
    if checked == 0: lines.append("INFO  no numbers above 10 were found to check")
    elif warn == 0: lines.append(f"PASS  all {checked} numbers checked appear in the facts file" + (f" ({skipped} example-data scene(s) skipped)" if skipped else ""))
    lines.append("NOTE  numbers are read from text, narration, data-tool arguments and a module-level FIGURES = {...} block; a number that only exists inside a loop variable is not seen, so keep shown figures in FIGURES.")
    lines.append(f"\nSUMMARY: {warn} number(s) to confirm." if warn else "\nSUMMARY: every checked number is backed by the facts file.")
    text = "\n".join(lines); print(text)
    if a.out: open(a.out, "w", encoding="utf-8").write(text + "\n")
    if a.strict and warn: sys.exit(1)


if __name__ == "__main__":
    main()
