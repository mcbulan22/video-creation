#!/bin/sh
# THE ONE COMMAND on a Mac: voice + picture + sound.   sh make.sh --draft   |   sh make.sh --theme playful   |   sh make.sh --engine edge
# (Same tool as on a Windows PC: python3 studio.py make)
cd "$(dirname "$0")"
exec python3 studio.py make "$@"
