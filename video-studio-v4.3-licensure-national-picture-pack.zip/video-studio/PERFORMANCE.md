# Speed and quality

## What changed (v3.3)
1. **Frames no longer go through PNG files.** Measured on a test machine: saving each frame as a PNG took 66 to 91% of the time of every frame,
   while drawing it took only 22 to 74 ms. Each worker now sends raw frames straight into its own ffmpeg encoder.
   Result on the same scene and settings: **24.0 s before, 8.1 s now (3 times faster)**, the same frame count, and the picture is the same
   (52.7 dB similarity between the old and new route). It also removes gigabytes of temporary image files.
2. **Memory-aware workers.** The pack starts as many render workers as your processor allows, but never more than free RAM can hold
   (measured: about 0.35 GB per worker at 1080p, about 1.2 GB at 4K). They also run at slightly lower priority, so the PC stays usable.
3. **Quality levels** (`--quality NAME`), drawn natively at the final size (so 4K text is truly sharp, not enlarged):

| Quality | Picture | Frames/s | Extra | Use it for |
|---|---|---|---|---|
| draft | 1280x720 | 20 | fastest | quick checks |
| **standard** (default) | 1920x1080 | 30 | | most videos, LMS upload |
| smooth | 1920x1080 | 60 | | very smooth motion (springs, slides), larger files |
| cinema | 1920x1080 | 30 | motion blur x4 | a polished final copy (about 3 times slower than standard) |
| ultra | 3840x2160 (4K) | 30 | motion blur x3 | only if you need 4K (about 8 to 10 times slower, files several times larger) |
Single settings can be changed on top of a level: `--fps 60`, `--height 1440`, `--blur 3`.
4. **Colour tagging.** Videos are now tagged as standard HD colour (BT.709), so players show the colours as designed. Earlier renders were untagged and some players shifted reds and greens slightly.
5. **`benchmark`** measures your computer and estimates render time for every quality level (Mac: `sh benchmark.sh`, Windows: `benchmark.bat`).
6. The old route is still there as a fallback: add `--frames png`.

## Your office PC (i5-12400, 8 GB RAM, Intel UHD 730)
- **Processor: strong for this.** The engine draws on the processor, and the 12400 has 6 fast cores (12 threads). That is where the speed comes from.
- **RAM: the real limit.** With about 4.7 GB free (typical for Windows with a browser open) the pack should choose about **8 workers at 1080p and 2 at 4K**.
  Close browsers and other programs before a long render and the numbers go up (about 11 workers at 1080p with 6.5 GB free). The RAM speed (2400 MT/s) matters little here.
- **Graphics card: not used.** The UHD 730 shares system memory, and this engine draws on the processor. Using the integrated graphics for drawing would not be faster and would risk crashes; I did not add it.
  The video encoder (x264) also runs on the processor, which is fast enough that it is not the bottleneck.
- **Recommended:** `standard` for everyday use, `cinema` for a final polished copy, `smooth` if you like very fluid motion. Treat `ultra` (4K) as a special case: the files are large, many LMS upload limits are lower than that, and students watch on phones.
- **To know for sure:** run `benchmark.bat` on the PC. It prints the estimated minutes for your deck at each level. Send me the table and I can tune further.
- These worker counts are my calculation from the measured per-worker memory; I could not run on your PC itself.

## Tips
- `--fx off` skips the drifting background effects: much less drawing for static scenes.
- `--workers N` overrides the automatic choice (for example `--workers 4` if the PC feels slow while it renders).
- If the PC runs out of memory, the error mentions ffmpeg; lower the quality or the worker count.
