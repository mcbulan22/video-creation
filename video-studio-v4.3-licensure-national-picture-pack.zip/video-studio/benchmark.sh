#!/bin/sh
# Measure this Mac and estimate render times.   sh benchmark.sh
cd "$(dirname "$0")"
exec python3 studio.py benchmark "$@"
