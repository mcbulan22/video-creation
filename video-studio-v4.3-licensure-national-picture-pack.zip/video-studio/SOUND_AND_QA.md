# Sound effects and automatic checks (v4.2)

## Sound effects made from maths
No sound files, no licences, no downloads (`scripts/sfx_synth.py`, Python standard library). `make` now adds a quiet effects layer under the voice:
- a soft whoosh and a faint low thud at every scene change
- a small pop when each beat's content appears (notes from a pentatonic scale, so they never clash)
- a gentle swell at the start, a chime and sparkle on the last beat, a deep water rush at the horizon dive
- effects dip a little while the narrator speaks, and the final mix is loudness-matched in two passes (about -16 LUFS)

Options (same on Mac and PC): `--sfx rich` (default), `--sfx on` (the older whoosh-only version), `--sfx off`, `--sfx-level 0.6` (quieter) or `1.4` (louder).

Per-scene control in `scenes.py`:
```python
@scene("TITLE", [...], sfx="off")                                           # no pops in this scene
@scene("RESULTS", [...], sfx=[(0, 0.2, "pop"), (1, 0.0, "chime", 0.4), (2, 0.1, "typing")])
#                                  beat, seconds after the beat starts, sound[, volume]
```
Sounds: pop, tick, click, whoosh, riser, chime, impact, typing, shimmer, swell, splash. Hear them all: `python scripts/sfx_synth.py` (writes `sfx_demo.wav`).
Using your own music: put `music.mp3` in `inbox/` (it ducks under the voice). Only use music you are allowed to use.

## Automatic checks
`make` and `render` finish by checking the video and saving `output/qa_report.txt`. Run it again any time: `python studio.py qa`.
It looks for: a frozen picture longer than 6 s, black gaps, one-frame flashes and sudden jumps (away from scene changes), loudness and true peak, long silences, and the video length against the plan.
`WARN` means "look at this", not "broken". Example: `WARN frozen picture: 0:05.0 to 0:13.0 (8.0 s), scene 2`.

## Independent review (free)
A second pair of eyes catches what the builder misses. After a draft: open a NEW chat, paste CRITIC_PROMPT.md, attach the pictures in `output/qa/` (the contact sheets), `output/qa_report.txt`, `narration_script.txt` and your source material. Give the findings back to the chat that built the video, fix, and re-check.
