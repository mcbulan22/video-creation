# Scene patterns and API cheat sheet

## Canvas and grid
1920x1080. Safe content area x 120-1800, y 170-960. Chapter label sits at y=70, footer at y=1050, wave decoration
at y~1010. Typical title baseline y=190-210. Card rows start at y~300. Center = x 960.

## Palette tokens (hex)
bg1 #0A1A2F, bg2 #103250, card #14304D, edge #2B5A87, white #F4F7FA, mute #8FA6BF,
teal #2EC4B6, amber #FFB703, red #EF476F, green #06D6A0, sky #4CC9F0, dark #08121F.
Pass either a token name or a hex string anywhere a color is expected.

## Reveal model
`S.p(k, dur=0.55, delay=0)` returns 0->1 progress that starts when beat `k` starts. Pass it as the last argument `p`
of any primitive; the primitive fades and slides in by itself. Stagger items inside one beat with `delay`
(e.g. `S.p(2, .5, i*.35)`). `S.t` is local scene time, `S.bs[k]` the start time of beat k.
Continuous motion (flashing) is allowed only if you register the beat in `ext={k: seconds}` so frames are re-rendered.

## Primitives
- `S.text(s, x, baseline_y, size, color, weight, align, p, maxw=None, lh=1.28, strike=0)`; weights `l r m b`; align `l c r`; with `maxw` it wraps. Returns height.
- `S.rr(x, y, w, h, radius, fill, stroke, sw, p, dash=None)` rounded card; `fill`/`stroke` may be None.
- `S.circ(x, y, r, fill, stroke, sw, p)`, `S.line(x0,y0,x1,y1,color,sw,p,dash)`, `S.arrow(x0,y0,x1,y1,color,sw,p,head)`
- `S.check(x,y,size,color,p)`, `S.cross(x,y,size,color,p)`, `S.pill(text,cx,cy,size,color,fill,p)`
- `S.ship(cx,cy,scale,color,p)`, `S.waves(x0,x1,y,amp,color,alpha,n,gap)`, `S.image(path,x,y,w,h,p,r,fit)`
- Raw Skia is available via `S.c` (canvas) for custom paths.

## Recipes (all in assets/reference_explainer_scenes.py)
| Need | Scene to copy |
|---|---|
| Title card with ship + waves | 1 |
| Big question / key statement | 2, 16 |
| Split compare with gap + bridge arrow | 3, 8 |
| Flow row (A -> B -> C -> D) + stakeholder cards | 4 |
| Strengths / limits rows, bars, pass/fail cards | 6, 7 |
| Mismatch table + "most critical" banner | 9 |
| Three-phase architecture cards | 10 |
| 2x2 grid with mini bar chart | 11 |
| Pyramid with tier mapping | 12 |
| Stacked foundation (build-up) | 13 |
| Staircase (levels of understanding) | 14 |
| 6-step roadmap grid with dashed placeholders | 15 |
| Closing question + before/after cards | 17 |

## Beat writing
- Beat text = exact narration. 1-2 sentences, 5-35 words. A beat shorter than 1.2 s is stretched to 1.2 s.
- Start a scene with a beat that sets the headline; end it with the takeaway.
- Dashed placeholder cards that fill in later make "the structure, then the content" reveals feel intentional.

## v4 Motion Kit recipes (see KIT.md and examples/motion_showcase.py)
| Need | Use |
|---|---|
| Hero title with gradient and glint | `S.grad_text(..., ("teal","amber"), shimmer=True)` |
| Words arriving in sequence | `S.kinetic(..., mode="rise" / "pop" / "drop" / "blur")` |
| Row of concepts with icons | `S.icon(name, x, y, 96, color, p, bg="circle")` above a caption |
| Key figures | `S.stat(...)` cards, `S.ring(...)` for a percentage |
| Trend / comparison | `S.linechart`, `S.bars`, `S.hbars`, `S.donut` |
| Process with steps | `S.stepper(...)` or cards joined by `S.flow(...)` |
| Before to after | `S.morph_text`, `S.morph_shape`, `S.morph_rr` |
| Focus on one thing | `S.spotlight(...)` then a caption card |
| Celebration at the end | `S.burst(...)`, `S.sparkle(...)` |
