# Avoiding the generic "AI motion" look (read before writing scenes)

Generic output is not caused by missing tools; it comes from picking the statistical middle every time. Decide on purpose.

## Do not
- Give every element the same fade-and-slide-up. Pick a motion language for the video (two easing curves, one entrance style per element type).
- Put three equal cards in a row on every scene. Vary the layout: one huge number, a diagram, a split screen, a single quote.
- Move everything at once, or move things that carry no meaning (decorative confetti, floating shapes behind text, a background that competes with the narration).
- Use effects as decoration. Each effect must explain something: a line draws to show a process, a shape morphs to show a change, a number counts up because the size of it matters.
- Stack different effects in one video (kinetic text + glitch + morphs + particles). Choose three at most and repeat them.
- Rely on one default look (dark glow plus gradient text) for every topic. Match the mood to the audience: formal institutions want calm and clear, not flash.
- Write vague claims ("seamless", "revolutionary", "powerful"). Say what happens, with the number from facts.md.
- Mix icon styles or sizes. Use one icon set (Lucide) at one stroke weight.

## Do
- One hero moment per scene; everything else supports it. State the scene's point in the first beat.
- Use contrast of scale: a very large figure with small labels beats a grid of medium things.
- Exits shorter than entrances, stagger under 0.1 s per item, and let the finished picture hold at least 0.6 s before the next change.
- One accent colour plus one support colour; text always readable (26 px or larger, strong contrast).
- Tie sound to content: pops when a point appears, a chime only on the conclusion (the sound layer does this automatically).
- End on one clear message, not a summary slide full of bullets.

## Before delivering, Claude must
1. Name each scene's single point in one sentence (if it takes two, split the scene).
2. Check contact sheets for overlap, clipping and crowding; check at least two looks.
3. Confirm every number against facts.md (`python studio.py facts`) and list anything labelled "Example data".
4. Run `python studio.py qa` on a draft and report remaining WARN lines honestly.
