# Pitfalls already hit (and fixes)

- **Tool call limit about 300 s.** Full renders and encodes take longer. Always launch `build_video.py` detached with
  `(setsid nohup ... > log 2>&1 < /dev/null &)` and poll. A plain `nohup ... &` was killed when the call ended.
- **Single CPU core.** Frame rendering is about 0.09 s per unique frame; encoding 10 minutes of 1080p took about 8-10 min.
  Use `--draft` for previews and `--only` for subsets. Static stretches are stored as one frame with a duration, so only
  animated moments cost render time.
- **Missing glyphs.** Poppins has no arrow (U+2192) and the font renders unknown characters as boxes. The engine prints a
  warning; draw arrows/ticks with primitives. `!=` sign U+2260, middle dot, em dash, curly quotes are fine.
- **Layout overlaps found only visually.** Always run `contact_sheet.py --beats` and view the sheets. Typical problems:
  wrapped text colliding with the next row, labels longer than the space before a bar, pills sitting on subtitles,
  a floating block that lands on another block (check final positions of any moving element).
- **Brace expansion in `mkdir -p a/{b,c}` is not available** in the tool shell; list directories explicitly.
- **Font files:** Poppins Light/Regular/Medium/Bold at `/usr/share/fonts/truetype/google-fonts/`. If missing, change `FD`/the
  weight map at the top of `engine.py`.
- **No Chromium here**, so no Playwright/HTML rendering path. Do not try to download browsers (network allow-list).
- **dash effects:** use `skia.DashPathEffect.Make`, not the constructor.
- **Concat demuxer** needs absolute paths (the scripts handle this) and the last file repeated once for its duration to apply.
- **Timing is word-count based.** Never claim sync with a real voice; offer `--audio` to rescale.
