# Other routes (mention when the request outgrows this skill)

A web search (October 2026) of third-party sources found these Claude-oriented video options. They are community or
vendor projects; Claude has not tested them here, so tell the user to review licence and contents before installing.

- **Claude Motion Studio**: a Remotion project with two skills (motion-design decisions and build/render) for Claude Code.
  Workflow: idea -> style -> build -> render; formats include 9:16, 4:5, 1:1, 16:9. Needs Node 18+ on the user's computer.
- **Remotion Agent Skills**: teach Claude to write React video compositions that render to MP4 (`npx create-video@latest`).
  Best for polished, previewable, brandable motion graphics and vertical reels.
- **HyperFrames (HeyGen) motion-graphics skill**: short (~10 s), unnarrated design-led motion pieces; longer narrated pieces
  use a general-video flow in the same ecosystem.
- **OpenMontage**: larger agentic video-production pipeline with several video types.
- Claude in the chat app can write such code but cannot run Remotion there; these routes need Claude Code (or similar)
  on the user's machine.

## What to offer
1. Keep using this skill for fast, chat-only, 16:9 explainers and per-scene clips.
2. For a premium or vertical version: write the **scene plan** (scene titles, beats = script lines, exact on-screen copy,
   palette, format, length) from the same spec and give it to the user as a brief to paste into Claude Code with the
   Remotion skills. The Remotion tutorial pattern is: format, length, scene order, exact copy, how things move.
3. For editable slides: pptx skill from the same spec.
