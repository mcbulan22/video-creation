"""REFERENCE: the full 17-scene explainer that this skill was built from ("Rethinking the Exam").
Copy patterns from here: title card, split compare, flow row, checklist rows, strengths/limits, before/after,
mismatch table, three-card architecture, 2x2 safeguard grid, pyramid + mapping, stacked foundation,
staircase, 6-step roadmap grid, strike-through key idea, closing question.
Each scene: @scene(chapter, beats) + a draw(S) function that reveals things with S.p(beat_index, ...)."""
import math, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *
DECK_TITLE = "Rethinking the Exam"

# 1 -------------------------------------------------------------
@scene("THE EXPLAINER", [
 "Welcome back to The Explainer. Let's get right into it, because today we're looking at how maritime academies are radically rethinking the way they assess cadet readiness.",
 "And look, this isn't just about tweaking a syllabus or updating a textbook. We're talking about a fundamental shift in how we prove that a future officer is truly, undeniably ready to take the helm."])
def s1(S):
    p0 = S.p(0, 0.9); S.ship(960, 290, 1.25, "teal", p0); S.waves(560, 1360, 372, 10, "sky", .5 * p0, 3, 24)
    S.text("THE EXPLAINER", 960, 520, 30, "teal", "m", "c", p0)
    S.text("Rethinking the Exam", 960, 640, 112, "white", "b", "c", S.p(0, .8, .25))
    S.text("How maritime academies are redefining cadet readiness", 960, 715, 40, "mute", "r", "c", S.p(0, .8, .5))
    S.text("Not a syllabus tweak. Not a new textbook.", 960, 840, 40, "mute", "r", "c", S.p(1))
    S.text("A fundamental shift in how we prove a future officer is ready to take the helm.", 960, 905, 44, "white", "m", "c", S.p(1, .6, .5), maxw=1500)

# 2 -------------------------------------------------------------
@scene("THE CORE QUESTION", [
 "So take a second to really think about this.",
 "Is knowing the right answer actually the right thing?",
 "Because that is the core question driving our explainer today."])
def s2(S):
    S.text("Take a second to think about this…", 960, 330, 44, "mute", "r", "c", S.p(0))
    S.text("Is knowing the right answer", 960, 510, 100, "white", "b", "c", S.p(1))
    S.text("actually the right thing?", 960, 640, 100, "amber", "b", "c", S.p(1, .6, .35))
    S.pill("THE CORE QUESTION DRIVING THIS EXPLAINER", 960, 820, 32, "teal", None, S.p(2))

# 3 -------------------------------------------------------------
@scene("THE GAP", [
 "We're diving straight into that dangerous gap between theoretical knowledge and real-world performance.",
 "Think about it. In a perfectly calm, air-conditioned classroom, a cadet might easily jot down the exact step-by-step procedure for a steering failure.",
 "But what happens at 2 a.m. in heavy seas when the alarms suddenly start screaming at them?",
 "Well, that gap, that hesitation, is exactly what head assessors are desperately trying to close."], ext={2: 3.2})
def s3(S):
    p0 = S.p(0)
    S.rr(120, 250, 700, 640, 28, "card", "edge", 3, p0)
    S.rr(1100, 250, 700, 640, 28, "card", "edge", 3, S.p(0, .55, .2))
    S.text("THEORETICAL KNOWLEDGE", 470, 215, 34, "teal", "m", "c", p0)
    S.text("REAL-WORLD PERFORMANCE", 1450, 215, 34, "amber", "m", "c", S.p(0, .55, .2))
    S.line(960, 250, 960, 890, "red", 5, S.p(0, .6, .4), dash=[16, 14])
    S.text("THE GAP", 960, 300, 32, "red", "b", "c", S.p(0, .6, .5))
    # left
    S.text("A calm, air-conditioned classroom", 470, 320, 30, "mute", "m", "c", S.p(1))
    S.rr(200, 360, 540, 470, 14, "#EEF3F8", None, 0, S.p(1, .5, .1))
    S.text("STEERING FAILURE — PROCEDURE", 470, 415, 26, "#16324F", "b", "c", S.p(1, .5, .2))
    steps = ["Notify the master", "Use emergency steering", "Reduce speed, warn traffic", "Inform the engine room"]
    for i, st in enumerate(steps):
        pp = S.p(1, .45, .35 + i * .35)
        S.text(f"{i+1}.  {st}", 235, 500 + i * 80, 28, "#16324F", "m", "l", pp, maxw=450)
        S.check(705, 490 + i * 80, 20, "green", pp)
    # right
    pr = S.p(2); S.text("02:00", 1450, 410, 96, "amber", "b", "c", pr)
    S.text("Heavy seas · alarms screaming", 1450, 470, 32, "white", "m", "c", S.p(2, .5, .2))
    fl = 1.0 if S.t - S.bs[2] > 3.0 or S.t < S.bs[2] else (0.55 + 0.45 * math.sin((S.t - S.bs[2]) * 11))
    for i, cx in enumerate([1250, 1450, 1650]):
        pp = S.p(2, .4, .3 + i * .15)
        if pp > 0:
            pa = skia.Path(); pa.moveTo(cx, 560); pa.lineTo(cx + 70, 690); pa.lineTo(cx - 70, 690); pa.close()
            S.c.drawPath(pa, S.paint("red", pp * fl))
            S.text("!", cx, 667, 64, "white", "b", "c", pp)
    S.waves(1140, 1760, 770, 14, "sky", .6 * pr, 3, 28)
    # bridge
    pb = S.p(3, .9)
    S.rr(790, 520, 340, 130, 20, "#2A1020", "red", 3, S.p(3, .5))
    S.text("HESITATION", 960, 595, 36, "red", "b", "c", S.p(3, .5))
    S.arrow(820, 700, 1100, 700, "green", 8, pb)
    S.text("Close the gap", 960, 770, 34, "green", "b", "c", S.p(3, .6, .6))

# 4 -------------------------------------------------------------
@scene("THE ULTIMATE GATEKEEPER", [
 "And right now, there is just one, literally just one, final massive check before a cadet gets their degree and is officially cleared to become an officer in charge of a watch.",
 "This single, comprehensive examination is the ultimate gatekeeper.",
 "A pass here tells the institution,",
 "the global shipping industry,",
 "and honestly, the cadet's own family,",
 "that they are ready for the immense responsibility of an ocean-going role.",
 "Because this exam carries such incredible weight, any changes to it have to be handled with extreme care."])
def s4(S):
    xs = [250, 700, 1150, 1600]; labs = [("CADET", "Final year"), ("COMPREHENSIVE\nEXAMINATION", ""), ("DEGREE", "Graduation"), ("OFFICER IN CHARGE\nOF A WATCH", "Cleared to sail")]
    ww = [300, 340, 300, 340]
    for i in range(4):
        pp = S.p(0, .55, i * .45)
        hl = 1 if i == 1 else 0
        bx = xs[i] - ww[i] / 2; bw = ww[i]; by = 330
        glow = S.p(1, .5) if i == 1 else 0
        S.rr(bx, by - 8 * glow, bw, 160 + 16 * glow, 24, "card", "amber" if (i == 1 and glow > 0) else "edge", 5 if i == 1 else 3, pp)
        for j, ln in enumerate(labs[i][0].split("\n")):
            nl = len(labs[i][0].split("\n"))
            S.text(ln, xs[i], by + 78 + (j - (nl - 1) / 2) * 38 + (0 if not labs[i][1] else -8), 30, "amber" if i == 1 else "white", "b", "c", pp)
        if labs[i][1]: S.text(labs[i][1], xs[i], by + 128, 24, "mute", "r", "c", pp)
        if i < 3: S.arrow(xs[i] + ww[i] / 2 + 12, 410, xs[i + 1] - ww[i + 1] / 2 - 12, 410, "mute", 5, S.p(0, .4, i * .45 + .3))
    S.text("ONE FINAL CHECK  ·  THE ULTIMATE GATEKEEPER", 960, 570, 42, "amber", "b", "c", S.p(1, .6, .2))
    cards = [("Institution", 2), ("Global shipping industry", 3), ("The cadet's own family", 4)]
    for i, (nm, k) in enumerate(cards):
        pp = S.p(k); x = 150 + i * 570
        S.rr(x, 640, 520, 150, 22, "card", "edge", 3, pp)
        S.text(nm, x + 260, 725, 34, "white", "b", "c", pp, maxw=440)
        S.check(x + 260, 765, 16, "green", pp)
    S.text("A pass says: ready for the immense responsibility of an ocean-going role.", 960, 870, 38, "teal", "m", "c", S.p(5), maxw=1600)
    S.pill("CHANGES MUST BE HANDLED WITH EXTREME CARE", 960, 975, 28, "amber", None, S.p(6))

# 5 -------------------------------------------------------------
@scene("01 · THE BASELINE", [
 "Okay, let's jump to section 1, the baseline. To really understand where we're headed, we kind of have to look at where we are right now.",
 "The current backbone of this assessment is firmly rooted in the STCW code, specifically using scenario-based essays.",
 "So whether a cadet is deck or engine, they get placed in this realistic, hypothetical situation and have to write out what they do, why they do it, and exactly what rules and procedures apply."])
def s5(S):
    p1 = S.p(1, .8); ty = 520 - 300 * p1
    S.text("01", 960, ty - 110, 60, "teal", "b", "c", S.p(0))
    S.text("The Baseline", 960, ty, 104, "white", "b", "c", S.p(0, .6, .2))
    S.text("Where we are right now", 960, ty + 70, 40, "mute", "r", "c", S.p(0, .6, .45) * (1 - .0))
    S.rr(260, 360, 560, 130, 24, "card", "edge", 3, S.p(1)); S.text("STCW Code", 540, 440, 44, "white", "b", "c", S.p(1))
    S.arrow(830, 425, 1090, 425, "mute", 6, S.p(1, .5, .3))
    S.rr(1100, 360, 560, 130, 24, "card", "amber", 4, S.p(1, .55, .35)); S.text("Scenario-based essays", 1380, 440, 40, "amber", "b", "c", S.p(1, .55, .35))
    S.text("Deck or Engine cadet  ·  realistic, hypothetical situation  ·  write it out", 960, 600, 38, "white", "m", "c", S.p(2), maxw=1600)
    for i, (a, b) in enumerate([("WHAT", "you do"), ("WHY", "you do it"), ("WHICH", "rules & procedures apply")]):
        pp = S.p(2, .5, .6 + i * .5); x = 170 + i * 560
        S.rr(x, 690, 520, 190, 24, "card", "teal", 3, pp)
        S.text(a, x + 260, 770, 52, "teal", "b", "c", pp); S.text(b, x + 260, 825, 32, "white", "m", "c", pp, maxw=460)

# 6 -------------------------------------------------------------
@scene("01 · THE BASELINE", [
 "Now, this current system? It's a bit of a balancing act.",
 "It definitely has some real strengths.",
 "I mean, it follows the STCW tables perfectly,",
 "it forces cadets to actually reason through a problem rather than just rote memorize,",
 "and it has a very fair retake policy. If you bomb one competence, you only retake that one, not the whole shebang."])
def s6(S):
    p0 = S.p(0, .9); c = S.c
    tilt = (1 - p0) * 0.12 - 0.0
    S.text("A balancing act", 960, 200, 64, "white", "b", "c", S.p(0))
    c.save(); c.translate(960, 330); c.rotate(math.degrees(-0.12 * (1 - ease(S.p(1, 1.0)) * .0) * p0))
    c.drawLine(-260, 0, 260, 0, S.paint("white", p0, 8)); c.restore()
    pa = skia.Path(); pa.moveTo(960, 330); pa.lineTo(920, 400); pa.lineTo(1000, 400); pa.close(); c.drawPath(pa, S.paint("edge", p0))
    S.text("STRENGTHS", 960, 470, 34, "green", "b", "c", S.p(1))
    rows = [("Follows the STCW tables", "perfectly"), ("Forces reasoning", "rather than rote memorizing"), ("A very fair retake policy", "fail one competence, retake only that one")]
    for i, (a, b) in enumerate(rows):
        pp = S.p(2 + i); y = 520 + i * 150
        S.rr(250, y, 1420, 120, 24, "card", "green", 3, pp)
        S.check(320, y + 62, 28, "green", pp)
        S.text(a, 390, y + 55, 38, "white", "b", "l", pp); S.text(b, 390, y + 98, 28, "mute", "r", "l", pp)

# 7 -------------------------------------------------------------
@scene("01 · THE BASELINE", [
 "But the limits are pretty glaring.",
 "It relies way too heavily on writing ability rather than hands-on performance.",
 "You could have a brilliant cadet who just struggles to write under pressure completely fail,",
 "while an articulate writer who would totally freeze up on a chaotic bridge ends up passing.",
 "Plus, it just doesn't test integrated watchkeeping, how all these different skills actually mesh together when you're running a live ship."])
def s7(S):
    S.text("THE LIMITS", 960, 205, 64, "red", "b", "c", S.p(0))
    p1 = S.p(1, .9)
    S.text("Writing ability", 180, 330, 30, "white", "m", "l", S.p(1)); S.rr(600, 295, 1100 * .9 * p1, 50, 25, "red", None, 0, S.p(1))
    S.text("Hands-on performance", 180, 410, 30, "white", "m", "l", S.p(1)); S.rr(600, 375, 1100 * .16 * p1, 50, 25, "green", None, 0, S.p(1))
    for i, (a, b, st, col, k) in enumerate([("Brilliant cadet", "Struggles to write under pressure", "FAIL", "red", 2), ("Articulate writer", "Freezes up on a chaotic bridge", "PASS", "green", 3)]):
        pp = S.p(k); x = 120 + i * 870
        S.rr(x, 500, 810, 250, 26, "card", "edge", 3, pp)
        S.text(a, x + 50, 580, 46, "white", "b", "l", pp); S.text(b, x + 50, 635, 32, "mute", "r", "l", pp)
        S.pill(st, x + 640, 690, 34, col, None, S.p(k, .4, .6), "b", 40)
    S.rr(220, 820, 1480, 130, 24, "#2A1020", "red", 3, S.p(4))
    S.cross(290, 885, 30, "red", S.p(4))
    S.text("Doesn't test integrated watchkeeping", 350, 875, 40, "white", "b", "l", S.p(4))
    S.text("how all the skills mesh together on a live ship", 350, 920, 30, "mute", "r", "l", S.p(4))

# 8 -------------------------------------------------------------
@scene("02 · THE CATALYST", [
 "The catalyst. Assessors obviously saw these limits, right? So they proposed a really profound shift to bridge this gap.",
 "We're looking at moving entirely away from an exam that just tests if you can write down the steps on paper,",
 "to a dynamic setup that observes you actually executing them.",
 "This new proposal pushes for multiple-choice tests to nail down that baseline knowledge,",
 "but then it leans heavily on practical simulator tasks. That's where they test performance, analysis, and real-time justification.",
 "It's a massive evolution from, tell me what you would do, to show me exactly how you do it."])
def s8(S):
    S.text("THE CATALYST", 960, 190, 34, "teal", "m", "c", S.p(0))
    S.text("A profound shift", 960, 275, 70, "white", "b", "c", S.p(0, .6, .2))
    S.rr(120, 340, 760, 190, 26, "card", "edge", 3, S.p(1))
    S.text("WRITE the steps on paper", 500, 445, 44, "mute", "b", "c", S.p(1)); S.text("what you would do", 500, 495, 30, "mute", "r", "c", S.p(1))
    S.arrow(900, 435, 1020, 435, "amber", 8, S.p(2, .5))
    S.rr(1040, 340, 760, 190, 26, "card", "amber", 4, S.p(2))
    S.text("EXECUTE them — observed", 1420, 445, 44, "amber", "b", "c", S.p(2)); S.text("show how you do it", 1420, 495, 30, "white", "r", "c", S.p(2))
    S.rr(120, 580, 760, 180, 26, "card", "teal", 3, S.p(3)); S.text("Multiple-choice tests", 500, 665, 40, "teal", "b", "c", S.p(3)); S.text("nail down baseline knowledge", 500, 715, 30, "white", "r", "c", S.p(3))
    S.rr(1040, 580, 760, 180, 26, "card", "sky", 3, S.p(4)); S.text("Practical simulator tasks", 1420, 665, 40, "sky", "b", "c", S.p(4)); S.text("performance · analysis · real-time justification", 1420, 715, 28, "white", "r", "c", S.p(4), maxw=700)
    S.text("“Tell me what you would do”", 470, 900, 34, "mute", "m", "c", S.p(5))
    S.arrow(790, 885, 1085, 885, "amber", 8, S.p(5, .6, .3))
    S.text("“Show me exactly how you do it”", 1450, 900, 34, "amber", "b", "c", S.p(5, .6, .6))

# 9 -------------------------------------------------------------
@scene("02 · THE CATALYST", [
 "But, you know, it's a first draft. And like any ambitious first draft, there were some pretty significant inconsistencies in the initial proposal.",
 "The source material points out that written proposal and the actual presentation just didn't match up.",
 "We had conflicting phase numbers. Two phases in one document, three in another.",
 "Question bank ratios were all over the place.",
 "Even assessor pay rates differed.",
 "Actually, scratch that. An oral defense was mentioned in the presentation, but completely MIA from the written text.",
 "And most critically, it lacked clearly defined passing standards."])
def s9(S):
    S.text("A first draft — with inconsistencies", 960, 190, 56, "white", "b", "c", S.p(0))
    S.rr(260, 250, 520, 110, 22, "card", "edge", 3, S.p(1)); S.text("WRITTEN PROPOSAL", 520, 318, 34, "white", "b", "c", S.p(1))
    S.rr(1140, 250, 520, 110, 22, "card", "edge", 3, S.p(1, .5, .2)); S.text("PRESENTATION", 1400, 318, 34, "white", "b", "c", S.p(1, .5, .2))
    S.text("≠", 960, 340, 100, "red", "b", "c", S.p(1, .5, .5))
    rows = [("Number of phases", "2  vs  3", 2), ("Question-bank ratios", "Inconsistent", 3), ("Assessor pay rates", "Different", 4), ("Oral defense", "In the presentation · missing from the text", 5)]
    for i, (a, b, k) in enumerate(rows):
        pp = S.p(k); y = 410 + i * 90
        S.rr(200, y, 1520, 76, 18, "card", "edge", 2, pp)
        S.text(a, 250, y + 50, 32, "white", "m", "l", pp); S.text(b, 1670, y + 50, 30, "red" if k != 5 else "amber", "b", "r", pp)
    pp = S.p(6)
    S.rr(200, 800, 1520, 130, 24, "#2A1A05", "amber", 4, pp)
    S.text("MOST CRITICAL", 250, 850, 26, "amber", "b", "l", pp)
    S.text("No clearly defined passing standards", 250, 905, 46, "white", "b", "l", pp)
    S.cross(1640, 865, 40, "red", pp)

# 10 -------------------------------------------------------------
@scene("03 · THE SYNTHESIS", [
 "So obviously, before anything becomes official policy, those wrinkles absolutely have to be ironed out.",
 "So let's look at how we fix that in section three, the synthesis.",
 "To smooth out all those inconsistencies, a really elegant, unified, three-phase architecture was developed.",
 "And the beauty here is how each phase gathers a completely different type of evidence about the cadet's readiness.",
 "Phase one is a multiple-choice exam, checking pure knowledge and understanding. You just have to know the facts.",
 "Phase two keeps the scenario-based authentic essay, but specifically to check judgment and application. Can you plan and justify a course of action?",
 "And then finally, phase three is the simulator and lab practical. This is the ultimate integration test, checking real-world performance.",
 "It's a very logical, very deliberate progression."])
def s10(S):
    p2 = S.p(2, .5)
    S.text("Iron out the wrinkles", 960, 480, 90, "white", "b", "c", S.p(0) * (1 - p2))
    S.text("before anything becomes official policy", 960, 570, 44, "mute", "r", "c", S.p(0, .6, .3) * (1 - p2))
    S.text("03  ·  THE SYNTHESIS", 960, 200, 36, "teal", "m", "c", S.p(1))
    S.text("One unified, three-phase architecture", 960, 270, 60, "white", "b", "c", S.p(1, .6, .2) * p2 if S.t >= S.bs[2] else 0)
    ph = [("PHASE 1", "Multiple-choice exam", "KNOWLEDGE &\nUNDERSTANDING", "You just have to know the facts", "teal", 4),
          ("PHASE 2", "Scenario-based authentic essay", "JUDGMENT &\nAPPLICATION", "Plan and justify a course of action", "amber", 5),
          ("PHASE 3", "Simulator & lab practical", "REAL-WORLD\nPERFORMANCE", "The ultimate integration test", "sky", 6)]
    for i, (a, b, c_, d, col, k) in enumerate(ph):
        x = 120 + i * 580; pp = S.p(2, .55, i * .3); pf = S.p(k)
        S.rr(x, 340, 520, 470, 28, "card", col if pf > 0 else "edge", 4 if pf > 0 else 2, pp, dash=None if pf > 0 else [14, 12])
        S.text(a, x + 260, 405, 36, col, "b", "c", pp)
        S.text(b, x + 260, 480, 34, "white", "b", "c", pf, maxw=460)
        for j, ln in enumerate(c_.split("\n")): S.text(ln, x + 260, 600 + j * 56, 44, col, "b", "c", pf)
        S.text(d, x + 260, 750, 28, "mute", "r", "c", pf, maxw=440)
        if i < 2: S.arrow(x + 528, 575, x + 572, 575, "white", 6, S.p(7, .5, i * .3), head=14)
    S.pill("EACH PHASE GATHERS A DIFFERENT TYPE OF EVIDENCE", 960, 905, 30, "teal", None, S.p(3))
    S.text("A logical, deliberate progression", 960, 985, 34, "white", "m", "c", S.p(7))

# 11 -------------------------------------------------------------
@scene("03 · THE SYNTHESIS", [
 "But here's the thing. You can't just build these massive assessment gates without protecting the cadets walking through them, right? You need strict safeguards.",
 "First off, each competence is judged individually, so no averaging out.",
 "You can't use a stellar score in navigation to hide a fatal weakness in safety procedures.",
 "If a cadet fails, they only retake that precise component.",
 "Also, passing standards aren't just pulled out of thin air. They're set by recognized educational methods, like the modified Angoff approach.",
 "On top of that, assessors absolutely must be independent, meaning they literally cannot assess a cadet they taught in class.",
 "That guarantees fairness and total integrity across the board."])
def s11(S):
    S.text("Strict safeguards", 960, 205, 64, "white", "b", "c", S.p(0))
    cards = [(120, 280, "Each competence judged individually", "No averaging out", "teal", 1),
             (990, 280, "Retake only what you failed", "Fail one component, retake only that precise component", "amber", 3),
             (120, 620, "Recognized standard-setting", "Passing standards set by the modified Angoff approach", "sky", 4),
             (990, 620, "Independent assessors", "Cannot assess a cadet they taught in class", "green", 5)]
    for x, y, a, b, col, k in cards:
        pp = S.p(k)
        S.rr(x, y, 810, 300, 28, "card", col, 4, pp)
        S.text(a, x + 40, y + 70, 36, col, "b", "l", pp, maxw=730); S.text(b, x + 40, y + 125, 32 if k != 1 else 28, "white", "r", "l", pp, maxw=730)
    p2 = S.p(2)
    for i, (nm, v, col) in enumerate([("Navigation", 92, "green"), ("Safety procedures", 38, "red")]):
        yy = 455 + i * 52
        S.text(nm, 160, yy + 8, 26, "white", "m", "l", p2); S.rr(430, yy - 22, 4.6 * v * p2, 36, 18, col, None, 0, p2)
    S.text("An average would hide the weakness", 160, 562, 26, "red", "b", "l", S.p(2, .5, .5))
    S.pill("FAIRNESS  ·  INTEGRITY", 960, 985, 30, "teal", None, S.p(6))

# 12 -------------------------------------------------------------
@scene("04 · THE SCIENCE OF ASSESSMENT", [
 "All right, let's dig into section four, the science of assessment. What I find absolutely fascinating about this three-phase structure is that none of this is just guesswork.",
 "It aligns perfectly with established educational frameworks. Take a look at Miller's levels of clinical competence.",
 "It's basically a pyramid describing how humans actually learn.",
 "Learners first know,",
 "then they know how,",
 "then they show how,",
 "and finally, they do.",
 "Our three new phases map to this flawlessly.",
 "Phase one checks if a cadet knows,",
 "phase two checks if they know how,",
 "and phase three forces them into the simulator so they can actually show how to command a watch."])
def s12(S):
    p0 = S.p(0) * (1 - S.p(1, .5))
    S.text("04", 960, 440, 60, "teal", "b", "c", p0); S.text("The Science of Assessment", 960, 540, 90, "white", "b", "c", p0)
    S.text("None of this is guesswork", 960, 615, 40, "mute", "r", "c", p0)
    S.text("Miller's pyramid of clinical competence", 960, 190, 52, "white", "b", "c", S.p(1))
    cx, top, base, hw = 520, 290, 920, 400
    tiers = [("DOES", "amber", 6), ("SHOWS HOW", "sky", 5), ("KNOWS HOW", "teal", 4), ("KNOWS", "green", 3)]
    for i, (nm, col, k) in enumerate(tiers):
        y0 = top + i * (base - top) / 4; y1 = y0 + (base - top) / 4
        w0 = hw * (y0 - top) / (base - top); w1 = hw * (y1 - top) / (base - top)
        pp = S.p(k); po = S.p(2)
        pa = skia.Path(); pa.moveTo(cx - w0, y0 + 3); pa.lineTo(cx + w0, y0 + 3); pa.lineTo(cx + w1 - 4, y1 - 3); pa.lineTo(cx - w1 + 4, y1 - 3); pa.close()
        if po > 0: S.c.drawPath(pa, S.paint("edge", po, 3))
        if pp > 0: S.c.drawPath(pa, S.paint(col, pp * .9))
        S.text(nm, cx, (y0 + y1) / 2 + 12, 32, "dark" if pp > .5 else "mute", "b", "c", max(pp, po * .6))
    maps = [("PHASE 1", "Checks if a cadet KNOWS", 3, 8, "teal", 3), ("PHASE 2", "Checks if they KNOW HOW", 2, 9, "amber", 2), ("PHASE 3", "Show how — command a watch in the simulator", 1, 10, "sky", 1)]
    S.text("OUR THREE PHASES", 1400, 345, 30, "mute", "m", "c", S.p(7))
    for a, b, ti, k, col, _ in maps:
        y0 = top + ti * (base - top) / 4; yc = y0 + (base - top) / 8; pp = S.p(k)
        S.line(cx + hw * (y0 + (base - top) / 8 - top) / (base - top) + 20, yc, 1000, yc, col, 4, pp, dash=[10, 10])
        S.rr(1000, yc - 62, 800, 124, 22, "card", col, 4, pp)
        S.text(a, 1040, yc - 8, 34, col, "b", "l", pp); S.text(b, 1040, yc + 38, 28, "white", "m", "l", pp, maxw=730)

# 13 -------------------------------------------------------------
@scene("04 · THE SCIENCE OF ASSESSMENT", [
 "And this whole idea is completely backed up by Gagné's theory of complexities.",
 "Gagné basically proved that you cannot just jump straight into high-stress, complex tasks without a solid foundation.",
 "The overwhelming, chaotic simulator tasks in phase three simply cannot be successfully navigated unless they are firmly supported by those bedrock facts checked way back in phase one."])
def s13(S):
    S.text("Foundations before complexity", 960, 205, 62, "white", "b", "c", S.p(0))
    S.text("Gagné's learning hierarchy", 960, 265, 34, "teal", "m", "c", S.p(0, .5, .25))
    p1, p2 = S.p(1), S.p(2, .9)
    drop = ease((S.t - S.bs[2] - .3) / .9)
    ty = 300 + 140 * drop
    S.rr(510, ty, 900, 150, 24, "card", "sky", 4, p1)
    S.text("PHASE 3 — Chaotic, high-stress simulator tasks", 960, ty + 88, 34, "sky", "b", "c", p1, maxw=840)
    if S.t < S.bs[2] + 1.0:
        S.rr(510, 480, 900, 430, 24, None, "red", 3, p1 * (1 - p2), dash=[16, 14])
        S.text("No solid foundation", 960, 720, 44, "red", "b", "c", p1 * (1 - p2))
        S.cross(960, 630, 56, "red", p1 * (1 - p2))
    S.rr(510, 760, 900, 150, 24, "card", "green", 4, p2); S.text("PHASE 1 — Bedrock facts", 960, 848, 36, "green", "b", "c", p2)
    S.rr(510, 600, 900, 150, 24, "card", "amber", 4, S.p(2, .6, .35)); S.text("PHASE 2 — Judgment & application", 960, 688, 34, "amber", "b", "c", S.p(2, .6, .35))
    S.text("firmly supported", 1450, 690, 30, "mute", "m", "l", S.p(2, .6, .9))

# 14 -------------------------------------------------------------
@scene("04 · THE SCIENCE OF ASSESSMENT", [
 "Then you throw the SOLO taxonomy into the mix, and it really reinforces the ultimate goal of phase three.",
 "This model details how understanding evolves from just recalling separate facts",
 "to linking those ideas together",
 "and ultimately transferring that knowledge into totally new situations,",
 "which, let's be honest, is exactly what a maritime officer does every single day.",
 "Phase three forces cadets to take isolated rules they read in a textbook and dynamically apply them to completely unpredictable, high-stress simulator scenarios."])
def s14(S):
    S.text("SOLO taxonomy", 960, 205, 62, "white", "b", "c", S.p(0)); S.text("how understanding evolves", 960, 265, 34, "teal", "m", "c", S.p(0, .5, .25))
    steps = [("RECALL", "Separate facts", "green", 1, 150), ("LINK", "Ideas together", "teal", 2, 240), ("TRANSFER", "To totally new situations", "amber", 3, 330)]
    for i, (a, b, col, k, h) in enumerate(steps):
        x = 160 + i * 570; pp = S.p(k); y = 770 - h
        S.rr(x, y, 530, h, 22, "card", col, 4, pp)
        S.text(a, x + 265, y + 70, 44, col, "b", "c", pp); S.text(b, x + 265, y + 125, 30, "white", "m", "c", pp, maxw=480)
        if i < 2: S.arrow(x + 538, 700 - h * .3, x + 562, 690 - h * .3 - 40, "mute", 5, S.p(k + 1, .4), head=12)
    S.text("exactly what a maritime officer does every day", 1565, 350, 28, "amber", "b", "c", S.p(4), maxw=520)
    S.rr(160, 830, 700, 120, 22, "card", "edge", 3, S.p(5)); S.text("Isolated textbook rules", 510, 905, 38, "white", "b", "c", S.p(5))
    S.arrow(880, 890, 1040, 890, "amber", 8, S.p(5, .5, .4))
    S.rr(1060, 830, 700, 120, 22, "card", "red", 3, S.p(5, .5, .5)); S.text("Unpredictable, high-stress simulator scenarios", 1410, 878, 28, "red", "b", "c", S.p(5, .5, .5), maxw=640, lh=1.2)

# 15 -------------------------------------------------------------
@scene("05 · IMPLEMENTATION", [
 "Okay, moving on to section five, charting the implementation course. So the theory is rock solid, but how do we actually turn this blueprint into an institutional reality?",
 "By condensing the initial recommendations from our material, we get this very deliberate six-step roadmap.",
 "First, we reconcile the blueprints so we don't miss any STCW competencies.",
 "Then we methodically design phases one and two,",
 "followed by those really complex phase three simulator scenarios.",
 "Step four is crucial. We have to train and qualify our independent assessors.",
 "Step five locks all of this down into official policy.",
 "And finally, we don't just roll this out blindly. We run a controlled pilot, study the results, adjust, and then fully implement."])
def s15(S):
    p0 = S.p(0) ; S.text("05", 960, 175, 36, "teal", "b", "c", p0); S.text("Charting the implementation course", 960, 250, 58, "white", "b", "c", S.p(0, .6, .2))
    items = [("Reconcile the blueprints", "Don't miss any STCW competence", "teal", 2), ("Design Phases 1 & 2", "Multiple-choice + scenario essay", "teal", 3),
             ("Design Phase 3", "Complex simulator scenarios", "teal", 4), ("Train & qualify assessors", "Independent and crucial", "amber", 5),
             ("Lock into official policy", "Make it the rule", "teal", 6), ("Controlled pilot, then implement", "Study results, adjust, then fully implement", "green", 7)]
    for i, (a, b, col, k) in enumerate(items):
        x = 120 + (i % 3) * 590; y = 340 + (i // 3) * 300; pg = S.p(1, .5, i * .12); pf = S.p(k)
        S.rr(x, y, 540, 250, 28, "card", col if pf > 0 else "edge", 4 if pf > 0 else 2, pg, dash=None if pf > 0 else [14, 12])
        S.circ(x + 60, y + 65, 34, col if pf > 0 else "edge", None, 0, pg); S.text(str(i + 1), x + 60, y + 78, 38, "dark" if pf > 0 else "mute", "b", "c", pg)
        S.text(a, x + 115, y + 80, 34, "white", "b", "l", pf, maxw=400, lh=1.15); S.text(b, x + 40, y + 190, 27, "mute", "r", "l", pf, maxw=470, lh=1.2)

# 16 -------------------------------------------------------------
@scene("THE KEY IDEA", [
 "I really want to highlight this one profoundly important sentiment from our source material.",
 "The goal is not to make the examination harder.",
 "The goal is to make the evidence of competence stronger.",
 "This whole evolution, it isn't some obstacle course designed to punish cadets.",
 "It's about proving without a single shred of doubt that when a cadet is handed their degree, they are actually ready to keep their crew safe."])
def s16(S):
    S.text("THE KEY IDEA", 960, 190, 34, "teal", "m", "c", S.p(0))
    S.text("THE GOAL IS NOT", 960, 330, 36, "mute", "m", "c", S.p(1))
    S.text("A HARDER EXAMINATION", 960, 430, 88, "mute", "b", "c", S.p(1, .5, .1), strike=ease((S.t - S.bs[1] - .7) / .5))
    S.text("THE GOAL IS", 960, 570, 36, "teal", "m", "c", S.p(2))
    S.text("STRONGER EVIDENCE OF COMPETENCE", 960, 665, 76, "white", "b", "c", S.p(2, .6, .15))
    S.text("Not an obstacle course designed to punish cadets.", 960, 790, 38, "mute", "r", "c", S.p(3))
    S.text("Proof, beyond a shred of doubt, that every graduate is ready to keep their crew safe.", 960, 890, 42, "amber", "b", "c", S.p(4), maxw=1600)

# 17 -------------------------------------------------------------
@scene("ONE FINAL QUESTION", [
 "And that leaves us with one final pretty provocative question to consider as we wrap up this explainer.",
 "If we successfully build this framework, if we create undeniable concrete evidence of a cadet's competence before they ever even set foot on a working vessel, how is that going to transform the future safety of our global maritime industry?",
 "Because ultimately, better, smarter assessment today absolutely means safer, more secure oceans tomorrow.",
 "Thanks for joining me for this explainer, and keep asking the tough questions."])
def s17(S):
    S.text("One final question", 960, 220, 70, "white", "b", "c", S.p(0))
    S.text("If we create undeniable evidence of a cadet's competence before they ever set foot on a working vessel — how will that transform the future safety of global shipping?", 960, 360, 52, "amber", "m", "c", S.p(1), maxw=1560, lh=1.3)
    S.rr(200, 640, 640, 140, 26, "card", "sky", 4, S.p(2)); S.text("Better, smarter assessment", 520, 715, 36, "sky", "b", "c", S.p(2)); S.text("today", 520, 755, 28, "white", "r", "c", S.p(2))
    S.arrow(860, 710, 1060, 710, "white", 8, S.p(2, .5, .35))
    S.rr(1080, 640, 640, 140, 26, "card", "green", 4, S.p(2, .55, .5)); S.text("Safer, more secure oceans", 1400, 715, 36, "green", "b", "c", S.p(2, .55, .5)); S.text("tomorrow", 1400, 755, 28, "white", "r", "c", S.p(2, .55, .5))
    S.text("Keep asking the tough questions.", 960, 930, 56, "teal", "b", "c", S.p(3))
