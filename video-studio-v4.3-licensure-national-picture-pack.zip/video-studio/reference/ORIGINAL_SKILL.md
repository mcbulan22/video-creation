---
name: scene-video-studio
description: Build scene-by-scene explainer videos, motion-graphics presentations and slide-style videos from a script, transcript or outline, directly in chat with no AI video generator. Produces one MP4 clip per scene, a full silent video the user can narrate or dub, a timed SRT script-cue file, an optional captioned read-along copy, and (via the pptx skill) an editable PowerPoint built from the same scene spec. Use this skill whenever the user asks for a video, explainer, motion graphics, animated slides, "video presentation", visuals for a NotebookLM/podcast-style transcript, a silent video to add their own voice-over, scene-by-scene or per-slide clips, or mentions Remotion, Claude Motion, or code-rendered video - even if they do not say "skill". Also use it when they want a PPT and a video of the same content.
---

# Scene Video Studio

Turn a script into a designed, animated video, scene by scene. Claude does not generate video; it writes
**scenes as code** (a function of time), renders frames with Skia, and stitches them with ffmpeg. Everything
runs inside this chat sandbox. The user records their own narration afterwards (or supplies audio), so the
deliverable is usually a **silent, script-timed video** plus cue sheets.

## What you deliver

| File | Purpose |
|---|---|
| `clips/scene_NN.mp4` (zipped) | One clip per scene so the user can reorder, replace or reuse a scene |
| `full_video_silent.mp4` | All scenes joined, 1080p, 24 fps, no audio |
| `script_cues.srt` | Every script line with start/end time: the dubbing cue sheet, also importable into editors |
| `full_video_with_captions.mp4` (optional, `--captions`) | Script burned in at the bottom for read-along recording |
| `timing.tsv` | Scene start times and durations |
| `.pptx` (optional) | Editable deck from the same scene spec, narration in speaker notes (see "Slides") |

## Pick the route first

- **This skill (default)**: the user is in chat, wants something now, 16:9, explainer/slide-style motion. Free apart from usage.
- **Deck only** (no video): use the pptx skill (or the Slides artifact type when the session offers it).
- **Premium motion graphics, vertical reels, long polished pieces, real-time preview**: tell the user these are better built in Claude Code on their own computer with Remotion's agent skills or Claude Motion Studio; read `references/other-routes.md` for what to say. Offer to write the scene plan and brief they can hand to Claude Code.

## Workflow

1. **Intake (keep it to what is missing).** Subject and audience; narration plan (user records later / has audio / none); target length; any brand colors or logos. If they uploaded a transcript, treat it as the narration script and do not rewrite it.
2. **Scene plan.** Split the script into scenes (one idea each, roughly 15-60 s spoken) and each scene into **beats** (3-8 short script chunks; a beat is the words spoken while one visual appears). Show a brief outline (scene title + what is on screen). Proceed unless the user wants to change it; for long decks, confirm the outline first because rework is expensive.
3. **Set up.** `sh scripts/setup_env.sh` (installs skia-python if missing). Read `references/scene-patterns.md`. Open `assets/example_scenes.py` for the structure; grep `assets/reference_explainer_scenes.py` for richer patterns (pyramid, staircase, roadmap grid, comparison tables, strike-through key idea).
4. **Write `scenes.py`** in a working folder: `from engine import *` (add `scripts/` to `sys.path`), set `DECK_TITLE`, then one `@scene(chapter, beats)` function per scene. Beat strings are the verbatim script; the visual for beat *k* is revealed with `S.p(k, dur, delay)`. Technical terms in the script that look mis-transcribed (names of methods or theorists) should be spelled correctly on screen and flagged to the user.
5. **QA before rendering (do not skip).** `python scripts/contact_sheet.py scenes.py --out qa --beats`, then view `qa/sheet_*.png` and the per-scene `*_beats.png`. Fix overlaps, clipped text, tofu boxes, and crowded cards. Stderr warnings about missing glyphs mean the font lacks a character. Re-run for changed scenes with `--only`.
6. **Render detached**, because one tool call is limited to about 300 s and background jobs started with plain `&` get killed when the call returns:
   `(setsid nohup python scripts/build_video.py scenes.py --out out --captions > out.log 2>&1 < /dev/null &)`
   Poll with `sleep 200; tail out.log` until `ALL DONE`. Budget about 1.2 minutes of wall-clock per minute of finished video on a single core. Use `--draft` (720p, fast) when the user wants to preview first. Re-running skips finished clips; delete a clip to re-render that scene; `--only 3-5` renders a subset.
7. **Sanity-check the output**: `ffprobe` duration and resolution, then pull 3-4 frames with `ffmpeg -ss T -frames:v 1` and view them.
8. **Deliver.** Zip the clips (`python -c "import shutil;shutil.make_archive('/mnt/user-data/outputs/scene_clips','zip','out/clips')"`), copy the full MP4, SRT and optional captioned MP4 to `/mnt/user-data/outputs/`, and present them. Then say briefly: duration, that timing is estimated from a reading pace (default about 147 wpm, `--wps` to change), and anything the user should verify.

## Timing and audio

Durations come from word counts, so they match a natural reading pace but not a specific voice. If the user later sends their recording (or NotebookLM audio), rebuild with `--audio their_file.mp3`: all beats are scaled so the video equals the audio length. This is a global scale, so tell them it may drift by a few seconds inside long scenes; for tighter sync, ask for the timestamps where each scene starts and adjust `LEAD`/beat text, or re-split scenes.

## Slides (PPTX from the same spec)

When the user wants a PPT, or "slides and a video", read `/mnt/skills/public/pptx/SKILL.md` first. Build one slide per scene: the scene's headline as title, the 3-6 key phrases that the scene reveals as slide content, and the scene's beats joined as **speaker notes**. Reuse the same palette (hex values in `references/scene-patterns.md`) so deck and video look like one product. Mention that the video is the animated version of the same scenes.

## Design rules that keep output looking professional

- One idea per beat; reveal in the order the narrator speaks. Never show a full slide of text at once.
- At 1080p keep body text at 26 px or larger, headlines 56-110 px, at most about 7 items per scene.
- Keep the bottom 150 px free if a captioned copy is wanted (footer text sits at y=1050).
- Use the palette tokens (`teal`, `amber`, `sky`, `green`, `red`, `card`, `edge`, `mute`) rather than raw hex; add a theme by editing `C` in `engine.py`.
- Meaning must not rely on color alone (pair green/red with check/cross icons or words).
- Poppins has no arrow glyph: draw arrows with `S.arrow()`, ticks with `S.check()`, crosses with `S.cross()`.
- Only 16:9 (1920x1080) layouts are supported out of the box. Vertical (9:16) needs scenes written with coordinates relative to `W`/`H`; recommend Claude Code with Remotion for social reels.
- Images the user provides (logos, screenshots, photos) can be placed with `S.image(path, x, y, w, h, p)`. No stock footage or web images are available here.
- No narration audio is generated here. If the user wants a voice track, they can record it from `script_cues.srt` / the captioned copy, or use a text-to-speech service of their choice, then come back with `--audio`.

## Honesty checklist for the final message

State the real duration and the estimated-timing caveat; list spelling/terminology you corrected or were unsure about; say which outputs were not made (e.g. no audio); keep the message short and refer to the files by name.

## Files

- `scripts/engine.py`: primitives (`rr`, `text`, `arrow`, `check`, `cross`, `circ`, `line`, `pill`, `ship`, `waves`, `image`), scene registry, timeline, frame renderer
- `scripts/build_video.py`: clips + full video + SRT (+ captions, audio scaling, draft mode)
- `scripts/contact_sheet.py`: storyboard/QA sheets without rendering video
- `scripts/setup_env.sh`: dependency check
- `assets/example_scenes.py`: smallest working deck; `assets/reference_explainer_scenes.py`: 17-scene pattern library
- `references/scene-patterns.md`: API cheat sheet, layout grid, palette, recipes
- `references/pitfalls.md`: environment limits and bugs already hit
- `references/other-routes.md`: Remotion / Claude Motion Studio / other options, what to tell the user
