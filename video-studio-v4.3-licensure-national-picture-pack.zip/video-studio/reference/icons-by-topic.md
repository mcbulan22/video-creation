# Icons by topic (Lucide 1.61, all verified to exist in this pack)

Use with `S.icon(name, cx, cy, size, color, p, bg="circle")`. Lucide renames icons between versions, so only use names from this list or from `python scripts/find_icon.py <word>`.
See them drawn: `sh make.sh --scenes examples/icon_gallery.py --draft`.

**Maritime**: ship, ship-wheel, ship-cargo, anchor, sailboat, life-buoy, lighthouse, compass, navigation, map, map-pin, container, fuel, gauge, thermometer, wind, cloud-lightning, radio, binoculars, bridge, fish, droplets, siren, route

**Education**: graduation-cap, book-open, book-check, school, library, notebook-pen, pencil, clipboard-check, clipboard-list, file-check, award, medal, trophy, presentation, brain, lightbulb, target, users, user-check, languages, calculator, microscope, flask-conical, atom

**Safety**: shield-check, shield-alert, hard-hat, fire-extinguisher, siren, triangle-alert, octagon-alert, lock, key-round, eye, bell-ring, heart-pulse, life-buoy, badge-check, circle-check, ban, scan-face, bandage, lighthouse, alarm-smoke, flashlight, shield-half

**Process**: workflow, git-branch, list-checks, route, repeat, refresh-cw, arrow-right, move-right, play, circle-play, hourglass, timer, calendar-check, flag, rocket, settings, cog, wrench, hammer, puzzle, layers, blocks

**People**: user, users, user-round, user-check, user-plus, contact, handshake, message-circle, messages-square, mic, megaphone, thumbs-up, hand-helping, heart-handshake, face-slightly-smiling

**Data**: chart-bar, chart-line, chart-pie, chart-column, trending-up, trending-down, activity, table, database, file-spreadsheet, calculator, percent, sigma, gauge, scale, search, binary, list-filter

**Status**: check, circle-check, circle-x, circle-alert, info, clock, loader, bell, star, flag, bookmark, thumbs-up, thumbs-down, badge-question-mark

**Documents**: file-text, file-check, folder-open, files, clipboard, scroll-text, stamp, file-badge, archive, paperclip, printer, mail, send, book-bookmark

