# Motion

How things move is set by each theme, not by the scenes. Your `scenes.py` only says WHEN something appears (the beat);
the theme decides HOW it arrives. This guide is adapted from the open-source LottieFiles "motion-design" skill (MIT),
translated for narrated video (video pacing is about twice as slow as app animation, because viewers are watching, not clicking).

## v4 additions
Two new personalities: **aurora** (fluid-modern: expo-out with a 5% settle, words rise out of masks, glass cards) and **editorial**
(snappy launch, firm stop, hard-shadow cards that stamp down). The Motion Kit (KIT.md) adds beat-driven effects on top: kinetic text, morphs,
drawing icons and charts. They follow the same rules below: spread them over beats, hero first, never everything at once.

## The six personalities (v3; aurora and editorial are described above)
| Theme | Personality | Signature curve | Entrance | Extras |
|---|---|---|---|---|
| clean | Corporate: clean and decisive | Material "standard" bezier (0.2, 0, 0, 1), no bounce | 0.48 s | background drifts against the slide; shadow arrives after the card |
| ocean | Fluid: floaty (original, unchanged) | small springy settle (6%) | 0.60 s | original look kept byte-for-byte |
| techno | Energetic, machine-precise | fast exponential snap, no bounce on purpose | 0.36 s | everything arrives from the left; typewriter text; borders breathe |
| classroom | Paper: hand-placed | small settle (4.5%) | 0.60 s | slight arc, from the left; chalk lines "boil" like real chalk |
| formal | Premium: slow and elegant | bezier (0.4, 0, 0.2, 1), zero overshoot | 0.78 s | gentle 10 px arc; text lands after the card; soft shadow after the card |
| playful | Playful: springy | damped spring, about 18% overshoot then a small dip | 0.51 s | curved 26 px arcs; wiggling underline; confetti on scenes 1, 5, 9, 13 |

## The rules every theme follows
1. **One signature curve per theme.** Entrances decelerate (fast start, soft landing). Never linear for movement.
2. **Exits are shorter than entrances** (30 to 50% shorter): people care about what appears, not what leaves.
3. **Cascades stay under 0.5 s in total.** Scenes ask for a stagger (for example 0.25 s per row); the theme scales it
   (`stagger_scale`) so four rows never take longer than half a second to arrive.
4. **Follow-through.** Text lands a beat after its card (`text_lag`), shadows after the shape. Nothing arrives all at once.
5. **Curved, consistent paths.** Elements enter from one consistent side (`enter_dx`) and bulge slightly (`arc`) instead of a straight line.
6. **Three layers.** Primary = what enters; secondary = shadows, text lag, underlines; ambient = living background
   (drifting light, particles, chalk boil, breathing borders). Flat animation is missing a layer.
7. **Counter-motion.** The background drifts a little against the slide (`parallax`) for depth.

## Check it (no video render needed)
    sh motion_check.sh                 plots every theme's curve and checks the rules above on YOUR deck
                                       -> output/motion/motion_curves.png and motion_report.txt
    sh motion_check.sh 3 1             also writes a filmstrip of scene 3, beat 1 entering, for every theme
                                       -> output/motion/strip_scene03_beat1.png  (frames 0.1 s apart)
Each line in the report is PASS or WARN. Ocean shows two WARNs on purpose: its motion is kept exactly as you first rendered it.

## Tune a theme
Open `themes/<name>.py`. The motion block near the top has everything:

    personality = "..."          label shown in the report
    dur_scale   = 0.8            entrance speed (smaller = faster)
    stagger_scale = 0.35         how tight the cascade is
    fade_out_scale = 0.7         exit length vs entrance
    text_lag    = 1.25           >1 = text lands later than its card
    enter_dx    = -70.0          px: slide in from the left (negative) or right
    arc         = 10.0           px: sideways bulge halfway through
    parallax    = 0.25           background counter-drift (0 to 0.4)
    def ease(self, x): ...       the signature curve. Library: E.bezier(a,b,c,d), E.ease_out_cubic, E.ease_out_quint,
                                 E.ease_out_expo, E.ease_in_out_sine, E.ease_spring(damping, frequency), E.ease_back(x, overshoot)
Then run `sh motion_check.sh` and `sh make.sh --theme <name> --draft`.

## Rules for writing scenes (so every theme looks good)
- Do not hand-code delays longer than about 0.3 s per item; the theme tightens them anyway.
- Give every important reveal a position change, not opacity alone (the engine's slide handles this: keep the default `dy`).
- Put the hero element (title, the one key line) on the first beat of its scene and supporting items on later beats.
- Keep to about a third of the elements moving at once: spread items over beats instead of showing everything on beat 0.

On a Windows PC use `motion_check.bat` instead of `sh motion_check.sh` (see COMPUTERS.md).
