# Freeform mode (v4.1): effects written as code, for one video

Themes are shortcuts. In freeform mode Claude writes custom animation code for THIS video (its own look, backgrounds, letter
animations, drawings, cameras, transitions) on top of the same engine. Same files, same commands, free, runs on Mac and PC.
Try the example first:   `sh make.sh --scenes examples/freeform_example.py --draft`   (PC: `make.bat --scenes examples/freeform_example.py --draft`)

## How to ask Claude
"Use freeform mode. Material: ... Mood: ... (colours, references, anything you like). Length: about 3 minutes."
Claude returns a new `inbox/scenes.py` (and sometimes `inbox/fonts/`). Replace the file, run the usual command.

## The five ways to customise (all in scenes.py)
1. **A look for this deck**: `THEME = "aurora"` (base) then `set_look(palette=..., fonts=..., background=fn, fx=fn, hero_bg=fn, transition=fn, draw_card=fn, chrome=fn, ...)`.
   Overrides sit on top of whichever look is active. `THEME = "..."` in the file is honoured when you do not type `--theme`.
2. **Per-scene hooks**: `@scene("TITLE", [...], bg=fn, fg=fn, trans=fn, live=True)`
   - `bg(c, t, T)` own background effect for this scene (t = scene seconds, T = video seconds)
   - `fg(c, t, bs)` overlay above the content (vignette, scanlines, light leaks)
   - `trans(c, t, sc)` this scene's own scene-change flourish
   - `live=True` keeps time-based effects moving even with `--fx off`
3. **The `fx` toolbox** (in every scene file): `fx.mesh_gradient`, `flowfield`, `particles`, `stars`, `network`, `rings`, `sunburst`, `perspective_grid`,
   `waveform`, `bokeh`, `halftone`, `light_streaks`, `vignette`, `scanlines`, `camera`, `keyframes`, `sequence`, `ease`, `noise2`, `fbm`, `mix_color`, `draw_svg`.
4. **Letters and drawings**: `S.text_anim(text, ..., fn="wave|spin|scatter|bounce|flip|glitch|typewriter" or your own fn(i, n, q, ch, t))`
   and `S.svg(path_data, x, y, scale, p, color, sw, fill=, glow=)` which draws any SVG path line by line.
5. **Raw Skia**: `S.c` is the canvas (`c.drawPath`, gradients, blends, clips). Anything Skia can draw is allowed.

Custom fonts: put `MyFont-Bold.ttf` in `inbox/fonts/` and use `fonts=dict(b="MyFont-Bold")` in `set_look`. Only use fonts you are licensed to use (OFL / free fonts).

6. **Sound cues per scene**: `@scene(..., sfx="off")` or `sfx=[(beat, seconds_after, "pop"|"whoosh"|"riser"|"chime"|"impact"|"typing"|"shimmer"|"swell", gain)]` (see SOUND_AND_QA.md).

7. **Better easing and cameras (v4.3)**: `S.p(beat, dur, delay, ease="spring_bouncy")` gives any element an exact-physics spring (`spring_gentle`, `spring_snappy`, `spring_bouncy`, `spring_wobbly`, `spring_stiff`, `spring_slow`; or your own `fx.spring_ease((stiffness, damping, mass))`).
   `fx.cam(t, [(time, (zoom, cx, cy[, rot]), "easing"), ...], shake=0)` returns camera arguments that zoom evenly in log space and pan at constant on-screen speed: `with fx.camera(S.c, *fx.cam(S.t, [...])):`.

## Rules (these keep renders correct and fast)
- **Pure functions of time.** Never keep state between frames (no counters, no lists that grow). Frames render in parallel and out of order; an effect must look the same whichever frame is drawn first. All `fx` tools already obey this.
- **Roles, not hex**, for anything that should follow the palette (`"teal"`, `"white"`, `"edge"` ...). Raw `"#RRGGBB"` is fine for a one-off.
- **Budget**: particles under 400, flow lines under 160, network nodes under 60, soft glows only on a few items. If a draft takes more than about 3x the video length to render, cut effects.
- **One hero effect per scene.** A moving background plus a moving foreground plus animated text all at once reads as noise. Keep body text 26 px or larger and make sure the background stays quiet behind it.
- **Check cheaply first**: `python3 scripts/contact_sheet.py inbox/scenes.py --out output/qa` (a picture of each scene), then `--draft`, then the final quality.
- Time-based effects need `live=True` (scene hooks) to keep moving under `--fx off`.

## Recipes
| Want | Write |
|---|---|
| Moving colour behind everything | `set_look(fx=lambda c, T: fx.mesh_gradient(c, T, ("teal","sky","amber")))` |
| Embers rising on the title scene | `bg=lambda c,t,T: fx.particles(c, T, region=(0,700,1920,1080), angle=(-1.8,-1.3), colors=("teal","amber"), glow=1)` |
| Slow camera push over a scene | `with fx.camera(S.c, *fx.keyframes(S.t, [(0,(1.0,960,540)), (7,(1.1,1000,540),"in_out_sine")])):` |
| Letters that fall in alternately | `S.text_anim(txt, x, y, 64, "white", "b", "c", p, fn=lambda i,n,q,ch,t: dict(dy=-(1-fx.ease("out_back",q))*300, a=fx.clamp(q*4)))` |
| Your own diagram drawn on | `S.svg("M0 0 L100 0 L100 60 Z", x, y, 1.5, p, "teal", 6, fill="teal")` |
| Signal / data feel | `fx.network(...)`, `fx.waveform(...)`, `fx.perspective_grid(...)` |
| Celebration | `fx.particles(S.c, S.t, origin=(960,470), shape="rect", gravity=600, start=S.bs[1], end=S.bs[1]+0.2)` |

## Rendering somewhere other than your computer (free, untested here)
The pack is plain Python (skia-python, pillow) plus ffmpeg. Google Colab or GitHub Codespaces can run it: install `skia-python pillow`, make sure `ffmpeg` exists,
use `--engine edge` or your own recordings for voice (the Mac `say` voice is not there). Free tiers have time limits, so render draft quality first.
