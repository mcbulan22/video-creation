Discover Education 

Derouich _Discover Education_ (2025) 4:486 https://doi.org/10.1007/s44217-025-00915-7 

## **Open Access** 

## **RESEARCH** 



# Ensuring outcome-based curriculum coherence through systematic CLO–PLO alignment and feedback loops 

Moncef Derouich<sup>1*</sup> 

*Correspondence: Moncef Derouich derouicmoncef@gmail.com; aldarwish@kau.edu.sa 

1Department of Astronomy and Space Science, Faculty of Science, King Abdulaziz University, PO Box 80203, 21589 Jeddah, Saudi Arabia 

### **Abstract** 

This study proposes a quantitative framework to enhance curriculum coherence through the systematic alignment of Course Learning Outcomes (CLOs) and Program Learning Outcomes (PLOs), contributing directly to the continuous improvement of outcome-based education. Grounded in widely recognized accreditation standards such as ABET and NCAAA, the model introduces mathematical tools that map exercises, assessment questions, teaching units (TUs), and student assessment components (SACs) to CLOs and PLOs. This dual-layer approach—combining microlevel analysis of assessment elements with macro-level curriculum evaluation— enables detailed tracking of learning outcomes and helps identify misalignments between instructional delivery, assessment strategies, and program objectives. The framework incorporates alignment matrices, weighted relationships, and practical indicators to quantify coherence and evaluate the overall performance of a course or program. Application of this model reveals gaps in outcome coverage and underscores the importance of realignment, especially in cases where specific PLOs are underrepresented or CLOs are not adequately supported by assessments. The proposed model is practical, adaptable, and scalable, making it suitable for academic programs in science, technology, engineering, and mathematics (STEM). Its systematic structure supports institutions in implementing evidence-based curriculum enhancements and provides a reliable mechanism for aligning teaching practices with desired learning outcomes. Ultimately, this framework offers a valuable tool for closing the feedback loop between instructional design, assessment execution, and learning outcomes, thereby promoting greater transparency, accountability, and educational effectiveness. Institutions that adopt this model can expect to strengthen their quality assurance processes and ensure that students graduate with the competencies required by academic standards and professional expectations. 

**Keywords** Curriculum alignment, Learning outcomes, Assessment design, Higher education, Quality assurance 

> © The Author(s) 2025. **Open Access** This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence to share adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit  h t t p : / / c r e a t i v e c o m m o n s . o r g / l i c e n s e s / b y - n c - n d / 4 . 0 /. 

Page 2 of 20 

Derouich _Discover Education_ (2025) 4:486 

### **1 Introduction** 

Constructive alignment is a cornerstone of curriculum design, linking teaching, learning, and assessment within a coherent framework [1]. In professional fields such as engineering, effective alignment ensures that instructional activities genuinely support intended outcomes [2], and diversified, outcomes-focused assessment strengthens this connection [3]. Despite this consensus, implementation remains difficult. Differences in how instructors teach and how students prefer to learn—e.g., an emphasis on abstract theory when learners benefit from concrete, applied problem-solving—can depress engagement [4]. More critically, assessment practices often emphasize tasks that are straightforward to grade—for example, multiple-choice items, short factual answers, or single-solution exercises—because they are efficient and consistent, especially at scale,yet these formats chiefly capture lower-order skills (recall, routine procedures and can neglect higher-order outcomes such as analysis, synthesis, and authentic problem-solving that programs explicitly value [5]. Institutions also face persistent challenges embedding Outcome-Based Education (OBE) within accreditation constraints [6]. Foundational curriculum models have long emphasized that aims, instruction, and assessment must operate in concert for learning to be effective [7, 8]. 

Recent work spans faculty evaluation, sector-level improvement, instrument design, institutional OBE indices, and accreditation-driven attainment procedures [9–12]. Relative to these strands, the present study introduces a quantitative, compositional alignment framework with two defining features. First, at the micro level, we specify a weighted mapping from assessment items (questions/exercises) → Course Learning Outcomes (CLOs) → Program Learning Outcomes (PLOs), yielding closed-form expressions that make each item’s contribution explicit and auditable [3, 13]. Second, at the macro level, we quantify intended versus delivered emphasis in Teaching Units (TUs) and Student Assessment Components (SACs) via Intended Teaching Units (ITU) and Instructional Support and Assessment Coverage (ISAC), with acceptance bands to separate normal variation from patterns warranting action [2, 14]. We then relate these indicators to student-performance evidence to close the feedback loop and guide targeted adjustments [5, 15]. The formulation also clarifies program distribution: a course may, by design, contribute minimally to selected PLOs if coverage is secured elsewhere [14, 16, 17]. 

Positioning and distinctiveness relative to existing frameworks. The proposed framework differs from prior contributions in the unit of analysis and the methodological design. Agrawal and Sharma [9] prototype a system for faculty performance evaluation,our focus is curriculum-level alignment across courses and programs. Goba et al. (2024) synthesize quality-improvement strategies at a policy/sector level; we operate at design/execution level with quantitative CLO–PLO mapping. Bernold and Díaz-Michell (2022) offer a multi-dimensional assessment instrument centered on constructivist interaction; our model is compositional, tracing item-to-PLO contributions and TU/SAC aggregation. Lu and Hao [11] develop institutional evaluation indices using multi-criteria methods,in contrast, we analyze curricular coherence through explicit mappings and tolerance bands. Beena and Suresh [12] present accreditation-aligned CO–PO/PSO correlation and attainment averages,we move beyond correlations to an 

Page 3 of 20 

Derouich _Discover Education_ (2025) 4:486 

auditable, equation-based mapping that (i) decomposes item-level evidence to PLOs, (ii) integrates TU/SAC signals via metrics that evaluate the alignment of TU and SAC, and (iii) generates actionable flags when acceptance bands are exceeded. In short, whereas prior work emphasizes faculty, policy, instrument, or institutional index perspectives, our contribution is a generalizable, quantitative curriculum-alignment framework that links assessment items and teaching units to program outcomes, revealing precise alignment gaps and enabling principled corrections. 

Astronomy curricula are inherently interdisciplinary, integrating core areas of physics—mechanics, electromagnetism, and quantum or statistical physics—with a strong mathematical foundation in calculus, linear algebra, and numerical methods. These are complemented by observational and experimental components, including laboratory work, instrumentation, and data analysis. The proposed framework is well suited to managing and evaluating such complex structures. 

By enabling transparent mapping of item-level evidence from physics- and mathintensive courses to astronomy-specific CLOs and PLOs, the framework supports a rigorous audit of curricular alignment. It helps evaluate the balance between theoretical instruction and observational or assessment-based components, ensuring that no essential outcomes are overlooked. Importantly, it also captures—by design—instances where certain astronomy PLOs are not addressed in specific courses because they are intentionally covered in companion laboratory, methods, or capstone experiences. This structured visibility allows departments to demonstrate a coherent progression from foundational skills to astronomy-specific competencies, reducing ambiguity and supporting program-level coherence. 

The aim of this work is to evaluate whether the proposed framework ensures comprehensive coverage between CLOs and PLOs while identifying actionable misalignments. These misalignments are quantified through suitable parameters, and defined acceptance bands, with the overarching goal of strengthening continuous improvement in curriculum alignment and delivery. 

The paper is organized into five sections. Section 2 introduces the foundational approach based on the alignment of exercises, assessment questions, CLOs, and PLOs, including a worked example and the combined expression from questions to PLOs. Section 3 develops a broader audit using TUs, SACs, indicators that measure the alignment of TUs and SACs, and acceptance bands. Section 4 presents key observations and recommendations (e.g., uncovered PLOs, overlap, focused mapping). Section 5 details closing the loop through re-alignment of TUs and SACs with CLOs and PLOs, embedding mechanisms for institutionalizing continuous improvement. Section VI concludes. 

### **2 Approach based on alignment of exercises, questions, CLOs, and PLOs** 

#### **2.1 Alignment of PLOs with CLOs** 

The alignment of PLOs with CLOs is designed to ensure students develop comprehensive knowledge, skills, and competencies throughout their academic journey. This alignment integrates theoretical foundations, practical applications, and interdisciplinary problem-solving strategies, all tailored to meet the objectives of the program. The process includes the mapping of PLOs to specific courses and assessing their contribution 

Page 4 of 20 

Derouich _Discover Education_ (2025) 4:486 

to student achievement, an approach widely used in accreditation-driven case studies (e.g. [12]). 

The alignment of PLOs with CLOs is performed according to the following considerations: 

- Structured Mapping 

   - Each PLO is mapped to multiple courses, ensuring comprehensive coverage across different stages of the curriculum. 

   - For example, foundational courses address introductory-level knowledge, while advanced courses tackle specialized skills and applications. Prior studies confirm that such structured matrices are essential for curriculum quality audits (e.g. [11]). 

- Iterative Assessment 

   - PLO attainment is evaluated through both direct (e.g., exams, assignments) and indirect methods (e.g., surveys, reflective feedback). 

   - Faculty analyse course-level data to identify gaps and recommend adjustments in course content or assessment strategies. Faculty-centered performance systems have been proposed as one mechanism to improve this loop (e.g. [9]), though our focus here is curriculum alignment rather than instructor evaluation. 

- Continuous Improvement 

   - The alignment meetings ensure coherence by systematically reviewing CLO–PLO matrices, comparing intended outcomes with assessment data, and documenting any gaps. This structured process guarantees that adjustments are based on evidence rather than informal impressions. At the institutional and sector level, quality-improvement strategies (Goba et al. 2024) and multi-dimensional assessment instruments (Bernold and Díaz-Michell 2022) have been proposed. Our contribution complements these by working at the compositional level— examining how individual questions, exercises, and teaching units aggregate into _CLO_ s and _PLO_ s, and by developing indicators that quantify their alignment. 

   - The role of faculty is to analyze course-level results and recommend revisions to _CLO_ s, while advisory board members contribute external and professional perspectives to validate relevance. Together, these contributions ensure that alignment is both academically rigorous and responsive to industry expectations. 

While the general framework provides a conceptual foundation for aligning _PLO_ s with _CLO_ s, a more precise and quantitative approach is necessary to ensure that the alignment is measurable, consistent, and effective. To achieve this, we introduce a mathematical model that formalizes the relationships between individual assessment components (e.g., exercises, questions) and the broader learning outcomes ( _CLO_ s and _PLO_ s). Relevant mapping and quantitative outcome assessment work has been done. For example, Zayani et al. [18] introduced an automated framework for assessing _CLO_ -to- _PLO_ relationships using weighted aggregation across course sections. Mendoza et al. [19] analyze 

Page 5 of 20 

Derouich _Discover Education_ (2025) 4:486 

curriculum mapping at macro, meso, and micro levels. Mustaffa et al. [20] provide quantitative measurement of _CLO_ achievement in large classes using multiple metrics. These works inform but do not decompose down to the level of individual questions or teaching units in the way our weighted mapping model does. 

#### **2.2 Equations linking exercises, questions, CLOs, and PLOs** 

#### **_2.2.1 Definitions_** 

Exercises here designate problem-solving tasks, assignments, projects, lab work, presentations, and exams, each designed to evaluate students' understanding and skills. This section outlines the mathematical relationships between question-level outcomes ( _Qli_ , the _i_ -th question in the _l_ -th exercise), _CLOs_ ( _CLO_ 1, _CLO_ 2, _CLO_ 3, …), and _PLO_ s ( _PLO_ 1, _PLO_ 2, _PLO_ 3, …). These relationships are modeled through weighted contributions. The Exercises- _CLO_ Mapping Matrix aligns structured learning activities with specific _CLOs_ to ensure comprehensive assessment. Some exercises, like Exercise 2, may be composed of multiple questions ( _Q_ 21, _Q_ 22, _Q_ 23, _Q_ 24, _Q_ 25, _Q_ 26), each targeting different _CLOs_ . For example, _Q_ 22 assesses _CLO_ 3, while _Q_ 11 maps to _CLO_ 1, and _Q_ 22, _Q_ 23, _Q_ 24, _Q_ 25, _Q_ 26 serve to evaluate _CLO_ 3. This structured mapping ensures that exercises contribute effectively to measuring and achieving the intended learning outcomes. 

#### **_2.2.2 Mathematical approach for mapping Questions to CLOs_** 

Each question _Qli_ in the exercises is designed to assess specific _CLOs_ , as defined by the course objectives. For example, in Table 1, Exercise 1 evaluates _CLO_ 1 and _CLO_ 2. Exercise 2 evaluates: 

- _CLO_ 1 (through _Q_ 21), 

- _CLO_ 3 (through _Q_ 22 _, Q_ 23 _, Q_ 24 _, Q_ 25 _, Q_ 26), 

- _CLO_ 5 (through _Q_ 26) 

The mapping can be described using weighted contributions: 



where: 

> _CLOj_ : The _j_ -th Course Learning Outcome (CLO). 

> _Qli_ : The _i_ -th question in the _l_ -th exercise. 

_wlij_ : a weight factor that represents the contribution of question _Qli_ to _CLOj_ . 

- _m_ : Total number of exercises. 

- _n_ : Total number of questions per exercise. 

#### **_2.2.3 Mapping CLOs to PLOs_** 

Following standard curriculum-mapping practice, we assume each PLO is supported by multiple CLOs with unequal emphasis; that emphasis is represented by non-negative 

**Table 1** Exercises-CLO mapping matrix 

|**Exercise**|**Questions**|**Mapped CLOs**|
|---|---|---|
|Exercise 1|_Q_11,_Q_12,_Q_13|_CLO_1(_Q_11),_CLO_2(_Q_12,_Q_13)|
|Exercise 2|_Q_21, _Q_22, _Q_23, _Q_24, _Q_25,_Q_26|_CLO_1(_Q_21), _CLO_3 (_Q_22, _Q_23, _Q_24, _Q_25, _Q_26), _CLO_5 (_Q_26)|



Page 6 of 20 

Derouich _Discover Education_ (2025) 4:486 

weights that are normalized to sum to 1 across the contributing CLOs [7, 11, 12, 14, 16]. Each _CLO_ contributes to one or more _PLOs_ according to this equation: 



where: 

- _PLOk_ : the _k_ -th Program Learning Outcome. 

- _CLOg_ : the _g_ -th Course Learning Outcome. 

- _vgk_ : weight of _CLOg_ contributing to _PLOk_ 

- _p_ : the total number of _CLOs_ . 

#### **_2.2.4 Combined relationship: questions to PLOs_** 

By substituting the equation for _CLOs_ into the equation for _PLO_ s, the relationship between questions and _PLO_ s can be expressed as: 



- Each question _Qli_ contributes to _CLOg_ based on weights _wlig_ . 

- Each _CLOg_ contributes to _PLOk_ based on weights _vgk_ . 

- C ombined weights _vgkwlig_ determine the relative contribution of each question _Qli_ to each _PLOk_ . For example, if _vgkwlig_ =0, it means _Qli_ does not contribute to PLOk. The _vgkwlig_ weights aggregate the contribution of each question to the PLOs, allowing a quantitative measure of how assessments impact program objectives. 

As an example of application of the Mathematical formalism, using Table 1, througth Equation (1) one can identify how individual questions contribute to specific _CLO_ s 

_CLO_ 1 = _w_ 111 _Q_ 11 + _w_ 211 _Q_ 21 _CLO_ 1 = _w_ 111 _Q_ 11 + _w_ 211 _Q_ 21 _CLO_ 2 = _w_ 122 _Q_ 12 + _w_ 132 _Q_ 13 _CLO_ 3 = _w_ 223 _Q_ 22 + _w_ 233 _Q_ 23 + _w_ 243 _Q_ 24 + _w_ 253 _Q_ 25 + _w_ 263 _Q_ 26 _CLO_ 4 = 0 _CLO_ 5 = _w_ 265 _Q_ 26 _CLO_ 6 = 0 

Using Table 2 and Eq. (2), the combined relationships relating questions to PLOs equations can be written numerically as: 

**Table 2** CLO-PLO mapping matrix 

**_P LO_ 1** **_P LO_ 2** **_P LO_ 3** **_P LO_ 4** **_P LO_ 5** **_P LO_ 6** _CLO_ 1 _CLO_ 2 _CLO_ 6 _CLO_ 2 _CLO_ 4 _CLO_ 5 

Page 7 of 20 

Derouich _Discover Education_ (2025) 4:486 

**Table 3** Exercises-CLO mapping matrix with weights _wlij_ 

|**_Qli_/****_CLOj_**|**_CLO1_**|**_CLO2_**|**_CLO3_**|**_CLO4_**|**_CLO5_**|**_CLO6_**|
|---|---|---|---|---|---|---|
|_Q_11|0.5|–|–|–|–|–|
|_Q_12|–|0.3|–|–|–|–|
|_Q_13|–|0.7|–|–|–|–|
|_Q_21|0.5|–|–|–|–|–|
|_Q_22|–|–|0.2|–|–|–|
|_Q_23|–|–|0.2|–|–|–|
|_Q_24|–|–|0.2|–|–|–|
|_Q_25|–|–|0.2|–|–|–|
|_Q_26|–|–|0.2|–|0.8|–|



**Table 4** CLO-PLO mapping matrix with weights _vgk_ 

|**_CLOg_/****_P LOk_**|**_PLO1_**|**_PLO2_**|**_PLO3_**|**_PLO4_**|**_PLO5_**|**_PLO6_**|
|---|---|---|---|---|---|---|
|_CLO1_|0.4|–|–|–|–|–|
|_CLO2_|–|0.6|–|–|–|–|
|_CLO3_|0.4|–|–|–|–|–|
|_CLO4_|–|0.4|–|–|–|–|
|_CLO5_|0.2|–|–|–|–|–|
|_CLO6_|–|–|–|–|1.0|–|



_PLO_ 1 = _v_ 11 _CLO_ 1 + _v_ 31 _CLO_ 3 + _v_ 51 _CLO_ 5 = _v_ 11 _w_ 111 _Q_ 11 + _v_ 11 _w_ 211 _Q_ 21 + _v_ 31 _w_ 223 _Q_ 22 + _v_ 31 _w_ 233 _Q_ 23 + _v_ 31 _w_ 243 _Q_ 24 + _v_ 31 _w_ 253 _Q_ 25 + _v_ 31 _w_ 263 _Q_ 26 + _v_ 51 _w_ 265 _Q_ 26 _PLO_ 2 = _v_ 22 _CLO_ 2 + _v_ 42 _CLO_ 4 = _v_ 22 _w_ 122 _Q_ 12 + _v_ 22 _w_ 132 _Q_ 13 _PLO_ 3 = 0 _PLO_ 4 = 0 _PLO_ 5 = _v_ 65 _LO_ 6 = 0 _PLO_ 6 = 0 

In concrete terms, by design, the teacher can propose an exam where the questions are related to the _CLO_ s by matrix of Table 3. Thus: 

_CLO_ 1 = _w_ 111 _Q_ 11 + _w_ 211 _Q_ 21 = 0 _._ 5 _Q_ 11 + 0 _._ 5 _Q_ 21 _CLO_ 2 = 0 _._ 3 _Q_ 12 + 0 _._ 7 _Q_ 13 _CLO_ 3 = 0 _._ 2 _Q_ 22 + 0 _._ 2 _Q_ 23 + 0 _._ 2 _Q_ 24 + 0 _._ 2 _Q_ 25 + 0 _._ 2 _Q_ 26 _CLO_ 4 = 0 _CLO_ 5 = 0 _._ 8 _Q_ 26 _CLO_ 6 = 0 

Therefore, using the CLO-PLO mapping matrix shown in Table 4, we obtain: 

_PLO_ 1 = 0 _._ 4 _CLO_ 1 + 0 _._ 4 _CLO_ 3 + 0 _._ 2 _CLO_ 5 _PLO_ 2 = 0 _._ 6 _CLO_ 2 + 0 _._ 4 _CLO_ 4 = 0 _._ 6 _CLO_ 2 since _CLO_ 4 = 0 (see above) _PLO_ 3 = 0 _PLO_ 4 = 0 _PLO_ 5 = _CLO_ 6 _PLO_ 6 = 0 

Thus, one can determine the relative contribution of each question _Qli_ to each _PLOk_ by substituting the _CLO_ s with their expressions in terms of the _Qli_ , following the principle of constructive alignment (e.g. Biggs 1996; [7]). _PLO_ 3, _PLO_ 4, and _PLO_ 6 evaluate to 

Page 8 of 20 

Derouich _Discover Education_ (2025) 4:486 

zero because no _CLO_ in this course maps to them. A zero at the course level indicates that the _PLO_ is outside the intended scope of this course, not that it is neglected by the program. Even if this course doesn’t address certain _PLO_ s, the program as a whole still does—because other courses cover them. 

#### **2.3 Observations and recommendations** 

#### **_2.3.1 Observations_** 

### (a) Gaps in alignment 

- _PLO_ 3, _PLO_ 4, and _PLO_ 6 are not mapped to any CLO, which could mean certain program objectives are not addressed through the course design **(e.g.** [7] **).** 

- This leaves room for improvement to ensure comprehensive curriculum coverage. 

### (b) Overlapping CLOs for PLO1 

   - _PLO_ 1 is mapped to three _CLO_ s ( _CLO1, CLO2, CLO5_ ), suggesting a strong emphasis on the outcomes tied to this program-level objective. 

   - Consider redistributing _CLO_ s to reduce redundancy and focus on addressing gaps. 

- (c) Focused Mapping 

   - _PLO5_ is mapped to only one _CLO_ ( _CLO_ 6), which may indicate targeted coverage but could also mean insufficient breadth for this outcome. Note that _CLO_ 6 is not covered by any exercise ( _PLO_ 6 = 0) (e.g. Biggs 1996). 

#### **_2.3.2 Recommendations_** 

### (a) **Address Gaps** 

- Some courses include a _CLO-PLO_ mapping matrix that may not align with certain _PLO_ s. For instance, as shown in Table 1, one course does not address _PLO_ 3, _PLO_ 4, and _PLO_ 6. In these cases, it is necessary for other courses in the study plan to cover the missing _PLO_ s [7] (NCAAA 2023). 

- The study plan (i.e. the curriculum) should be balanced to ensure that all _PLO_ s are achieved and that courses complement one another. Therefore, it is essential to evaluate course objectives to confirm that every program outcome is adequately addressed. 

### (b) **Curriculum Review** 

- Perform a detailed review of the curriculum to identify opportunities for adding or refining CLOs to ensure alignment with the full set of PLOs (Biggs 1996) [7]. 

### **3 More general approach** 

#### **3.1 Approach adequacy** 

The Exercises-Questions- _CLO_ s- _PLO_ s approach presented in the previous section is more suited for assessment design than for curriculum design. It focuses on ensuring that individual questions align with learning outcomes, providing micro-level insights 

Page 9 of 20 

Derouich _Discover Education_ (2025) 4:486 

into how specific exercises and questions contribute to _CLO_ s and _PLO_ s [7, 21]. While this granularity is valuable for detailed analysis, it may overlook the broader curriculum goals and the holistic impact of teaching and assessment methods on student learning (Biggs 1996) [22]. By concentrating on specific exercises and questions, this approach risks missing the bigger picture of how teaching and assessment strategies collectively contribute to achieving learning outcomes (Biggs 1996) [23]. 

To address this limitation, a more comprehensive approach can be employed to infer CLO and PLO attainment rates by incorporating both delivered TUs and SACs into the evaluation process. This approach links TUs and SACs to CLOs and PLOs, providing a more holistic view of curriculum alignment and effectiveness [7, 22, 24] (NCAAA 2023). 

TUs should align with the _CLO_ s and reflect the intended emphasis of each outcome. The emphasis of _CLO_ s in TUs can vary depending on the teaching approach, student needs, and instructional adjustments. Misalignment of TUs with _CLO_ s over multiple course deliveries suggests the need for curriculum revision. For each course, SACs should cover specific _CLO_ s and reflect their intended importance. The emphasis of _CLO_ s in SACs can be quantified to assess their alignment. A misalignment between TUs and SACs (i.e., if a _CLO_ is not assessed adequately) indicates a potential gap in curriculum delivery [7, 22, 24] (NCAAA 2023). 

This approach is flexible and can be applied to a wide range of teaching and assessment methods, regardless of the specific exercises or questions used. It is adaptable to different courses, disciplines, and educational contexts, making it more general and widely applicable. This approach emphasizes the teaching and assessment processes as a whole, rather than individual components like exercises or questions. It aligns with modern educational practices that focus on outcome-based education (OBE), where the emphasis is on how teaching and assessment methods collectively contribute to achieving learning outcomes [24, 25] (NCAAA 2023). 

#### **3.2 TUs and student assessment components (SACs)** 

#### **_3.2.1 Teaching units (TUs)_** 

- **Definition** : TUs encompass all teaching and learning activities, such as lectures, tutorials, labs, projects, and presentations. This approach considers the entire teaching process, not just specific exercises or questions. 

- **Purpose** : It allows for a holistic view of how teaching methods contribute to achieving _CLO_ s and _PLO_ s. By analyzing the time and effort spent on each topic, institutions can ensure that the intended emphasis of each _CLO_ is reflected in the delivered curriculum. 

- **Alignment** : TUs should align with the CLOs and reflect the intended emphasis of each outcome. Misalignment of TUs with CLOs over multiple course deliveries suggests the need for curriculum revision. 

#### **_3.2.2 Student assessment components (SACs)_** 

- **Definition** : SACs include all assessment methods, such as exams, quizzes, homework, lab reports, and group projects. This approach considers the entire assessment process, not just individual questions or exercises (Biggs 1996) [7, 22]. 

Page 10 of 20 

Derouich _Discover Education_ (2025) 4:486 

- **Purpose** : It provides a comprehensive view of how assessments measure student achievement of _CLO_ s and _PLO_ s. By ensuring that SACs cover all _CLO_ s and reflect their intended importance, institutions can better evaluate the effectiveness of their curriculum. 

- **Alignment** : SACs should align with the intended emphasis of _CLO_ s. A misalignment between TUs and SACs (e.g., if a _CLO_ is not assessed adequately) indicates a potential gap in curriculum delivery (Biggs 1996) [22, 23]). 

#### **3.3 Mathematical formulation** 

A mathematical method, similar to the one presented in the previous section, can be used to develop indicators that measure the alignment of TU and SAC with Course Outcomes (CO) and Program Outcomes (PO). These indicators include: 

- Emphasis of CLO and PLO in delivered TU **:** ITU-CLO and ITU-PLO 

- Emphasis of CLO and PLO in SAC: ISAC-CO and ISAC-PLO 

- Alignment of SAC with TU: ISAC-CO/ITU-CO and ISAC-PLO/ITU-PLO 

These indicators offer a systematic and rational basis for aligning TU and SAC with _CLO_ and _PLO_ . Additionally, they support the revision of _CLO_ and the re-alignment of _CLO_ with _PLO_ as needed. The estimation process can be automated using a spreadsheet, which facilitates comparison of results against user-defined limits and generates a comprehensive summary report, including tables and figures. 

#### **_3.3.1 Estimation of emphasis of CLOs in delivered TUs_** 

This section introduces the concept of _ITU-CLO_ and _ITU-PLO_ , which are indicators used to measure the alignment between the intended and delivered emphasis of _CLO_ s and _PLO_ s in the curriculum. These indicators provide a quantitative basis for evaluating how well the teaching and assessment processes align with the program's objectives. Table 5 outlines the planned weight for each CLO as designed by the course architect. For example, _CLO_ 1 was assigned a weight of 4 (28.6% of the overall emphasis). The table then shows how many lectures and tutorials were actually dedicated to each outcome, converting those session counts into an effective delivered weight. A weighted system was applied— lectures contributing 0.8 and tutorials 0.2—to convert the number of sessions into a percentage of the total Teaching Unit (TU). Table 5 employs a four-point scale, where 1 indicates minimal emphasis and 4 indicates maximum emphasis, to map the Teaching Unit to each _CLO_ . 

For instance, for _CLO_ 1, the calculation is as follows: 

- Lectures: 26.7% of total lecture time × 0.8 = 21.36% 

- Tutorials: 25% of total tutorial time × 0.2 = 5% 

- Total Delivered Emphasis: 21.36% + 5% = 26.36%, equivalent to a weight: 26.36/100 × 15 = 3.95 

This table is critical for identifying discrepancies between the designed emphasis and what was actually delivered. It highlights where the course might have underemphasized or overemphasized certain outcomes relative to the original plan. The Delivered emphasis of _CLO_ in TU calculated in Table 5 by using the relation: 

Page 11 of 20 

Derouich _Discover Education_ (2025) 4:486 

|We use a||||**Weight**|3.954|3.114|2.964|1.782|2.082|1.104|15|
|---|---|---|---|---|---|---|---|---|---|---|---|
|to tutorials was 0.2.|||**Lectures + tutorials**|**Percent**|26.36|20.76|19.76|11.88|13.88|7.36|100|
|ght assigned||||**Percent**|25|15|10|15|25|10|100|
|0.8 and the wei<br>|o each CLO||**Tutorials**|**Number**|5|3|2|3|5|2|20|
|ectures was<br>|case, TU-1) t|||**Percent**|26.7|22.2|22.2|11.1|11.1|6.7|100|
|nd tutorials, the weight assigned to l<br>|um emphasis–to map the TU (in this|**Delivered emphasis of CLO in TU**|**Lectures**|**Number**|12|10|10|5|5|3|45|
|lectures a<br>|ts maxim|||**Percent**|26.67|20.0|20.0|13.33|13.33|6.67|100|
|Estimation of emphasis of CLO in delivered TU. To add<br>|int scale–where 1 signifes low emphasis and 4 represen|**mber**<br>**Intended emphasis of CLO in TU by design**||**Weight**|4|3|3|2|2|1|15|
|**le 5**<br>|-po|**Nu**|||||||||l|
|**Tab**<br>|four|**CLO**|||_CLO1_|_CLO2_|_CLO3_|_CLO4_|_CLO5_|_CLO6_|Tota|



Page 12 of 20 

Derouich _Discover Education_ (2025) 4:486 



Table 6 presents a quantitative comparison between the intended emphasis and the delivered emphasis of each CLO within the TUs. The intended emphasis reflects the course designer’s planned focus for each CLO, while the delivered emphasis is calculated based on the actual distribution of teaching time across lectures and tutorials. The ratio _IT U −CLO_ of delivered to intended emphasis (ITU-CLO) provides an indicator of alignment, helping to identify whether each CLO was adequately addressed during course delivery. 

The _IT U −CLO_ is mathematically obtained by using the formula: 



where: 

- If _ITU-CLO_ = 1, the delivered emphasis matches the intended emphasis. 

- If _ITU-CLO_ > 1, the delivered emphasis exceeds the intended emphasis. 

- If _ITU-CLO_ < 1, the delivered emphasis is less than the intended emphasis. 

- Alignment Criteria: 0.85 ≤ _IT U −CLO_ ≤ 1.15 (Aligned). 

The calculated _ITU-CLO_ values allow for a detailed evaluation of how well each _CLO_ was emphasized during the actual course delivery compared to the original design. By examining these values, it becomes possible to identify where teaching emphasis matched expectations and where discrepancies occurred, highlighting areas for potential curriculum refinement or confirmation of effective alignment. 

For _CLO_ 1, the _ITU-CLO_ value is 0.9885. The delivered emphasis of 3.95 is slightly below the intended emphasis of 4, indicating a minor underemphasis. However, this falls within the acceptable alignment range (0.85–1.15), suggesting that the alignment is still adequate. _CLO2_ has an _ITU-CLO_ of 1.038, with a delivered emphasis of 3.12 slightly exceeding the intended emphasis of 3, reflecting a slight overemphasis that remains within acceptable limits. For _CLO_ 3, the _ITU-CLO_ value is 0.988, showing that the delivered emphasis of 2.964 is very close to the intended emphasis of 3, indicating near-perfect alignment. In the case of _CLO_ 4, the _ITU-CLO_ value is 0.891, with a delivered emphasis of 1.782 falling below the intended emphasis of 2, signifying underemphasis. Although this is slightly below the acceptable range, it suggests a need for minor adjustment. _CLO_ 5 shows an _ITU-CLO_ of 1.041, where the delivered emphasis of 2.082 slightly exceeds the intended emphasis of 2, indicating a small but acceptable overemphasis. Finally, _CLO_ 6 has an _ITU-CLO_ of 1.104, with the delivered emphasis of 1.104 exceeding the intended emphasis of 1. This overemphasis is within the acceptable range, although the low intended emphasis suggests that this outcome may not be critical. 

#### **_3.3.2 Estimation of emphasis of PLOs in TUs_** 

The evaluation now focuses on how well the _CLO_ s collectively support the achievement of the _PLO_ s. This is accomplished by analyzing the _CLO_ -to- _PLO_ mappings to determine both the intended and delivered emphasis of each _PLO_ . Table 7 illustrates a balanced mapping between _CLO_ s and _PLO_ s, where each _CLO_ contributes to multiple _PLO_ s with 

Page 13 of 20 

Derouich _Discover Education_ (2025) 4:486 

**Table 6** Teaching unit (TUs) to course learning outcomes (CLOs) mapping 

|**TU/CLO**|**CLO-1**|**CLO-2**|**CLO-3**|**CLO-4**|**CLO-5**|**CLO-6**|**Total**|
|---|---|---|---|---|---|---|---|
|Intended emphasis|4|3|3|2|2|1|15|
|Delivered emphasis|3.954|3.114|2.964|1.782|2.082|1.104|_≈_15|
|ITU-CLO|0.9885|1.038|0.988|0.891|1.041|1.104|_≈_6|



Scale: 1 = Low emphasis, 2 = Moderate emphasis, 3 = High emphasis, 4 = maximum emphasis 

**Table 7** Weights of CLO-PLO links 

|**_CLOg_/****_P LOk_**|**_PLO1_**|**_PLO2_**|**_PLO3_**|**_PLO4_**|**_PLO5_**|**_PLO6_**|
|---|---|---|---|---|---|---|
|_CLO1_|2|1|–|3|–|–|
|_CLO2_|–|2|3|–|2|–|
|_CLO3_|1|–|2|–|–|1|
|_CLO4_|–|1|–|2|–|1|
|_CLO5_|–|–|1|–|1|–|
|_CLO6_|–|–|–|–|–|1|



**Table 8** Estimation of emphasis of all PLOs in TUs 

|**PLO number**|**Intended emphasis of****_P LOj_ in TU**|**Delivered emphasis of****_P LOj_ in TU**|**_ITU-PLO_**|
|---|---|---|---|
|_PLO1_|3.667|3.624|0.988|
|_PLO2_|3.000|2.991|0.997|
|_PLO3_|2.833|2.892|1.021|
|_PLO4_|3.200|3.085|0.964|
|_PLO5_|2.667|2.770|1.039|
|_PLO6_|2.000|1.950|0.975|



varying weights. This distribution ensures that course-level outcomes support a broad range of program competencies. Higher weights indicate stronger contributions to specific _PLO_ s, while the presence of all _PLO_ s in the mapping confirms comprehensive curriculum alignment. 

To quantify this alignment, we introduce the indicator _ITU-PLO_ , which reflects the degree of alignment between the planned curriculum objectives and the actual instructional emphasis for each _PLO_ . _ITU-PLO_ is defined as: 



where 





The _WeightofCLOi − PLOj_ is provided in the _CLO-PLO_ mapping matrix (Table 7). The intended and delivered emphasis of _CLOi_ are provided in the TU-CLO mapping matrix (Table 6, second and third rows, respectively). 

By applying Eqs. (4) and (5), the intended and delivered emphasis of each _PLO_ , along with the ratio _ITU-PLO_ , are calculated to serve as alignment indicators. The target value for _ITU-PLO_ is 1, indicating perfect alignment (see Table 8). 

Page 14 of 20 

Derouich _Discover Education_ (2025) 4:486 

Let us calculate the intended and delivered emphasis for _PLO_ 1 as an example. To this aim, the needed data includes the weights of _CLO_ s- _PLO_ 1 links (from Table 7), the intended emphasis of _CLO_ s (from Table 5), and the delivered emphasis of _CLO_ s (from Table 5). 

The application of the Eq. (6) gives that: 

### _Intended Emphasis of PLO_ 1 _in TU_ = [(2 _×_ 4) + (1 _×_ 3)] _/_ (2 + 1) = 11 _/_ 3 = 3 _._ 667 

Similarly, the delivered emphasis of _PLO_ 1 is: 

_Delivered Emphasis of PLOj in TU_ = [(2 _×_ 3 _._ 954) + (1 _×_ 2 _._ 964)] _/_ (2 + 1) = 10 _._ 872 _/_ 3 = 3 _._ 624 

The _ITU-PLO_ ratio for _PLO_ 1 is determined by dividing the delivered emphasis by the intended emphasis, which is 3.624/3.667 = 0.988. This ratio indicates the alignment between the delivered and intended emphasis for _PLO_ 1. Similar treatment should be appliedto the other _PLO_ s in order to complete the Table 8. For PLO2 shows near-perfect alignment with an _ITU-PLO_ of 0.997, as the delivered emphasis (2.991) closely matches the intended emphasis (3.000). For _PLO_ 3, the _ITU-PLO_ is 1.021, reflecting a slight overemphasis with the delivered value (2.892) slightly exceeding the intended value (2.833), which remains acceptable. _PLO4_ has an _ITU-PLO_ of 0.964, showing a small underemphasis where the delivered emphasis (3.085) is marginally lower than the intended (3.200), suggesting a possible area for adjustment. _PLO_ 5 demonstrates slight overemphasis with an _ITU-PLO_ of 1.039, as the delivered emphasis (2.770) exceeds the intended value (2.667). Finally, _PLO_ 6 presents an _ITU-PLO_ of 0.975, with the delivered emphasis (1.950) slightly below the intended emphasis (2.000), but still within acceptable limits. 

Overall, the _ITU-PLO_ values confirm adequate alignment across all _PLO_ s, with only minor discrepancies that may warrant further monitoring or small adjustments. 

#### **_3.3.3 Estimation of emphasis of CLOs and PLOs in delivered SACs_** 

To evaluate the alignment between student assessment and the intended _CLO_ s, we analyzed the actual emphasis of _CLO_ s within the SACs. Table 9 presents a comparison between the intended emphasis (as defined in course design) and the delivered emphasis, 

**Table 9** Estimation of emphasis of CLO in delivered SAC 

|**CLO Number**|**Intended em-**<br>**phasis of CLO**<br>**by design**||**Delivered em-**<br>**phasis of CLO**<br>**in SAC**||||
|---|---|---|---|---|---|---|
||||**Exams**|**Other SAC**|**Exams and**<br>**other SAC**||
||**Weight**<sup>**a**</sup>|**Percent**|**Assigned**<br>**Grades(%)**|**Assigned**<br>**Grades(%)**|**Weight**<sup>**a**</sup>|**Per-**<br>**cent**<sup>**b**</sup>|
|_CLO1_|4|26.67|25.0|30.0|3.975|26.5|
|_CLO2_|3|20.00|20.0|20.0|3.0|20.0|
|_CLO3_|3|20.00|25.0|10.0|3.075|20.5|
|_CLO4_|2|13.33|12.0|15.0|1.935|12.9|
|_CLO5_|2|13.33|15.0|10.0|2.025|13.5|
|_CLO6_|1|6.67|3.0|15.0|0.99|6.6|
|Total|15|100|100|100|15|100|



a Scale: 1 = low emphasis; 2 = moderate emphasis; 3 = high emphasis; 4 = maximum emphasis b To add grades of exams and other SAC, the weight assigned to exams was 0.7 and the weight assigned to other SAC was 0.3 

Page 15 of 20 

Derouich _Discover Education_ (2025) 4:486 

which is calculated based on the relative weight of each assessment component—70% for exams and 30% for other SACs (projects, homework, etc.). 

The results presented in Table 9 indicate a strong overall alignment between the intended emphasis of the _CLO_ s and the actual emphasis reflected in the SACs. _CLO_ 1, which carries the highest intended emphasis (26.67%), is assessed at a comparable level, with a delivered emphasis of 26.5% which implies a delivered weight = (26.5/100) × 15 = 3.975 (see Table 9). _CLO_ 2 and _CLO_ 3 also show very close alignment, with delivered emphases of 20.0% and 20.5%, respectively, almost exactly matching their intended values (20.0% each). _CLO_ 4 and _CLO_ 5 exhibit small deviations, with delivered emphases slightly below or above their intended values, but these differences are minor and within acceptable bounds. _CLO_ 6 shows the largest relative discrepancy, where the delivered emphasis (6.6%) is slightly lower than the intended (6.67%), though the absolute difference is negligible due to the low weight assigned to this outcome. These results suggest that the assessment strategy effectively mirrors the planned instructional priorities, ensuring that students are evaluated according to the importance of each _CLO_ as designed in the curriculum. Minor variations likely reflect practical considerations in exam and SAC design, such as the distribution of question difficulty or the inclusion of skills assessed through alternative formats. Overall, the findings confirm that the assessment components are well aligned with the _CLO_ s, supporting accurate measurement of student achievement and reinforcing curriculum coherence. 

Table 10 summarizes the comparison between the intended and delivered emphasis of each _CLO_ within the SACs. The delivered emphasis reflects how the assessment activities—weighted by the relative contributions of exams and other SACs—correspond to the planned importance assigned to each _CLO_ . 

The _ISAC-PLO_ values are computed as: 



These values (Table 10) indicate a high degree of consistency between the intended and delivered emphasis across all _PLO_ s. Most _ISAC-PLO_ values are very close to 1, confirming strong alignment between the planned assessment strategy and its actual implementation. Slight variations are within acceptable limits and reflect typical flexibility in assessment design and execution. 

Table 11 presents the alignment between the intended and delivered emphasis of each _PLO_ within the SACs. 

Table 12 provides the ratios of _ISAC-CLO /ITU-CLO_ and _ISAC-PLO/ ITU-PLO_ for each _PLO_ and each _CLO_ . It shows that the course is well-aligned with its intended learning outcomes. The alignment between TUs and SACs is effective, ensuring that students are assessed on the outcomes emphasized during teaching. This alignment is crucial for achieving the program’s educational goals and meeting accreditation standards. Table 12 confirms 

**Table 10** Comparison of intended versus delivered CLO emphasis 

|**_SAC_/****_CLO_**|**_CLO1_**|**_CLO2_**|**_CLO3_**|**_CLO4_**|**_CLO5_**|**_CLO6_**|**Total**|
|---|---|---|---|---|---|---|---|
|Intended emphasis|4|3|3|2|2|1|15|
|Delivered emphasis|3.975|3.0|3.075|1.935|2.025|0.99|15|
|ISAC-PLO|0.994|1.0|1.025|0.968|1.013|0.99|5.99|



Scale: 1 = Low emphasis, 2 = Moderate emphasis, 3 = High emphasis, 4 = maximum emphasis 

Page 16 of 20 

Derouich _Discover Education_ (2025) 4:486 

**Table 11** Estimation of emphasis of all PLOs in SACs 

|**PLO Number**|**Intended Emphasis of****_P LOj_ in SAC**|**Delivered Emphasis of****_P LOj_ in SAC**|**_ISAC-PLO_**|
|---|---|---|---|
|_PLO1_|3.667|3.675|1.001|
|_PLO2_|3.0|2.9775|0.9925|
|_PLO3_|2.833|2.8625|1.0115|
|_PLO4_|3.200|3.159|0.9872|
|_PLO5_|2.667|2.675|1.0019|
|_PLO6_|2.000|2.000|1.000|



**Table 12** Alignment of delivered SACs with TUs 

|**_ISAC-CLO/ITU-CLO_**|**Comment**<sup>**a**</sup>|**_ISAC-PLO/ITU-PLO_**|**Comment**<sup>**a**</sup>|
|---|---|---|---|
|1.006|Aligned|1.017|Aligned|
|0.962|Aligned|0.995|Aligned|
|1.046|Aligned|0.992|Aligned|
|1.085|Aligned|1.024|Aligned|
|0.972|Aligned|0.963|Aligned|
|0.917|Aligned|1.034|Aligned|



> _aAligned if 0.85_ ≤ _ISAC-PLO/ ITU-PLO_ ≤ _1.15 and 0.85_ ≤ _ISAC-CLO /ITU-CLO_ ≤ _1.15_ 

**Table 13** Average performance of students on each CLO as indicated by earned grades 

|**CLO number**|**Delivered em-**<br>**phasis of CLO in**<br>**SAC**<sup>**a**</sup>||**Exams (%)**|**Other SAC**<br>**(%)**|**Overall**<sup>**b,c**</sup>||
|---|---|---|---|---|---|---|
||**Weight**<sup>**a**</sup>|**Percent**|||**Percent**|**Weight**|
|_CLO1_|3.975|26.5|85|91.4|86.92|3.455|
|_CLO2_|3|20|83|89.5|84.95|2.55|
|_CLO3_|3.075|20.5|90|93|90.9|2.796|
|_CLO4_|1.935|12.9|80|82|80.6|1.56|
|_CLO5_|2.025|13.5|87|85|86.4|1.75|
|_CLO6_|0.99|6.6|92|95|92.9|0.92|



a Delivered emphasis of CLO in SAC (see Table 10) b Overall percent = (Exams × 0.7) + (Other SAC × 0.3) c Overall weight = Overall percent*Delivered Emphasis /100 

**Table 14** Relative achievement of CLOs based on student performance 

|**_SP_/****_CLO_**|**_CLO1_**|**_CLO2_**|**_CLO3_**|**_CLO4_**|**_CLO5_**|**_CLO6_**|
|---|---|---|---|---|---|---|
|_ISP-CLO_ (%)|86.375|85|93.2|78|87.5|92|



that the current course structure successfully aligns with its intended learning outcomes. This reflects an improvement from prior assessments, where some outcomes showed misalignment. Future monitoring and refinements will help sustain this positive trend. 

Table 13 quantifies the average student performance across both exam-based and non-exam SACs, computing weighted achievement scores for each _CLO_ based on the delivered emphasis. The data show that most _CLO_ s have high levels of attainment, particularly _CLO3_ and _CLO_ 6, which exceed 90% performance, suggesting that these outcomes are being effectively taught and assessed. Table 14 builds on this by converting these scores into relative achievement indicators ( _ISP-CLO_ ), comparing the actual performance weights against intended curriculum emphasis. The _ISP-CLO_ ( _%_ ) values of Table 14 are computed as: 

Page 17 of 20 

Derouich _Discover Education_ (2025) 4:486 

> <sup>_Weight_</sup><sup><u>(</u></sup><sup>_Table_13)</sup> _ISP − CLO_ (%) = _Intended_<sup>_Overall_</sup> _Weight_ ( _Table_ 10)<sup>_×_100</sup> 

The analysis confirms that five out of six _CLO_ s meet or exceed the achievement threshold of 80%, with only _CLO_ 4 falling short (78%), marking it as a candidate for instructional or assessment adjustment. This underperformance aligns with earlier findings related to misalignment in TU and SAC coverage of _CLO_ 4, reinforcing the need for curriculum refinement to ensure balanced _CLO_ achievement. 

### **4 Closing the loop: re-alignment of TU and SAC with CLO and PLO** 

Closing the loop is a critical phase in outcome-based education, where the results of alignment and performance analyses are translated into actionable improvements [24, 25] (Deming 1986, Biggs 1996, NCAAA 2023). This section addresses how the curriculum can be re-aligned based on discrepancies identified in the relationships between TUs, SACs, _CLO_ s, and _PLO_ s [7, 22] **.** 

#### **4.1 Identifying misalignment** 

The results from the previous section reveal several minor but important discrepancies in alignment: 

- _CLO4_ shows an _ITU-CLO_ value of 0.891 and an _ISP-CLO_ of only 78%, indicating both under-delivery in TUs and underachievement in assessment (Biggs 1996) [21, 26, 27]. 

- _PLO4_ and _PLO5_ also exhibit lower-than-expected delivered emphasis compared to their intended weights (see _ITU-CLO_ and _ISAC-PLO_ ), highlighting curriculum areas that need reinforcement [24] (NCAAA 2023). 

- SAC coverage for _CLO6_ is proportionally higher than its intended teaching weight, potentially leading to overassessment [23, 27]. 

These deviations signal the need for realignment interventions to ensure consistent emphasis in both delivery and assessment (Biggs 1996) [28]. 

#### **4.2 Re-alignment strategies** 

Re-alignment uses TU and SAC evidence (e.g., ITU-CLO, ISAC-CLO) to recalibrate teaching and assessment to intended CLOs/PLOs within OBE (Biggs 1996) [25]. It also satisfies accreditation expectations and follows Plan–Do–Check–Act (PDCA) improvement cycles [24] (NCAAA 2023; Deming 1986). 

#### **_4.2.1 Adjust teaching units (TUs)_** 

- Redistribute instructional time to reinforce under-delivered _CLOs_ like _CLO4_ . 

- Introduce new TU activities (e.g., case studies, collaborative tasks) to better support CLOs that feed into weakly covered PLOs. 

- Ensure that low-weighted _CLOs_ such as _CLO6_ remain aligned with their actual contribution to program goals without overemphasis in assessment. 

#### **_4.2.2 Rebalance student assessment components (SACs)_** 

- Adjust exam and SAC design to ensure _CLOs_ such as _CLO4_ and _CLO5_ are assessed at levels proportional to their intended weight. 

Page 18 of 20 

Derouich _Discover Education_ (2025) 4:486 

- Diversify assessment methods to better match the teaching approach (e.g., including project-based evaluation for higher-order outcomes). 

#### **_4.2.3 Review CLO-PLO mapping_** 

- Evaluate whether some _CLOs_ can be re-mapped or shared with underrepresented _PLOs_ (e.g., _PLO4_ or _CLO6_ ) to achieve better overall program coverage. 

- Consider introducing or modifying _CLOs_ in other courses to cover any _PLOs_ not sufficiently addressed by the current structure. 

#### **4.3 Institutionalizing continuous improvement** 

To sustain alignment over time: 

- Implement a course-level dashboard that tracks TU, SAC, CLO, and PLO alignment in real time. 

- Require faculty to conduct alignment reviews at the end of each course offering, using _ITU-CLO_ , _ISAC-CLO_ , _ISP-CLO, ITU-PLO_ , and _ISAC-PLO_ indicators. 

- Integrate this feedback into curriculum committee reviews, so that re-alignment becomes a cyclical process rather than a reactive one. 

### **5 Conclusion** 

The findings of this study offer meaningful contributions to the pursuit of curriculum integrity in outcome-based education, grounded in constructive alignment and program-level coherence [1, 8]. By analyzing how exercises, questions, teaching units, and student assessment components collectively influence learning outcome coverage, the framework facilitates a more accurate and balanced evaluation of both teaching delivery and student assessment, across two complementary layers that connect the granular to the programmatic: (i) alignment from assessment items to course learning outcomes and then to program learning outcomes; and (ii) alignment from the design and delivery of teaching and assessment to course learning outcomes and ultimately to program learning outcomes, using explicit weights and acceptance bands to distinguish normal variation from meaningful misalignment [5, 7]. Through the application of weighted mapping and alignment indicators, we uncovered not only well-aligned areas but also critical mismatches—such as unaddressed _PLO_ s and underemphasized _CLO_ s—including concrete, auditable cases (e.g., under-delivery and under-attainment for a specific _CLO_ ; underrepresented _PLO_ s), thereby moving beyond anecdotal course reviews [3, 13]. 

Importantly, the approach moves beyond static course design and enables dynamic, evidence-based curriculum refinement, using indicators of delivered teaching emphasis, assessment coverage, and student performance as triggers for proportionate adjustments to teaching time, assessment blueprints, and CLO–PLO allocations [5, 7]. This empowers faculty and administrators to implement specific adjustments—such as reallocating teaching time, redesigning assessment components, or redistributing learning outcomes across the program—while preserving transparency of the evidence chain from assessment items and teaching units up to program outcomes [13]. Rather than presenting alignment as a one-time compliance measure, the model fosters an ongoing feedback loop that links teaching, learning, and evaluation in a responsive and evidence-based 

Page 19 of 20 

Derouich _Discover Education_ (2025) 4:486 

manner, aligning with recognized quality-assurance expectations and accreditation logics (ENQA 2015) [2, 14, 29] 

It is especially relevant to programs seeking or maintaining accreditation from national and international bodies, where demonstrable outcome alignment is essential, because it makes explicit how course-level evidence aggregates to program-level competencies and where redistribution is pedagogically justified [2, 14]. Furthermore, the framework supports both centralized curriculum committees and individual instructors by offering scalable tools that can be integrated into institutional quality-assurance systems, and it is readily extensible across multi-course sequences, laboratories, and capstones to ensure coherent progression [16]. 

In essence, this study reinforces that aligning learning outcomes with instructional and assessment strategies is not only a quality requirement but a pedagogical necessity— one that ensures educational programs remain relevant, accountable, and impactful in preparing students for academic and professional success. Future work will (i) calibrate weighting schemes and acceptance bands empirically across disciplines, (ii) evaluate reliability and generalizability of indicators in large-enrollment and multi-section contexts, and (iii) integrate automated dashboards with e-assessment data for longitudinal monitoring and program-level decision-making [3, 13, 15, 16]. 

##### **Author contribution** 

None (single author). 

##### **Funding** 

Not applicable. 

##### **Data availability** 

Data of this study are available upon request from the corresponding author. 

#### **Declarations** 

**Ethics approval and consent to participate** No applicable. 

**Consent for publication** Not applicable. 

##### **Competing interests** 

The authors declare no competing interests. 

Received: 17 June 2025 / Accepted: 13 October 2025 



##### **References** 

1. Biggs J, Tang C. Teaching for quality learning at university (4th ed.). McGraw-Hill Education; 2011. ISBN: 9780335242757. 

2. Felder RM, Brent R. Designing and teaching courses to satisfy the ABET engineering criteria. J Eng Educ. 2003;92(1):7–25.  h t t p s : / / d o i . o r g / 1 0 . 1 0 0 2 / j . 2 1 6 8 - 9 8 3 0 . 2 0 0 3 . t b 0 0 7 3 4 . x. 

3. Craddock D, Mathias H. Assessment options in higher education. Assess Eval High Educ. 2009;34(2):127–40.  h t t p s : / / d o i . o r g / 1 0 . 1 0 8 0 / 0 2 6 0 2 9 3 0 8 0 1 9 5 6 0 2 6 . 

4. Felder RM, Silverman LK. Learning and teaching styles in engineering education. Eng Educ. 1988;78(7):674–81. 

5. Reeves TC. How do you know they are learning? The importance of alignment in higher education. Int J Learn Technol. 2006;2(4):294–309. https://doi.org/10.1504/IJLT.2006.011336. 

6. Patil AS, Codner G. Accreditation of engineering education: review, observations and proposal for global accreditation. Eur J Eng Educ. 2007;32(6):639–51. https://doi.org/10.1080/03043790701520594. 

7. Harden RM. AMEE guide no. 21: curriculum mapping: a tool for transparent and authentic teaching and learning. Med Teach. 2001;23(2):123–37. https://doi.org/10.1080/01421590120036547. 

8. Tyler RW. Basic principles of curriculum and instruction. University of Chicago Press; 1949. 

9. Agrawal R, Sharma K. Enhancing educational quality: a prototype system for evaluating faculty performance in higher education. J Eng Educ Transf. 2025;38(4):210–9.  h t t p s : / / d o i . o r g / 1 0 . 1 6 9 2 0 / j e e t / 2 0 2 4 / v 3 8 i 4 / 2 5 1 0 8. 

10. Bernold LE, Díaz-Michell B. A multi-dimensional quality assessment instrument for engineering education. In: Proceedings of the international conference on science and technology engineering education; 2023. pp. 1–6. 

Page 20 of 20 

Derouich _Discover Education_ (2025) 4:486 

11. Lu Y, Hao X. Evaluation indices and evaluation method of OBE education quality based on teaching process. J Eng Sci Technol Rev. 2022;15(4):106–12. https://doi.org/10.25103/jestr.154.14 

12. Beena T, Suresh R. Course-outcome and program-outcome attainment evaluation toward curriculum quality improvement. J Eng Educ Transf. 2021;35(2):60–66.  h t t p s : / / d o i . o r g / 1 0 . 1 6 9 2 0 / j e e t / 2 0 2 1 / v 3 5 i 2 / 2 2 0 7 3 

13. Mak WK, Frezza ST. Using objective evidence to support curriculum assessment and accreditation. In: Proceedings of the 2006 ASEE annual conference & exposition; 2006. 

14. National Commission for Academic Accreditation and Assessment (NCAAA). (2021). Handbook for Quality Assurance and Accreditation in Higher Education in the Kingdom of Saudi Arabia. Education & Training Evaluation Commission (ETEC). 

15. Wanous M, Procter B, Murshid K. Assessment for learning and skills development: the case of large classes. Eur J Eng Educ. 2009;34(1):77–85. https://doi.org/10.1080/03043790902721462. 

16. González J, Wagenaar R. Tuning educational structures in Europe: universities’ contribution to the bologna process. Universidad de Deusto; 2008.  h t t p s : / / t u n i n g a c a d e m y . o r g / w p - c o n t e n t / u p l o a d s / 2 0 1 4 / 0 2 / T u n i n g E U I I _ F i n a l - R e p o r t _ E N . p d f 

17. European Association for Quality Assurance in Higher Education (ENQA). Standards and guidelines for quality assurance in the European higher education area (ESG). ENQA; 2015. 

18. Zayani M, Sboui T, Halbaoui S. A framework for efficient and accurate automated CLO and PLO assessment. Eng Technol Appl Sci Res. 2024;14(4):13362–8. https://doi.org/10.48084/etasr.6846 

19. Mendoza JM, Sabuilda JH, Arada J. Curriculum mapping to program outcomes: a data-driven approach. Educ Sci. 2022;12(8):541. https://doi.org/10.3390/educsci12080541. 

20. Mustaffa NA, Zulkifliand M, Murat RIZ. Measuring course learning outcome for large class of introductory statistics course. Int J Innov Technol Explor Eng. 2019;8(7S2):382–8. 

21. Downing SM. Twelve steps for effective test development. Med Teach. 2006;28(9):701–5.  h t t p s : / / d o i . o r g / 1 0 . 1 0 8 0 / 0 1 4 2 1 5 9 0 6 0 0 7 1 1 2 6 7 . 

22. Prideaux D. ABC of learning and teaching in medicine: curriculum design. BMJ. 2003;326(7383):268–70.  h t t p s : / / d o i . o r g / 1 0 . 1 1 3 6 / b m j . 3 2 6 . 7 3 8 3 . 2 6 8 . 

23. Wiggins G, McTighe J. Understanding by design (Expanded 2nd ed.). ASCD; 2005. 

24. ABET Engineering Accreditation Commission. (2024). Criteria for Accrediting Engineering Programs, 2025–2026. ABET. 

25. Spady WG. Outcome-based education: critical issues and answers. American Association of School Administrators; 1994. 

26. van der Vleuten CPM, Schuwirth LWT. Assessing professional competence: from methods to programmes. Med Educ. 2005;39(3):309–17.  h t t p s : / / d o i . o r g / 1 0 . 1 1 1 1 / j . 1 3 6 5 - 2 9 2 9 . 2 0 0 5 . 0 2 0 9 4 . x. 

27. Suskie L. Assessing student learning: a common sense guide (3rd ed.). Jossey-Bass; 2018. 

28. Banta TW, Palomba CA. Assessment essentials: planning, implementing, and improving assessment in higher education (2nd ed.). Jossey-Bass; 2015. 

29. Council for Higher Education Accreditation (CHEA). The value of accreditation. CHEA; 2010. 

### **Publisher's Note** 

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

