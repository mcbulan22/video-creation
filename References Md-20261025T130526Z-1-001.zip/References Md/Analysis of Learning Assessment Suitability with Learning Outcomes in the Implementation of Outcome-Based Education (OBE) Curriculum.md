

# **Analysis of Learning Assessment Suitability with Learning Outcomes in the Implementation of Outcome-Based Education (OBE) Curriculum** 

Zulfikar Ali Buto Siregar<sup>1</sup> , Abdul Kadir<sup>2</sup> , Muhibuddin<sup>3</sup> , Rauzatul Jannah<sup>4</sup> 

1, 2Department of Islamic Education, Universitas Islam Negeri Sultanah Nahrasiyah, Lhokseumawe, Indonesia 

3Department of Islamic Studies, Institut Agama Islam Negeri Langsa, Langsa, Indonesia 

4Department of Sharia Economics, Universitas Islam Negeri Sultanah Nahrasiyah, Lhokseumawe, Indonesia *Email: zulfikar@uinsuna.ac.id 

**ARTICLE INFO ABSTRACT** _Keywords:_ **Purpose –** Outcome-Based Education (OBE) is now a key component Outcome-Based Education, of the Merdeka Curriculum in Indonesian universities. However, in learning assessment, religious colleges, learning goals often do not match how students learning outcomes, are tested. This study examines how well Course Learning Merdeka Curriculum. Outcomes (CPMK), their indicators, and assessment methods align. It also identifies specific challenges lecturers face. 

**Methodology –** This study used a range of methods, including reviewing curriculum documents, conducting surveys, and conducting interviews. The participants were 52 lecturers from IAIN Lhokseumawe, covering different study programs with OBE-based curricula. The study analyzed data to assess how well assessments aligned with OBE goals. It also looked at common problems in implementing OBE **.** 

**Findings –** The results show that while Graduate Learning Outcomes (CPL) and CPMK mostly align, the assessment methods are inconsistent. There are issues with rubric consistency, assessment variety, and the use of real-world assessments that align with learning goals. Statistical analysis found a strong positive association between assessment alignment and achievement of OBE outcomes, highlighting the importance of good assessment design. 

**Contribution –** This study provides new insights into the assessment of OBE in Islamic higher education. It points out specific challenges different from those in general higher education. Although the study focuses on one institution, it highlights the need for specialized training, particularly in understanding assessments and using digital tools, to improve OBE implementation **.** 

Received 08 October 2025; Received in revised form 18 October 2025; Accepted 02 February 2026 Jurnal Eduscience (JES) Volume 13 No. 1 (2026) Available online 28 February 2026 

©2025 The Author(s). Published by LPPM Universitas Labuhanbatu. This is an open-access article under the **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY - NC - SA 4.0)** 

51 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

### **INTRODUCTION** 

The transformation of higher education in Indonesia has become an inevitability in line with the advancement of globalization and the Industrial Revolution 4.0. In response to these dynamics, the government has introduced the _Merdeka Belajar Kampus Merdeka_ (MBKM) policy, which aims to provide students with greater flexibility in developing their competencies through diverse forms of learning beyond their study programs. MBKM is expected to produce graduates who are adaptive, creative, and aligned with the needs of both industry and society. (Siregar et al., 2020; Simatupang & Yuhertiana, 2021). However, implementing this policy faces challenges, particularly in private Islamic higher education institutions, which are still adapting to limitations in human resources, infrastructure, and academic governance (Arifin & Muslim, 2020). 

Globally, the Outcome-Based Education (OBE) approach has become a key strategy in curriculum reform. OBE emphasizes the attainment of learning outcomes as the primary orientation of the learning process, with curriculum, teaching methods, and assessments designed to ensure that graduates' competencies align with labor market demands (Nesa Novrizal, 2025). Researches Rustam & Priyanto, 2022;Ali & Jamin, 2025; Ishaq et al., 2023; Li et al., 2025; Mahrishi et al., 2025; Rustam & Priyanto, 2022; Shi, 2025). OBE emphasizes the importance of synergy among learning outcomes, teaching strategies, and assessment systems as key to achieving graduate competencies (Mahrishi et al., 2025; R, 2023). Recent global studies show that OBE not only strengthens transparency in learning achievement but also encourages pedagogical innovation through authentic assessment, learning analytics, and the use of artificial intelligence in ongoing quality assurance (Ahmed, 2025; Ansari, 2025; Sanaj M S, 2025). However, the main challenge OBE still faces internationally is the lack of faculty competence in designing assessment instruments that are truly aligned with Course Learning Outcomes (CLOs) and Graduate Learning Outcomes (Li et al., 2025; Shi et al., 2025). 

In the context of Islamic education, the challenges of implementing OBE become increasingly complex. Research in Uganda and Southeast Asia shows that religious educational institutions face two main challenges: adapting to global OBE standards and preserving the distinctive values and orientations of the institution (Dien et al., 2025; Kiggundu et al, 2025). Although several studies in Indonesia have discussed the development of learning media, OBE-based lesson plans, and curriculum innovations (Ahmed, 2025; Ali & Jamin, 2025; Damanik et al., 2024; Dien et., all 2025; Erdiana & Yasin, 2019; Ishaq et al., 2023; Li et al., 2025; Lubis et al., 2025;  R, 2023; Rahmaniati et al., 2024; Rahmawati & Wahyuni, 2024; Sistiana Windyariani, 2023; Shi, 2025; Silitonga et al., 2025; Sudarshan Balasaheb Babar, 2025; Ware et al., 2025; Wenjie Shi et., all 2025), empirical research specifically examining the alignment of OBE assessment within the MBKM policy framework in religious higher education institutions remains limited. This represents the main research gap that has not yet been widely addressed. 

At IAIN Lhokseumawe, the OBE-based Merdeka Curriculum has been implemented through Rector's Decree Number 347 of 2022. However, nearly two years have passed, and the new learning paradigm has yet to be fully realized. There are still inconsistencies between Graduate Learning Outcomes (CPL), Course Learning Outcomes (CPMK), the delivery of learning activities, and the assessment system. Evaluation practices are still dominated by Midterm and Final Examinations, resulting in partial, instantaneous measurement of learning outcomes and a less reflective assessment of students' actual competencies. This phenomenon aligns with Ahmed's (2025) findings that OBE implementation failures often stem from weak assessment design and execution. Based on these conditions, the focus of this research problem is sharply directed toward the alignment between CPMK, CPMK indicators, and assessment instruments in the implementation of OBE-based MBKM, as well as the factors that hinder the optimization of outcome-based assessment in religious higher education institutions. Accordingly, this research aims to analytically and conceptually examine the empirical relationship between assessment alignment and OBE achievement, while also identifying structural and pedagogical challenges affecting the effectiveness of OBE implementation. Academically, this research is crucial as it strengthens the global discourse on OBE in non-technical fields and religious education, which have so far been underexplored (Damanik et al., 2024; Mahrishi et al., 2025). This study also broadens perspectives on integrating national MBKM policies with assessment-based OBE 

52 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

practices. It provides an empirical basis for developing more authentic, adaptive, and sustainable assessment models in Indonesian Islamic higher education institutions. 

### **METHODOLOGY** 

### **Research Design** 

This study uses a mixed-methods approach with a convergent parallel design, collecting both quantitative and qualitative data simultaneously to examine the same issue from two complementary perspectives. The quantitative approach aims to measure the alignment between learning outcomes and assessments. In contrast, the qualitative approach explores lecturers' perceptions, understandings, and experiences in implementing assessment within the Outcome-Based Education (OBE) framework, using a descriptive-analytical design. The descriptive-correlational design was chosen because this research not only describes the existing empirical conditions but also examines the relationships among relevant variables to assess their conformity with OBE principles in the implementation of the Merdeka Belajar–Kampus Merdeka (MBKM) curriculum. 

### **Population and Sample** 

The research population consists of all lecturers at IAIN Lhokseumawe who teach MBKM-based courses during the 2023–2024 academic year. The sample was selected using purposive sampling techniques because it requires respondents who have direct experience in designing and implementing learning and assessment based on OBE. The selected lecturers are those who teach KKNI–MBKM courses in the second and fourth semesters and are responsible for preparing the Semester Learning Plan (RPS). Based on these criteria, the research sample includes 52 lecturers from various study programs and 40 RPS documents, which serve as the primary data sources. 

### **Data Collection** 

Data collection was conducted through three main techniques to ensure the completeness and depth of information. First, a document analysis of the RPS was conducted to identify alignment among the Graduate Learning Outcomes (CPL), Course Learning Outcomes (CPMK), teaching strategies, and assessment instruments. Second, qualitative data collection was carried out through Focus Group Discussions (FGD) to explore in greater depth lecturers' understanding, the challenges they face, and the practical applications of implementing OBE-based assessments. Third, Likert-scale questionnaires were used to collect quantitative data on lecturers' levels of understanding and practices in designing assessments aligned with learning outcomes. 

### **Instrument** 

The research instruments consist of a document analysis sheet, a questionnaire, and a focus group discussion (FGD) guide. The document analysis sheet was developed based on the OBE (Outcome-Based Education) principles to assess the correlation between Program Learning Outcomes (PLOs), Course Learning Outcomes (CLOs), assessment methods, and rubrics. The questionnaire was designed to measure lecturers' understanding and attitudes toward assessment based on learning outcomes, with content validity assessed through expert evaluation (CVI = 0.87) and reliability assessed using Cronbach's Alpha (α = 0.91). The FGD guide was prepared in a semi-structured format to keep the discussion focused while allowing lecturers to share their experiences and perspectives freely. 

### **Data Analysis** 

### **_Quantitative Data Analysis_** 

Quantitative data from questionnaires and RPS analyses are analyzed using descriptive statistics, such as means, percentages, and frequency distributions, to illustrate the alignment between assessments and learning outcomes. Additionally, Pearson correlation tests are conducted to examine the relationship between the level 

53 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

of assessment alignment and CPL and CPMK achievement. This analysis aims to provide empirical evidence regarding the role of assessment in supporting the successful implementation of OBE. 

### **_Qualitative Data Analysis_** 

Qualitative data from FGDs are analyzed using the interactive model of Miles and Huberman, which includes the stages of data reduction, data presentation, and conclusion drawing. In the data reduction stage, data are selected and coded to identify main themes. Next, the data are presented in narrative and thematic matrix form to facilitate interpretation. The final stage involves concluding, verified through comparisons across data sources to ensure the consistency of findings. 

### **_Data Integration_** 

Quantitative and qualitative data integration is carried out during the interpretation stage of the research results. Quantitative findings show general patterns and trends, while qualitative findings explain the reasons and context behind those patterns. By combining both types of data, this study provides a more comprehensive understanding of the level of alignment in assessments and the challenges of implementing OBE within the MBKM framework. 

### **Research Ethics** 

This research is conducted in accordance with the principles of research ethics. All involved lecturers are provided with an explanation of the research objectives, procedures, and are asked to give voluntary consent before participating. The respondents' identities are kept confidential through data anonymization, and all data collection is conducted with official permission from the IAIN Lhokseumawe. 

### **FINDINGS** 

### **Quantitative Research Results** 

In implementing the Merdeka Curriculum based on Outcome-Based Education (OBE), the design of learning assessments is a fundamental aspect that determines achievement of the Graduate Learning Outcomes. Assessments serve not only as evaluation tools but also as instruments to ensure that the entire learning process aligns with the established educational objectives. Therefore, lecturers' understanding of designing assessments integrated with learning outcomes is essential so that the teaching and learning process has a clear, measurable direction and optimally encourages the achievement of student competencies. 

**Table 1.** Descriptive Statistics of Respondents Identity 

||Respondent Identity|Frequency|Percent|
|---|---|---|---|
||Astronomy|6|11.5|
||English Language Teaching|4|7.7|
||Mathematics Education|5|9.6|
||Islamic Communication and Broadcasting|3|5.8|
||Sharia Economy|5|9.6|
||Arabic Language Education|1|1.9|
||Early Childhood Islamic Education (PIAUD)|1|1.9|
|Lecturers of the|Islamic Education Management|1|1.9|
|Department|Pendidikan Guru Madrasah Ibtidaiyah (PGMI)|1|1.9|
||Sharia Economic Law (Mua'malah)|1|1.9|
||State Law (Siyasah)|1|1.9|
||Guidance and Counseling in Islamic Education|5|9.6|
||Islamic Guidance and Counseling|1|1.9|
||Islamic Religious Education|4|7.7|



54 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

||Respondent Identity|Frequency|Percent|
|---|---|---|---|
||Indonesian Language Teaching|5|9.6|
||Sharia Accounting|1|1.9|
||Sharia Banking|2|3.8|
||Islamic Library and Information Science|1|1.9|
||Islamic Family Law (Ahwal al-Syakhshiyyah)|1|1.9|
||Knowledge of the Qur’an and Tafsir|3|5.8|
||Total|52|100.0|
||Man|18|34.6|
|Gender|Woman|34|65.4|
||Total|52|100.0|



At IAIN Lhokseumawe, the implementation of the OBE-based Merdeka Curriculum requires every lecturer not only to understand the concepts of gol, Course Learning Outcomes (CLO), and Sub-CLO, but also to develop appropriate assessments, including techniques, forms, components, and assessment rubrics. Aligning assessment instruments with learning outcomes will result in an evaluation process that is objective, fair, and supports improvements in learning quality. Based on this foundation, the following discussion will systematically describe: the alignment of Graduate Learning Outcomes and course learning outcomes, the alignment of course learning outcomes and Sub-course learning outcomes, assessment techniques, components, forms, weights, types of assessment, types of results, the alignment of exam questions with learning outcomes, assessment guidelines, learning models that support OBE, and portfolios. 

### **Alignment of Learning Assessment with Learning Outcomes** 

This description is expected to serve as a guideline in designing comprehensive, relevant, and competency-oriented learning assessments in accordance with the requirements of the OBE-based Merdeka Curriculum, as follows: 

**Table 1.** Summary of Lecturers' Understanding of OBE-Based Assessment Design 

|Rated aspect|Answer<br>Categories|Frequency|Percentage|Cumulative<br>Distribution|Average|
|---|---|---|---|---|---|
|Connectedness GLO &|Do not|1|1.9|1.9|2.75|
|CLO|understand|||||
||Understand|11|21.2|23.1||
||Very Understand|40|76.9|100.0||
|Connectedness CLO &|Appropriate|2|3.8|3.8|2.96|
|SUB-CLO||||||
||Very Appropriate|50|96.2|100.0||
|Assessment and|Less Appropriate|16|30.8|30.8|1.96|
|Connectedness||||||
|Techniques CLO||||||
||In accordance|22|42.3|73.1||
||Very suitable|14|26.9|100.0||
|Assessment|Incomplete|29|55.8|55.8|1.50|
|Components||||||
||Complete|20|38.5|94.2||
||Very Complete|3|5.8|100.0||
|Assessment Form|Two Types|23|44.2|44.2|2.27|
||Three Types|19|36.5|80.8||



55 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

|Rated aspect|Answer<br>Categories|Frequency|Percentage|Cumulative<br>Distribution|Average|
|---|---|---|---|---|---|
||>3 Types|10|19.2|100.0||
|Assessment Weight|Incomplete|11|21.2|21.2|1.79|
||Complete and<br>Detailed|41|78.8|100.0||
|Types of Assessment|Formative|35|67.3|67.3|1.40|
||Summative|13|25.0|92.3||
||Diagnostic|4|7.7|100.0||
|Outcome Type|There is no|7|13.5|13.5|2.42|
||Two Outcomes|30|57.7|71.2||
||Three Outcomes|1|1.9|73.1||
||>3 Outcomes|14|26.9|100.0||
||It is not in<br>accordance with|35|67.3|67.3|1.88|
|Matching Questions to|Less Suitable|2|3.8|71.2||
|Achievements||||||
||Appropriate|1|1.9|73.1||
||Very Appropriate|14|26.9|100.0||
|Assessment Rubric|None|38|73.1|73.1|1.58|
||Incomplete|4|7.7|80.8||
||Complete|4|7.7|88.5||
||Very Complete|6|11.5|100.0||
|OBE Learning Model|None|36|69.2|69.2|1.84|
||Part of the|2|3.8|73.1||
||Meeting|||||
||Ada|1|1.9|75.0||
||Blended Learning|13|25.0|100.0||
|Portofolio|None|11|21.2|21.2|2.71|
||Incomplete|11|21.2|42.3||
||Complete|12|23.1|65.4||
||VeryComplete|18|34.6|100.0||



Source: Research results based on data processed using SPSS 25, 2025 

Table 1 presents an analysis of lecturers' comprehension of the design of Outcome-Based Education (OBE) assessments. Regarding the correlation between Graduate Learning Outcomes (GLO) and Course Learning Outcomes (CLO), a substantial majority of respondents exhibited a strong understanding, with 76.9% indicating a high level of comprehension, as evidenced by an average score of 2.75. The alignment between CLOs and Sub-CLOs also produced highly satisfactory results, with 96.2% of respondents rating it as highly appropriate, yielding an average score of 2.96. These findings suggest that lecturers have effectively deconstructed CLOs into Sub-CLOs. However, the alignment of assessment techniques for evaluating CLO achievement remains suboptimal. Specifically, 30.8% of respondents indicated that the assessment techniques are less appropriate. In comparison, 42.3% found them appropriate, and 26.9% considered them very appropriate, with an average score of 1.96, indicating a need for improvement in this area. 

Regarding the comprehensiveness of assessment components, over half of the respondents (55.8%) reported that the components are incomplete, with an average score of 1.50, highlighting a significant weakness in the planning and documentation of assessments within the OBE framework. In terms of assessment types, most lecturers employ two to three types. Regarding assessment weighting, the majority of respondents (78.8%) have established detailed, comprehensive assessment weights, suggesting that grading arrangements are generally well-structured. Formative assessment is the most frequently utilized type (67.3%), 

56 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

whereas diagnostic assessment is seldom applied. Regarding learning outcomes, most lecturers employ two or more outcomes, although some have not explicitly documented them. The alignment of test items with learning objectives indicates that most respondents perceive them as not entirely appropriate. 

Furthermore, the development of comprehensive grading rubrics remains limited, as most lecturers have not yet created them. In the implementation of OBE-based learning models, most respondents have not consistently applied these models in their teaching practices. Conversely, the use of portfolios shows more favorable results, although completeness levels vary. 

The following presents the mean scores, percentages, and frequency distribution. To determine the level of alignment between the assessment and the learning outcomes, this can be observed in the following graph: 

## **Average Value of Each Aspect** 



<!-- Start of picture text -->
Portfolio 2,71<br>OBE Learning Model 1,84<br>Assessment Rubric 1,58<br>Alignment of Questions with Learning Outcomes 1,88<br>Type of Outcome 2,42<br>Type of Assessment 1,4<br>Assessment Weighting 1,79<br>Form of Assessment 2,27<br>Assessment Components 1,5<br>Assessment Technique & Relationship with Course… 1,96<br>Relationship between Sub-CLOs and CLOs 2,96<br>Relationship between Program Learning Outcomes… 2,75<br><!-- End of picture text -->

**Figure 1.** Average Score of Lecturers' Understanding of OBE-Based Assessment Design 

The average score graph for each aspect indicates that lecturers' understanding of the linkage between the Intended Learning Outcomes and Course Learning Outcomes, as well as the connection between Course Learning Outcomes and Sub- Course Learning Outcomes, falls within the high category, with mean scores approaching three, According to the assessment scale employed in this study, a mean score approaching 3 signifies a high level of understanding, suggesting that these elements of curriculum planning are already well comprehended. This suggests that the aspect of curriculum planning is already well comprehended. However, aspects of assessment, such as assessment types, components, rubrics, and weighting, remain relatively low, with average scores below 2. This condition indicates that although lecturers' conceptual understanding is relatively strong, the technical application, particularly in the development of assessments and evaluation instruments, still requires improvement to ensure a more optimal implementation of Outcome-Based Education (OBE). 

The results of the Spearman's correlation test indicate a significant positive relationship between the alignment of learning assessments and OBE achievements. The correlation coefficient of 0.570 with a significance value of 0.000 < 0.01 demonstrates that the higher the level of assessment alignment, the greater the OBE achievement attained. Thus, well-designed and properly aligned assessments contribute significantly to achieving outcome-based learning. 

**Table 2.** Spearman's Correlation Test Results 

57 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

|Spearman's rho||Suitability Assessment Learning|OBE<br>Achievement|
|---|---|---|---|
|Suitability of<br>Learning|Correlation Coefficient|1.000|0.570|
|Assessment|Sig. (2-tailed)|.|0.000|
||N|52|52|
|OBE Achievement|Correlation Coefficient|0.570|1.000|
||Sig. (2-tailed)|0.000|.|
||N|52|52|



Source: Research results based on data processed using SPSS 25, 2025 

### **Qualitative Research Results** 

### **_Implementation of Assessment in the Learning Process and Lecturers' Perspectives_** 

The implementation of assessment in the learning process is a crucial stage to ensure the attainment of Outcome-Based Education (OBE) as mandated in the _Merdeka Curriculum_ . Assessment is not merely a final evaluation instrument but also an integral part of learning strategies aimed at achieving the Intended Learning Outcomes (ILO). Accordingly, the success of assessment implementation largely depends on lecturers' understanding, readiness, and perspectives in designing and conducting evaluations that align with curricular objectives. Lecturers' viewpoints serve as a decisive factor, as they are directly involved in linking assessment planning with classroom practices, thereby enabling assessments to provide a tangible depiction of students’ competency attainment. 

Most lecturers demonstrated a moderate to high level of understanding regarding the alignment between Program Learning Outcomes (CPL), Course Learning Outcomes (CPMK), and Sub-CPMK. Lecturers from education-based programs, such as Mathematics Education and Early Childhood Islamic Education, reported greater familiarity with outcome mapping due to prior exposure to curriculum workshops. One lecturer noted: 

“ _We already understand that CPMK must be derived from the program learning outcomes, and sub-CPMK helps make them measurable” (_ Lecturer, Mathematics Education _)._ 

However, lecturers from several non-education programs described their understanding as procedural rather than conceptual, indicating that alignment was often carried out to meet administrative requirements rather than pedagogical intent. This suggests a variation in depth of understanding across programs. 

In terms of assessment techniques, lecturers predominantly relied on summative assessments, including midterm and final examinations, quizzes, and written assignments. Formative assessment was present but generally low in intensity and structure. Lecturers who attempted formative approaches often implemented them informally, such as summaries or reflective papers, without clear indicators linked to CPMK. 

_“We do give assignments during the semester, but they are not always tied to specific learning outcomes” (_ Lecturer, Islamic Education). 

This indicates that assessment alignment exists on a partial level, where assessments measure learning activities but not necessarily intended outcomes systematically. The degree of completeness of assessment components within the Semester Learning Plan (RPS) also varied. Some lecturers provided relatively detailed descriptions of assessment methods but lacked explicit indicators, instruments, or weighting schemes. Others, particularly lecturers who had previously participated in OBE mentoring programs, assessed components more comprehensively. 

Regarding assessment weighting, several lecturers admitted that weighting decisions were based on convention rather than outcome priority: 

_“The weights are usually based on institutional guidelines, not specifically adjusted to each CPMK”_ (Lecturer, Sharia Economics). 

This finding shows that the alignment of assessment weighting varies from minimal to moderate, rather than being strictly outcome focused. The utilization of assessment rubrics was inconsistent among lecturers 

58 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

and programs. Some lecturers created simple rubrics for projects or presentations, but many did not incorporate them into their RPS, citing time constraints and limited assessment literacy. 

_"We can assess students directly without a rubric, so it is not always necessary."_ (Lecturer, Sharia Economics). 

Portfolio-based assessment showed a similar pattern. A small number of lecturers implemented portfolios comprehensively to track student progress, while others included portfolios in name only or omitted them entirely. Overall, the portfolio system remains at an early stage of development. Regarding student learning outcomes, most lecturers reported producing two types of outcomes per course, typically in the form of reports or papers. Only a limited number of lecturers, mostly from applied or education-oriented programs, reported producing more diverse and applied outputs, such as projects or case analyses. 

The implementation of learning models supporting OBE, such as Project-Based Learning (PjBL) or CaseBased Learning (CBL), was generally low to moderate. Most lecturers still relied heavily on lectures and discussions, while only a few used blended or student-centered models experimentally. 

_"We have heard about PjBL and CBL, but we are not confident yet in applying them fully."_ (FGD participant, IAIN Lhokseumawe). 

Overall, the qualitative findings indicate that while lecturers' conceptual understanding of outcome alignment is relatively well established, the implementation of OBE-aligned assessment remains uneven. Challenges include limited variation in assessment techniques, incomplete assessment components, inconsistent use of rubrics, unclear weighting mechanisms, modest learning outputs, reliance on conventional learning models, and underdeveloped portfolio practices. These challenges vary in intensity across study programs and individual lecturers. Lecturers consistently emphasized the need for structured mentoring, hands-on training, and institutional support to strengthen assessment literacy and ensure that assessment practices genuinely reflect OBE principles rather than merely fulfilling curricular formalities. 

### **DISCUSSION** 

This study uncovers a significant gap between lecturers' understanding of Outcome-Based Education (OBE) and its practical application, especially in assessment methods at IAIN Lhokseumawe. Although most lecturers understand the hierarchical relationships among Program Learning Outcomes (PLO/CPL), Course Learning Outcomes (CLO/CPMK), and Sub-CLO (Sub-CPMK), this knowledge is not consistently reflected in the assessment designs that genuinely evaluate learning achievements. This gap suggests that OBE is more thoroughly integrated into curriculum documentation than into teaching and assessment practices. From an Outcome-Based Education (OBE) perspective, alignment among learning outcomes, activities, and assessments is fundamental (Ansari, 2025; Sudarshan et al., 2025). The high rate of lecturers reporting strong alignment between CPL–CPMK and CPMK–Sub-CPMK suggests that outcome mapping has become a common practice, likely influenced by institutional policies and accreditation standards. However, qualitative data shows that for some educators, this alignment remains more procedural than pedagogical, serving mainly as an administrative task. This aligns with earlier OBE research, which found that lecturers often follow outcome-mapping formats without fully understanding their teaching implications. 

A critical issue identified in this study is the limited diversity of assessment techniques. The dominance of summative assessment reflects a traditional assessment paradigm that prioritizes grading over learning improvement. In OBE, formative assessment plays a crucial role in providing continuous feedback and supporting competency development. The low average score for assessment technique alignment (mean = 1.96) indicates that assessments remain only weakly aligned with specific CLO indicators. This condition limits the capacity of assessment to function as a learning tool rather than merely a measurement instrument. 

Additionally, the incomplete assessment components, such as indicators, instruments, rubrics, and weighting schemes, reveal a deficiency in lecturers' assessment literacy. Rubrics play a crucial role in OBE by converting intangible learning outcomes into clear, measurable performance criteria. The lack of rubrics in the majority of RPS documents (73.1%) implies that assessment judgments remain mostly subjective, which conflicts with the core principles of transparency, accountability, and consistency promoted in OBE curricula. 

59 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

The disconnect between exam questions and learning outcomes further emphasizes this concern. The high percentage of exam questions classified as misaligned (67.3%) indicates that learning outcomes have not been sufficiently operationalized into measurable indicators. This finding suggests that although learning outcomes are officially stated, they are not yet effectively used as a reference framework for assessment development. As a result, assessments fail to capture the intended competencies, especially higher-order thinking and applied skills. Regarding learning outputs, the predominance of written reports and papers reflects a narrow view of learning achievement. Outcomes-Based Education (OBE) emphasizes the production of diverse and authentic outputs that demonstrate students' competencies in real or simulated contexts. The limited adoption of innovative learning models, such as Project-Based Learning (PjBL) and Case-Based Learning (CBL), impedes the development of these outputs. This indicates that assessment limitations are closely linked to instructional practices, as innovative assessments require corresponding learning models that support active and student-centered learning. 

Portfolio assessment remains underdeveloped despite its significance in OBE for documenting long-term competency growth. Its inconsistent and partial use points to institutional and individual challenges, like time constraints and limited technical support. Without systematic portfolio adoption, lecturers miss an essential tool for monitoring students’ progress across learning outcomes. Notably, Spearman’s correlation analysis shows a moderate, statistically significant relationship (r = 0.570; p < 0.01) between assessment alignment and OBE achievement. This supports the idea that assessment quality strongly influences outcome attainment. However, the correlation also reveals that assessment alignment alone cannot fully explain OBE success, suggesting that other factors, such as teaching strategies, student involvement, institutional backing, and learning resources, also play a role. Therefore, this relationship should be viewed critically rather than as direct causation. 

The results of this study align with previous research, which emphasizes that the main obstacle to implementing OBE lies in assessment, not in formulating learning outcomes. Studies by Ahmed (2025), Setiono, Sistiana Windyariani (2023), and Kiggundu et al. (2025) show that the dominance of summative assessment, the lack of rubrics, and the weak connection between exam questions and learning outcomes reflect low assessment literacy among lecturers. These findings are also consistent with Ali & Jamin (2025) and Mahrishi et al. (2025), who highlight that OBE often stops at the administrative level without translating learning outcomes into measurable indicators and instruments. Additionally, the limitations in applying innovative learning models such as PBL and PjBL, as reported by Shi (2025) and Dien Nur Chotimah, et all., (2025) Dien Nur Chotimah et al. (2025), further restrict the development of authentic assessments. Therefore, this research supports previous findings that the success of OBE heavily depends on increasing lecturers' capacity to design rubric-based assessments and integrate them with active learning models. 

Overall, this study contributes to the OBE literature by showing that conceptual compliance does not automatically lead to practical implementation. Although lecturers at IAIN Lhokseumawe have internalized mainly the structure of outcome alignment, significant gaps persist in assessment design, execution, and integration with learning models. These findings underscore the need for systematic capacity-building programs, including hands-on workshops, mentoring, and communities of practice explicitly focused on assessment literacy rather than on curriculum formatting alone. This study is not without limitations. The sample size is limited to one institution, and reliance on self-reported questionnaire data may introduce response bias. 

Additionally, student perspectives and actual assessment artifacts were not analyzed. Future research should therefore involve multi-institutional studies, include document analysis of assessment instruments, and incorporate evidence of student learning to provide a more comprehensive evaluation of OBE implementation. Such studies would further strengthen the empirical foundation for improving outcomebased assessment practices in higher education. 

60 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

### **CONCLUSION** 

This study finds that while the alignment of Graduate Learning Outcomes, Course Learning Outcomes, and Sub-Course Learning Outcomes within the OBE-focused Merdeka Curriculum at IAIN Lhokseumawe has been structurally established during curriculum planning, significant gaps remain in the practical application of assessment practices. Currently, assessment mainly relies on Mid-Semester and Final Examinations, indicating that Outcome-Based Education principles have not yet been fully embraced as a guiding pedagogical framework for daily teaching and assessment decisions. Empirical evidence shows a gap between formal outcome mapping and actual assessment practices, thereby addressing and narrowing the research gap on OBE implementation in Islamic higher education institutions, which has been underexplored in previous research. The strong positive link between assessment alignment and achievement of learning outcomes underscores assessment’s critical role in OBE. However, this connection also shows that alignment alone is not enough without pedagogical change. Qualitative data reveal that limited assessment variety, the lack of rubric-based evaluation, and the absence of authentic tasks hinder the credible achievement of outcomes. These findings highlight that, in Islamic higher education, where curriculum reform often intersects with tradition and resource constraints, OBE implementation requires ongoing pedagogical capacity building, not just policy compliance. The practical implications are strategic, suggesting that IAIN Lhokseumawe should develop structured mentoring focused on discipline-specific assessment design, rubric creation, and outcome-focused learning models. Creating standardized yet adaptable assessment rubrics, peer-reviewed Semester Learning Plans, and outcome-tracking tools embedded in internal quality systems are steps toward stronger OBE in religious higher education. This study has limitations: it was conducted at a single Islamic institution, limiting generalizability; it mainly relied on document analysis, self-reports, and lecturer perspectives, without classroom observation or student performance data; and its cross-sectional design does not capture changes over time. Future research should use longitudinal designs to study how mentorship and professional development influence assessment practices within OBE. Further studies should explore authentic assessment methods like Project-Based Learning (PjBL) and Case-Based Learning (CBL) in Islamic educational contexts and use digital analytics to track learning outcomes. Comparative studies between Islamic and non-Islamic universities are also recommended to understand how contextual factors affect the effectiveness of OBE-based assessment in Indonesia. 

### **REFERENCES** 

- Ahmed, F. (2025). Outcomes-Based Education (OBE) Implementation Challenges and Solutions: A Case Study Using the Exit Outcomes Strategy. _Center for Open Science_ . https://doi.org/10.35542/osf.io/a6chy_v1 

- Ali, R., & Jamin, H. (2025). Curriculum Development Strategy Based on Outcome-Based Education (OBE) to Improve the Quality of Education in Higher Education. _Journal of Education and Religious Studies (JERS)_ , _05_ (02). https://doi.org/http://dx.doi.org/10.57060/jers.s9w3x850 

- Ansari, M. A. (2025). Artificial Intelligence-Powered Learning Analytics and Student Feedback Mechanisms for Dynamic Curriculum Enhancement and Continuous Quality Improvement in Outcome-Based Education. _RADemics Research Institute_ , 339–366. https://doi.org/10.71443/9789349552531-13 

- Arifin, S., & Muslim, M. (2020). Tantangan Implementasi Kebijakan “Merdeka Belajar, Kampus Merdeka” Pada Perguruan Tinggi Islam Swasta Di Indonesia. _Semantic Scholar_ . https://doi.org/10.32529/ALILMI.V3I1.589 

- Damanik, S. A., Damanik, S., Chairad, M., & Husna, A. (2024). Buku Elektronik Scouting Education Berbasis Kurikulum Outcome Based Education ( OBE ) Di Fakultas Ilmu Keolahragaan Scouting Education Electronic Book Based on Outcome Based Education ( OBE ) Curriculum at the Faculty of Sports Science. _Jurnal Prestasi_ , _8_ (2), 85–91. 

- Dien Nur Chotimah, Makhiulil Kirom, Khafid Roziki, M. A. (2025). Outcome-Based Education (OBE) Curriculum: Implementation in the Arabic Language and Literature Study Program. _Tadris: Jurnal Keguruan Dan Ilmu Tarbiyah_ , 369–382. https://doi.org/10.24042/tadris.v10i1.25279 

- Erdiana, N., & Yasin, B. (2019). Exploring Students ’ Perceptions of Project-based Learning in An OutcomeBased Education ( OBE ) Curriculum Framework. _Proceedings Of International Conference On Education Teacher Training & Education Faculty Universitas Serambi Mekkah_ , 15–20. 

61 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

Ishaq, U. M., Wicaksono, M. F., & Nurhayati, S. (2023). Aplikasi Probe Untuk Penilaian Capaian Pembelajaran Mahasiswa Pada Kurikulum OBE (Outcome-Based Education ) Probe Application for Assessment of Student Learning Outcomes in the OBE Curriculum (Outcome-Based Education ). _Komputika: Jurnal Sistem Komputer Volume_ , _12_ (148), 187–194. https://doi.org/10.34010/komputika.v12i2.9763 

- Kiggundu Musoke Muhammad, John Kalule, B. M. S. (2025). An Analysis of Teachers’ Insights on Assessment Approaches in the Implementation of a Competency-Based Curriculum for Islamic Religious Education in Secondary Schools in Wakiso District – Uganda. _East African Journal of Education Studies_ , _8_ (1), 362–374. https://doi.org/10.37284/eajes.8.1.2693 

- Li, W., Liu, A., & Huang, C. (2025). Research on Outcome-Based Education ( OBE ) in Software Engineering Curriculum Reform. _Angus Academic Press_ , 140–143. https://doi.org/10.70114/aimedr.2025.2.1.P140 

Lubis, S., Siregar, R., & Sari, A. (2025). Media Development in Teaching Listening using Podcasts Based on Outcome-Based Education (OBE). _ICIESC 2024,_ . https://doi.org/10.4108/eai.17-9-2024.2352869 

- Mahrishi, M., Ramakrishna, S., Hosseini, S., & Abbas, A. (2025). A systematic literature review of the global trends of outcome-based education ( OBE ) in higher education with an SDG perspective related to engineering education. _Discover Sustainability_ . https://doi.org/https://doi.org/10.1007/s43621-02501496-z 

Nesa Novrizal, R. R. M. (2025). Design Curriculum Based on Outcome-Based Education (OBE): Preparing Work-Ready Graduates. _Journal of Islamic Education_ , _4_ (1), 374–384. https://doi.org/https://doi.org/10.61159/edukasiana.v4i1 

- R, A. K. B. (2023). Handbook of Outcome-Based Education Model (OBE): Best Practices and Formats for OBE Implementation in Technical Higher Education Programs. _International (a Part of SCIENCEDOMAIN International)_ . https://doi.org/10.9734/bpi/mono/978-81-19315-93-2/ch0 

Rahmaniati, R., Rosawati, P., Purnama, A., Education, T., Training, T., Kalimantan, C., & Kalimantan, C. (2024). Pelatihan Pembuatan RPS Berbasis OBE bagi Dosen Fakultas Pertanian dan Kehutanan Universitas Muhammadiyah Palangkaraya. _PengabdianMu: Jurnal Ilmiah Pengabdian Kepada Masyarakat_ , _9_ (8), 1458– 1463. https://doi.org/https://doi.org/10.33084/pengabdianmu.v9i8.7541 

Rahmawati, Z. D., & Wahyuni, S. (2024). Pengembangan Kurikulum Pendidikan Islam Multikultural Berbasis Outcome-Based Education. _Ta’lim : Jurnal Studi Pendidikan Islam_ , _7_ (2), 218–236. 

Rustam, R., & Priyanto, P. (2022). Pembelajaran Tamadun Melayu Jambi Berbasis Outcome-Based Education (OBE) Berorientasi Produk Kreatif. _Diglosia: Jurnal Kajian Bahasa, Sastra, Dan Pengajarannya_ , _null_ , null. https://doi.org/10.30872/diglosia.v5i2.284 

Sanaj M S, M. M. B. (2025). Artificial Intelligence-Powered Learning Analytics and Student Feedback Mechanisms for Dynamic Curriculum Enhancement and Continuous Quality Improvement in OutcomeBased Education. _RADemics Research Institute_ , 394–420. https://doi.org/10.71443/9789349552531-15 

Setiono, Sistiana Windyariani, A. J. (2023). Implementasi Sistem Penilaian Berbasis Outcome-Based Education di Perguruan Tinggi. _Jurnal Pendidikan_ , _11_ (1), 1–9. 

Shi, W. (2025). Integrating Outcome-Based Education (OBE) and Problem-Based Learning (PBL) in Psychiatric Clinical Practice Teaching : An Empirical Study. _Research Article Keywords:_ , _3_ , 1–15. https://doi.org/https://doi.org/10.21203/rs.3.rs-7223072/v1 

Silitonga, P. D. P., Damanik, R., Siagian, N. A., & Sahputra, H. (2025). Workshop Rubrik Penilaian Berbasis OBE dan Implementasi Kurikulum OBE. _ULEAD: Jurnal E-Pengabdian_ , _4_ , 84–87. http://ejournal.ust.ac.id/index.php 

Simatupang, E., & Yuhertiana, I. (2021). Merdeka Belajar Kampus Merdeka terhadap Perubahan Paradigma Pembelajaran pada Pendidikan Tinggi: Sebuah Tinjauan Literatur. _Jurnal Bisnis, Manajemen, Dan Ekonomi_ , _null_ , null. https://doi.org/10.47747/JBME.V2I2.230 

Siregar, N., Sahirah, R., & Harahap, A. A. (2020). Konsep Kampus Merdeka Belajar di Era Revolusi Industri 4.0. _Fitrah: Journal of Islamic Education_ , _null_ , null. https://doi.org/10.53802/fitrah.v1i1.13 

Sudarshan Balasaheb Babar, S. S. R. (2025). Transforming Outcome-Based Education with Social Media Strategies and AI-Driven Digital Marketing for Personalized Learning and Institutional Growth. _RADemics Research Institute_ , 91–118. https://doi.org/10.71443/9789349552685-04 

Ware, Y., Putri, H. E., Education, G., Indonesia, U. P., History, A., & Outcome-based, T. (2025). Transformation Of Geography Education In The Digital Era: Evaluation Of Geography Teacher Readiness Through Outcome-Based Education (OBE) Approach. _GeoEco_ , _11_ (2), 575–592. https://doi.org/https://doi.org/10.20961/ge.v11i2.96827 

Wenjie Shi, Xiangsong Shi, Lirong Zhuang, Tingting Zhu, Gongyin Li, C. H. (2025). Integrating Outcome- 

62 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

Based Education (OBE) and Problem-Based Learning (PBL) in psychiatric clinical practice teaching: an empirical study. _BMC Medical Education 25 (1), Springer Science and Business Media_ . https://doi.org/10.1186/s12909-025-08212-5 

63 **|** Jurnal Eduscience Volume 13, No.1 (2026) 

