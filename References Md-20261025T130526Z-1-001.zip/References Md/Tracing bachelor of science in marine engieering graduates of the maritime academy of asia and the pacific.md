




MAAP Research Journal Page 15

Tracing Bachelor of Science in Marine Engineering Graduates of the
Maritime Academy of Asia and the Pacific


C/E Jesus Mendoza
## 1
## , Caroline Dacwag
## 2
& 3/E Kid Arthur Poncardas
## 3
Office of the Assistant Dean, Academic Research Unit & Academic Supervisor’s Office-
Department of Academics
Maritime Academy of Asia and the Pacific


Abstract: Graduates are one of the best sources
of   vital   information   on   how   the   curriculum
being   offered   by   an   institution   is   faring.
Likewise,  they  help  in  strengthening  the  system
of  their  institute  and  developing  further  the
services    of    those    institutions    to    ensure
responsiveness    and    competitiveness    in    the
global market. These vital pieces of information
provided  by  the  graduates  are  obtained and
appropriately     categorized     and     interpreted
through  graduate  tracer  studies.  Tracer  studies
help   in   collecting   relevant   information   that
helps    the    institutions    know    where    their
graduates  are,  particularly  their  employment
status.    Moreover,    tracer    studies    help    in
determining  other  factors  that  might  affect  the
employability  of  the  graduates.  In  this  context,
this  project  was  undertaken  to  determine  the
status  of  the  Bachelor  of  Marine  Engineering
graduates of the Maritime Academy of Asia and
the  Pacific  from  2003-2012.  In  particular,  it
aims  to  describe  the  effect  of  the  personal  and
educational  variables  on  the  employability  of
MAAP BSMarE alumni. Using survey forms, the
marine  engineering  graduates  of  MAAP  were
found  to  be  employed.  Most  of  these  graduates
had their employment through the job placement
office   of   MAAP.   Moreover,   the   respondents
started  working  less  than  three  months  to  12
months after graduation as officers in charge of
the     engine     watchkeeping.     Finally,     these
respondents  think  that  all  the knowledge  and
skills  provided  by  the  Academy  are  relevant  to
their present job with the technical skills having
the highest relevance.

Keywords: employability status, MAAP
engineering graduates
## 1. Introduction
Employability  of  graduates  is  the  primary
aim  of  any  higher  educational  institution  (HEI).
It  is  for  this  concern  that  these  educational
institutes  design  their  curricula  and  decide  on
the  knowledge  and  skills  to  be  developed.  In
considering    employability,    HEIs    need    to
account  for  the  global  and local  market,  the
specific  requirements  of  each  program  offered
and  the  process  of  enabling  the  students  to
acquire the knowledge and skills required by the
two. According to Yorke (2001) and Knight and
Yorke    (2001)    as    cited    by    Lees    (2002),
employability has two main concepts, and these
are   the   acquisition   of   the   graduates   of   the
necessary  knowledge  and  skills  to  be  employed
and   their   ability   to   get   a   job.   Also,   the
graduates’ knowledge and skills must match the
employers’  expectation  of  contribution  for
“effective  functioning  of  their  organization”
(Harvey, 1997 as cited by Lees, 2002).
One  of  the  most  common  and  probably  the
most  effective  way  to  determine  the  status  of
graduates     and     the     relationship     of     their
educational   training   with   their   employment
status is the graduate tracer studies.
Since   2003,   when   the   first   batch   of   the
Maritime   Academy   of   Asia   and   the   Pacific
(MAAP)  graduated,  no  documentation  has  been
carried   to   track   the   whereabouts   of   these
graduates;  hence  the  conceptualization  of this
endeavor.  This  paper  primarily  aims  to  profile
the  Marine  Engineering  graduates  of  MAAP
from 2003-2012 and at the same time, assess the
relevance  of  their  training,  and  knowledge  and
skills to their present job.
1.1. Statement of the Problem
The  study  primarily  aims  to  address  how  the
personal  and  educational  variables  may  affect
the   employability  status  of  the  graduates  of
Bachelor   of   Science   in   Marine   Engineering
(BSMarE)  at  the  Maritime  Academy  of  Asia
and   the   Pacific   (MAAP),   Mariveles,   Bataan
from 2003 to 2012.
## F-020
## Issue 0 Rev. 0
## 15 January 2016
## MARITIME ACADEMY OF ASIA AND THE PACIFIC
## KAMAYA POINT
Associated Marine Officers’ and Seamen’s Union of the Philippines – PTGWO - ITF
## Kamaya Point, Brgy. Alas-asin, Mariveles, Bataan




MAAP Research Journal Page 16


Specifically,  the  study  aims  to  answer  the
following questions:
- What   is   the   profile   of   the   respondents
considering the following:
## 1.1 Personal    Variables:    Sex,    Age,
## Civil   Status,   Religion,   Urbanity
(location),  Dialect,  and  Region  or
origin; and
1.2 Educational Variables:Year of
graduation; OIC licensure
examination performance; Reasons
for taking the course; Adequacy of
educational     preparation     before
college,  and;  Study  provisions  and
study conditions experienced?
- How   do   the   respondents   perceive   the
relevance   of   the   skills   and   knowledge
acquired at MAAP in their respective job?
- How  may  the  status  of  employability  of  the
respondents  be  described  considering  the
following:
3.1  Current occupation;
3.2  Approaches to getting first
seagoing jobs;
3.3 Waiting  time  on  first  seagoing  job
placement after graduation;
3.4 Average   length   of   service   per
embarkation;
3.5 Initial Position held on board
3.6 Present Position/s held on board;
3.7 Current license/rank;
3.8 Initial  gross  monthly  salary  in  the
first job;
3.9 Present salary, and;
## 3.10 Professional Success?
- Are    there    profile    variables    that    are
significantly  associated  with  the  status  of
employability of respondents?
- Is  there  a  significant  relationship  between
the   relevance   of   skills   and   knowledge
acquired from the academy and the status of
employability of the respondents?

## 1.2.  Literature Review

The    succeeding    paragraphs    present    the
findings  of  past  studies  conducted  in  different
fields.   These   findings   are   used   as   bases   in
identifying areas and findings where the present
study   is   similar   with.   In   the   same   manner,
contrasts were also noted.

Martin,   Lang-ay,   and   Guidangen   (2015)
traced the Bachelor of Arts in History graduates
of   the   Kalinga-Apayao   State   College.   They
found  that  84  out  of  98  are  employed  with  32
working  in  the  government,  35  in  the  private
sector,   3   OFWs   and   14   self-employed.   The
same   study   also   found   that   most   of   the
respondents  secured  a  job  less  than  one  year
after  graduation.  However,  second  in  rank  was
that other respondents landed in a job four years
and above after graduation. The others had their
jobs one to three years after graduation.

In Hotel and Restaurant Management (HRM)
field,  Fronda  and  Villanueva  (2015)  focused  on
the  employed  HRM  graduates  in  determining
the  employment  potential  as  indicated  by  job
movement and the relevance of the graduates’
positions to their field of study. The respondents
were found to be both locally and
internationally  employable  with  some  of  them
securing  immediate  employment  abroad  after
graduation  and  the  academic  achievers  being
mobile  in  their  jobs.  These  graduates  have  a
good  perception  of  their  degree  program,  and
they  believe  that  they  have  learned  the  relevant
hospitality  industry  knowledge  and  skills  from
the curricular offering of the school.

Outside   the   Philippines,   Rupande   (2015)
conducted a tracer study on the 140 graduates of
Zimbabwe  Open  University  to  determine  the
adequacy  of  the  diploma  and  degree  programs
offered by the said university about the needs of
the work force. The  study found that 120 of the
graduates  are  employed,  and  80  of  them  are
employed full time in government agencies. The
respondents  reasoned  that  they  enrolled  in  the
university  because  of  the  flexible  schedule,  and
accessible and flexible education.

Cañizares (2015) focused on the Science and
Mathematics    Education    graduates    of    the
University  of  San  Carlos  in  his  tracer  study.  He
determined  the  relevance  of  the  curriculum  to
the   needed   teaching   manpower   and   to   the
implementation of the k-12 program. The author
found that most of the 43 respondents passed the
licensure exam for teachers and are permanently
employed.   Regarding   the   relevance   of   the
curriculum,    the    respondents    indicated    the
subjects  sequencing  as  the  best  aspect.  Also,
they mentioned working with others as the most
helpful trait developed by the University.





MAAP Research Journal Page 17

In  another  area  of  teacher  education,  Gines
(2014) conducted a tracer study on the graduates
of the Philippine Normal University. The author
discovered  that  PNU  graduates,  who  are  mostly
female,  enrolled  in  the  university  because  of  its
affordability   and   because   of   its   reputation.
Many    of    these    graduates    were    employed
immediately  after  their  application.  According
to   the   respondents,   PNU   very    adequately
provided  the  necessary  skills  like  knowledge
and  technical,  communication,  human  relations,
leadership,  research,  problem  solving  and  other
relevant  competencies.  Further,  these  graduates
are  highly  satisfied  with  the  university’s
services, learning environment and facilities.

Nursing  graduates  in  Davao  Doctors  College
were  the  respondents  of  Pia,  Matunding  and
Salvador  (2014)  when  they  conducted  a  tracer
study.  They  aimed  to  profile  their  graduates
based  on  their  employability,  job  status,  type  of
employment,  monthly  income  and  employer’s
information.  They  also  included  the  perspective
of   the   nursing   graduates   on   the   academic
program,  facilities  and  the  impact  of  teaching
and    learning    process    experienced    in    the
institution.  The  study  found  that  most  of  the
graduates   are   licensed   already   and   regularly
employed   as   staff   nurses.   Considering   their
preparation, the respondents identified
communication  skills,  human  relations,  critical
thinking   and   problem-solving   as   relevant   in
their getting a job.

Ramirez,     Cruz     and     Alcantara     (2014)
determined the  relationship between the field of
specialization of Rizal Technological University
(RTU) graduates and the skills and
competencies  they  acquired  from  school.  The
study  found  that  these  skills  and  competencies
had  a  great  contribution  to  their  performance  in
their jobs, and are therefore relevant.

In  the  field  of  information  technology  (IT),
Balingbing (2014) focused on the employability
of  IT  graduates  of  Camarines  Sur  Polytechnic
Colleges, Nabua, Camarines Sur and discovered
that  the  graduates,  who  are  mostly  female,  are
20-25    years    old,    and    TESDA    certified.
Moreover,  graduates  of  the  school  year  2003-
2004  were  found  incompetent  in  knowledge,
skills,   and   attitudes   while   the   rest   of   the
graduates  were  competent  in  the same  areas.
Lastly, the level of competence of the graduates
had    no    significant    relationship    with    the
difficulties encountered in the university.

Celis,  Festijo,  and  Cueto  (2013)  studied  the
employability  of  the  graduates  of  Hotel  and
Restaurant   Management   of   the   Lyceum   of
Philippines  University  from  2005-2009.  They
found   that   majority   of   the   graduates   are
employed  and  had  a  job  one  to  two  years  after
they   had   graduated.   These   graduates   also
considered  human  relations  and  communication
skills  the  most  useful  competencies  they  had
learned   from   school.   For   the   school   related
factors,  they  identified  the  faculty  members’
communication  and  mastery  skills  as  the  most
important.

In  the  maritime  field,  two  studies  are  cited.
Orence    and    Laguador    (2013)    traced    the
maritime graduates of Lyceum University of the
Philippines University. They found that most of
their  respondents  are  employed  in  maritime-
related  jobs.  On  the  other  hand,  Estimo  (2012)
tracked down the maritime graduates of John B.
Lacson-Bacolod.  She  discovered  that  most  of
the  alumni  were  working  as  ordinary  seamen,
and some of them did not reach the highest rank
even  after  17  years  after  graduation.  The  study
is    very    relevant    though    because    of    its
recommendations  related  to  improved  maritime
education and training.

## 1.3. Conceptual Framework

The  figure  below  illustrates  the  relationship
between  the  variables  of  the  study.  The  main
focus,  the  status  of  MAAP  BSMarE  graduates,
is  related  to  their  profiles  and  the  skills  and
knowledge  acquired by  the  respondents  when
they  were  in  the  academy.  This  way,  it  can  be
determined     whether     these     pre-determined
factors  have  an  association  with  and  effect  to
where the graduates are at present.

















MAAP Research Journal Page 18














Figure 1. Research paradigm

## 2. Methodology

This  paper  is  descriptive-survey  in  design
since  it  presents  a  picture  of  the  accumulated
132  responses  from  the  Bachelor  in  Marine
Engineering  graduates  of  MAAP  from  batch
2003   until   2012.   The   data   was   gathered
primarily  through  online  correspondence  since
most of the alumni are either on board or not in
the  academy.  Some  respondents  accomplished
the  tracer  study  form  when  they  came  to  the
academy    for    visits    or    for    the    alumni
homecoming.  Few  of  these  alumni  were  also
interviewed    when    they    did    not    feel    like
answering the form on their own.

The  data  gathered  were  statistically  treated
using mostly frequency counting and
determining  the  weighted  mean.  For  the  degree
of association, Cramer’s V was used to establish
the relationship. Overall, the data was processed
using SPSS version 18.
- Results and Discussion
3.1. Profile of the Respondents

## 3.1.1. Personal Profile

MAAP  BSMarE  graduates  are  24-39  years
old.    Seventy    one    (53.8%)    of    the    132
respondents  are  within  30-34  years  old  while
three (2.3%) are between the ages of 35 and 39.
One    hundred    twenty-eight    (97%)    of    the
respodents  are males  while the  rest are females;
59 are married while 73 are still single. Most of
the  respondents  (108  or  81.8%)  speak  Tagalog
while   the   rest   belong   to   different   language
groups.  In  terms  of  religion,  106  are  Roman
Catholics   while   the   rest   are   Protestants   in
different   sects.   In   terms   of   residence,   67
(50.8%)  live  in  the  city  while  the  rest  (65  or
49.2%)  reside  in  the  provinces.  Finally,  44  of
the  respondents  are  from  Central  Luzon,  37  are
from  CALABARZON,  12  are  from  NCR,  ten
are   from   Central   Visayas   and   the   rest   are
scattered in the different regions of the country.

## 3.1.2. Educational Experience

Most  of  the  respondents  for  the  first  five
years  are  from  the  class  of  2006  with  22  out  of
75  respondents.  This  class  is  followed  by  the
classes   of   2003   and   2005   with   17   and   15
respective   respondents.   The   least   number   of
respondents  is  from  the  class  of  2004  with  nine
respondents only.

For  the  second  group,  covering from  classes
2008   until   2012,   most   of   the   respodents
graduated  in  2011  with  20  (15.2  %)  out  of  57
respondents.  The  class  with  the  least  number  of
respondents   is   Class   2012   with   three   (3)
respondents  only  and  having  a  percentage  of
## 2.3.

3.1.3. Reasons for taking the course

The  number  one  reason of  the  graduates for
taking the course is scholarship, as evidenced by
101  (76.5%)  responses  for  this  choice.  This
reason  is  followed  by  the  hope  for  employment
right  after  graduation  with  57  (43.2%)  favoring
responses,  the  chance  of  working  abroad  with
54  (40.9%)  responses,  financial  comfort  for  the
family    (44    or    33.3%),    and    influence    of
parents/relatives  (39  or  29.5%).  The  last  reason
of  the  respondents  for  choosing  this  field  of
study is their  high grades in the courses related
to the program (6 or 4.5%) like Mathematics.

The  number  one  reason  identified  by  the
MAAP  alumni  is  in  contrast  with  the  reason  of
affordability  and  school’s  reputation  given  by
the    education    graduates    of    the    Philippine
Normal University (Gines, 2014).

3.1.4. Adequacy  of  Educational  Preparation
before Entering the Course
## Respondent’s Profile
## - Personal
## - Educational
Relevance    of    Skills
and Knowldege
Acquired from the
## Academy

Status of Employability of the Respondents
- Current occupation
- Approaches in getting first seagoing jobs
- Waiting time after graduation
- Initial position held
- Present position on board
- Current license/rank
- Initial gross monthly income in the fisrt job
- Present salary
- Professional succes





MAAP Research Journal Page 19


In  reference  to  the  question  on  whether  the
preparation  of  the  respondents  before  entering
the  academy  is  adequate  or  not,  117  (88.6%)
said  that  the  educational  training  was  adequate.
Four   or   3.0%   of   the   respondents   expressed
uncertainty  in  this  aspect,  while  11  (8.3%)  said
that they were not prepared.

## 3.1.5. Problems  Encountered  While  Studying
at MAAP

During their stay in the academy, most of the
respondents (87 or 65.9%) said that they did not
have   any   problem.   Eleven   (8.3%)   identified
homesickness  as  the  problem  encountered  most
of  the  times.  This  problem  may  be  due  to  the
situation  where  they  were  far  from  home  and
had  no  regular  communication  with  their  loved
ones.  Worse,  those  who  were  restricted  and
deficient  were not allowed to enjoy shore leave.
Following these two are academics-related (9 or
6.8%),  semi-regimented  training-related  (7  or
5.3  %),  and  adjustment  and  food  and  water
factors (6 or 4.5%).

In  the  early  years  of  operation,  MAAP  did
not have the academic probation program where
those who failed in the course/courses are given
another  chance,  so  cadets  then  had  a  lot  of
pressure  in  maintaining  their  passing  grades.
Also,  regimentation  was  so  stiff  until 2012.
Rules and regulations were strictly
implemented.  This  may  be  one  of  the  reasons
why   adjustment   was   also   mentioned   as   a
problem.  Further,  cadets  were  allowed  to  eat
three  times  a  day  only,  and  they  ate  what  was
served  to  them.  They  were  not  allowed  to  bring
or  buy  other  foods  from  outside  except  when
they   had   shore   leave   or   they   were   upper
classmen,  and  they  had  the  privilege  to  buy
limited   goods   at   the   slop   chest.   The   least
problem  encountered  is  the  lack  of  practicals  at
the laboratories. MAAP has been equipped with
state-of-the-art    facilities    where    cadets    can
practice  the  theoretical  concepts  taken  in  the
classroom.




3.1.6. Study Provisions and Study Conditions
## Experienced

Considering the teaching-learning
environment experienced by the respondents, all
of them rated this area ‘good.’ This means that
MAAP  is  doing  well  in  preparing,  training  and
involving   its   cadets   in   its   operations   and
processes.     Among     these     provisions     and
conditions,  the  respondents  rated  ‘overall
experience in the academy’ the highest mean of
4.36 and the ‘chances to participate in research
and  extension  projects’  and  ‘chances  for
students to have an impact on academy policies’
the lowest mean of 4.04.

The  semi-regimented  training  and  set-up  of
the  academy  could  be  a  factor why  the  students
do not have much chances to have an impact on
the  policies  implemented  in  the  academy.  The
Midshipman  Fleet  Regulation  (MFR)  states  all
the  acceptable  educational,  personal  and  social
(including  leadership)  practices  allowed  in  the
academy.

Gines (2014) used adequacy to rate the study
provisions  of  the  Philippine  Normal  University
(PNU),  and  found  out  that  the  school  (PNU)
adequately   provided   its   graduates   with   the
necessary   skills.   On   the   other   hand,   Celis,
Festijo,  and  Cueto  (2013)  rated  the  provisions
according to their importance. Their respondents
mentioned   that   the   faculty   member’s
communication  and  mastery  skills  are  the  most
important.

3.1.7. OIC-Engine   Watchkeeping   licensure
examination performance

From the Marine Engineering graduates from
2003  to  2012,  125  or  94.7% passed  with  80
(60.6 %) having an average between 70 and 79,
and  45  (34.1%)  averaging  between  80  and  90.
Three (2.3%) out of 132 did not pass while four
(3.0%)  either  did  not  take  the  examination  or
did not answer this question.

3.2. Relevance   of   Knowledge   and   Skills
Acquired at MAAP in Jobs

The  responses  of  the  population  on  how  the
pre-determined   factors   are   relevant   to   their
respective   jobs   are   presented were   collated.
These pre-determined factors    refer    to    the
knowledge  and  skills  offered  by  the  academy.
These  are  deemed  necessary  in  building  the
midshipmen   in   all   aspects   so   they   can   be




MAAP Research Journal Page 20

equipped for their future profession and for their
future life, in general.

Generally,  all  the  knowledge  and  skills  are
considered   relevant   by   all   the   respondents,
except for technical knowledge and skills which
are  rated  very  relevant.  Among  the  relevant
skills and knowledge, theoretical and
communication  knowledge  and  skills  got  the
lowest respective means of 4.25 and 4.32.

The relevance of the  knowledge and skills  as
perceived  by  the  graduates  of  MAAP  is  the
same  with  the  perception  of  HRM  graduates
(Fronda & Villanueva, 2015), nursing graduates
(Pia,  Matunding  &  Salvador,  2014)  and  the
graduates   of   Rizal   Technological   University
(Ramirez, Cruz & Alcantara, 2014). The finding
on  the  relevance  of  communication  skills  is  the
same  with  the  finding  of  Orence  and  Amador
(2013)  who  focused  on  the  maritime  graduates
of  Lyceum  of  the  Philippines  University  from
## 2007-2011.

3.3. Status of Employability of the Graduates

3.3.1. Occupation of Seafarers

As noted, 95 or 72% of the respondents are in
active    seafaring.    Twenty-six    (19.7%)    are
working  both  at  sea  and  on  land,  while  the  rest
of  the  population,  11  or  8.3%,  are  in  maritime
land-based  jobs,  mostly  teaching.  Of  the  total
population,  103  or  78%  are  contractual,  while
the rest (29 or 22%) are regular.

3.3.2. Approaches  in  Getting  First  Seagoing
## Job Placements

As  gathered, 10,  102  (77.3%)  graduates  are
presented to have secured their first job through
MAAP’s job placement or scholarship. Through
this  program,  graduates  were  given  sponsors
who  supported  their  education  from  their  first
year  until  their  last  year  in  the  academy.  Those
who were not able to qualify for the sponsorship
applied for one during their  first year or second
year.  The  rest  landed  on  their  jobs  through
recommendations,    information    from    others,
advertisements  or  family  business.  Two  (1.5%)
used  other  approaches  in  landing  to  their  first
job.

3.3.3. Waiting   time   on   first   seagoing   job
placement after graduation

Thirty-nine  (29.5%)  of  the  MAAP  alumni
had  to  wait  for  three  to  six  months  before
landing  a  job,  31  or  23.5%  waited  for  less  than
three  months  only,  27  (20.5%)  had  six  to  nine
months  waiting,  18  or  13.6% had  nine  to  12
months,  six  (4.5%)  had  over  one  year,  and  11
(8.3%)  did  not  indicate  how  long  they  had  to
wait.

The  length  of  time  between  graduation  and
employment, which is mostly one year or less is
similar  to  the  waiting  time  of  graduates  from
other disciplines like AB History (Martin, Lang-
ay   &   Guidangen,   2015),   HRM   (Fronda   &
Villanueva, 2015) and education (Gines, 2014).

3.3.4. Average    Length    of    Service    Per
## Embarkation

As   mentioned   earlier,   those   who   became
active  seafarers  worked  on  a  contractual  basis.
However,  the  duration  of  contract  varies  from
one  company  to  another  and  from  one  position
to    another.    As    presented,    out    of    132
respondents,   59   (44.7%)   signified   that   the
average  length  of  their  contract  is  seven  to  nine
months.  Thirty-seven  (28.0%)  usually  work  on
board from five to six months, 15 (11.4%) work
for over  nine  to  12  months  and  12  (9.8%)  work
for  less  than  five  months.  Nine  or  6.8%  of  the
respondents  did  not  mention  their  length  of
service.

3.3.5. Initial  and  Present  Positions  Held on
## Board

Ninety-four or   71.2%   of   the   respondents
boarded  their  ships  for  the  first  time  as  engine
cadets, 20 or 15.2% boarded as ratings and 17 or
12.9%  first  went  on  board  as  operational  level
officers.   One   did   not   indicate   his/her   initial
position,    explaining    the    total    number    of
responses  (131).  At  present,  out  of  these  131
respondents,  97  or  73.5%  are  in  the  operational
level  while  34  or  25.8%  are  in  the  management
level.

Though  coming  from  different  programs,  the
information on the present rank of the alumni of
the  academy  is  in  contrast  with  the  data  on  the
BSMT  alumni  of  John  B.  Lacson-Bacolod  who
are mostly ordinary seamen (Estimo, 2012).





MAAP Research Journal Page 21

3.3.6. Current license/rank

Regardless  of  positions held  on  board, 53  or
40.2% of the MAAP engineering graduates have
licenses  as  second  engineers,  51  or  38.6%  are
third    engineers,    16    or    12.1%    are    fourth
engineers,  and  six  or  4.5%  are  chief  engineers.
Six  or  4.5%  of  the  respondents  did  not  indicate
their licenses.

The license held does not equal position since
different  shipping  companies  have  their  own
policies  in  promoting  their  crew.  So  it  happens
that  even  if  the  seafarer  is  a  licensed  chief
engineer,  he may  still be  working on board as a
second or a first engineer.

3.3.7. Initial   and   Present   Gross   Monthly
Earnings as Seafarers

The respondents have varying income ranges
when  they first  boarded  their  vessel.  The  same
is  true considering  their  position  at  present.  In
relation  to  their  initial  position,  90  or  68.2%
received   below   $1,000.   Eighteen   or   13.6%
received  between  $1,501  and  $2,  000,  ten  or
7.6%  received  a  salary  between  $1,000  and  $1,
500,  seven  or  5.3%  received  $2,001  and  $2,
- One or 0.8% of the population received the
highest pay of between $4,001 and $4,500.

During the time of data gathering, 38 or 28%
of  the  population  were  receiving  over  $5,000.
Thirty-four  or  25.8%  of  the  131  respondents
were  receiving  $3,001  to  3,  500;  13  or  9.8%
were  receiving  $2,  501  to  3,000;  nine  or  6.8%
were  within  the  bracket  of  $3,  501  to  4,000;
eight  were  within  the  brackets  of  $1,000  to
1,500 and $2,001 to 2, 500. The least number of
respondents,   three,   were   receiving   a   salary
between $1, 501 to 2, 000.

## 3.3.8. Professional Success

Considering  10  factors,  the  respondents  are
satisfied  with  where  and  what  they  are  now  as
numerically represented by a composite mean of
3.92.  This  satisfaction  level  is  highly  evidenced
in    their    position    which    has    the    highest
satisfactory  mean  of  4.01.  On  the  other  hand,
awards    and    recognition    have    the    lowest
satisfaction  level,  with  a  composite  mean  of
## 3.65.

3.4. Profile     Variables     and     Status     of
## Employability

This part shows the relationship between year
graduated     variables and     the     status     of
employability    of    the    MAAP    engineering
graduates.  The  year  graduated  variables  are  the
year  and  their  age  when  they  graduated.  Also
included   here   are   the   study   provisions   and
conditions,  and  the  relevance  of  knowledge  and
skills acquired in the academy.

The  occupation of  the  marine  engineering
graduates and  their profile  variables  of  age  and
year graduated have a moderate association. The
same  is  true  for  average  embarkation  and  civil
status  and  year  graduated.  The  initial  job  level
and  age  have  a  weak  association,  while  the
initial   job   level   and   year   graduated   have   a
moderate  association.  Civil  status  and  present
job  level  have  a  moderate  association.  On  the
other hand, the latter and age and year graduated
have    a    relatively    strong    association.    The
graduates’ initial pay and their urbanity and year
of  graduation  have  a  moderate  association.  In
addition, present pay of the alumni and age have
moderate    association    also.    Their    year    of
graduation    and    their    present    pay    have    a
relatively strong association.

The  graduates’  license  and  the  study
provisions  and  conditions  of  MAAP  have  a
moderate  association.  Meanwhile,  professional
success   and  study  provisions  and  conditions
have  a  relatively  strong  association,  but   the
same  status  of  employability  and  relevance  of
knowledge    and    skills    have    a    moderate
association.

- Summary and Conclusion

This tracer  study  was  conducted  as  an  initial
effort  to  gather  information  on  the  status  of  the
graduates of the Maritime Academy of Asia and
the  Pacific.  Based  on  the  results,  most  of  the
graduate-respondents   are   gainfully   employed
with   most   of   them   still   active   in   seafaring,
holding various licenses and positions.

These    grduates    entered    MAAP    mostly
because  of  scholarship,  and  many  of  them  also
claimed  that  they  were  adequately  prepared  for
their  program.  Since  they  were  prepared  and
probably  motivated by  scholarship,  majority  of




MAAP Research Journal Page 22

the  graduates  did  not  encounter  any  problem
during  their  stay  in  the  academy.  At  the  same
time, they had a good experience with the study
provisions   and   conditions   of   MAAP.   More
importantly, these alumni consider the
knowledge  and  skills  offered  by  MAAP  to  be
relevant.

In terms of their present status, the graduate-
respondents  described  that  they  are  satisfied  in
all the dimensions of their profession. However,
they gave the awards and recognition the lowest
‘satisfied’ level.

## 5. Recommendations

Based   on   the   findings   of   the   study,   the
following are recommended:
- The  alumni  office  should  come  up  with
a  better  contact  and/or  communication
system    with    the    graduates    of    the
academy     so     each     class     can     be
represented  in  the  tracer  studies  in  the
future;
- The midshipmen of the academy should
be    actively    involved    in    extension
services  so  they  may  understand  and
appreciate   more   their   contribution   to
their community;
- The    midshipman    fleet    should    be
oriented   with   and   encouraged   to   be
actively    involved    in    the    different
research    activities.    The    earlier    the
orientation   and   exposure,   the   better.
This  way,  they  will  not  have  a  very
difficult   time   when   they   take   their
research courses;
-  Teachers  should  ensure  that  students
understand the theoretical bases of their
practical exercises. Also, the
Department  of  Academics  as  a  whole
and   the   administration,   including   the
Department   of   Midshipman   Affairs,
should  improve  further  their  topics  and
trainings    related    to    communication,
critical    thinking, leadership,    human
relations  and  problem  solving  in  such  a
way    that    the    students    realize    the
significance  of  these  to  their  future  life
on board and to their life in general.
- Future  researchers  should    include   a
bigger  population  from  each  class  so
that  the  total  population  can  be  well
represented.  Also,  other  variables  like
areas    of    academic    operations    for
improvement may be included.

## 6. References

Balingbing,   A.   (2014).   Tracer   study   of   BS
Information Technology (BSIT) graduates
of  Camarines  Sur  Polytechnic  Colleges,
Nabua,  Camarines  Sur  from  2004-2010.
Asia  Pacific  Journal  of  Multidisciplinary
## Research, 2 (4).

Cañizares, M. (2015). Tracing University of San
Carlos’   science   and   mathematics
education  graduates:  How  well  are  we  in
developing teacher professionals?
International  Journal  of Research  Studies
in Education, 4 (2).

## Celis,   M.,   Festijo,   B.   &   Cueto,   A.   (2013).
Graduate’s employability: A tracer study
for   bachelor   of   science   in   hotel   and
restaurant  management. Asian  Academic
Research  Journal  of  Multidisciplinary,  1
## (1).

Estimo, E. (2012). The alumni as integral to the
stakeholders  of  a  maritime  institution:  A
tracer study. Paper presented at the World
## Research   Festival,   Marco   Polo   Plaza,
Cebu  City,  Philippines.  Retrieved  from
http://www.jblfmu.edu.ph/The-Alumni-
as-Integral-to-the-Stakeholders-of-a-
Maritime-Institution_A-Tracer-Study

## Fronda,   F.   &   Villanueva,   F.   (2015).   Tracer
study     of     employment     of     BSHRM
graduates of the La Consolacion
University   Philippines   for   2011-2013.
Journal  of  Social  Sciences &  Humanities
## Research, 1 (2).

Gines,    A.    (2014).    Tracer    study    of    PNU
graduates. American International
Journal of Contemporary Research, 4 (3).

Lees,    D.    (2002).    Graduate    employability:
Literature review. Retrieved from
www.qualityresearchinternational.com/es
ecttools/esectpubs/leeslitreview.pdf.

## Martin,  J.,  Lang-ay,  P.  &  Guidangen,  J.  (2015).
Tracer  study  of  2009-2013  BA  history
graduates   of   the   Kalinga-Apayao   State




MAAP Research Journal Page 23

College. International Journal of
Advanced  Research  in  Management  and
## Social Sciences, 4 (12).

## Orence, A. & Laguador, J. (2013).
Employability  of  maritime  graduates  of
Lyceum   of   the   Philippines   University
from  2007-2011. International  Journal  of
Research in Social Sciences, 3 (3).

Paadi,  K.  (2014).  Perceptions  on  employability
skills    necessary to    enhance    human
resource  management  graduates  prospects
of  securing  a  relevant  place  in  the  labour
market. European    Scientific    Journal
(Special Edition).

## Pia,  M.,  Matunding,  L.  &  Salvador,  G.  (2014).
Davao  Doctors  College  tracer  study  of
bachelor   of   science   in   nursing. UIC
## Research Journal, 20 (2).

## Ramirez,  T.,  Cruz,  L.  &  Alcantara,  N.  (2014).
Tracer  study  of  RTU  graduates. Journal
## Of Arts, Sciences & Commerce, V (1).

## Rea,  L.  M.,  &  Parker,  R.  A.  (2014). Designing
and    conducting    survey    research:    A
comprehensive guide. John Wiley & Sons.

## Rupande, G. (2015). Zimbabwe Open
## University    Mashonaland    East    Region
tracer study of former students from 2010
to     2014. International     Journal     of
Humanities Social Sciences and
## Education, 2 (1).







































































