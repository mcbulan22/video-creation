RESEARCH REPORT 

# Assessment Drives Learning: An Unavoidable Truth? 

Benjamin W. Wormald, Scarpa Schoeman,<sup>*</sup> Arnold Somasunderam, Michelle Penn Centre for Medical and Healthcare Education, St George’s, University of London, London, United Kingdom 

The debate around which factors drive medical students’ learning is ongoing and controversial. What is the influence of an assessment’s weighting on the motivation of students to study the particular subject? One medical school in London is in a unique position to investigate this question. At our institution, the weighting of Anatomy within the overall scheme of assessment has changed twice in recent years, a trend of increased weighting. This enabled a comparative investigation into the effect these changes have had on the students’ motivation to learn Anatomy. A five-point Likert-scale questionnaire survey was used to evaluate students. A section within a broad survey of Anatomy teaching and learning at our institution was dedicated to the evaluation of the amount of weighting Anatomy received within the assessment structure and the effect this had on students’ motivation toward learning the subject. Increasing Anatomy’s weighting within the scheme of assessment produced a dramatic increasing trend toward students’ motivation to learn Anatomy. The weighting of Anatomy has a profound effect on students’ motivation to learn it. Although multifactorial and complex in nature, medical students’ selfreported drive to study a subject is directly influenced by the weighting of the subject in the overall scheme of assessment. Anat Sci Educ 2:199–204, 2009. © 2009 American Association of Anatomists. 

Key words: assessment; weighting; learning; anatomy education 

## INTRODUCTION 

The factors that motivate or drive students to study and learn particular subject areas in medical education is a developing and interesting subject. The role that assessment plays within this controversial topic has surfaced in editorials of a prominent medical education journal (Schuwirth and van der Vleuten, 2004; McLachlan, 2006) and called for more research and discussion into this ongoing academic debate. In addition, further articles have emerged more recently around this issue, which focused on how regular and repeated assessment can increase the retention of knowledge in medical students (Larsen et al., 2008; Kromann et al., 2009). 

This article is partly in response to other authors’ appeal for more research into this area (Schuwirth and van der 

*Correspondence to: Dr. Scarpa Schoeman, Centre for Medical and Healthcare Education, St George’s, University of London, Cranmer Terrace, Tooting, SW17 0RE, United Kingdom. E-mail: s.schoeman@sgul.ac.uk 

Received 24 June 2009; Accepted 27 July 2009. 

Published online 9 September 2009 in Wiley InterScience (www. interscience.wiley.com). DOI 10.1002/ase.102 

© 2009 American Association of Anatomists 

Vleuten, 2004) and further explores the impact that assessment has on learning. It particularly addresses the paucity of evidence in the published literature regarding the impact of an assessment’s weighting on medical students’ motivation to study and learn the relevant subject area. Does the weighing of a subject in the overall assessment structure play a role in how motivated medical students are to study and learn a subject? St George’s, University of London (SGUL) was uniquely positioned to investigate this question. 

There are many factors that influence a student’s drive to learn a subject. One of the earliest studies to distinguish students differing approaches to learning was carried out by Marton and Sa¨ljo¨ in 1976 (Marton and Sa¨ljo¨, 1976). Students were instructed to read a piece of text on which they would later be tested. Marton and Sa¨ljo¨ then asked the students how they had approached learning the text and found two differing styles of learning. One group of students attempted to understand the meaning of the subject as a whole, identified as a deep learning approach. The other group instead aimed to learn just the facts they believed would be examined—this was described as a surface approach (Marton and Sa¨ljo¨, 1976). Ramsden (2003) went on and summarized the key features of each learning style. The deep approach is characterized by the student’s attempts to understand the ideas and principles within a subject. Similarities and distinctions are made between new concepts and 

Anatomical Sciences Education SEPTEMBER/OCTOBER 2009 

Anat Sci Educ 2:199-204 (2009) 

relevant previous knowledge. Concepts are related to everyday experience. The surface approach is typified by the students aim to memorize facts, to complete the task of learning, for example to prepare for an exam. In the surface approach, the student fails to distinguish new from old knowledge and does not relate the knowledge to the real world (Ramsden, 2003). However, the differences between deep and surface approaches should not be taken to imply that memorizing does not occur within the deep approach (Entwistle and Peterson, 2004). A third approach has since been hypothesized, termed the ‘‘strategic’’ approach. This approach involves students aiming to achieve the optimum grade through effective study methods, time management, and an awareness of the assessment procedure (Entwistle and Ramsden, 1983; Entwistle, 2000). Students learning Anatomy are required to spend considerable time learning a large number of body structures together and the relationships with other structures of the body. Anatomy may be one discipline where distinctions between deep and surface learning strategies are blurred (Pandey and Zimitat, 2007). Students who successfully learn Anatomy employ both superficial (SA) and deep approaches (DA) to learning. Pandey and Zimitat showed a significant positive correlation between DA and achieving a higher quality learning of Anatomy. This was not observed for SA alone (Pandey and Zimitat, 2007). 

Larsen et al. (2008) reviewed the evidence for testenhanced learning in cognitive psychology. Despite substantial evidence that testing enhances retention and factual recall, the potential for using tests to promote learning has been largely overlooked during the 20th century. The act of taking the test has proven to be the actuator in promoting memory retention, and not just the process of going over the material again in preparation for the test (Larsen et al., 2008). Repeated testing has been shown to promote better retention than taking a single test (Wheeler and Roediger, 1992). The benefits of repeated testing have proven greater still when testing is distributed over time (Landauer and Bjork, 1978; Karpicke and Roediger, 2007). 

Interestingly, there is little evidence directly exploring the effect a subject’s weighting (within an assessment system) has on the students’ motivation to learn it. We set out to investigate what effect an increase in the weighting of Anatomy in the overall assessment structure had on the motivation of the students to study and learn the subject. 

Anatomy is taught and assessed during the preclinical segment (the first two years) of the medical curriculum at SGUL. Anatomy knowledge is assessed with questions within written examinations as well as an Objective Structured Practical Examination (OSPE) which is carried out in the dissecting room. 

In 1996, SGUL adopted a new medical curriculum to reflect the UK General Medical Council’s first edition of Tomorrow’s Doctors (GMC, 1993). There was a marked reduction in the Anatomy curriculum time in the first two years of the five year medical course. As a direct consequence, its representation (or weighting) within the overall scheme of assessment in the preclinical part of the course, also declined significantly. Over the subsequent years, anecdotal reports from both clinicians and students emerged that the Anatomy knowledge of St George’s students is poor. Among some students there was a belief that the weighting of Anatomy within the scheme of assessment played a part in discouraging them from learning Anatomy, thus contributing to perceived poor knowledge and clinical application. 

However, in 2005, a new preclinical scheme of assessment was implemented at SGUL. An important change to the assessment process was the removal of compensation between the disciplines examined. In the pre 2005 cohorts, students could compensate between all the different subjects in the medical curriculum to achieve the overall pass standard for the year. As a result, students could potentially completely neglect a subject and focus more of their study efforts on subjects they perceive are easier to learn and still pass the year. However, when the scheme of assessment changed in 2005, it was mandatory to pass each theme of the two-year preclinical course separately. This model, which does not allow for compensation, has also been called for by other academics in institutions where a system-based basic science curriculum had been introduced (McKeown et al., 2003). The themes were Basic Clinical Sciences (BCS), Community and Population Health and Personal and Professional Development (CPH-PPD), and Patient and Doctor (PD). Anatomy is assessed within the BCS theme and comprises a substantial proportion of the BCS workload and subsequent assessments. This meant that performance within each theme, and therefore individual subjects, had to be consistent as it would be more difficult to pass the examinations with a poor performance in any one particular subject, including Anatomy. The weighting Anatomy carried in this revised assessment structure was significantly increased. Two years later, in 2007, SGUL implemented a new medical curriculum and within its scheme of assessment, Anatomy’s weighing increased again. This resulted in a unique window of opportunity to investigate the different medical student cohorts’ motivation to studying and learning their Anatomy. 

## METHOD 

Because of the two changes in the scheme of assessment, we have grouped the current medical student body into three cohorts of students; ‘‘Pre 2005’’, ‘‘2005 and 2006,’’ and ‘‘2007.’’ The overall weighting that Anatomy carries has increased with each revision of the scheme of assessment. Table 1 illustrates how the weighting has changed. 

Between April and May 2008, we conducted a survey of student opinion regarding the Anatomy teaching at SGUL. A section of the survey focused on the effect weighting of Anatomy, within the assessment scheme, had on students’ selfreported learning motivation. The other sections of the survey were dedicated to evaluating the students’ opinion on the current Anatomy curriculum and its delivery within the institution. 

A pilot of the survey was conducted with the aim of refining the questionnaire. A random sample of each year group was invited to attend a session to view the questionnaire and give feedback both on the scope of the statements and the level of clarity in which those statements were being asked. Twenty-eight students attended this session. 

Students were asked to respond to statements using a fivepoint Likert scale, where one 5 strongly agree and five 5 strongly disagree. We designed the survey to have approximately half the statements negatively phrased to force the respondent to think about the statement being posed. The survey consisted of 21 statements spread across several separate sections. Two statements which related specifically to Anatomy’s weighting within the assessment structure were rated. They were: 

Wormald et al. 

200 





<!-- Start of picture text -->
100%<br>Bi Strongly disagree<br>2 Disagree<br>3 Uncertain<br>4 Agree<br>5 Strongly agree<br>80%<br>60%<br>te<br>=a<br>{4<br>a<br>: ZZ<br>/ |<br>‘Oo<br>Pre 2005 2005 and 2006 2007<br>Cohort<br><!-- End of picture text -->



<!-- Start of picture text -->
100%<br>1 Strongly disagree<br>12 Disagree<br>3 uncertain<br>4 Agree<br>5 Strongly agree<br>_ has<br>60%<br>et<br>o<br>2<br>a<br>a _ a<br>20%<br>0%<br>Pre 2005 2005 and 2006 2007<br>Cohort<br><!-- End of picture text -->

ination system is likely to have resulted from the institution’s attempt to correct this perceived deficiency. 

Malcolm Knowles’ theory of adult learning (Knowles, 1990) describes several assumptions that are required for effective adult learning. He states that adults ‘‘need to know why they need to learn something,’’ that the learner must have ‘‘self-concept’’ in which they are responsible for their own decisions, that adults need ‘‘readiness to learn’’ so as to manage life situations, and that adults are ‘‘life-centered’’ in their learning as opposed to children who are ‘‘subject-centered.’’ It can possibly be argued that the current practice of medical educators and assessors is more pedagogical than andragogical. 

Without a good Anatomy knowledge base, it is difficult to attain safe clinical practice in terms of effective examination, interpretation of imaging and carrying out clinical procedures (Leonard et al., 1996, 2001; Turney, 2007). Studies show that medical students identify Anatomy to be a crucial component of clinical medicine (Moxham and Plaisant, 2007). As can be seen from Figure 1, students at SGUL were positive about the changes in the scheme of assessment toward a greater weighting of Anatomy. Concordance between students’ and the faculty’s views with regards to weighting of elements of the curriculum is very valuable to an assessment scheme. If the learners agree with the weighting of a subject they have both intrinsic and extrinsic motivation to learn that subject. This will augment self-direction, and therefore, they will have an increased readiness to learn, fulfilling Knowles’ criteria for successful adult learning. 

As discussed in the introduction of this article, there are various different learning styles that individuals adopt. Figure 2 shows that when Anatomy had less weight in the assessment scheme more students considered that they were discouraged from spending time learning Anatomy. This perhaps implies that the students were aiming to achieve the best possible grade through an awareness of the assessment scheme and appropriate time management, therefore exhibiting traits of ‘‘strategic’’ learners. 

Currently at SGUL, there is no direct student input into specific decisions on the weighting of the assessment process. Evaluating the importance that learners place on individual subjects by means of ongoing surveys might be a useful tool in aiding decisions concerning weighting of subjects within assessment schemes. A successful collaboration between students and the faculty could potentially improve the assessment scheme and possibly have a positive impact on the subsequent knowledge of medical graduates. 

## LIMITATIONS 

There are a number of limitations of this study. The first limitation is self-selection bias. It is possible that the people who did respond to the survey were students who have particularly strong feelings about Anatomy teaching and assessment, therefore causing selection bias. There were only two statements within the overall survey of 21 statements that directly related to the weighting of Anatomy. If there had been more statements concerning weighting it may have been possible to draw more conclusive evidence from the results. Another limitation of the study is the difference between the three different cohorts. The 2007 cohort have not yet entered the clinical practice years of their training. It is possible that this cohort has not yet realized the implication of their Anatomy 

knowledge on their clinical practice. In contrast, the ‘‘pre 2005’’ cohorts are now junior doctors and perhaps are more inclined to reflect that Anatomy should have been weighted more. It may be interesting to perform a retrospective survey (i.e., when all three cohorts have qualified) and compare the results to this survey. The overall response rate of the survey was 52%, although 530 students participated, which is a signumber of students. 

A simplistic interpretation of this study may be that this survey is evidence that subjects must be adequately weighted if they are expected to be learned. We would argue that such a self evident conclusion, in line with educational logic, may have laid the basic foundation for an evidence base. We would suggest that the sub analyses of the two statements that medical students were asked about their perception of the weighting given to Anatomy, and its effect on their behavior raises fundamental and as yet unanswered questions about the learning processes of doctors in training. 

## NOTES ON CONTRIBUTORS 

BENJAMIN WILLIAM WORMALD, M.B.B.S., B.Sc., is a recently qualified doctor who studied at St George’s, University of London. London, United Kingdom. He was the research lead, helped design, administer and analyze the survey. He authored the method, results and contributed to the discussion section of the article. 

SCARPA SCHOEMAN, M.B.Ch.B., P.G.Dipl (Med.Ed.), F.H.E.A., is a clinician lecturing in clinical skills in the Centre of Medical and Healthcare Education at St George’s, University of London, London, United Kingdom. He teaches clinical skills and clinical surface anatomy to all levels of medical students. He helped design and administer the survey. He authored the introduction and contributed to the discussion section of the article. 

ARNOLD SOMASUNDERAM, B.Sc., is a senior medical student at St George’s, University of London, London, United Kingdom. He designed and implemented the online survey environment and contributed to the introduction section of the article. 

MICHELLE PENN is a senior medical student at St George’s, University of London, London, United Kingdom. She helped to design and to administer the survey and contributed to the discussion section of the article. 

### LITERATURE CITED 

Dusseau J, Knutson D, Way D. 2008. Anatomy correlations: Introducing clinical skills to improve performance in anatomy. Fam Med 40:633–637. Entwistle N. 2000. Promoting deep learning through teaching and assessment: Conceptual frameworks and educational contexts. TLRP First Annual Conference. Teaching and Learning Research Programme. Leicester, UK; 9–10 November 2000. TLRP, Institute of Education, University of London, London, UK. URL: http://www.tlrp.org/pub/acadpub/Entwistle2000.pdf [accessed 24 June 2009]. 

Entwistle N, Peterson E. 2004. Conceptions of learning and knowledge in higher education: Relationships with study behaviour and influences of learning environments. Int J Educ Res 41:407–428. 

Entwistle NJ, Ramsden R. 1983. Understanding Student Learning. London, UK: Croom Helm. 272 p. 

GMC 1993. General Medical Council. Tomorrow’s Doctors. 1st Ed. London, UK: General Medical Council. p 40. URL: http://www.gmc-uk.org/education/ undergraduate/GMC_tomorrows_doctors.pdf [accessed 24 June 2009]. 

Karpicke JD, Roediger HL III. 2007. Expanding retrieval practice promotes short-term retention, but equally spaced retrieval enhances long-term retention. J Exp Psychol Learn Mem Cogn 33:704–719. 

Knowles MS. 1990. The Adult Learner: A Neglected Species. 4th Ed. Houston, TX: Gulf Publishing Co. 292 p. 

Anatomical Sciences Education SEPTEMBER/OCTOBER 2009 

203 

Kromann CB, Jensen ML, Ringsted C. 2009. The effect of testing on skills learning. Med Educ 43:21–27. 

Landauer TK, Bjork RA. 1978. Optimum rehearsal patterns and name learning. In: Gruneberg MM, Morris PE, Sykes RN (Editors). Practical Aspects of Memory. London, UK: Academic Press Inc. p 625–632. 

Larsen DP, Butler AC, Roediger HL III. 2008. Test-enhanced learning in medical education. Med Educ 42:959–966. 

Leonard RJ, Acland RD, Agur A, Blevins CE, Cahill DR, Collins JD, Dalley AF II, Dolph J, Hagedoorn JP, Hoos PC, Jones DG, Mathers LH, McFee R, Mennin SP, Negulesco JA, Nelson ML, Olson TR, Page DW, Pawlina W, Petterborg LJ, Price JM, Spielman JE, Younoszai R. 1996. A clinical anatomy curriculum for the medical student of the 21st century: Gross anatomy. Clin Anat 9:71–99. 

Leonard RJ, Blevins CE, Cahill DR, Hoos PC, Marks SC Jr, Page DW, Pawlina W, Petterborg LJ. 2001. Clinical anatomy and the physical examination part I: Thorax, abdomen, perineum, and pelvis. Clin Anat 14:332–348. 

Marton F, Sa¨ljo¨ R. 1976. On qualitative differences in learning: 1. Outcome and process. Br J Educ Psychol 46:4–11. 

McKeown PP, Heylings DJ, Stevenson M, McKelvey KJ, Nixon JR, McCluskey DR. 2003. The impact of curricular change on medical students’ knowledge of anatomy. Med Educ 37:954–961. 

McLachlan JC. 2006. The relationship between assessment and learning. Med Educ 40:716–717. 

Moxham BJ, Plaisant O. 2007. Perception of medical students towards the clinical relevance of anatomy. Clin Anat 20:560–564. 

Older J. 2004. Anatomy: A must for teaching the next generation. Surgeon 2:79–90. 

Pandey P, Zimitat C. 2007. Medical students’ learning of anatomy: Memorisation, understanding and visualisation. Med Educ 41:7–14. 

Ramsden P. 2003. Learning to Teach in Higher Education. 1st Ed. London, UK: RoutledgeFalmer. 288 p. 

Schuwirth L, van der Vleuten C. 2004. Merging views on assessment. Med Educ 38:1208–1210. 

Tibrewal S. 2006. The anatomy knowledge of surgical trainees: The trainers view. Bull Roy Coll Surg Engl 7:240–242. 

Turney BW. 2007. Anatomy in a modern medical curriculum. Ann R Coll Surg Engl 89:104–107. 

Wheeler MA, Roediger HL III. 1992. Disparate effects of repeated testing: Reconciling Ballard’s (1913) and Bartlett’s (1932) results. Psychol Sci 3:240– 245. 

Wormald et al. 

204 

