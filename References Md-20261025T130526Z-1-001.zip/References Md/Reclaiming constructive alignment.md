

## **European Journal of Higher Education** 

**ISSN: (Print) (Online) Journal homepage: https://www.tandfonline.com/loi/rehe20** 



# **Reclaiming constructive alignment** 

#### **Colin Loughlin , Simon Lygo-Baker & Åsa Lindberg-Sand** 

**To cite this article:** Colin Loughlin , Simon Lygo-Baker & Åsa Lindberg-Sand (2020): Reclaiming constructive alignment, European Journal of Higher Education, DOI: <u>10.1080/21568235.2020.1816197</u> 

**To link to this article:** <u>https://doi.org/10.1080/21568235.2020.1816197</u> 













© 2020 The Author(s). Published by Informa UK Limited, trading as Taylor & Francis Group Published online: 15 Sep 2020. 



Submit your article to this journal 

Article views: 311 



View related articles 



View Crossmark data 

Full Terms & Conditions of access and use can be found at https://www.tandfonline.com/action/journalInformation?journalCode=rehe20 

EUROPEAN JOURNAL OF HIGHER EDUCATION https://doi.org/10.1080/21568235.2020.1816197 



### Reclaiming constructive alignment 

Colin Loughlin a, Simon Lygo-Bakerb and Åsa Lindberg-Sand 

###### a 

> aEducational Sciences, Lunds Universitet, Lund, Sweden; bDepartment of Higher Education, University of Surrey, Guildford, UK 

###### ABSTRACT 

Constructive Alignment (CA) is neither the panacea, nor the unalloyed evil depicted in the majority of higher education discourses. But rather, the theory is a heuristic and accessible representation of commonly agreed upon aspects of modern curriculum and educational theory, designed explicitly to support learning and teaching. However, when imposed top-down for accountability purposes, or used as a quality assurance tool, th <mark>e</mark> seemingly step-by-step simplicity that gives it an administrative potential can also diminish or even destroy its relevance as an educational tool. For these reasons CA and particularly learnin <mark>g</mark> outcomes are often vilified amongst academic staff as <mark>a</mark> pernicious influence on learning and teaching. It has been argued that the mechanistic use of alignment and learning outcomes for validation and audit purposes can create an illusion of quality control which bears little relation to the reality of teaching practice and student learning. 

ARTICLE HISTORY Received 10 March 2020 Accepted 27 July 2020 

###### KEYWORDS 

Constructive alignment; learning outcomes; constructivism; curriculum theory; outcomes based education; educational philosophy 

This paper explores the tensions that have been created as constructive alignment has journeyed and expanded from an educational theory into Higher Education teaching policy an <mark>d</mark> practice. The purpose is to reclaim its original perspective as a tool for professional academic teaching. 

##### Introduction 

Why would Constructive Alignment (CA) need reclaiming? It is, after all, still required reading on the majority of Higher Education (HE) academic development programmes, and the embedded framework of most curriculum validation documents. T S Eliot’s The Hollow Men describes those who have: ‘Shape without form, shade without colour, Paralysed force, gesture without motion’ (2004, 81). This paper examines the notion that CA has become a Hollow Man; one in which its journey from theory to policy and practice have created an illusion of systemic academic integrity at odds with reality. 

This critical reflection will draw on a range of sources, from educational theory, policy documents, government reports, journal articles, and opinion pieces. The 

CONTACT Colin Loughlin colin.loughlin@uvet.lu.se Educational Sciences, Lunds Universitet, Sölvegatan 16, MNOhuset, Lund 221 00, Sweden Technology Enhanced Learning, Cathedral Education Centre, University of Surrey, Guildford GU2 7XH, UK 

> © 2020 The Author(s). Published by Informa UK Limited, trading as Taylor & Francis Group This is an Open Access article distributed under the terms of the Creative Commons Attribution-NonCommercial-NoDerivatives License (http://creativecommons.org/licenses/by-nc-nd/4.0/), which permits non-commercial re-use, distribution, and reproduction in any medium, provided the original work is properly cited, and is not altered, transformed, or built upon in any way. 

2 C. LOUGHLIN ET AL. 

genesis for this article is the chasm that we have witnessed between HEIs corporate rhetoric of innovative teaching and active learning, supported by Quality Assurance (QA) processes (claimed to be founded on the principles of CA), placing the student at the centre of learning; and, the frequently observed delivery of transmissive lectures. The purpose is to explore any disconnect between CA as a theory described in its original form, and the theory as currently practised in HE. While much of the evidence and observations relate to UK and Swedish HE (with which the authors are most familiar), CA originates from John Biggs’ teaching experiences in the Far East, Canada and Australia; much of the curriculum theory discussed emanate from the United States, and learning outcomes (LOs) have been widely promoted across Europe as a result of the Bologna Process. The context from which CA emerged; massification, diversity, internationalisation, and large class sizes; are an international phenomenon. And so, while the lens is primarily that of the UK and Sweden, many of the issues will be familiar to an international audience. 

We chart the rise of CA as ‘one of the most influential ideas in higher education’ (Houghton 2004) and its inclusion in HE teacher training programmes and teaching practice, through to curriculum validation processes and quality assurance. 

In the aftermath of Bigg’s 1996 paper introducing CA, which coincided with major HE reforms and the start of the Bologna Process across Europe, there were a flurry of journal articles on the subject of CA, often focusing on LOs. However, in recent years little published work has problematized their relationship with HE. In highlighting areas of concern regarding the tensions which exist between the theory and practice of CA and LOs, we provide a contribution to the discourse in this area. 

More recently, CA, along with a range of other interpretations of outcomes-based approaches, have been drawn together under the umbrella term of Outcomes-Based Education (OBE). Our position in this paper is that CA (and OBE used within this context), are qualitative tools, whose success in practice is predicated on implementation by skilled, professional educators. When the terminology is lifted from this context and used externally, for QA or audit purposes, the meanings diverge materially; one concerned primarily with the process of learning and teaching, and the other with only its product. While the policy intention is that one framework will provide enhancement and accountability, the two uses are in most cases we contend, mutually exclusive. 

This paper first provides a brief history of the developments leading to CA and our interpretation of it as a curriculum theory. This is followed by CA’s adoption by HE policy makers across Europe, and the fundamental changes that occurred as a result of repurposing CA as a QA tool. We then look at the impact of policy interventions and the responses of the academic community to CA as practiced. We conclude with some thoughts on reclaiming CA and OBE as educational tools of enhancement. 

Throughout this paper, we will refer to Aims, Objectives and Outcomes. Within HE there is now broad agreement on their use in the context of curriculum design: aims tend to be a high-level statement of intentions; objectives (if used) describe how the aims will be achieved; and, outcomes or intended LOs, what the student should achieve and be able to demonstrate (e.g. Rielly 2015). Aims and objectives are often seen as teacher-focused whereas outcomes are student-focused and are typically described in terms of observable (and assessable) behaviour. In early curriculum discourse, however, aims, objectives and outcomes were used relatively interchangeably, and occasionally still are. 

EUROPEAN JOURNAL OF HIGHER EDUCATION 3 

##### A history of constructive alignment 

Whether you lean towards Cartesian dualism or Vygotskian monism (Liu and Matthews 2005), the idea that education is an ‘active and constructive process’ (Dewey 2012) is a pervasive theme in the history of educational theory. The roots of constructivist theories of learning can be traced back to the ideas of Plato (who differentiated between ‘teaching’ and ‘telling’), and beyond. However, it was Piaget who is credited with coining the term ‘constructivism’ in the early twentieth century, at the same time cognitivism (which also views learning as an active and constructive process) was gaining traction in the world of Psychology. ‘Cognitive approachestolearningstressthatlearningisan active,constructive,andgoal-orientedprocess that is dependent upon the mental activities of the learner’ (Shuell 1986, 415). 

During this period, the central tenets of what was perceived as quality teaching were taking shape. In 1918 Bobbitt suggested teachers be ‘required to write out their objectives in clear, non-technical language’ (Kelly 2009, 68). Prior to this, the curriculum was principally described in terms of the course content, e.g. Hamlet or Calculus, the detail of what was to be learned, or how, remained largely unarticulated. In 1924, Charters argued that the ‘ideals’ of education should first be decided upon and only then should educators identify suitable ‘activities’ to achieve those ideals (Kelly 2009, 68). Tyler (2013) agreed that defining what education is for was the first step, cautioning, however, that identifying those purposes is subjective, and that ‘a comprehensive philosophy of education is necessary to guide making those judgements’ (52). It is this crucial (if problematic and contested), first step that is often either implicit, or omitted entirely, in subsequent learning design models. The vacuum regularly filled directly, or indirectly, with political ideology, bureaucracy and institutional pragmatism (e.g. Trowler 2003). 

The essential framework for CA was present in Tyler’s 1949 book: Basic principles of curriculum and instruction. Shuell (1986) further developed the themes and said that ‘if students are to learn the desired outcomes […] then the teacher’s fundamental task is to get students to engage in learning activities that are likely to result in their achieving these outcomes’ (429). However, it was John Biggs (1996) paper Enhancing teaching through constructive alignment, which fully articulated the concept. He developed and expanded on it in his book Teaching for quality learning at university: 

‘A good teaching system aligns teaching method and assessment to the learning activities stated in the objectives, so that all aspects of the system are in accord in supporting appropriate student learning. This system is called constructive alignment, based as it is on the twin principles of constructivism in learning and alignment in teaching’ (1999, 11). 

For Biggs, the traditional teaching methods used in higher education relied on intrinsic motivation and highly developed study skills of an academic elite. However, he believed that with massification came diversification and class sizes ‘that seem to preclude any but the same methods of teaching and assessing that aren’t working’ (Biggs 1999, 2). 

The significant steps that Biggs made over his predecessors, were to explicitly embed a theory of learning, ‘constructivism’, into a model for the design of teaching in relation to the curriculum; and, to articulate the connection and direction of travel between LOs, learning activities and assessment: alignment. 

‘In constructive alignment, we start with the outcomes we intend students to learn, and align teaching and assessment to those outcomes. The outcome statements contain a learning 

4 C. LOUGHLIN ET AL. 

activity, a verb, [that] verb says what the relevant learning activities are that the students need to undertake in order to attain the intended learning outcome. Learning is constructed by what activities the students carry out; learning is about what they do, not about what we teachers do. Likewise, assessment is about how well they achieve the intended outcomes, not about how well they report back to us what we have told them or what they have read’ (Biggs n.d.). 

Bigg’s short description of CA mentions activities three times and alignment once. He highlights the importance of constructivism in informing instructional design decisions at every stage of the process, and the centrality of learning-activities in the creation of meaning for students. A key difference between OBE used as an educational tool, and its institutional use for validation and accountability purposes, is the shift in focus and language from that of student-centred activities (what the student does) to that of demonstrable alignment (what the teacher does, to defend their teaching in institutional documentation). It is to this shift in emphasis that we now turn. 

##### Adoption and adaption of OBE by HE policy makers 

Across Europe the political momentum of the 1990s for closer institutional alignment resulted in major HE policy and regulatory reform, culminating in the 1999 Bologna Accord which sought to ‘harmonise’ standards, and create a borderless European Higher Education Area (EHEA) for students and employees. 

##### The European context 

The original 29 signatories of the Bologna Accord grew rapidly and now stand at 48. While LOs did not feature in the original declaration, they were included in the 2003 - Berlin Communiqué and have since become the core component for evidencing qualifi cations at the European level, CA is explicitly referenced from 2015 onwards. Three policy documents work together to outline the nature of the alignment across nations: The Qualifications Framework, the ECTS Users’ Guide and Guidelines for Quality Assurance in EHEA. These display a tight theoretical and conceptual construction with LOs applied from individual modules through to the programme level. This external alignment offers symbolic meaning to qualitative descriptions of the qualifications students have acquired. However, it is supposed to be not only symbolically but actually aligned, the guarantee being the professional contribution from academics supported by CA (note here the transformation of ‘constructive’ from noun to verb, and the effect on its meaning): 

The academic staff responsible for delivering the programme and its components should ensure consistency between the learning outcomes stated in the programme, the learning and teaching activities and the assessment procedures. This constructive alignment (Biggs, 2003) between learning outcomes, learning activities and assessment is an essential requirement for educational programmes. (European Commission 2015, 26) 

The commission insists that LOs are applied to all programme components in order to maintain trust in ECTS (De Lel et al. 2018). However, looking for alignment between LOs at different levels, as between course modules, programmes, and national degree levels, is quite an abstract endeavour, for which evidence may be elusive. Even where 

EUROPEAN JOURNAL OF HIGHER EDUCATION 5 

claimed, the implementation of LOs varies widely within nations, let alone across a continent (Gaebel and Zhang 2018). However, policy makers, institutional leadership and HE administrators still put faith in the European curriculum and in the qualifications framework described. 

Despite the clear intention that LOs should lead to quality learning, implementation suggests that, when imposed top-down, they lend themselves more easily to audit purposes than reliable measures of achievement (Gallavara et al. 2008). Additionally, policy makers, employers and professional bodies see LOs as a way to embed their particularly cherished skills or competences into the curriculum at the European level. 

The most recent Bologna implementation report celebrates the almost ubiquitous take up of LOs and the establishment of external Quality Assurance Agencies (QAAs) across Europe. While stating that there is ‘a consensus that quality assurance is necessary to ensure accountability and support enhancement’ (De Lel et al. 2018, 131), the report also notes that ‘improvement-oriented models of external quality assurance are far less prevalent in the EHEA than supervisory models’ (14). 

Biggs seemed to be aware of this danger stating that CA ‘properly implemented enhances teaching and learning quality, and thus, as a form of quality enhancement, subsumes forms of quality assurance that can often be counter-productive’ (Biggs 2014, 5). He further insists that his version of CA ‘is concerned only with improving teaching and learning’ (Biggs n.d.), but that it has unfortunately been used ‘across institutions to serve a managerial agenda’ (Biggs n.d.). 

##### The national context (UK and Sweden) 

In Swedish HE, widely regarded as a success story of the Bologna Process, the transition to define modules in terms of LOs began in 2006 and took less than a year to complete. From 2007, the curricular system included LOs only at two levels – in the course modules and at the national level in the form of general descriptors for each degree (Lindberg-Sand 2012). It has been suggested that the speed of the transition led to policy changes superimposed onto the old systems and, without sufficient time to adapt content or assessment practices, the LOs produced largely represented the existing learning objectives, and were poorly aligned to the outcomes achieved (Lindberg-Sand 2012). As Adams points out, superficial alignment at policy level can lead to the ‘sterile creation of LOs to fit existing unmodified modules’ (2008). 

In the UK, political disquiet with HE led to the 1997 Dearing Report and many reforms which pre-empted, and indeed inspired, elements of the Bologna Process (Gallavara et al. 2008). Dearing recommended qualification frameworks, a modular structure, LOs, external QAAs, and the immediate introduction of accredited training programmes for university lecturers. 

It is important to note that the LOs of which Dearing and the QAA spoke, were not linked to CA, or indeed, any educational theory (Jackson 2002). While it was hoped or expected that introducing LOs would lead to better learning experiences, their explicit intention in this context was to provide a means of measurement. The literature describing the QAA implementation of LOs talks in terms of product or results of learning, and not process. In an audit conducted by the QAA (2007), not one of the 70 responding institutions linked regulatory LOs to student-centred learning. 

6 C. LOUGHLIN ET AL. 

The UK QAA recognized the lack of educational theory in their implementation of LOs as a weakness, and retrospectively, embedded CA into their documentation (Jackson 2002). 

##### A vitiated theory: CA in educational practice 

As early as 2002 the UK QAA, in appending CA to their outcomes-based framework, states that it produces a ‘carefully and systematically constructed curriculum with the need to align delivery, support and evaluation mechanisms’ (Jackson 2002, p. 143, emphasis added). This sentence is representative of how quickly constructivism disappeared from the theory as practised and leads to a sharpened focus on LOs and alignment. The appropriation and re-direction of the key elements of CA by policy makers diluted the prominence of the theory, and by reframing the terminology, reduced its capacity to enhance the curriculum. 

##### Alignment: curricula overwhelmed with policy requirements 

As can be seen from the preceding quote from the QAA, alignment fared little better than constructivism on the journey from theory to policy. The idea of learning being delivered is far removed from the student-centred approaches advocated by CA. Alignment in CA is intended to create a ‘web of consistency’ (Biggs 1999, ix) in which the required outcomes are reflected in the assessment and learning activities. This integrated approach can lead to learning for understanding rather than memorization, the consistent messaging of alignment cuts through the institutional focus on grades (Shepherd 2005) and challenges the superficial ‘serial acquisition of LOs’ (Trowler 2003, 132), common in audit driven settings. 

However, as Jackson points out ‘the rational way in which policy view the world often has little time for educational theory’ (2002, 142). As European, national, professional, and institutional bureaucracy acquired the language of alignment, a vast array of outcomes have evolved which require complex mapping to ensure that each one can be ticked off during a period of study. 

An example of alignment used as a vehicle for policy is the UK’s National Subject Benchmark Statements, introduced in the UK in 1999 as a device to regulate academic standards across the sector. These weighty documents are at once incredibly detailed, and sufficiently vague, that almost any module descriptors already in place, can be aligned. While recognizing that ‘learning is not a precise science and that there is an important element of professional judgement involved’ (149), individual benchmarking statements contain up to 50 skills outcomes to be assessed against three levels of explicit performance criteria. Thus, programmes are sliced into 150 pieces before any content is considered. This is in addition to any institutional curriculum design requirements, in one (not untypical) example there is a further grid of elements to be aligned, including: employability skills, soft skills, digital literacy skills, internationalization, resilience and inclusion; amounting to a further 91 elements of fragmentation. To require alignment with a tenuously related list of outcomes is a departure from the original theory, and one which undoubtedly dilutes the integrity of the model. 

EUROPEAN JOURNAL OF HIGHER EDUCATION 7 

In the UK, the resulting process for programme and module validation has become an enormous administrative task, with hundreds of items to be mapped onto programmes, and modules. It is understandable that a busy academic might view this as an instrumentalist tick-box exercise designed to fulfil many competing demands; few of them educational in nature. Little wonder then, that many academics complete LOs in ‘bad faith’ (Furedi 2012), never intending that they represent what is to be taught, or how. Specifying LOs ‘for the sake of the paperwork’, while keeping them and ‘other syllabus details as vague as possible [are] common’ responses to CA in the validation process (Trowler 1998, 104). While both OBE and CA are based on starting with a learning design and then thinking about content, in most cases, the content already exists, and therefore a busy academic, with no imperative to change their teaching, is likely to stretch and contort it to meet the QA requirements. 

##### LOs: tension between internal and external quality demands 

For Biggs, the curriculum is driven by student’s perception of the assessment: ‘students learn what they think they will be tested on’ (1999, 141). Therefore, the only way to ensure that students learn what academics intend they should learn, is by making it part of the assessment (alignment). This creates, what can be a surprisingly troubling question: what do you want students to learn as a result of your teaching? This is particularly so when curricula is described in terms of content. If the course content is Hamlet for instance, but what is actually being taught is literary criticism, the expectations of students are implicit, and often so nuanced that attempting to articulate them as LOs can be unsettling. Yet, answering the question of what students should be able to demonstrate at the end of a learning experience can be revelatory for educators, sometimes leading to the very student-centred teaching practices that CA is designed to encourage. 

There is a significant difference between LOs used for enhancement, qualitatively or process oriented, and those product oriented used for audit. Others have noted the same phenomena; Franssen and Friberg express it as ‘epistemic drift’ (2015, 154) with a shift in focus from ‘students to results of the local faculties, institutions or organisations’ (2015, 154); while, Havnes and Prøitz (2016) frame it as internally or externally focused, with a further dimension of open-ended with limited measurability and full-ended and measurable. 

As part of the QAA agenda, LOs are required to be presented such that they can be readily checked-off as complete; that is to say, full-ended and measurable, which can limit their utility and lead to the production of ‘approved’ verbs and formulations. Of the 249 million results returned by Google for the search ‘how to write LOs’, the first two pages came up with things such as; ‘creating measurable LOs’ and ‘creating easily measurable LOs’. Among the results were items from Advance HE (the awarding body for professional accreditation in UKHE) who note that although, ‘many academics have serious misgivings about the outcomes-based approach […] This paper simply aims to give some advice on how to do this as painlessly as possible’ (‘www.advance-he.ac.uk’ n.d.); and, a university stressing that LOs describe only observable (assessable) behaviours and actions. 

None of the results returned in the first few pages of the search mentioned the process or enhancement implications of LOs, the focus was entirely on product, to satisfy regulatory requirements. Many provided copy and paste examples which obviate the need for 

8 C. LOUGHLIN ET AL. 

academics to reflect on their teaching entirely. The LOs of theory and regulation share only the same spelling. 

Highlighting the misalignment between policy and practice, Nasrallah found that a ‘more traditional approach still dominated regardless of what was stated in the course syllabi’ (2014, 268). Another study established that, across a range of institutions, 60% of LOs ‘fail to meet a level of accepted best practice’ (Schoepp 2019, 624), suggesting the cause was a combination of resistance and confusion amongst academics. The study’s ‘bleak findings’ raised a number of concerns regarding the validity and reliability of proxies used for accountability and concluded that policy-imposed LOs ‘failed to provide any evidence that good teaching is occurring’ (625). 

Hussey and Smith are persuasive in arguing that LOs used for non-academic accountability purposes are questionable as, the ‘alleged explicit clarity, precision and objectivity […] are largely spurious’ (2002, 232), and that their function in this context could be equally well-served by a list of course content. This, they suggest, is because the assessment of LOs requires a judgement to be made about their achievement which only academics are in a position to make. They are less convincing when they suggest that outside a particular learning event, LOs are less relevant. Trigwell and Prosser contend that holistically aligned LOs question the assumed knowledge-base and can lead to curricula that ‘transcend the content’ (2014, 150). 

##### Constructivism: disappears from the theory as practiced 

A multitude of detailed constructivist theories exist; however, the association in CA remains high-level and nonspecific, largely stressing the students’ role in actively constructing their own understanding. While Biggs is initially explicit in his book that CA is based on ‘the twin principles of constructivism in learning and alignment in teaching’ (1999, 11), he seems to contribute to the enervation of constructivism within CA. Mentioned fourteen times in the first edition, constructivism appears just seven times in the text of the (much larger) fourth edition (Biggs and Tang 2011). Possibly, this is an attempt to make the theory more accessible, with the authors instead focusing on learning activities. The implication being that the constructive part of the model is a component of curriculum construction rather than an underlying theory of learning. In the 2011 edition, Biggs and Tang even seem to be distancing themselves from the theory. They state, for example, that whilst the theories of teaching they utilize are based on constructivism and phenomenology, which one you use ‘may not matter too much, as long as your theory is consistent’ (Biggs and Tang 2011, 22). However, by failing to maintain an emphasis on the constructivist origins, or explain its omission, a void of understanding is left to be filled at the whim of practitioners and policymakers. 

If the constructive element is read as ‘constructing’ (structurally) or ‘constructive’ (as in positive and valuable) and not ‘constructivism’, one of the central pillars of the theory has been removed. Practitioners are then free to claim constructive alignment for a course containing ten lectures and an exam; so long as the LOs are stated, and the assessment aligned with the LOs. While constructivist approaches would not prohibit lectures, the studentcentredness of an active learning approach would probably make that difficult to justify. ‘Lecturing is logistically convenient [however] the learning that takes place in lecturing is demonstrably worse than in other teaching situations’ (Biggs and Tang 2011, 157). 

EUROPEAN JOURNAL OF HIGHER EDUCATION 9 

Thus, constructivism has essentially disappeared from CA as it was conceptualized by Biggs. While active learning features in policy documents and academic development programmes, the rationale lacks the coherence of an overarching framework and contributes to a reductive approach to curriculum design. From a policy perspective, the various elements of alignment, outcomes and active learning could now be viewed as a kind of pick-n-mix, in which the combination and composition are unimportant; whereas, the original aim of CA was to provide an understanding of the phenomenon of learning as a process. 

##### Reaction and resistance: contested understandings 

The contested articulation of curriculum outcomes did not begin at the inception of CA, but rather echoes earlier arguments relating to learning objectives. Caught within the shifting debates about the applied meaning of CA has been the academic. The positioning of academics, whose role as the arbiter of student learning has been challenged in a period of increased monitoring and control in the name of accountability, helps to frame some of the more polemic reactions to CA and LOs (Fransson and Friberg 2015). 

##### Deprofessionalisation 

The neo-liberal influenced marketization of HE in the 1990s ‘is closely connected to the rise of the culture of quality assurance, the corollary of accountability’ (Biesta 2016, 54). While this was taking place, Trowler (2003) talks of a discourse of derision in which academics were attacked for left-wing bias as a way of limiting a progressive agenda and imposing accountability controls. It is interesting to see that the tactic is still in use, with regular media articles accusing academics of political indoctrination of students (See Morgan 2019). The inevitable consequence of generating mistrust in academics, is a demand for transparency and the imposition of a growing list of external objective auditing measures. A further consequence is reductive deprofessionalization, where ‘actors become just one link in a long chain, and they see and have the ability to control only the next link; they can neither see nor control the ultimate and overall aims’ (Biesta 2016, 66). While it is difficult to think in terms of well-paid, middle-class academics as the oppressed, Freire’s description does resonate: ‘If for a person to be in the world of work is to be totally dependent, insecure and permanently threatened – if their work does not belong to them – the person cannot be fulfilled [and work] becomes an effective means of dehumanization’ (2017, 118). Kolsaker (2008) argues that these fears are overstated and that academics are more accepting of their lot; tacit approval evidenced by a lack of resistance. For Furedi however, the utilisation of LOs in the audit culture, which was expected to make HE transparent and accountable, paradoxically, fosters ‘a climate of non-responsibility’ (2012). 

The increased emphasis on alignment for audit purposes may have led to a reduced sense of individual responsibility amongst academics. The widespread use of copy and paste LOs would certainly suggest that as long as the paperwork is complete, the academics have fulfilled their institutional obligation. As Barnett reflects, in ‘higher education, whatever its validity in other contexts, such a single-minded check-list approach to safe-guarding quality is misguided, ineffective and pernicious’ (1992, 119). 

10 C. LOUGHLIN ET AL. 

##### Academic development 

Partly as a consequence of the Bologna Process (and post the Dearing Report in the UK) the early 2000s saw a dramatic rise in the relatively new and often contested role of the educational or academic developer. Their function is a microcosm of the tensions that exist in HE between theory, policy, and practice. 

Academic development is ostensibly an academic discipline with the scholarship of learning and teaching in HE as its subject. While many teachers find the pedagogic courses offered by academic developers to be useful and worthwhile (Roxå and Mårtensson 2017), there are those who view them as either a professional service or, an irrelevance. Their difficulties stem from the relative nascence of the discipline, along with the mandatory nature of many courses which can lead to resentment among academics. Positioned between management and academics they are often required to implement policy developments in areas such as e-learning, internationalization, QA and accountability which ‘drip through the institution’ (96). Academic developers have been criticized as agents of suppression for neo-liberal ideology, producing homogenized academics who are denied their academic freedom. CA in this context becomes a ‘design template for university courses as cogs in an aligned educational system leaving no space of action for the disciplinary experts’ (98). Given the time that is available to assist those engaging, often for the first time, with a variety of complex concepts, it is perhaps not surprising that, on occasion, rather than critiqued to explore the implications of constructivism for academic practice, the theory becomes used instrumentally. In other words, once the LOs are written, the learning and assessment strategy simply fall out of these. 

Academic developers are themselves acutely aware of their parlous position on the compliance-resistance continuum. Handal et al (2014) discuss academic developer’s agency through the lens’ of professional accountability and professional responsibility when put in the position of implementing policies with which they might ‘partly or even totally disagree’ (12). The pragmatic response, as in many situations, tends to be to implement the policy in a ‘somewhat revised form’ (16). 

Despite the best efforts of academic developers, it would appear that factors such as beliefs about teaching, disciplinary practice and local academic culture can undermine the pedagogic knowledge imparted in teacher training courses. There is a growing body of evidence (e.g. Hattie 2015) which suggests that attitudes to teaching (broadly described as learner- or teacher-centred) significantly impact on the way that OBE is practiced. Subject to academics learner/teacher-centred orientation, the ‘articulation of a programme learning outcome […] may be experienced in qualitatively different ways’ (Trigwell and Prosser 2014, 151), meaning that aligned and correctly formulated LOs can still result in transmissive teacher-centred lectures. Thus, pedagogical understanding (of CA for instance) is necessary, but not sufficient, to ensure that student-centred approaches are enacted in practice (Barman, Bolander-Laksov, and Silén 2014); and, further demonstrate that OBE imposed from above will not ensure a qualitative enhancement of learning experiences. 

Academic developers could benefit from surfacing the contradictions in the original theory of CA as a pedagogical tool, and CA as an administrative policy practice, making academics accountable for the delivery of actual LOs in the HE curriculum. 

EUROPEAN JOURNAL OF HIGHER EDUCATION 11 

##### Conflating theory with practice 

While most serious criticism of OBE occurs in peer-reviewed journal articles, there are regular editorials and opinion pieces appearing which conflate evolved academic and institutional practice with the original theories. 

A common complaint of CA is that the precision of intended LOs proscribes creativity and unanticipated LOs; yet Biggs is clear on this issue stating that, to ‘make the objectives upfront and salient is not to exclude other desirable but unforeseen or unforeseeable outcomes […] higher level activities are open-ended […] particular outcomes are here unspecified, it is only the process that is specified’ (Biggs 1999, 43). 

Nelson (2018) makes the point that all HE institutions claim to encourage creativity, while simultaneously generating a ‘grid of expectations’ which discourage it. However, contrary to Biggs’ explicit guidance, Nelson suggests that this is the result of CA, where ‘learning from the outset belongs to the discourse of assessment’ and that the ‘strict’ alignment of learning activities with LOs is ‘killing creativity’. For Nelson, CA produces a ‘straitjacket’ concerned only with demonstrating evidence, and that creativity would have to be ‘wangled’ into any LOs. 

In a more polemic article, Furedi also conflates the theory and practice: ‘Those who advocate LOs do so expressly with the aim of abolishing [open-ended] experiences’ (2012). 

Both Nelson and Furedi appear to yearn for the days where courses were described in terms of learning objectives, aims, or possibly just a list of content, claiming that this gave academics more freedom to be creative; yet, as Barnett (himself no advocate of LOs) says: ‘Whether we realise it or not, whether we wish to recognise it or not, as educators we must have aims. All educators, if they are serious about the task, must operate with the intention of achieving some kind of outcome’ (1992, p. 33). 

##### Critical appraisal of learning objectives and outcomes 

Ironically, many of the criticisms levelled at student-centred CA and LOs by those nostalgic for teacher-centred learning objectives, are identical to those directed at educational objectives by Eliot Eisner in his 1967 paper Educational Objectives: Help or Hindrance. He says that through the work of Bobbitt, Tyler and Bloom, that educational objectives stated in behavioural terms had ‘been elevated – or lowered – to almost slogan status in curriculum circles. Yet, despite these efforts, teachers seem not to take educational objectives seriously – at least when prescribed from above’ (Eisner 1983, 553). He asserts that if educational objectives were useful, teachers would use them, and that as they do not ‘there might be something wrong with the theory [and that], the dynamic and complex process of instruction yields outcomes far too numerous to be specified in behavioural and content terms in advance’ (554). He invokes Dewey’s distinction between the application of a standard and the making of a critical judgement, before going on to say that ‘what is most educationally valuable […] is capable of being described only in metaphoric or poetic terms’ (557). In a similar vein, Walker says that: ‘Beliefs about what is educationally desirable, that is, beliefs about the good and the beautiful in education, I call aims’ (1971, 56). The implication being that the success, or otherwise, of a good education is something that can only be judged, and not measured. 

12 C. LOUGHLIN ET AL. 

Speaking to learning objectives as applied to the humanities, Stenhouse suggested that, in the US and Europe, the objectives model is ‘often advanced naively and yet confidently, even assertively’ (1970, 74). He goes on to say that the study of works of art (such as Hamlet) cannot be described in behavioural terms. The theme of reductionism is one that appears regularly in the discourse of CA. The original theory was relatively open, but inevitably narrowed as Biggs sought to provide detailed guidance for its possible applications (his book growing from 250 pages in the first edition to 389 pages in the fourth). Academic developers helpfully produced lists of acceptable verbs to be used in LOs and more worryingly prohibited verbs (see Furedi 2012). This not only fuelled reductionism but further narrowed the focus of LOs to observable (assessable) behaviours. The possibility of open-ended LOs suggested in Biggs’ original theory has largely evaporated. This relatively subtle shift in emphasis has led to the much bigger imbalance in alignment; from everything being aligned to LOs, to a perception that everything is aligned with the assessment (e.g. Jervis and Jervis 2005). 

##### Criticism of constructivism 

The criticism by those from the humanities; that fixed outcomes cannot represent the unanticipated consequences of teaching; is echoed by those in the natural sciences. However, some in the scientific community appear to be more vehement in their opposition to both CA and, constructivism in general. Pointing out that constructivism is a broad church of individual approaches to learning theory, Jervis and Jervis go on to say that this ambiguity is incompatible with the precision of natural sciences. They highlight some confusion as to whether CA uses constructivism as a theory of knowing or a theory of learning, they argue that ‘regardless of whether a realist or constructivist theory of knowledge informs what is learnt, learning happens by the same process’, and also, somewhat incongruously, doubt that it is ‘possible to have a constructivist pedagogy allied to a realist epistemology’ (2005, 5). They suggest that constructivism is in some way responsible for limiting students’ opportunities to engage with practical experiments, which would appear to be the opposite of the main thrust of constructivism: that learning is an active and constructive process. They conflate theory with institutional practice, accusing constructivism of everything from a ‘preoccupation with assessment and LOs’ (4) to a prohibition on lecturing and ultimately, the production of ‘less objective medical practitioners’ (6). 

There are two recurrent themes in literature critical of CA which emanate, particularly, from the science teaching community. One is the student-centeredness of the approach which is (mistakenly we believe) taken to mean that any interpretation of learning constructed by the student is acceptable, irrespective of any objective reality. While CAs constructivism is implicitly monist, it does not inherently deny an objective reality, it merely suggests that objective reality is mediated through individually constructed understanding (e.g. Steffe and Gale 1995). A student would have to present a very convincing argument to persuade even the most ardent constructivist, that two plus two was equal to seven. The move from learning objectives to LOs recognized the role of the student in the educational process. ‘The point is that, in teaching, educators cannot achieve their aims by themselves, the outcome is realized through some other person, the pupil or student. Given this indirectness, educators have to have some notion of what they are hoping to see in their students’ (Barnett 1992, 34). 

EUROPEAN JOURNAL OF HIGHER EDUCATION 13 

The second noticeable theme is that, given the ‘broad church’ (Jervis and Jervis 2005, 1) of constructivist approaches available, some researchers choose one of the more niche versions to examine, and then claim it does not work in their discipline or context. For example, in a widely referenced 2006 paper (over 7000 citations according to Google Scholar), Kirschner et al analyse the failure of: ‘Constructivist, Discovery, Problem-based, Experiential, and Inquiry-Based Teaching’ (2006). Many of the claims made by the authors relate to Discovery Learning with minimal instruction; an approach cautioned against by Jerome Bruner when he introduced Discovery Learning (1961). They claim that ‘students learn so little from a constructivist approach, most ’ teachers […] end up giving considerable guidance (Kirschner, Sweller, and Clark 2006, 79). In a 2007 rebuttal Hmelo-Silver et al highlight some of the many flaws and inaccuracies in the original Kirschner et al article, including that they ‘lump together several distinct pedagogical approaches – constructivist, discovery, problem-based, experiential and inquiry-based – under the category of minimally guided instruction’ (2007, 99), and overlook many, more favourable, comparative studies. Interestingly, when Kirschner et al describe some of the features of direct instruction (their preferred teaching approach) such as; ‘providing novices in an area with extensive guidance [which] can be relaxed only with increased expertise’ (2006, 80) one could be forgiven for noting a resemblance to popular interpretations of constructivist theories. As Vygotsky says: ‘With assistance, every child can do more than he can by himself’ (2012, 198). That Kirschner et al also claim ‘scaffolding’ is used to ‘rescue’ failed constructivist teaching interventions’ (2006, 79) must be a little galling to Bruner enthusiasts, as he coined the term scaffolding in relation to social-constructivism in the 1970s (Wood, Bruner, and Ross 1976). 

This is important because the partial and misrepresentative study of Kirschner et al still has currency. In 2019, it was cited 590 times, while during the same period, the rebuttal by Hmelo-Silver et al just once. Even Kirschner and colleague’s later (more nuanced) engagement with the topic has failed to come close to the enduring impact of their original article. This contributes to a widely held view within teaching that constructivist pedagogies are not effective for teaching the natural sciences. The irony is of course, that some of the most successful constructivist pedagogies, such as Peer Instruction (Crouch and Mazur 2001), emanate from large-class teaching of natural sciences. 

It is also worth noting that: 

A common misunderstanding regarding constructivism is that instructors should never tell students anything directly but, instead, should always allow them to construct knowledge for themselves. This is actually confusing a theory of pedagogy (teaching) with a theory of knowing […] Thus, even listening to a lecture involves active attempts to construct new knowledge. (David 2015) 

The criticism of CA is predominantly defined in terms of constructivism or LOs. Constructivism is a cornucopia of theories and criticism tends to focus on relatively narrow interpretations. The central tenet, that learning is an active and constructive process, remains largely unchallenged. 

LO’s problems are more situational than interpretive. Legitimate concerns are raised in relation to the encouragement of utilitarian and behaviourist approaches, and that the transparency afforded could lead students to fixate on assessment. However, the majority 

14 C. LOUGHLIN ET AL. 

of criticism stems from the conflation of their use as a means of enhancement, and a means of control. 

##### Reclaiming CA 

In the course of this critical reflection, a number of tensions and themes have surfaced which go some way to explain why the potential impact of OBE has been compromised in practice. Given the structural complexity and constraints within which HE operates, it would be wrong to suggest that there are simple solutions to the central problem of educational theory misguidedly being used by policymakers in QA processes. What constitutes quality education is a question infused throughout this discussion; its contested nature underscoring the assertion that quality is something that can only be judged, and not measured. 

Conceived as a tool for reflection to aid the creation of optimal learning situations; CA encapsulates, in an accessible form, many commonly agreed upon aspects of what constitutes good practice for those teaching in HE. This paper should not be read as an unqualified defence of CA and recognizes its limitations. We have argued that when used holistically it entails reflecting on the deeper purpose of teaching, and thus, in its original conception, has value for academics. CA is anchored in the practice of teaching and learning. The pretence that CA may also be applied at administrative levels, thereby validating aspects of quality teaching, makes the work of academics appear invisible and controllable. 

The detrimental impact of this is twofold, firstly, it creates an illusion of QA at policy level which is inconsistent with practice (Schoepp 2019); by appropriating CA, documents can be produced which check-off the LOs and student-centredness of OBE, and yet, teaching remain free from the active learning approaches they are intended to evidence (e.g. Trigwell and Prosser 2014). Secondly, by framing LOs as tools of accountability and control in the validation process, ownership is transferred from academics to administrators, encouraging the resistance and rejection that can be seen in the literature (e.g. Nelson 2018). This second point relates to the Handal et al (2014) discussion of academic accountability versus responsibility. When senior academics boast of LOs: ‘I just make them up and ignore them’ (Furedi 2012), it undermines what could be a valuable resource for their colleagues, and abdicates responsibility by failing to confront policy implementations which they believe to be pernicious. 

From an academic perspective, reclaiming CA would call for a challenge to check-box approaches to QA and the normalization of LOs used for the purposes of control and audit. In order to revive the credibility of OBE policymakers need to recognize the futility of attempting to micro-manage what happens in classrooms and restore some of the trust in academics that has been eroded in recent decades. 

##### Conclusion 

Those who speak of education as a journey undertaken by student and teacher together, to an unknown, unknowable destination would, we suspect, struggle with a compulsory module comprised of six-hundred mixed ability undergraduate students. 

Written as a response to the realities of massification and diversification in contemporary higher education (which, coupled with declining per capita budgets, typically results in 

EUROPEAN JOURNAL OF HIGHER EDUCATION 15 

larger class sizes and less contact time), CA offered an opportunity for theory to underpin practice and for academics to rethink how they conceive of their teaching. 

Between the idea And the reality Between the motion And the act Falls the Shadow (The Hollow Men, T S Eliot) 

There can be no doubt that one intention of introducing CA and LOs into policy was to improve learning and teaching. However, between policy and practice, falls the shadow. In adopting the language of educational theory for the purposes of audit, policy makers and bureaucrats have created a façade of academic legitimacy. The amalgamation of educational theory with bureaucratic accountability has, in many instances, transformed educational tools into administrative hurdles. 

Much of the ire directed towards CA is a result of this misappropriation. Reclaiming the meaning of CA is crucial if HE is serious about student-centred learning. Alignment should be used to guide students towards effective learning not to steer academics; and, constructivism puts the student at the heart of learning, without it, learning design can have the structure of CA and yet lack its substance. 

Learning theories are qualitative tools that require thoughtful application. Reclaiming CA and LOs from the miasmic dominion of accountability metrics and perfunctory journalism are essential in avoiding the frustration of their educational purpose. 

##### Disclosure statement 

No potential conflict of interest was reported by the author(s). 

##### Notes on contributors 

Colin Loughlin is a PhD candidate in the Department of Educational Sciences at Lund University, Sweden. His research area is higher education. He has a background in computing and works in educational technologies at the University of Surrey. 

Simon Lygo-Baker is a Senior Lecturer inHigher Education at the University of Surrey and a visiting faculty at UW-Madison in the US. He has been an academic developer for twenty years and has devised and developed a number of programmes aimed at enhancing learning and teaching. He is particularly interested in curriculum design, the role of values in teaching and learning within clinical teaching environments. 

Associate Professor Åsa Lindberg-Sand, is a senior researcher and academic developer at the Division for Higher Education Development (AHU) in the Department of Educational Sciences at Lund University, Sweden. In different positions she has contributed to the national development of courses for academics in university pedagogy in Sweden. Her research includes studies on student assessment in higher education, curriculum reforms induced by the Bologna Process, and the changing conditions for doctoral education. 

##### ORCID 

Colin Loughlin http://orcid.org/0000-0001-9240-2565 Åsa Lindberg-Sand http://orcid.org/0000-0002-0860-6723 

16 C. LOUGHLIN ET AL. 

##### References 

- Adam, Stephen. 2008. “Learning Outcomes Current Developments in Europe: Update on the Issues and Applications of Learning Outcomes Associated with the Bologna Process.” Bologna Seminar: Learning Outcomes Based Higher Education: The Scottish Experience 21: 1–20. http://aic.lv/ace/ ace_disk/2007_09/sem07_09/LO_edinb/Edinburgh_Feb08_Adams.pdf. 

- Barman, Linda, Klara Bolander-Laksov, and Charlotte Silén. 2014. “‘Policy Enacted – Teachers’ Approaches to an Outcome-Based Framework for Course Design’.” Teaching in Higher Education 19 (7): 735–746. 

- Barnett, Ronald. 1992. Improving Higher Education: Total Quality Care. Buckingham: Society for Research into Higher Education: Open University Press. 

- Biesta, Gert. 2016. Good Education in an Age of Measurement: Ethics, Politics, Democracy. Interventions : Education, Philosophy & Culture. London New York: Routledge, Taylor & Francis Group. 

- “ ” 

- Biggs, John. 1996. Enhancing Teaching Through Constructive Alignment. Higher Education 32 (3): 347–364. 

- Biggs, John. 1999. Teaching for Quality Learning at University: What the Student Does. 1st ed. Philadelphia: Society for Research into Higher Education: Open University Press. 

Biggs, John. 2014. “Constructive Alignment in University Teaching.” HERDSA Review of Higher Education 1 (1): 5–22. 

- Biggs, John. n.d. ‘Constructive Alignment’. John Biggs. Accessed 24 April 2018. http://www. johnbiggs.com.au/academic/constructive-alignment/. 

Biggs, John, and Catherine So-kum Tang. 2011. Teaching for Quality Learning at University: What the Student Does. 4. ed. SRHE and Open University Press Imprint. Maidenhead: McGraw-Hill, Society for Research into Higher Education & Open University Press. 

Bruner, Jerome S. 1961. “The Act of Discovery.” Harvard Educational Review 31: 21–32. 

Crouch, Catherine H., and Eric Mazur. 2001. “Peer Instruction: Ten Years of Experience and Results.” American Journal of Physics 69 (9): 970–977. 

David, L. 2015. ‘Constructivism’. Learning Theories. 20 June 2015. https://www.learning-theories. com/constructivism.html. 

De Lel, Gisèle, David Crosier, Ralitsa Donkova, Anna Horvath, Daniela Kocanova, Anita Kremo, Teodora Parveva, and Jari Riiheläinen. 2018. The European Higher Education Area in 2018: Bologna Process Implementation Report. http://dx.publications.europa.eu/10.2797/265898. 

Dewey, John. 2012. Democracy and Education: An Introduction to the Philosophy of Education. La Vergne: Emereo Publishing. 

Eisner, Elliott. 1983. ““Educational Objectives: Help or Hindrance?” Elliott Eisner [1967].” American Journal of Education 91 (4): 549–560. 

Eliot, T. S. 2004. The Complete Poems and Plays. London: Faber and Faber. 

European Commission. 2015. ECTS Users’ Guide. Publications Office of the European Commision. Fransson, Ola, and Torbjörn Friberg. 2015. “Constructive Alignment: From Professional Teaching 

Technique to Governance of Profession.” European Journal of Higher Education 5 (2): 141–156. Freire, Paulo. 2017. Pedagogy of the Oppressed. Erscheinungsort nicht ermittelbar: Penguin Books. Furedi, Frank. 2012. ‘The Unhappiness Principle’. Times Higher Education (THE). 29 November 2012. https://www.timeshighereducation.com/the-unhappiness-principle/421958.article. 

Gaebel, Michael, and Thérèse Zhang. 2018. Learning and Teaching in the European Higher Education Area. The Hague: European University Association. 

Gallavara, G., M. Sedigh Zadeh, A. K. Sorskar, C. Solvhjelm, E. Lindesjoo, M. Kajaste, and E. Hreinsson. 2008. Learning Outcomes: Common Framework. 

Handal, Gunnar, Kirsten Hofgaard Lycke, Katarina Mårtensson, Torgny Roxå, Arne Skodvin, and Tone Dyrdal Solbrekke. 2014. “The Role of Academic Developers in Transforming Bologna Regulations to a National and Institutional Context.” International Journal for Academic Development 19 (1): 12–25. 

Hattie, John. 2015. “The Applicability of Visible Learning to Higher Education.” Scholarship of Teaching and Learning in Psychology 1 (1): 79–91. 

EUROPEAN JOURNAL OF HIGHER EDUCATION 17 

- Havnes, Anton, and Tine Sophie Prøitz. 2016. “‘Why Use Learning Outcomes in Higher Education? Exploring the Grounds for Academic Resistance and Reclaiming the Value of Unexpected Learning.” Educational Assessment, Evaluation and Accountability 28 (3): 205–223. 

- Hmelo-Silver, Cindy E., Ravit Golan Duncan, and Clark A. Chinn. 2007. “Scaffolding and Achievement in Problem-Based and Inquiry Learning: A Response to Kirschner, Sweller, and Clark (2006).” Educational Psychologist 42 (2): 99–107. 

- Houghton, W. 2004. Learning and Teaching Theory for Engineering Academics. Loughborough: Loughborough University. https://dspace.lboro.ac.uk/dspace-jspui/bitstream/2134/9413/2/ EngSC-L%26T-guide-2004.pdf. 

- Hussey, Trevor, and Patrick Smith. 2002. “The Trouble with Learning Outcomes.” Active Learning in Higher Education 3 (3): 220–233. 

- Jackson, Norman. 2002. “Growing Knowledge About QAA Subject Benchmarking.” Quality Assurance in Education 10 (3): 139–154. 

- Jervis, Loretta M, and Les Jervis. 2005. “. ‘What Is the Constructivism in Constructive Alignment?” Bioscience Education 6 (1): 1–14. 

- Kelly, A. V. 2009. The Curriculum: Theory and Practice. 6th ed. Thousand Oaks, CA: SAGE Publications. 

- Kirschner, Paul A., John Sweller, and Richard E. Clark. 2006. “Why Minimal Guidance During Instruction Does Not Work: An Analysis of the Failure of Constructivist, Discovery, ProblemBased, Experiential, and Inquiry-Based Teaching.” Educational Psychologist 41 (2): 75–86. 

- Kolsaker, Ailsa. 2008. “Academic Professionalism in the Managerialist Era: A Study of English Universities.” Studies in Higher Education 33 (5): 513–525. 

- Lindberg-Sand, Åsa. 2012. “The Embedding of the European Higher Education Reform at the Institutional Level.” In European Higher Education at the Crossroads: Between the Bologna Process and National Reforms, edited by Adrian Curaj, Peter Scott, Lazăr Vlasceanu, and Lesley Wilson, 191–207. Dordrecht: Springer Netherlands. 

- Liu, Charlotte Hua, and Robert Matthews. 2005. “‘Vygotsky’s Philosophy: Constructivism and Its Criticisms Examined.’.” International Education Journal 6 (3): 386–399. 

- Morgan, John. 2019. ‘Are Universities Hotbeds of Left-Wing Bias?’ Times Higher Education (THE). 21 February 2019. https://www.timeshighereducation.com/features/are-universities-hotbedsleft-wing-bias. 

- Nasrallah, Rita. 2014. “‘Learning Outcomes’ Role in Higher Education Teaching.” Education, Business and Society: Contemporary Middle Eastern Issues 7 (4): 257–276. 

- Nelson, Robert. 2018. ‘Micro-Management of Learning Is Killing Creativity’. Times Higher Education (THE). 12 July 2018. https://www.timeshighereducation.com/opinion/micromanagement-learning-killing-creativity. 

- QAA (Quality Assurance Agency for Higher. 2007. Outcomes from Institutional Audit: The Adoption and Use of Learning Outcomes. QAA Gloucester. http://heer.qaa.ac.uk/ SummaryPDFsRestricted/QA125.pdf. 

- Rielly, Melissa. 2015. ‘Learning Aims and Outcomes’. Text. 23 March 2015. https://www. educationalpolicy.admin.cam.ac.uk/curricula-and-assessment/learning-aims-and-outcomes. 

- Roxå, Torgny, and Katarina Mårtensson. 2017. “. ‘Agency and Structure in Academic Development Practices: Are We Liberating Academic Teachers or Are We Part of a Machinery Supressing Them?” ’ International Journal for Academic Development 22 (2): 95–105. 

- Schoepp, Kevin. 2019. “The State of Course Learning Outcomes at Leading Universities.” Studies in Higher Education 44 (4): 615–627. 

- Shepherd, John. 2005. Weaving a Web of Consistency: A Case Study of Implementing Constructive Alignment. Sydney: HERDSA. 

- Shuell, Thomas J. 1986. “Cognitive Conceptions of Learning.” Review of Educational Research 56 (4): 411–436. 

- Steffe, Leslie P., and Jerry Edward Gale, eds. 1995. Constructivism in Education. Hillsdale, N. J: Lawrence Erlbaum. 

- Stenhouse, Lawrence. 1970. “Some Limitations of the Use of Objectives in Curriculum Research and Planning.” Paedagogica Europaea 6: 73–83. 

18 C. LOUGHLIN ET AL. 

Trigwell, Keith, and Michael Prosser. 2014. “Qualitative Variation in Constructive Alignment in Curriculum Design.” Higher Education 67 (2): 141–154. 

Trowler, Paul. 1998. “What Managerialists Forget: Higher Education Credit Frameworks and Managerialist Ideology.” International Studies in Sociology of Education 8 (1): 91–110. Trowler, Paul. 2003. Education Policy. 2nd ed. Gildredge Social Policy Series. London: Routledge. Tyler, Ralph W. 2013. Basic Principles of Curriculum and Instruction. Chicago, IL: University of Chicago Press. 

- Vygotsky, L. S. 2012. Thought and Language, Rev. and Expanded ed. edited by Eugenia Hanfmann. Translated by Gertruda Vakar and Alex Kozulin. Cambridge, MA: MIT Press. 

- Walker, Decker F. 1971. “A Naturalistic Model for Curriculum Development.” The School Review 80 (1): 51–65. 

- Wood, David, Jerome S. Bruner, and Gail Ross. 1976. “The Role Of Tutoring In Problem Solving.” Journal of Child Psychology and Psychiatry 17 (2): 89–100. 

- ‘www.advance-he.ac.uk’. n.d. HE Advance. Accessed 27 January 2020. https://s3.eu-west-2. amazonaws.com/assets.creode.advancehe-document-manager/documents/hea/private/writing_ learning_outcomes_1568036949.pdf. 

