

## 609
When Policy Meets Practice: A Multi-College
Qualitative Study of Systemic Misalignment in
## Outcome-based Assessment

## Ruslan Achok, Kamisah Osman
Faculty of Education, Universiti Kebangsaan Malaysia, 43600, Bangi Selangor, Malaysia
Email: p113913@siswa.ukm.edu.my

## Abstract
Assessment is still considered as the important component of implementation of OBE, with a
considerable gap between policy for constructive alignment and what really happens in the
classroom. As a critical part for quality of education in Sustainable Development Goal Four,
this  qualitative  research  uncovers  systemic misalignment between  OBE  and  assessment
practices within science lecturers at the Malaysian Matriculation Programme. The study used
purposive sampling and captured collective institutional experience primarily through focus
group  discussion,  supplemented  by  individual  interviews and analyzed the  data  using
thematic  analysis. The  finding identified five  themes that  are  closely related which  are
variability in assessment  practices, conceptual ambiguity  in  OBE  and  assessment, limited
awareness  of  constructive  alignment,  structural  time  constraints  and  weak  assessment
literacy. These    systemic    misalignments were further reinforced    by    administrative
accountability demands, resource limitations, and student-related challenges, indicating that
misalignment extends beyond   individual   competencies   to a broader systemic   and
institutional conditions. This study contributes empirical evidence of how policy-driven OBE
reforms  may  translate  into  compliance-oriented  assessment  practices  under  institutional
constraints. Through a multi-college qualitative analysis, this study demonstrates important
systemic   requirements  for   enhancing   assessment  practice   conditions   in   pre-university
education   and   draws   attention   to   the   ongoing   discussions   surrounding   constructive
alignment.
Keywords: Outcome-Based Education, Constructive Alignment, Assessment Practices, Policy–
## Practice Gap, Matriculation Programme

## Introduction
OBE Context and Constructive Alignment
Driven by the need to align educational delivery with job requirements skills, Outcome-based
Education (OBE) has become a dominant framework guiding the curriculum reform in higher
education system  worldwide Mahrishi  2025 (Mufanti et  al. 2024). Beyond  the  pedagogical

Vol 16, Issue 2, (2026) E-ISSN: 2222-6990


DOI Link: http://dx.doi.org/10.6007/IJARBSS/v16-i2/27655
## Published Date: 20 February 2026

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 610
aspect,  this globally  reform  is  deeply built  into  policies  and  quality  standards  required  by
accreditation  bodies   and international   agreements   such   as   Washington   Accord (Priya
Vaijayanthi and Raja Murugadoss, 2019). As a result, higher education institutions now use
OBE as a main benchmark for institutional accountability, ensuring that graduates possess the
same essential skills regardless of their geographical location (Almuhaideb and Saeed, 2020).
Central to the success of this paradigm is the concept of constructive alignment, which refers
to intended learning outcomes, teaching activities, and assessment tasks that must be aligned
and support each other (Biggs and Tang, 2011; Hailikari et al. 2022). Out of these three parts,
the ‘backwash effect’ makes assessment  probably  the  most  critical  component where
students naturally adjust and drive their learning strategies based on how they are going to
be assessed (Leber et al. 2018). A robust outcome-based curriculum requires that assessment
tasks  are  not  only  mapped  to  Course  Learning  Outcomes  (CLOs)  but  are  also  capable  of
generating valid evidence that Program Outcomes (POs) have been attained (Derouich, 2025).
However,  assessment  remains  the  most  challenging  aspect  of  OBE  implementation,  often
revealing significant gaps between policy intent and classroom reality (Mufanti et al. 2024).

Challenges and gaps in Implementing OBE Assessment
Despite   the   widespread use of   OBE   in   higher   education,   existing   research   on   OBE
implementation  has  largely focused on  quantitative surveys,  single  institution  case  studies
and self-reported lecturer perceptions (Handayani and Wibowo, 2021; Kushari and Septiadi,
2022;  Mohd  Noor et  al. 2021;  Mufanti et  al. 2024;  Yusof et  al. 2017).  While  these  studies
provide valuable data which often relies on self-reported knowledge of educators, they often
fail to capture how assessment practices are enacted under real institutional constraints or
how  policy  requirements  interact  with classroom teaching  realities (Ag  Damit et  al. 2021;
Mufanti et al. 2024). Consequently, there is a notable gap in qualitative evidence of how OBE
assessments are  implemented across  multiple  institutional contexts, particularly from  the
lecturers’  perspective within  centrally  governed  and  high  accountability  pre-university
systems. As   a   result, the  organizational,   cultural,   and   systemic  factors   that maintain
assessment misalignment remain inadequately explored.

Although the OBE system has been used for a long time, studies show that there are still major
problems in implementation action (Alonzo et al. 2022). Many educators still feel it is difficult
changing the old way of teaching to a new one which prioritizes student learning outcomes.
As  a  result, educators  have  difficulty  providing  learning materials and  tests  that  are  truly
appropriate (Mufanti et al. 2024). Furthermore, what is promised in the course objectives is
often not the same as what is learned in class. For instance, mapped courses frequently lack
the  specific  content required  to  achieved problems  solving  problems outcomes (Priya
Vaijayanthi and Raja  Murugadoss,  2019). This  misalignment is  getting worse  because
educators may  not  be  skilled  in  modern  assessment methods and  still  use  traditional tests
that measure the true abilities of students effectively (Leber et al. 2018). Finally, factors such
as administrative burdens and lack of support from the school also prevent this system from
running smoothly (Mufanti et al. 2024).

This  study  is  conceptually  informed  by  policy  implementation theory and  institutional
accountability perspectives, which emphasizes the  gap  between  formal  policy design  and
current practice within organizations. From this perspective, lecturers are viewed as frontline
implementers, who  must  translate  centrally  mandated  OBE  requirements  into  classroom

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 611
assessment practices while managing time constraints, reporting demands, and institutional
monitoring. Within an accountability-driven  system,  constructive  alignment  may shift from
being  a  pedagogical  principle  to  a  compliance  mechanism shaped  by  documentation  and
audit pressures.  This theoretical grounding guides the interpretation of findings by framing
assessment misalignment not as individual lecturer failure, but as a systemic outcome shaped
by institutional governance structures, workload conditions, and performance expectations.

Outcome-based Curriculum Reform in the Malaysian Matriculation Programme
While  these  challenges  have  been  documented across  various  higher  education  contexts,
limited research has examined how such misalignment unfolds within centrally governed pre-
university  systems such  as  the  Malaysian  Matriculation  Programme where  accountability
structures are particularly strong. Tension between documented alignment and implemented
assessment classroom practices may be exacerbated due to strong compliance and reporting
pressures. In order to determine whether OBE reforms serve as administrative mechanisms
or   as   pedagogical   transformation, examining   such   context   is   therefore   critical   for
understanding.

Prior to the implementation of OBE, the Malaysian Matriculation Programme focused more
on teaching subject content and academic preparation for studies at the university level. The
Matriculation Programme, which manages by  Matriculation  Division,  Ministry  of  Education
Malaysia, was established in 1998 by the Ministry of Education Malaysia as a pre-university
pathway   to   help   students,   especially Bumiputeras,   continue   their   studies   in   science,
technology and professional fields at universities both domestically and abroad. Over time,
the Matriculation Programme has expanded with an increase in the number of students, the
addition  of  colleges,  and  the  offering  of  more  diverse  study  streams,  demonstrating  its
important role in the Malaysia education system.

During   academic   session 2018/2019,   Matriculation Programme undertook   complete
curriculum restructuring with   the   implementation   of   OBE. The   reform   changes   from
traditional  content-based  teaching  into  competency-based  frameworks,  highlighting  clear
and  assessable  learning  achievement.  Curriculum  revisions  were guided  by  the Standard
Kursus Asas framework from the Malaysia Qualification Agency, maintaining with country’s
higher education quality and accreditation (Agensi Kelayakan Malaysia, 2014).

Although the guidelines and curriculum structure have been clearly provided, the success of
OBE  in  Matriculation Programme is  determined  by  lecturers’ understanding  and their
teaching  practices. Actual  OBE  implementation differs  from  college  to  college  even with
available   comprehensive   guidance   on   learner   outcomes   and   achievement   standard.
Therefore,  it  is  important  to  see  how  science  lecturers  in  various  matriculation  colleges
understand  and  implement  OBE  assessment  so  that  the  causes  of  this  problem  can  be
identified.

Purpose of the study
To address this gap, this study examines how outcome-based assessment is presented across
multiple  Malaysian  Matriculation  colleges,  focusing  specifically  on  science  lecturers as
frontline implementers. Adopting a qualitative multi-site design, the study explores how time
constraints,  accountability  requirements,  and  institutional  structures  influence  assessment

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 612
procedures  in  centrally  manage  pre-university  system. Rather  than  evaluating  individual
competencies,  the  study  aims  to  find  systemic  documented  OBE  policy  expectations  and
implemented classroom assessments practices. As a result, the scope of the study’s scope is
limited to the assessment procedures used in the Malaysian Matriculation Programme and it
makes no effort to generalize outside of this institutional context.

## Research Methodology
This  qualitative  study  used  focus  group  discussion  (FGDs) and  individual  interview to
investigate  the  widespread  problems why OBE assessment isn’t working properly among
science lecturers in Malaysian Matriculation colleges. FGDs were selected because participant
interaction  stimulated  collective  reflection,  enabling  lecturers  to  elaborate,  justify,  and
negotiate shared experiences of college assessment practices in way less accessible through
individual interviews (Morgan, 2012; Plummer 2017). Meanwhile, individual interviews were
conducted  to  supplement  FGDs  where  participants  were unavailable  and were  analyzed
alongside FGD data using the same thematic process. Purposive sampling was used to choose
participants from different colleges to make sure we got relevant responses and contextual
knowledge of OBE assessment implementation (Wright et al. 2012).

Participants  were selected  from several Malaysian  Matriculation  colleges  representing
different institutional  contexts.  A  total  of 4  science  lecturers  participated  in  a  focus  group
discussion while 3 individual interviews were conducted independently for those who were
unable to attend the group discussion. All participants had direct experience in implementing
OBE  assessment in classroom. Researchers facilitated  the  FGDs and  interview who held  no
administrative  role  in  OBE  implementation,  enabling  participants  to  discuss challenges
candidly  without  institutional  reporting  concerns. All  discussion  were  audio  recorded  and
transcribed  verbatim.  Ethical  approval was  obtained prior  to  data  collection.  Informed
consent, voluntary  participation, and  confidentiality  were  carefully  followed  because  the
topic deals with sensitive professional matters (Theadore et al. 2011; Wright et al. 2012).

Data were analyzed using reflexive thematic analysis, which selected for its ability to identify
recurring  themes and  interpretation  but  at  the  same time acknowledge the researcher’s
engaged  position  in  the  analytical  process (Ahmed et  al. 2025;  Xu and Zammit,  2020).  The
analysis process included data familiarisation, creating codes based on what emerge from the
data  itself,  theme  development  and  review,  and  analytic  writing.  Five  interrelated  themes
were   generated,   capturing   systematic   patterns   in   assessment   practices,   institutional
conditions, and conceptual understanding of OBE. Findings were reported using an integrated
narrative’s structure to reflect the interconnected nature of the themes rather than treating
them as discrete categories. Credibility was enhanced through thick description and verbatim
quotations  across participants,  while  dependability  was  supported  through  transparent
documentation of analytic decisions and reflexive memoing throughout the analysis (Ahmed
et al. 2025).

## Research Finding
Unless specified differently, the participant quotes presented in this study are primarily from
FGDs while interview quotes are included to support and explain the themes that emerged
from data.


## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 613
Systemic Misalignment of Assessment Practices Across Colleges
Participants  highlighted  the  differences  between  in  assessment implementation  between
colleges, which makes it difficult to ensure fairness and transparency according to the same
standard.  They  were  concerned  that  that  each  college  used  its  own  assessment  methods
without a uniform assessment framework.

“Bila  pelaksanaan  itu  mengikut  kolej  kan.  Jadi  ikut  kolej  lah  macam  mana  penilaian,
pentaksiran semua mengikut kolej lah... Jadi kita pun tak tahulah antara kolej ni macam mana
penilaian, macam mana telusnya penilaian tersebut.” (P1FGD)
“Kolej  ni  lain  soalannya...  Jadi  ni  kalau  disekatakan,  disamakan,  saya  rasa  bagus  juga.”
## (P2FGD)

Participants  were  also recognized  the  significance  of  need  for  unified  assessment  designs,
suggesting   that   consistent   evaluation   structures   might   support   fairness   and   diminish
competitive dynamics among college.

“Masing-masing  kita  di  bawah  satu  bumbung  yang  sama...  Bila  satu  bumbung  yang  sama,
kita bukannya berfokus nak kolej ni, nak kolej ni yang naik ke apa kan. So dari segi tu biarlah
orang kata matlamat tu adalah matlamat yang sama.” (P2FGD)
Participants also share experiences about the adjustments they had to make because of the
time constraints.

“Kadang-kadang  dalam  SOP  kami,  kami  menyusun  tu  tak  selaras  pun...  Maksudnya  kalau
intro tu dekat ni, minggu tujuh katakan. Tapi intro amali intro tu dah minggu baru, minggu
empat kita jalankan. Macam tu lah.” (P3FGD)

Conceptual Ambiguity in Understanding OBE and Assessment
Participant questioned whether assessment should be equated with examinations or should
prioritize  a  continuous  and  formative  approach. There  is  confusion  about  the  purpose  and
function of assessments within the curriculum framework, which raises questions about the
effectiveness   of  existing   assessment  methods   in   measuring   student   achievement   and
development.
“Saya  nak  tanya.  Kita  ni  kan  penilaian.  Penilaian  kan  adakah  sama  seperti  peperiksaan?”
## (P3FGD)

Another   concern   was   the  rigidity   on   assessment   practices,   particularly   in   relation  to
opportunities for students to review and improve their work.
“Bila penilaian tu sentiasa ada peluang penambahbaikan. Tapi kami masih follow lah yang itu.
Okay. Tapi bila difikir balik penilaian kenapa tak boleh beri peluang penambahbaikan?”
## (P3FGD)
“Saya nak reason tu, apa reasonnya kami selepas for dia submit, tak boleh beri balik, tak boleh
bagi peluang penambahbaikan.” (P3FGD)

Participant also  raised  concerns  about the  order  of  assessments  in  schedule,  especially
practical  tests. Participant questioned  whether  students  should  complete  all  practical  test
first before the theoretical component of vice versa.

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 614
“Itulah di bahagian sebenarnya benarkan ke kita buat kemudian kita buat practical kan dulu
waktu baru kita sambung balik. Nak tahulah sebenarnya.” (P1FGD)

In  addition,  there  are  differences  of  opinion  on  assessment  practices  among  lecturers.
Lecturers admit that there are various opinions on the methods of implementing assessment,
which further adds to the confusion among educators and students.
“Memang ada perbezaan dalam pendapat lah. Itu tidak boleh kita nafikan.” (P7Int3)

Limit Awareness of Constructive Alignment as a core OBE Principle
Participants  expressed  difficulty  in  identifying  constructive  alignment  in  curriculum  and
assessment documents. Although they interacted with various academic guidelines provided
by  the  Matriculation  Division,  there  was  still  ambiguity  in  understanding  how this  aspect
related to the principles of constructive alignment that should be implemented in the learning
and assessment system.
“Tak  pastilah  macam  mana  rupa  dia.  Ada  banyak  dokumen  yang  kita  tengok.  Tapi  kita  tak
pasti ada yang kita tengok itu adalah penjajaran konstruktif.” (P5Int1)

Participant  also  reported  that  they had  never  been exposed  to the  concept  of  constructive
alignment,  while  others  were  still  unclear  about  the  exact  definition  and  methods  of  its
implementation in the teaching and assessment system.

“Penjajaran konstruktif. Oh, itu tak pernah dengar. Tak tahu lah pun, tak dengar, tak pernah
dengarkah, ataupun apa benda yang dimaksudkan secara formal kalau dengar-dengar cakap
pun tak tahulah pula.” (P6Int2)
“Constructive alignment, tak.” (P7Int3)

Structural time Constraints and Assessment Feasibility
Another   problem   raised   by   lectures   is   insufficient   time   constraints   to   carry   out   a
comprehensive student assessment.
“Siapa nak pakai tinggal masa nak evaluate? Sebab kita ada tiga minggu je. Minggu kita kan
ni  berapa  minggu?  Ada  18  minggu  kan?  Berapa  minggu  je  kita  boleh  buat  evaluation  tu?”
## (P3FGD)
“Penat. Kami bukan berjalan tau kami berlari. Ya betul. Lari pecut. Kami lari pecut.” (P3FGD)
“Cuma  untuk  lepas  OBE  ni  masa  yang  diberikan  sangat  singkat.  Dan  kita  hanya  mengajar
certain sahaja... Selalunya practical test lah.” (P4FGD)

On  the  other  hand,  lecturers  expressed  regret  over  the  tight  schedule  constraints  for  the
implementation of practical tests which are part of the continuous assessment component.
The  pressure  to  complete  these  tests  earlier  than  the  last  week  of  the  semester  poses
challenges in ensuring the smoothness and accuracy of the assessment process.

“Jadi, agak kekangan dah dekat situ. Kita sebenarnya kekangan masa di matrik ni. Ujian amali
untuk markah PB, kita kena ambil awal. Minggu 16 dah kena habis.” (P2FGD)
Participant also expressed the opinion that the implementation of teaching and assessment
is not always in line with SLT recommendations.

“Cuma ni dari segi pelaksanaan, realitinya tak berlaku lah seperti mana SLT.” (P2FGD)

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 615
Assessment Literacy: Rubrics, Task Design, and Scoring Practices
Participant informed about the weakness of the assessment rubric, which is too simple, where
the  assessment  tends  to  be  in  a  binart  format  (yes/no)  without  detailing  the  level  of
achievement in detail.

“For me, problem is the rubrik. Rubrik dan kekangan masa. Rubrik kami yes, no, yes, no je.”
## (P3FGD)
Participant also acknowledged that developing well-structured rubrics requires specific skills,
which they may not yet fully mastered.

“Sebenarnya, we said rubrik, kita mesti ada skill.” (P3FGD)

Other problem raised by participants include the difficulty in designing and developing high
quality assessment questions.

“Saya paling terasa dalam tutorial, dalam assignment dan soalan laporan adalah penghasilan
soalan  laporan  yang  berkualiti.  Penghasilan  soalan  laporan  dan  assignment  yang  berkualiti
lah.   Maksudnya   kompetensi   pensyarah   dalam   mentaksir   ataupun   menggubal   soalan.”
## (P3FGD)

Participant  revealed that  there  is  a tendency among  lecturers not  to  provide  detail reports
explain the factors that caused students to obtain low grades to the college management.

“...Pengurusan akan  minta  laporan  pelajar  rendah  ni  kenapa  dia  dapat  rendah.  Kadang-
kadang ya lah dalam kalangan pensyarah sendiri pun kalau boleh dia nak mengelak lah. Buat
laporan sedemikian.” (P1FGD)

Participant also  informed  that the obligation  to prepare  reports  places them  under  stricter
scrutiny from institutional management.
“So bila buat laporan tu, kita akan ada kekangan dengan orang atasan kita lah, pengurusan
lah. So bila dalam keadaan macam tu, memang tak faham kita. Dan pensyarah pun akan kena
buat  laporan.  So  bila  laporan  tu  kita  kena  sediakan,  kita  jadi  macam  tak  senang  duduk  lah
kan sebab pengurusan nak tanya kita.” (P2FGD)

## Discussion
All  five  themes  identified  in  the  Findings  are  retained  as  the  analytic  structure for  the
## Discussion.

Systemic Misalignment of Assessment Practices Across Colleges
Differences in way that institutions carry out assessments have been strongly connected to
maintaining  fairness  and  transparency,  particularly  when  there  is  a  lack  of  calibration  or
standardization  between  assessors, which  leads  to  differences  in  how  they  mark  students’
works (Alqahtani et al. 2025). These inconsistencies get even worse when institutions don’t
have  clear  and well-organized policies  and  rules,  which have been  shown  to  produce
significant  variability  and  inconsistency  in  assessment  practices. According  to The  Quality
Assurance  Agency  for  Higher  Education  (2008), audit  reports have indicated that  many
institutions operate without  comprehensive  quality  assurance  policies  for assessment and

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 616
significant  variation in  how  assessment  requirements is implemented  across  institutions.
Furthermore, such  issues  persist  beyond  isolated  cases,  as  audit  trails  reveal  ongoing
inconsistencies  and  differences  in  assessment  practices (The  Quality  Assurance  Agency  for
Higher  Education,  2008). On  top  of  that,  this  variability  contributes  to  the  inconsistent
application  of  assessment  criteria,  thereby  posing  substantial  challenges  to  universities  in
achieving assessments that are both fair and transparent across colleges (Gonsalves and Lin,
## 2025).

The  need  for  a standardized assessment  structure is recognized by lecturers strongly
supported  by  recommendations  that  an  assessment  unit  be set  up to control  the planning
and execution of assessment and to enforce a clear policy for all examiners (Alqahtani et al.
2025). An assessment unit should actively monitor assessment systems and provide ongoing
support  to  examiners  through training  and  discussion  panels.  This would ensure sustained
consistency  and  shared  understanding  across  colleges (Alqahtani et  al. 2025). At  the
operational  level,  the concept  like  consistent  scoring  over  completion  date,  who  conduct
marking   and   assessment timeframe seems   to underscore the   role   of   standardized
frameworks in promoting equity and fairness in assessment outcomes  (Ling, 2024). Extending
beyond mere operational consistency, educators suggest that building collaborative academic
culture emphasizes teaching effectiveness and continuous improvement which can transform
from competitive  exercise  between  institutions into  collective  academic  accountability
(Dennin et al. 2017).  Following this viewpoint, institutions have been advised to create and
put into effect formal assessment policies and procedures in order to ensure that assessment,
advancement, and award processes are in in line with best practice, strengthening a unified
and   goal-oriented   assessment   framework (The   Quality   Assurance   Agency   for   Higher
## Education, 2008).

This  theme interacts closely  with  structural  time  constraints,  where  the absence  of  share
assessment framework among colleges deepens the pressure on lecturers to make immediate
adjustment to assessment implementation which meet the institutional timelines.

Due to time  constraints  in allocated  classroom  contact  hours,  it  is  frequently  necessary  to
either  eliminate  specific  learning  activities  or  adjust  them  into  independent  assignments.
These  adjustments  were  further worsened  through perceptions that  executing  continuous
assessment seems impractical when lecturers are burdened with substantial administrative
documentation  and  assessment  grading  workloads (Shahazwan  M.  T. et  al. 2025). Existing
research has similarly reported that allocated instructional time, such as 90 minutes per week,
is inadequate for executing continuous assessment method, resulting lecturers to prioritize
syllabus completion over formative assessment practices (Senouci, 2022). In addition, large
class sizes combined with limited instructional time were identified as structural barriers that
restrict lecturers’ ability to integrate diverse assessment strategies effectively into their
lessons (Moges, 2018). As  a  result,  some  lecturers  acknowledged  omitting  key  OBE-related
practices, such as sharing learning objectives, assessment criteria, and implementing self- and
peer-assessment, because the time provided was too short relative to the breadth of content
required (Moges, 2018).

Overall, the findings indicate that different colleges assessing students inconsistently, which
led  to  a  major  fairness  problem. In  the  absence of  common  standards  across  colleges,

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 617
lecturers  interpret  marking criteria differently  and  practice irregular marking. This  pattern
reflects a policy-practice gap in OBE implementation where policy claims all students should
achieve  similar outcomes, but  colleges don’t have the coordination, training,  or  support
system  need  to  work  consistently. Without  a  centralised mechanism to  set  standards  and
ensure  college  are  marking  the  same way,  misalignment  is  likely  to  persist  and  normalise
sudden  assessment  judgement  under  time  pressure,  undermining  confidence  in  outcome
claims across the Matriculation Programme.

Conceptual Ambiguity in Understanding OBE and Assessment
In  higher  education,  assessment  methods  have  traditionally  been  stuck  in  a  testing culture
with a strong emphasize on assessment of learning rather than assessment for learning. This
culture reinforcing the tendency to equate assessment with examinations (Williams, 2024).
This exam-oriented focus is evident in how students are constantly put through for high stakes
summative  assessments, rather  than  continuous  learning  and  development (Baartman and
Quinlan,  2024). Empirical  findings show consistently indicate  that  most grading remain
summative in nature, even though teachers agree that formative, ongoing feedback is what
helps  student  improve. This  agreement led to  a  major  gap between  what  assessment  is
supposed to do and how its practice (Alqahtani et al. 2025). Part of this problem is that the
traditional learning theories treat formative assessment as a separate, end of lesson activity
rather  than natural part of  daily  learning which  causes  confusion about  how  it  fits  into the
whole curriculum (Moges, 2018). As a result, traditional assessment still favours memorizing
facts  and  theories, while  failing  to measure  practical  competencies,  deep  reflection  and
creativity  and  ultimately failing  to  show  the  full  picture  of  student  achievement  and
development (Radzali et al. 2025).

A  central  concern  in  rigid  assessment  practices  is  that  formative  assessment  is  incomplete
without   a   follow-up   stage   that   allows   both   students   and   teachers   to adjust and
improvements, highlighting the importance of iterative learning processes rather than one-
off judgments (van der Steen et al. 2023). In this regard, scholars have emphasized the need
to  permit  students  to  resubmit  their  work  after  improvement,  as  such  practices  enable
learners to act on feedback and demonstrate progress over time (Moges, 2018). This point of
view aligns assessment  more  closely  with  learning  enhancement  than just grading by
redefining  it  as  an  active  process  of  feedback-informed  development  rather  than  just  and
endpoint (McGuire, 2025). However, experienced educators recognize the challenge to build
a  room  for  change  and  advancement  when  teaching  with  excessively  pack  course  outline
which  frequently  reinforces  strict  and  inflexible  assessment  methods (van  der  Steen et  al.
2023). Time restraint and excessive administrative workload worsen these issues by acting as
structural  obstacles  to continuous  assessment  and  limiting the  availability of meaningful
formative feedback (Shahazwan et al. 2025).

Conceptual ambiguity is  further  intensified  by  structural  time  constraints.  This encourages
reliance   on familiar examination-oriented   assessment   practices   rather and   reduce
opportunities to perform continuous assessment effectively.

There is uncertainty about the best order for assessment, which is a part of a larger debate in
education. Currently,  researchers do  not  know  much  about  whether it’s better  to  teach
theory first then followed by practice or vice versa in relation to assessment design (Natarajan

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 618
et  al. 2021). This  uncertainty  has  led  prompted  researcher to  explicitly  examine whether
curricula  should  use  a ‘capstone’ approach where  theory  comes  before  practice  or  a
‘foundation  stone’ approach where  practical  experience  introduced  first (Natarajan et  al.
2021).  This  shows that there  is  no agreement on  the  best order  of  assessments. From  the
learner’s perspective, student feedback has shown a strong preference for a ‘theory before
practice’ sequencing, suggesting that students may feel better prepared to engage in practical
assessments after gaining sufficient conceptual understanding (Natarajan et al. 2021).

Various   teaching   and   assessment   styles   currently   coexist across   higher   education   is
demonstrated  by  differences  in  assessment  practices whereby  varied  expectations  and
method are created among lecturers (Keong et al. 2020). These variations are largely shaped
by the fact that instructors’ perceptions of assessment directly influence how assessment is
designed  and  implemented,  leading  to opposite interpretations  of  appropriate  assessment
practices (Moges, 2018). Professional discussion reveals a clear diversity of understanding, as
lecturers  report  that different  viewpoints  among  colleagues  confuse  the  design  of  suitable
assessment  tools which further  complicating  efforts  to  establish  shared  assessment  norms
(Muspardi et  al. 2020).  Consequently,  the  lack  of  clarity  arising  from  these  divergent
perspectives  results  in  diverse  interpretations  among  stakeholders  such  as  module  leaders
and  tutors,  who  may  prioritize  different  aspects  of  assessment  transparency  and  rigor
(Gonsalves and Lin, 2025). Over time, such variability has been shown to produce inconsistent
application of assessment criteria across departments within the same institution, reinforcing
confusion among both educators and students (Gonsalves and Lin, 2025).

Overall,  the results  show  that  lecturers  frequently  continued  to  use traditional, exam-
oriented approach  because  of  conceptual  ambiguity surrounding the assessment’s goal
within  OBE  frameworks. This ambiguity significantly reduced  the  purpose of  continuous
assessment for  student  learning.  Consequently, these  results show  a  profound disconnect
between OBE policy and what actually happens in practice. The policy says assessment should
show evidence of student learning, but lecturers are working in an environment with heavy
workloads.  At  the  same time,  existing assessment  cultures  push  them  to  focus  on  giving
grades   and   covering   content father   than   helping   students   improve   progressively. If
Matriculation Programme doesn’t provide clearer guidance and proper training to helps
lecturers understand assessment purposes better, the system will end up using OBE policy on
paper  while  implementation  works  like traditional  exam  focused  system. This  could  make
outcome claims less credible of how students are actually developing and learning.

Limit Awareness of Constructive Alignment as a core OBE Principle
Identifying and  understanding  the constructive  alignment in curriculum  and  assessment
widely recognized as challenging especially when it involves alignment of learning outcomes
at different level such as in modules, programmes and national qualifications. (Loughlin et al.
2021). This challenge is anchor by valid practice where learning outcomes mostly specified for
the  sake  of paperwork while  other  syllabus is  kept  blurry  on  purpose. The  document  of
paperwork technically exists but does not actually help educators understand or use the real
principle of constructive alignment (Loughlin et al. 2021).

Nasrallah  (2014)  and  Romanowski  et  al.  (2024) further  indicates  that  attempts  to  align
learning    outcomes    with    teaching    methods,    institutional    plans,    and    accreditation

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 619
requirements  have,  in  some  contexts,  added  to  faculty  misinterpretations  rather  than
clarifying   constructive   alignment,   reinforcing   conceptual   ambiguity (Nasrallah,   2014;
Romanowski et  al. 2024).  At  the  policy  level,  superficial  alignment  has  been  shown  to
encourage  the  sterile  creation  of  learning  outcomes  designed  to  fit  existing,  unmodified
modules, weakening the intended pedagogical coherence of CA (Loughlin et al. 2021). Such
issues are often intensified by a lack of institutional strategic vision or clarity, which can lead
to weakened alignment practices or a compliance-oriented, ‘tick-the-boxes’ implementation
of constructive alignment (Ruge et al. 2019).

According  to  Romanowski  et  al.  (2024),  lecturers  who  receive  insufficient  training  on
constructive alignment become confused of some important issues. This demonstrates how
insufficient  exposure  to  constructive  alignment  causes  lecturers  to  have  misconceptions
about learning outcomes, such as their crucial role in teaching and assessment practices, their
inability to understand what they mean, and their confusion with objectives (Romanowski et
al. 2024). As  reflected  in  findings,  there  also  a  small number  of  faculty  members who
demonstrate  an  adequate  understanding  of  learning  outcomes, while many  remaining
unaware of the student-centered nature that underpins constructive alignment (Romanowski
et al. 2024). Other than getting the definition problem, Ali (2018) pointed out that the real
problem in higher education is figuring out how to make constructive alignment work in real
classroom (Ali,  2018). Constructive  alignment worsens this limited  understanding  in  new
institutional context where lecturers frequently interpret procedures and practice differently,
leading  to  inconsistent  enactment (Bauer and Kenton,  2005;  Romanowski et  al. 2024).
Consequently, key alignment components such as learning objectives, instructional activities,
and  assessment  tasks are  frequently  missing  or  not  explicitly  linked,  reflecting  practical
implementation gaps that stem from limited conceptual clarity (van der Steen et al. 2023).

This lack of  knowledge  about  constructive  alignment  is  related to assessment  literacy,  as  it
limits  lecturers'  capacity  to  create  tasks,  rubrics,  and  scoring  procedures  that  make  sense.
Despite the absence of precise conceptual knowledge about constructive alignment, lecturers
still engage in understanding alignment decision that were influences by time constraints and
institutional requirements rather than pedagogical considerations.

In practice, the findings show that constructive alignment usually just ends up as paperwork
that need to complete rather than actual teaching principle that should guide them how to
design assessments and teach in classes. The gap between OBE policy and actual practice is
enormous. The policy requires lecturers to demonstrate alignment in curriculum documents,
but there is not enough support for actual training or time they need to apply in their everyday
teaching. Without  enough institutional support and proper  training,  OBE  will  just  become
‘tick-the-box’ where people fill out forms to meet requirements. This undermines the whole
point of OBE where we can’t trust that student outcomes are actually meaningful.

Structural Time Constraints and Assessment Feasibility
Teaching  a  large  class  size with  limited  instructional  time  consistently constraint  lecturer
ability to integrate comprehensive assessment strategies in their teaching practices (Moges,
2018). These constraints get even worse when lecturers don’t have enough time to conduct
continuous assessment because of paperwork and marking demands which limit frequency
of assessment can be done. (Shahazwan M. T. et al. 2025). Senouci (2022) found that allocate

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 620
instructional time such as one and a half hours per week is not enough for implementing the
constructively  aligned  assessment  approaches.  Lecturer more  prioritizes the  completion of
syllabus over a time rather than doing many assessments activities. (Senouci, 2022). Due to
the limited time to cover the syllabi content, this condition led to a situation where lecturer
skip   over   the assessment   practices   including communicating   the   learning   objectives,
assessment  criteria, and  implementation  of  self  and  peer  assessment  (Moges,  2018). This
condition consistent with Shahazwan M. T. et al. (2025) findings where time constraint and
heavy  administrative  workloads  become systematic  barriers  to  continuous  assessment  and
reducing the effectiveness of formative feedback to the students.

These structural time constraints also amplify systemic misalignment across colleges, because
inconsistent   assessment   expectation reduce opportunities   for   coordinated   assessment
planning and increase pressure for rapid, localised implementation decision.

Practical   and   performance-based   assessments   are   widely   acknowledged   to   require   a
substantial  amount  of  time  and  a  high  level  of  precision  from  lecturers,  making  them
particularly  vulnerable  to  scheduling  pressures  within  the  academic  semester (Muspardi et
al. 2020). Under such tight timelines, lecturers have reported modifying or reducing planned
assessment activities, including skipping certain tasks or reallocating them as homework, to
cope with limited time for implementation (Lestari and Yusuf, 2025). These constraints also
help explain why lecturers tend to limit the use of constructively aligned practices and instead
rely on simpler assessment formats, such as quizzes or group-based assignments, especially
when  attempting  to  assess  large  student  cohorts  within  restricted  timeframes (Senouci,
2022).  Furthermore,  concerns  have  been  raised  regarding  the  reliability  and  accuracy  of
assessments  conducted  within  very  short  periods,  leading  some  lecturers  to  question
whether  high-stakes  summative  components,  such  as  final  examinations,  should  carry
substantial weighting under such conditions (Basera, 2019).

As part of the curriculum structure design, Student Learning Time (SLT) is formally embedded
withing Summary  of  Course  Information  (SCI) which  specifies Programme  Objectives  (PO),
learning  outcomes  and the  calculation  of  SLT (Md  Jani et  al. 2020).  However, there  is a big
difference between theoretical curriculum planning and classroom realities. Lecturer struggle
to  integrate  curriculum-based  assessment practice while following  the documented SLT
requirement. (Shahazwan et al. 2025).

Previous studies that specifically map assessment schedules and the quantity of assessment
tasks to SLT allocations provide more proof of this misalignment, indicating that the workload
state in curriculum documents might not be reflected in the current implementation (Md Jani
et al. 2020). According to practitioners’ viewpoint, institutional expectations may not match
pedagogical realities, and variations in lecturers' and institutions' definitions of a "successful
program"  also  lead  to  the  uneven  implementation  of  SLT  recommendations (O’Neill et  al.
2024).  At  a  conceptual  level,  critiques  have  argued  that  formal  models  of  constructive
alignment  and  SLT  fail  to  account  for  the  local,  experiential,  and  context-specific  nature  of
teaching  practice,  which  further  explains  why  SLT  prescriptions  are  not  always  faithfully
enacted in real teaching and assessment contexts (Romanowski et al. 2024).


## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 621
Overall, lecturers  are  prevented  from  conducting  adequate  assessments  by  their  busy
schedules. Having  a  complex, need  detailed  feedback and  precision, and  lack  of  hours  for
assessment  prevent  them to  follow  through  the  continuous  assessment. This  highlights a
major disconnect between OBE policy and actual practice. College documentation assumes a
certain  SLT  and  lecturer  effort,  but  those  numbers  are often  unrealistic for  the  actual
classroom practice. The policy assumes time and resources that match the reality of teaching
conditions. If  the  system  does  not make  an  adjustment on workload  models,  assessment
schedule, and administrative demands, things won’t get better. Lecturer will keep simplifying
assessment to meet requirement rather than doing the high-quality teaching. Consequently,
the system will continue rewarding compliance over quality.

Assessment Literacy: Rubrics, Task Design, and Scoring Practices
Assessment rubrics used in practice are often reduced to checklists that are easily converted
into scoring sheets with simple ‘yes/no’ decision. This decision thereby limiting the ability to
represent varying levels of student achievement (Allen and Tanner, 2006). According to Ling,
(2024) this issue is worsened because of many rubrics are inconsistent and characterized by
dichotomous positive/negative tone. Instead of offering a distinct evaluation, this rubric force
educator to make binary judgement. Even though the use of rubrics is widespread, many are
still confusing for both teachers and students. This lack of clarity prevents them from being
function  as  transparent  tools (Orrell,  2020). One  big  reason  for  this weakness  is  that  the
performance levels are not usually based on actual learning frameworks but relying on vague
words like “satisfactory” or “excellent” which  offer  a  little guidance  to  the  performance
standard. Because  of  this,  lecturers  have  reported struggle  with  inconsistence  grading  and
personal  bias.  This   ultimately   compromises  the  reliability   and  fairness   of   assessment
outcomes (Alqahtani et al. 2025).

Since creating enough high-quality items consistently has been found to be challenging across
disciplines, the difficulty of creating high-quality assessment questions is widely recognized,
demonstrating that this issue occurs everywhere and not just in one context (Karthikeyan et
al. 2019). The problem is made even worse by the fact that there is limited research explaining
why people struggle to write high quality assessment item in the first place. Because of this
limitation,   educators   are   often   left   without any   clear   guidance   on   how   to   improve.
(Karthikeyan et al. 2019). Research shows that many educators lack the right skills to create
their own assessment questions. Because of this, they often recycle past examination papers
instead  of developing  new  ones that fit  the class  learning. (Senjiro and Lupeja,  2023;  Shafii
and Berger, 2025).

These  assessments  literacy  challenges  interact  with conceptual  ambiguity  in  OBE, where
uncertainty  about  assessment  purpose reduces lecture’s ability  to  design  task  that capture
higher order learning outcomes.

In terms of difficulty, the development of higher order thinking skills (HOTS) question is always
misunderstood particularly about its concept and lack of knowledge how to test for it. This
makes it tough for them to create questions that really make students think hard (Lestari and
Yusuf, 2025). Because of this, educators usually resort to basic oral questions, classwork, or
homework task that  does not  really  connect with what  they  are  teaching  daily. This  means

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 622
the questions they user don’t really help students learn  better  or  show  what  they know
(Moges, 2018).

A recurring issue  in  assessment  reporting otherwise  is  about the  tendency  for  lecturers  to
submit  only  final grade  without supporting explanations  details, thus  limit management’s
ability to understand  the  factors of students’ low performance (Muspardi et  al. 2020).  This
practice usually reinforced  by  institutional  reporting system,  where  academic  portals  often
require only summary grades, thereby reducing the evidence support of student assessment
attitudes, knowledge and skills. (Muspardi et al. 2020). In addition to these systematic factors,
educators also face practical difficulties in processing and entering assessment data in detail,
especially for a large  class size. Thus,  educators become  discouraged  to  prepare  the
comprehensive assessment report to represent the student learning development. (Muspardi
et   al. 2020). Taken   together,   these   assessments   conditions   reflect   the   influence of
administrative   accountability   pressure,   where   reporting,   monitoring,   and   compliance
requirements increasingly shape assessment practices beyond pedagogical considerations.

As  a  part  of educator  daily  routine,  making  tests,  grading  students  and manage  student
learning seem to be burden when they are being watched and checked by the administrator.
(Parsons and Slabbert, 2001). This situation becomes distinct when assessment policies are
perceived as policing mechanisms, where the supervisor in administration closely monitor the
test  instrument to  ensure the guidelines are  being followed (Mussawy et  al. 2021). This
scrutiny came  from  the broader  managerial  demands  on  higher  education  institutions  to
value the money invested,  improve the productivity,  and to respond  to  external pressure
(Parsons and Slabbert,  2001). From  governance level,  policy makers believe  that  they  have
the right to watch academic staff allocate their time in institutions and demand efficiency and
effectiveness  across  institutional  operations (Parsons and Slabbert,  2001).  Consequently,
institutions increasingly rely on management information systems to generate detailed data
for accountability purposes, makes many lecturers feel that all the reporting is just a way for
management to control them (Parsons and Slabbert, 2001).

Overall,  the  findings show that lecturers  struggle  with  assessment  literacy  such  as  creating
good  rubrics, developing quality  test  items,  and evaluating  complex  thinking  skills. When
rubrics are too simple of teachers don’t know how to test critical thinking, the evaluation and
grading don’t actually prove what students learned. There is a significant gap between OBE
policy expectations and what is happening. Administrative keep pushing lecturers to report
student  outcome and  meet accountability  requirements which  makes  lecturers  focus  on
filling out paperwork instead of focusing on real teaching. Without systemic training and clear
guidelines to improve rubric quality, test design, and consistent grading, OBE risks producing
outcomes score that don’t credibly reflect actual student learning experiences.

This study suggests three key contributions to the literature on OBE and assessment practices.
First, in conceptually, it advanced the understanding of assessment misalignment by framing
it as a systematic and institutional phenomenon rather than an individual lecturer weakness.
Second, through empirical, it provides rare multi-college qualitative evidence from a centrally
management pre-university system, extending the existing OBE research that largely focused
on   single   institutions   or   quantitative   self-reports.   Next,   as   practically,   the   findings
demonstrate    how    accountability    compliance-oriented    assessment    practices    offering

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 623
important implications for education  policymakers  and  institutional  leaders  responsible for
OBE implementation.

## Conclusion
This  multi-college  qualitative  study  examined  systemic  misalignment  in  OBE  assessment
practices  among  science  lecturers  in  the  Malaysian  Matriculation  Programme. Qualitative
analyze reveals that  misalignment  is  sustained  by  institutional,  structural,  and  conceptual
conditions rather than isolated lecturer shortcomings. Assessment practices among lecturers
shows an absence of shared assessment framework and varies across colleges, compromising
the fairness  and  transparency. Lecturers demonstrate  a  significant  lack  of  clarity  about  the
specific function   and   component   of   assessment   in   OBE,   which   mostly   limited   by
understanding of  constructive  learning. Structural barriers including heavy  workloads  and
rigid time requirements restricted the implementation of continuous assessment while lack
of  assessment  literacy  led  to simplified rubric and inability  to  design assessment  in  higher
order thinking. Together,  these  conditions  illustrate  how  policy-driven  OBE  reforms,  when
enacted under strong administrative accountability pressure, can translate into compliance-
oriented assessment practices that compromise educational quality. Without addressing the
constraints identified, assessment will continue to diverge from intended learning outcomes,
undermining the integrity of pre-university level science education and potentially affecting
student readiness for tertiary study. There are some limitations on this study. The results are
context and specific and cannot be used to generalised as it is qualitative exploration.  The
focus   on   science   lecturers within   the   Malaysian   Matriculation   Programme   may   limit
transferability to other educational systems. Future research could extend this work through
mixed-methods  design,  longitudinal  studies,  or  comparative analyses across  different  pre-
university  of  foundation  studies  to  further  examine  how  systemic  conditions  shape  OBE
assessment practices.

## Glossary
FGD  Focus Group Discussion
HOTS  Higher Order Thinking Skills
PO  Programme Outcomes
OBE  Outcome-Based Education
SCI  Summary of Course Information
SDG  Sustainable Development Goals
SLT  Student Learning Time

## Acknowledgements
The authors would like to express their sincere appreciation to the science lecturers from the
Malaysian  Matriculation  Programme  who  generously  shared  their  experiences  and  insights
during the focus group discussions and interviews. Their willingness to participate made this
study  possible.  The  authors  also  acknowledge  the  support  and  facilitation  provided  by  the
relevant matriculation colleges during the data collection process.
This  research  did  not  receive  any  specific  grant  from  funding  agencies  in  the  public,
commercial, or not-for-profit sectors.

Disclosure statement
No potential conflict of interest was reported by the authors.

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 624
## References
Ag  Damit,  M.  A.,  Omar,  M.  K., and Mohd  Puad,  M.  H.  (2021).  Issues  and  Challenges  of
Outcome-based Education (OBE) Implementation among Malaysian Vocational College
Teachers. International  Journal  of  Academic  Research  in  Business  and  Social  Sciences,
11(3). https://doi.org/10.6007/ijarbss/v11-i3/8624
Agensi Kelayakan Malaysia. (2014). Standard Kursus Asas (Foundation).
Ali, L. (2018). The Design of Curriculum, Assessment and Evaluation in Higher Education with
Constructive  Alignment. Journal  of  Education  and  E-Learning  Research, 5(1),  72–78.
https://doi.org/10.20448/journal.509.2018.51.72.78
Allen,  D., and Tanner,  K.  (2006). Feature  Approaches  to  Biology  Teaching  and  Learning
Rubrics:  Tools  for  Making  Learning  Goals  and  Evaluation  Criteria  Explicit  for  Both
Teachers and Learners. https://doi.org/10.1187/cbe.06
Almuhaideb, A. M., and Saeed, S. (2020). Fostering sustainable quality assurance practices in
outcome-based   education:   Lessons   learned   from   abet   accreditation   process   of
computing programs. Sustainability (Switzerland), 12(20), 1–21.
https://doi.org/10.3390/su12208380
Alonzo,  D.,  Bejano,  J., and Labad, V. (2022). Alignment between Teachers’ Assessment
Practices  and  Principles  of  Outcomes-Based  Education  in  the  Context  of  Philippine
Education Reform. International Journal of Instruction, 16(1), 489–506.
https://doi.org/10.29333/iji.2023.16127a
Alqahtani, A. S., Al-Nasser, S., Alzahem, A., and Alqhtani, N. R. (2025). Educators’ perceptions
and challenges of student assessment process at Prince Sattam Bin Abdulaziz University
dentistry     program:     a     qualitative     study. BMC     Medical     Education, 25(1).
https://doi.org/10.1186/s12909-025-07227-2
Baartman, L. K. J., and Quinlan, K. M. (2024). Assessment and feedback in higher education
reimagined:    using    programmatic    assessment    to    transform    higher    education.
Perspectives: Policy and Practice in Higher Education, 28(2), 57–67.
https://doi.org/10.1080/13603108.2023.2283118
Basera, C. H. (2019). Learners’ perceptions of assessment strategies in higher education.
Journal of Education and E-Learning Research, 6(2), 76–81.
https://doi.org/10.20448/journal.509.2019.62.76.81
Bauer, J., and Kenton, J. (2005). Toward Technology Integration in the Schools: Why It Isn’t
Happening. Journal of Technology and Teacher Education, 13(4), 519–546.
Biggs,  J., and Tang,  C.  (2011). Teaching  for  Quality  Learning  at  University (4th  Edition).
McGraw-Hill.
Dennin, M., Schultz, Z. D., Feig, A., Finkelstein, N., Greenhoot, A. F., Hildreth, M., Leibovich, A.
K., Martin, J. D., Moldwin, M. B., O’Dowd, D. K., Posey, L. A., Smith, T. L., and Miller, E.
R.  (2017).  Aligning  practice  to  policies:  Changing  the  culture  to  recognize  and  reward
teaching at research universities. CBE Life Sciences Education, 16(4).
https://doi.org/10.1187/cbe.17-02-0032
Derouich,  M.  (2025). Ensuring  Outcome-Based  Curriculum  Coherence  through  Systematic
CLO-PLO Alignment and Feedback Loops.
Gonsalves,  C., and Lin, Z. (2025). Clear in advance to whom? Exploring ‘transparency’ of
assessment  practices  in  UK  higher  education  institution  assessment  policy. Studies  in
Higher Education, 50(7), 1454–1470. https://doi.org/10.1080/03075079.2024.2381124
Hailikari,  T.,  Virtanen,  V.,  Vesalainen,  M., and Postareff,  L.  (2022).  Student  perspectives  on
how  different  elements  of  constructive  alignment  support  active  learning. Active

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 625
Learning in Higher Education, 23(3), 217–231.
https://doi.org/10.1177/1469787421989160
Handayani,  N.  U., and Wibowo,  M.  A.  (2021).  Implementation  Strategy  of  Outcome-Based
Education:  A  Case  Study  in  Engineering  Faculty Diponegoro  University. Proceedings  of
the   Second   Asia   Pacific   International   Conference   on   Industrial   Engineering   and
## Operations Management Surakarta, Indonesia, 420–433.
Karthikeyan, S., O’Connor, E., and Hu,  W.  (2019).  Barriers  and  facilitators  to  writing  quality
items  for  medical  school  assessments - A  scoping  review.  In BMC  Medical  Education
(Vol. 19, Number 1). BioMed Central Ltd. https://doi.org/10.1186/s12909-019-1544-8
Keong,  S.  M.,  Juan,  S.  C., and Wen,  K.  C.  (2020).  A  Malaysian  Outcome-Based  Engineering
Education  Model:  The  Implementation  and  Challenges  in  Future. INTI  Journal, 2020
(20)(September).
Kushari,  B., and Septiadi,  L.  (2022).  A  learning  outcome  assessment  information  system  to
facilitate Outcome-Based Education (OBE) implementation. Jurnal Pendidikan Teknologi
Dan Kejuruan, 28(2). https://doi.org/10.21831/jptk.v28i2.42339
Leber,  J.,  Renkl,  A.,  Nückles,  M., and Wäschle,  K.  (2018).  When  the  type  of  assessment
counteracts teaching for understanding. Learning: Research and Practice, 4(2), 161–179.
https://doi.org/10.1080/23735082.2017.1285422
Lestari, S., and Yusuf, F. N. (2025). Aligning Assessment Practices with Learning Objectives: A
Case  of  EFL  Classes  in  Indonesia.  In Aligning  Assessment  Practices  with  Learning
Objectives Indonesian Journal of English Language Teaching and Applied Linguistics (Vol.
10, Number 1). http://dx.doi.org/10.210
Ling, J. H. (2024). Pedagogy: Indonesian Journal of Teaching and Learning Research A Review
of  Rubrics  in  Education:  Potential  and  Challenges. OPEN  ACCESS  JOURNAL  Pedagogy:
Indonesian Journal of Teaching and Learning Research, 2(1), 1–14.
Loughlin, C., Lygo-Baker, S., and Lindberg-Sand, Å. (2021). Reclaiming constructive alignment.
European Journal of Higher Education, 11(2), 119–136.
https://doi.org/10.1080/21568235.2020.1816197
McGuire, M. (2025). Feedback, reflection and psychological safety: rethinking assessment for
student well-being in higher education. Assessment and Evaluation in Higher Education.
https://doi.org/10.1080/02602938.2025.2548590
Md Jani, M. D. Bin, Latif, A. B. A., Talib, R. B., and Is, N. B. M. (2020). The implementation of
constructive alignment at the teachers education institute using rasch analysis. Journal
of Critical Reviews, 7(11), 659–665. https://doi.org/10.31838/jcr.07.11.120
Moges, B. (2018). The implementations and challenges of assessment practices for students’
learning  in  public  selected  universities,  Ethiopia. Universal  Journal  of  Educational
Research, 6(12), 2789–2806. https://doi.org/10.13189/ujer.2018.061213
Mohd Noor, A. F., Shukor, K. A., Hamdan, N., Abdul Basir, M. K., Latif, M. K., Saharudin, N. A.,
and Adnan, A. (2021). A Pilot Study of the Outcome-Based Education (Obe) Achievement
and  The  Implementation  of  Self-Regulated  Learning  Strategies  in  Islamic  Studies.
International  Journal  of  Academic  Research  in  Business  and  Social  Sciences, 11(7).
https://doi.org/10.6007/ijarbss/v11-i7/10584
Mufanti,  R.,  Carter,  D., and England,  N.  (2024).  Outcomes-based  education  in  Indonesian
higher education: Reporting on the understanding, challenges, and support available to
teachers. Social Sciences and Humanities Open, 9.
https://doi.org/10.1016/j.ssaho.2024.100873

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 626
Muspardi,   M.,   Yusmanila,   Y., and Desmariani,   E.   (2020). Problematika   Dosen   Dalam
Menggunakan   Instrumen   Penilaian   Pendidikan   Keterampilan   Umum   Mahasiswa
Berbasis Standar Nasional Tinggi (SN-Dikti). Jurnal Education and Development, 8(4).
Mussawy,  S.  A.  J.,  Rossman,  G., and Haqiqat, S. A. Q. (2021). Students’ and Teachers’
perceptions  and  experiences  of  classroom  assessment:  A  case  study  of  a  public
university  in  Afghanistan. Higher  Learning  Research  Communications, 11(2),  22–39.
https://doi.org/10.18870/hlrc.v11i2.1244
Nasrallah, R. (2014). Learning outcomes’ role in higher education teaching. Education,
Business    and    Society:    Contemporary    Middle    Eastern    Issues, 7(4),    257–276.
https://doi.org/10.1108/EBS-03-2014-0016
Natarajan, S., McCullen, N., Lo, S., Coley, D., Arja, O. A., and Moran, F. (2021). Practice before
theory? An approach for testing sequencing effects in pedagogical design. International
Journal of Technology and Design Education, 31(5), 981–1000.
https://doi.org/10.1007/s10798-020-09579-w
O’Neill, T., Hartigan, K., and Spillane,  J.  P.  (2024).  Factors  Inhibiting  Higher  Education
Institutions from addressing Industry driven change in Irish Construction Management
Programs. International Journal of Construction Education and Research, 20(1), 65–82.
https://doi.org/10.1080/15578771.2023.2181471
Orrell,  J.  (2020). Designing  an  assessment  rubric.  Tertiary  Education  Quality  and  Standard
## Agency. Australia.
Parsons, P. G., and Slabbert, A. D. (2001). Performance management and academic workload
in higher education. South African Journal of Higher Education, 15(3), 74–81.
Priya Vaijayanthi, R., and Raja Murugadoss, J. (2019). Effectiveness of curriculum design in the
context  of  outcome-based  education  (OBE). International  Journal  of  Engineering  and
Advanced Technology, 8(6), 648–651. https://doi.org/10.35940/ijeat.8090.088619
Radzali,  M.,  Yusof,  I.  J., and Tee, Y. L. (2025). Profiling Educators’ Alternative Assessment
Practices in Malaysian Vocational Colleges: A Psychometric Perspective BACKGROUND
OF  THE  STUDY. International  Journal  of  Research  and  Innovation  in  Social  Science
(IJRISS), IX(VIII), 64706483. https://doi.org/10.47772/IJRISS
Romanowski,  M.  H.,  Alkhateeb,  H., and Chaaban,  Y.  (2024).  Problematizing  constructive
alignment in higher education in gulf cooperation council countries. Teaching in Higher
Education, 29(8), 2042–2060. https://doi.org/10.1080/13562517.2023.2180729
Ruge, G., Tokede, O., and Tivendale, L. (2019). Implementing constructive alignment in higher
education–cross-institutional  perspectives  from  Australia. Higher  Education  Research
and Development, 38(4), 833–848. https://doi.org/10.1080/07294360.2019.1586842
Senjiro,  U., and Lupeja,  T.  (2023).  The  influence  of  formative  assessment  practices  in
promoting  21st  Century  skills  development  among  secondary  school  students  in
Tanzania. International   Journal   of   Research   Studies   in   Education, 12(6),   1–8.
https://doi.org/10.5861/ijrse.2023.29
Senouci, M. (2022). Continuous Assessment in Higher Education: EFL Teachers’ Practices and
Challenges. Langues  et  Cultures  Linguistiques  à  l’oeuvre, 9   (3).   https://aleph-
alger2.edinum.org/5440
Shafii,  R.  A., and Berger,  J.  L.  (2025).  Teacher  assessment  literacy,  formative  assessment
practices,  and  their  perceived  efficacy  in  Tanzania:  A  scoping  review. Studies  in
Educational Evaluation, 86. https://doi.org/10.1016/j.stueduc.2025.101496
Shahazwan  M.  T.,  Anwar  Farhan  M.  M,  Noorhayati  Z., and Hao  L.  (2025).  Exploring  The
Implementation  of  Classroom-Based  Assessment  in  Malaysian  Secondary  Schools:

## INTERNATIONAL JOURNAL OF ACADEMIC RESEARCH IN BUSINESS AND SOCIAL SCIENCES
## Vol. 16, No. 2, 2026,
## E-ISSN: 2222-6990
## © 2026
## 627
Alignment With Policy and Teacher Practices. Malaysian Online Journal of Educational
Management (MOJEM), 13, 81101. http://mojem.um.edu.my
The Quality Assurance Agency for Higher Educaton. (2008). Outcomes from institutional audit
Assessment of students Second series Sharing good practice. www.qaa.ac.uk
van der  Steen, J.,  van Schilt-Mol,  T.,  van der  Vleuten,  C., and Joosten-ten  Brinke, D.  (2023).
Designing  Formative  Assessment  That  Improves  Teaching  and  Learning:  What  Can  Be
Learned from the Design Stories of Experienced Teachers? Journal of Formative Design
in Learning, 7(2), 182–194. https://doi.org/10.1007/s41686-023-00080-w
Williams, A. (2024). Delivering Effective Student Feedback in Higher Education: An Evaluation
of the Challenges and Best Practice. International Journal of Research in Education and
Science, 10(2), 473–501. https://doi.org/10.46328/ijres.3404
Yusof,  R.,  Othman,  N.,  Norwani,  N.  M.,  Ahmad,  N.  L.  B., and Jalil,  N.  B.  A.  (2017).
Implementation  Of  Outcome- Based  Education  (OBE)  In  Accounting  Programme  In
Higher  Education. International  Journal  of  Academic  Research  in  Business  and  Social
Sciences, 7(6). https://doi.org/10.6007/ijarbss/v7-i6/3352

