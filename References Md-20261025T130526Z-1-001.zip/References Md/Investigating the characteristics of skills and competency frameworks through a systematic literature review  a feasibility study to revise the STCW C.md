

##### 

**ISSN: 1836-6503 (Print) 2333-6498 (Online) Journal homepage: www.tandfonline.com/journals/ramo20** 



# **Investigating the characteristics of skills and competency frameworks through a systematic literature review: a feasibility study to revise the STCW Code for seafarer training** 

## **Samrat Ghosh, Gholam Reza Emad & Anand Ravi** 

**To cite this article:** Samrat Ghosh, Gholam Reza Emad & Anand Ravi (2025) Investigating the characteristics of skills and competency frameworks through a systematic literature review: a feasibility study to revise the STCW Code for seafarer training, Australian Journal of Maritime & Ocean Affairs, 17:4, 616-632, DOI: 10.1080/18366503.2024.2374606 

**To link to this article:** <u>https://doi.org/10.1080/18366503.2024.2374606</u> 











© 2024 The Author(s). Published by Informa View supplementary material UK Limited, trading as Taylor & Francis Group Published online: 08 Jul 2024. Submit your article to this journal Article views: 3176 View related articles View Crossmark data Citing articles: 5 View citing articles 







Full Terms & Conditions of access and use can be found at https://www.tandfonline.com/action/journalInformation?journalCode=ramo20 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 2025, VOL. 17, NO. 4, 616–632 https://doi.org/10.1080/18366503.2024.2374606 



Investigating the characteristics of skills and competency frameworks through a systematic literature review: a feasibility study to revise the STCW Code for seafarer training 

Samrat Ghosh , Gholam Reza Emad and Anand Ravi 

National Centre of Ports and Shipping, Australian Maritime College, University of Tasmania, Hobart, Australia 

#### ABSTRACT 

<mark>R</mark> ecent research has provided a strong foundation to believe tha <mark>t</mark> future seafarers are expected to possess a traditional seafaring licence as a prerequisite for obtaining a licence to operate ‘smart’ ships [Maritime Autonomous Surface Ships (MASS)]. Since the standards of competence for a traditional seafaring licence are dictated by the Standards of Training, Certification, and Watchkeeping (STCW) Code, it may be implied that the Code may have to reinvent itself to include skills and competencies which will be relevant for the seafaring workforce of the future to take on expected roles and responsibilities. The question, thus arises, should the STCW Code continue in its current form in laying down the standards of competence, or should it draw lessons from skills and competency frameworks (used for the workforce of other industries) to outline defined set of behaviours deeply valued by the maritime industry? This question drove a systematic literature review, based on which, this paper presents findings to answer if past research had investigated the feasibility of the STCW Code to be translated into a skills and competency framework. This study also delved deeper into the essential characteristics of the frameworks which need to be imbibed (or which already exist) in the Code to continue allowing it to be relevant. 

### 1. Introduction 

The shipping industry is currently undergoing an extensive transition period during which an increasing number of Maritime Autonomous Surface Ships or MASS (with differing levels of autonomy) are being introduced to test their effect on the efficiency of operations. As the autonomy of ship systems increases, focus will shift to issues such as the operation of autonomous systems and human interaction with manned and unmanned ships from the shore control centres (SCC) (Lee 2008; Streng and Kuipers 2020). Hence, current seafarers (who have traditionally being employed on non-autonomous ships) will need to undergo new forms of training to play a key role in operating the ships of 

> © 2024 The Author(s). Published by Informa UK Limited, trading as Taylor & Francis Group 

This is an Open Access article distributed under the terms of the Creative Commons Attribution-NonCommercial-NoDerivatives License (http://creativecommons.org/licenses/by-nc-nd/4.0/), which permits non-commercial re-use, distribution, and reproduction in any medium, provided the original work is properly cited, and is not altered, transformed, or built upon in any way. The terms on which this article has been published allow the posting of the Accepted Manuscript in a repository by the author(s) or with their consent. 

CONTACT Samrat Ghosh sghosh@utas.edu.au Supplemental data for this article can be accessed online at https://doi.org/10.1080/18366503.2024.2374606 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 617 

the future (Hogg and Ghosh 2016; Sharma et al. 2019). This was recently validated in a qualitative study (Emad and Ghosh 2023), funded by the International Association of Maritime Universities (IAMU). The study interviewed 37 persons (including seafarers, educators, regulatory bodies, and employers) and concluded that, during the transition period, future operators of autonomous ships will be expected to possess a traditional seafaring licence as a prerequisite for obtaining a licence to operate smart ships. 

To be employed on ships, seafarers have traditionally been trained as per the requirements of the Standards of Training, Certification, and Watchkeeping (STCW) Convention which lays out the global, minimum standards of competence through the STCW Code (introduced by the International Maritime Organization or IMO in 1978 and revised in 1995 and 2011). Hence, it may be implied that the competence gained through traditional studies (promoted by the STCW Code) may need to be supplemented with specific skills (information technology, robotics, systems thinking, communication, software management, etc.) to manage ‘smart’ ships of the future (with a reduced human presence on board) from the SCC. Past several decades have, in particular, focused on the non-technical or soft skill development of seafarers (e.g. using Bridge Resource Management training to develop seafarers’ leadership, communication, teamwork, and decision-making skills) (Mallam, Nazir, and Renganayagalu 2019). However, recent research (Emad, Enshaei, and Ghosh 2021; Ghosh and Emad 2023a; Man et al. 2015) showed that although there is active research into identifying the skills of the future, there is a dearth of research on organising the skills and competencies into a structured framework. For example, Man et al. (2015) highlighted the cognitive skills training which may be required for future seafarers (who will operate autonomous ships from the SCC) to deal with the information communicated digitally from ships but failed to propose any framework for the development of those cognitive skills. 

In a recent research (Ghosh and Emad 2024), an extensive and systematic literature review revealed a global absence of a skills and competency framework in the maritime industry which may be used as a guidance to instil the required behaviours in seafarers. Does this imply that the maritime industry assumes that the STCW Code will automatically incorporate the identified competencies? But before doing so, it is important to confirm if the Code can continue its current form to lay down the skills and competencies or will its effectiveness be diminished in doing so. This justified the need to conduct a systematic literature review to investigate if past research has carried out a feasibility study for the STCW Code to be translated into a practical, usable framework for developing the future skills. In the absence of such studies, the review could be used to delve deeper into investigating the key and essential characteristics of skills and competency frameworks (used for the workforce of industries other than the maritime or seafaring) which could be imbibed by the Code to be influential and relevant in the future. The literature review will also be used to map the identified characteristics of skills and competency frameworks to the features of the STCW Code to determine the latter’s suitability in outlining new behaviours expected from future seafarers who will manage systems of the MASS. Modifying the existing STCW Code into a practical, usable skills and competency framework may also lead to its acceptance by the IMO member States in a relatively quicker time. This is especially so when compared with processes which may be time-consuming or plagued by bureaucracy due to the lack of transparency of approval processes 

618 S. GHOSH ET AL. 

and selected countries having the most potent influence in decision-making (Psaraftis and Kontovas 2020). 

### 2. Systematic literature review on MET for autonomous and unmanned ships 

In order to reveal studies which, highlight the essential characteristics of skills and competency frameworks and/or map the characteristics to the STCW Code, the authors of this paper sampled the population of published peer-reviewed papers that mentioned the key terms and Boolean operators. The Boolean operators used key terms and phrases like ‘skills and competency frameworks’, STCW Code, MASS, autonomous ships, unmanned ships, features, and characteristics. Terms like features and characteristics were truncated to include all possible versions of the word. Since the focus of the literature review was to reveal past studies which identified the key characteristics of skills and competency frameworks or the feasibility of the STCW Code to be translated into one, phrases like digitalisation in education, or automation and education were intentionally omitted. The first stage of the identification of the literature involved keyword searches in the databases of Scopus, Web of Science, and PubMed (additional search for articles was conducted on Google Scholar as well). The databases were selected since they are interdisciplinary (e.g. shipping and skills and competency frameworks) or multidisciplinary area (e.g. feasibility of the STCW Code to act as a skills and competency framework while addressing the concerns of various stakeholders) in nature and included a range of peer-reviewed academic sources of literature. The Boolean operators used are summarised in Table 1, along with the number of hits. 

### 2.1. Eligibility criteria and selection of studies 

After the systematic search, different inclusion and exclusion criteria were used to select the papers for this review. Papers were included when they considered skills and competency framework in the context of the maritime or seafaring industry and especially when they discussed the STCW Code (the authors’ own papers were not included since the synopsis from those papers were included in this paper as existing knowledge). The inclusion criteria also included articles which highlighted the essential characteristics of skills and/or competency frameworks while building one for the workforce or purely 

Table 1. First stage of the review <u>process.</u> 

|Boolean operators|Scopus|Web of<br>Science|PubMed|
|---|---|---|---|
|‘skills and competency framework’AND‘STCW Code’AND‘autonomous ships’AND|0|0|0|
|‘unmanned ships’ AND MASS||||
|‘skills framework’AND‘STCW Code’AND‘autonomous ships’AND‘unmanned ships’<br>AND MASS|0|0|0|
|‘competency framework’ AND‘STCW Code’ AND‘autonomous ships’ AND<br>‘unmanned ships’ AND MASS|0|0|0|
|‘skills and competency framework’AND (characteristics* OR features*)|0|0|0|
|‘skills framework’AND (characteristics* OR features*)|18|9|3|
|‘competency framework’ AND (characteristics* OR features*)|126|59|4|



AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 

619 

Table 2. Exclusion and inclusion criteria. 

|Criteria|Inclusion/<br>Exclusion|Number of<br>papers|
|---|---|---|
|Skills and competency frameworks discussed in the context of maritime industry|Included|4|
|Characteristics of skills and competency frameworks discussed in the context of<br>maritime industries|Included|0|
|Characteristics of skills and competency frameworks discussed in the context of<br>non-maritime industries|Included|5|
|Comparison of the STCW Code to skills and competency frameworks|Included|0|
|Designing, development, and implementation of skills and competency frameworks|Included|10|
|Identifying the need or purely recommending the need to design, develop, and<br>implement skills and competency frameworks, mention of the use of frameworks<br>without elaboration or expansion, insufcient information on the framework use,<br>focus on identifcation of skills and competencies only (and not on frameworks),<br>etc.|Excluded|107|
|Total papers selected||19|



out of theoretical interests. Conversely, the papers that did not meet the inclusion criteria were excluded. The basis of inclusion of selected papers is expanded in Table 2. 

The search was not restricted by year of publication, study design or any further factors, but by language (English). Books and book chapters were excluded (Türkistanli 2024). After removing duplicates that were identified by the three databases, the papers were screened in two phases: first the title and abstract, and second the full text of the papers were screened. A total of 19 papers were included in this review, which were diverse in type of study, geographic location, approach, and field of publication. The included articles were compiled for analysis with the aid of the referencing software Endnote. 

### 2.2. Data extraction and analysis 

After the selection of studies based on the inclusion criteria, the 19 papers were screened systematically to identify the characteristics of the skills and competency frameworks. Adopted for the maritime workforce or the workforce of non-maritime industries. Secondly, a thematic analysis was performed to classify the identified characteristics following both chronological phases of realisation and emerging themes. The identified themes formed the sub-headings (types of competencies, contextual and clarity in definitions of the identified competencies, guidelines for competence development, behavioural characteristics of competencies, and forms of assessment) in Section 3. Along with the identified characteristics, the gaps in the STCW Code towards incorporating the characteristics, and possible solutions also emerged. Solutions were suggested on their extent of 

Table 3. Evolution of themes from included papers. 

|Themes|Number of papers which included a<br>discussion|
|---|---|
|Need to incorporate the diferent types of competencies<br>|9|
|Need to defne competencies<br>|11|
|Need to defne guidelines for competence development|4|
|Need to combine technical competencies with behavioural<br>characteristics|7|
|Need to include diferent forms for competence assessment|3|



620 S. GHOSH ET AL. 

implementation indicating whether they were only recommended or also implemented in specific cases. The forthcoming section of this paper is structured based on the outcome of the systematic review of the selected literature. The identified themes and the number of papers discussing the themes are highlighted in Table 3. 

### 3. Mapping characteristics of skills and competency frameworks to the STCW Code 

An initial search of articles did not find any research where the skills and competency frameworks were mapped to and/or discussed in comparison to the STCW Code. The mention of the terms ‘skills’ and ‘competencies’ in the context of the Code was always in relation to the standards of competence outlined in the Code itself. Popova and Yurzhenko (2019) discussed a competency framework as an instrument to assess professional competency of future seafarers but focused only on communicative competencies in the English language course for future ship engineers. Thus, the framework was limited to a specific skill and to a specific sector of professionals within the industry which makes it hard to adapt to the broader workforce (or other skills). Skills and competency frameworks must be relevant across the entire spectrum of the profession covering all roles (Bowers and Sabin 2024). 

The subsequent search was for articles that described the essential characteristics of skills and competency frameworks to which the STCW Code may be mapped to. The search found frameworks in the context of non-technical skills (Perera, Griffiths, and Myers 2022), information technology (Bowers and Sabin 2024), student nurses (Attallah and Hasan 2022), family physicians (Thoma et al. 2023), and pharmacists in sales and marketing (Joya et al. 2023), among numerous others. However, it was challenging to derive the essential characteristics of skills and competency frameworks from some of the studies since the frameworks were applied or discussed in the context of skills and competency development and/or assessment. As a result, the findings of this study are based on the mapping of the STCW Code to the characteristics which could be extracted from the limited number of studies that were selected based on the inclusion criteria. The study, although does not claim to be a comprehensive one, does provide valuable insights into the challenges involved in modifying the STCW Code into a skills and competency framework, and suggests solutions (based on the analysis of the literature) to address them. 

### 3.1. Does the STCW Code incorporate the different types of competencies? 

Skills and competency frameworks are used by organisations to lay down behaviours essentially required, valued, and rewarded to grow as a professional and an employee. This raises the necessity to raise the question on how behaviours differentiate from skills and competencies, and address it through accepted definitions from the literature. Professional competence requires essential cognitive abilities of recalling information (knowledge) and applying it (skills) based on analytical and critical thinking (Nusche 2008) while competencies are the knowledge, skills, and behavioural attributes that contribute to an individual’s ability to perform the professional task. In other words, competence is focused on the output, i.e. what people need to do to perform a job whereas competency is focused on input or is a combination of behaviours that lie behind 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 621 

competent performance (Emad and Roth 2009, 2016; Johns 2023). In recent literature, the two terms (competence and competency) have become interchangeable due to a need to create a framework that can accommodate both terms to produce a workforce comprising of graduate employees who can perform in professional settings at expected standards (Johns 2023). 

With the definitions of competencies clearly outlined, it is important to reiterate that the STCW Code promotes global, minimum standards of competence seafarers are expected to acquire through professional experience acquired on ships and learning acquired from classrooms in maritime education and training (MET) institutes. Since the focus of the Code is essentially on the output or what seafarers need to do to demonstrate competence in workplace tasks, the Code would have to be modified to include the expected behaviours or inputs. For example, the UNESCO competency framework included core values, core competencies, and managerial competencies but, technical, inter-personal, techno-managerial, and strategic competencies were added later for particular industries (Kansal and Singhal 2018). 

In the context of the STCW Code, it should ideally include, for example (Gillis 2023; Johns 2023), core set of ethical values related to decision-making during emergencies (e.g. seafarers should avoid colliding with other ships when rescuing a person overboard), core skills and competencies which are essential for the professional role (e.g. seafarers should be able to operate fire extinguishers to extinguish fires), functional competencies which are essential to specific ranks (e.g. navigation officers must be able to plan a safe passage for a vessel), meta competencies which are relevant to the profession but not directly required for employment (e.g. seafarers should ideally be able to operate computers, but it is not required for finding work on ships; and leadership competencies which refer to management skills (e.g. certified officers are expected to manage the workload of the team they are supervising). 

On mapping the aforementioned competencies (e.g. functional, meta, and leadership) to the contents of the STCW Code, it was found that occasionally the Code does lay out some of the aforementioned core values and competencies. For example, the unit of competence of ‘Use of leadership and managerial skill’ requires seafarers to have the ‘knowledge and ability to apply decision-making techniques’ (IMO 2011, 122). However, a closer look reveals that this is not the case for all units of competence listed in the Code. For example, for the unit of competence of ‘Co-ordinate search and rescue operations’ (IMO 2011, 113), some of the essential behaviours like effective use and management of available resources, caring of rescued survivors, etc. are essentially missing or assumed to be understood as inherent components of competence development. The expected behaviours should ideally be included under the criterion for evaluating competence. Moreover, the meta competencies were not found to be mentioned directly or as recommendations. 

A possible solution to address the issue of overlooked behaviours may be to include a range of experts and professionals (governments, regulatory bodies, employers, educators, researchers, and seafarers) to update and revise the STCW Code at periodic intervals. Using the input provided by the stakeholders, the outdated competencies may be replaced with relevant and required competencies of the future. For example, Sharma et al. (2019) used 82 seafarers to highlight their perception about most relevant and irrelevant STCW competencies required for remotely controlled ships with reduced number 

622 S. GHOSH ET AL. 

Table 4. Comparison of STCW competencies perceived as irrelevant vs relevant by maritime experts: an example only. 

|Low-ranked competencies from Sharma et al. (2019)|High-ranking competencies from Ceylani,<br>Kolcak, and Solmaz (2022)|
|---|---|
|.<br>The ability to use and interpret information obtained from|.<br>Problem and confict solving|
|shipborne meteorological instrument.|.<br>Reasoning and Decision-making|
|.<br>Have understanding of the purpose of the ‘enhanced survey<br>programme’.|.<br>Ability to cope with complexity<br>.<br>Critical Thinking|



of seafarers on board (Autonomy Level 2). The competencies found most irrelevant to the future may then be replaced with future competencies found to be highly critical for the future by the experts (e.g. maritime academics) in the study by Ceylani, Kolcak, and Solmaz (2022). An example elaborating a comparison of irrelevant with relevant competencies is provided in Table 4. 

### 3.2. Does the STCW define the titles, behaviours, and levels of competencies? 

Identifying associated behaviours along with newly identified (or existing) skills and competencies may not be sufficient unless they are accompanied with descriptors of observable and measurable actions (Kansal and Singhal 2018). In the context of the STCW Code, the described actions will act as indicators of performance to be expected from seafarers when operating systems on ships. Hence, while outlining new skills and competencies, it is imperative to not only name them but also describe them by clearly outlining the associated key behaviours. For example, the non-technical skill of ‘Communication’ for MASS operators may be defined (Ghosh and Emad 2023b) as below in Table 5. 

Table 1 provides an example of how the non-technical (soft skill) competency of ‘Communication’ may be clearly defined with key behaviours. In comparison, the mapping of the STCW Code revealed that the same soft skill has vague descriptions in the Code which may lead to the setting of different standards when evaluating the competence. For example, for the unit of competence ‘Ability to safely perform and monitor all cargo operations’, one of the criteria for evaluating the underlying soft skill of ‘Communication’ includes wording like ‘Communications are clear, understood and successful’ (IMO 2011, 190). However, what may be construed as a ‘successful’ communication is not clearly outlined for uniform understanding by all assessing authorities. 

The description in Table 1 should be treated as a recommendation only and cannot be construed as a definition approved by regulatory bodies since the list of key behaviours here is not exhaustive. To ensure all required and relevant competencies (and associated 

Table 5. Example of how competencies may be defined for MASS operators. 

|Title|Communication|
|---|---|
|Defnition|MASS operators must evidence the ability to communicate operational breakdowns and technical<br>specifcations of machinery and equipment both onboard ships and in the Shore Control Centres. The<br>MASS operators must be able to develop knowledge and information and share within and across<br>locations, functions, or projects.|
|Key<br>Behaviours|Establish mechanisms to analyse, evaluate, and report information;<br>Coordinate the management and sharing of information and knowledge across departments and<br>across disparate geographical workplaces.|



AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 623 

Table 6. Example of different levels of <u>proficiency</u> for competencies required by MASS operators. 

|Competence|Support|Operational|Management|
|---|---|---|---|
|Communication|Establishes mechanisms to<br>analyse, evaluate, and report<br>information across diferent<br>workplace locations.<br>Coordinates the management<br>and sharing of information<br>and knowledge across<br>departments and locations|Makes decisions based on<br>research, analysis, and review<br>of information and knowledge<br>gathered across locations and<br>time.<br>Disseminates information to<br>team members across<br>locations.|Develops communication plans<br>to engage internal and<br>external stakeholders<br>Represents themselves and the<br>employer with authority and<br>credibility in public forums<br>and at events|



behaviours) as expected from the seafarers of the future are included in the STCW Code, statements should be created with the assistance of experts, practitioners, researchers, and educators through focus groups, workshops, surveys, interviews, advisory committees, and conferences (MacKay et al. 2023). Inclusion of key stakeholders and obtaining their consensus will ensure that the descriptions in the Code are not vague or ambiguous. For example, in the STCW Code, for the unit of competence of ‘Use of managerial and leadership skill’, the criterion for evaluating competence mentions ‘effective leadership behaviours are demonstrated’ or ‘the crew are allocated duties and informed of expected standards or work … ’. Terms like ‘effective’ or ‘expected’ can be construed as vague and be subjected to an individual seafarer’s interpretation as per their comprehension. 

The literature review conducted for the purposes of this paper revealed that skills and competency frameworks should also describe the behaviours needed by practitioners throughout the progression of their career, from being newly recruits to holding senior management positions in the organisation (Bowers and Sabin 2024). In the context of the STCW Code, the levels of proficiencies for competencies should be outlined for support (e.g. deck cadet or ordinary seaman) to operational (e.g. second officer or fourth engineer) to management (e.g. ship’s master or chief engineer) positions held on ships. 

Table 6 provides an example of how the levels of proficiency for non-technical skill (Communication) may be outlined for MASS operators at support, operational, and management positions. 

One may argue that the STCW Code has already laid out the competencies for seafarers under the categories of support, operational, and management. However, the behavioural attributes need to be expanded in detail for easy distinguishing and understanding of what is expected at different levels of proficiency. For example, a unit of competence at operational level (Application of leadership and team working skills) and management level (Use of leadership and managerial skill) expects the seafaring students to demonstrate the same ‘Effective leadership behaviours’ but does not clearly state the attributes expected. 

### 3.3. Does the STCW Code outline unambiguous guidelines for competence development? 

Skills and competency frameworks focus on the output, i.e. what people need to do to perform a job. For example, in the context of occupational health and safety, an employee should demonstrate clear behaviours described as: 

624 S. GHOSH ET AL. 

Table 7. Example of how future competencies may be added in addition to current STCW Code competencies for the technical units of competence (operational level). 

|STCW Code technical<br>units of competence|Current competencies required|Future competencies (predicted) required|
|---|---|---|
|Maintain a safe<br>navigational watch|Knowledge of the principles to be observed in<br>keeping a navigational watch.<br>The use of routeing in accordance with the<br>general provisions on ships’routeing.<br>Knowledge of blind pilotage techniques.|In addition to current competencies:<br>Troubleshoot faulty navigation electronic<br>equipment.<br>Identify and thwart cyber security threats.<br>Manage information overload from multiple<br>sources of information.|
|Respond to a distress<br>signal at sea|Knowledge of the contents of the<br>International Aeronautical and Maritime<br>Search and Rescue (IAMSAR) Manual.|In addition to current competencies:<br>Lead and/or work in teams to organise<br>required resources.<br>Communicate with the rescue services<br>coordinator and other ships proceeding to<br>assist.<br>Collaborate with internal and external<br>stakeholders to carry out or assist in<br>operations in an ethical manner.|



- . Use protective clothing 

- . Practice basic hygiene 

- . Assess the risks before commencing work 

- . Recognise hazards and take steps to address them 

- . Test equipment 

- . Complete safety checklists. 

In the process of mapping the STCW Code to the characteristics of skills and competency frameworks, what emerged was the Code’s focus on the knowledge aspects of performance which essentially dominated the requirements of performance for the majority of the units of competence listed. For example, the unit of competence ‘Ability to safely perform and monitor all cargo operations’ emphasises on candidates acquiring knowledge of ‘oil tanker design, systems and equipment … ’ (IMO 2011, 190) and ‘knowledge of pump theory and characteristics … ’ (IMO 2011, 190) and ‘knowledge and understanding of monitoring and safety systems … ’ (IMO 2011, 190). Such statements indicate that the Code focuses on providing standards of knowledge with suggested indicators of competence rather than providing ‘standards’ of demonstrated performance. This makes the STCW an input-based standard (Ghosh et al. 2014), which is in direct contradiction to the ‘outcome-based’ objective of a skills and competency framework. 

Moreover, as the level of technology (or automation) increases on ships and the number of seafarers required to work on MASS decreases, the competencies required for the units of competence outlined in the STCW Code will change as well. Table 7 provides an example of how new competencies (as required for the future) may be added in addition or replace current competencies for a technical units of competence outlined in the STCW Code. 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 625 

### 3.4. Does the STCW Code combine technical competencies with behavioural characteristics? 

The literature review conducted for the purposes of this paper revealed that skills and competency frameworks are context-dependent where there is progressive interaction between an individual’s competence and the systems and environments in which they perform the workplace tasks (MacKay et al. 2023). Knowledge of context-dependent frameworks is especially relevant in the case of the future seafarers who are expected to operate systems and processes on ships with differing levels of autonomy. For example, the taxonomy of autonomous ships proposed by the IMO is as follows: 

- . Level 1 – Ship with automated processes and decision support: Seafarers are on board to operate and control shipboard systems and functions. Some operations may be automated. 

- . Level 2 – Remotely controlled ship with seafarers on board: The ship is controlled and operated from another location, but seafarers are on board. 

- . Level 3 – Remotely controlled ship without seafarers on board: The ship is controlled and operated from another location. There are no seafarers on board. 

- . Level 4 – Fully autonomous ship: The operating system of the ship is able to make decisions and determine actions by itself (Emad, Enshaei, and Ghosh 2021). 

The different levels of autonomy proposed by the IMO indicate that the skills and competencies required for Level 1 will be significantly different from those, for example, at Level 4. For example, the non-technical competency of ‘Communication’ on Level 1 ships (with seafarers on board) will require demonstration of effective communication behaviours with other seafarers on board and the systems used for operation and maintenance, whereas the same competency for Level 4 ships (with no seafarers on board) will require seafarers (or shore-based operators) to purely communicate with fully automated systems to fix errors and troubleshoot breakdowns. Distinguishing expected behaviours for different levels of autonomy on ships is particularly important since the STCW Code is only applicable to ships with seafarers on board (Sharma et al. 2019), and hence, does not take into account the essential competencies required to operate fully remote or autonomous ships. 

A practical solution which emerged from the literature review (conducted for this study) suggested separating the technical competencies (e.g. operate survival and rescue boat, safely perform cargo operations, etc.) from the non-technical competencies (e.g. communication, leadership, etc.) (Bowers and Sabin 2024). An example of this was found in the STCW Code during its mapping with skills and competency frameworks, a unit of non-technical competence at the operational level (‘Application of leadership and team working skills’) (IMO 2011, 109) was mentioned separately from the management level (‘Use of leadership and managerial skill’) (IMO 2011, 122). However, the same practice needs to be followed for other non-technical competencies identified as essentially required for future seafarers. Listing non-technical competencies separately and defining the expected behaviours (as driven by the context of application) will allow the behaviours to be developed at the required standards and levels of achievement. 

626 S. GHOSH ET AL. 

### 3.5. Does the STCW Code include all forms of skills and competence assessment? 

One of the challenging aspects of the literature review conducted for the purposes of this study was to deal with the taxonomy associated with the skills and competencies listed in the frameworks for diverse workforces. This is understandably so since it is easier to define technical competencies for professions, but the non-technical competencies may require completely different behaviours as we switch between professions, roles, responsibilities, context of application, and objectives. For example, the behaviours expected from pharmacists (Pharmaceutical Society of Australia Ltd. 2016) for the non-technical competency of ‘Communication’ (e.g. dispensing medication based on communication received from prescriptions) will be drastically different from those expected from pharmacists in sales and marketing (Joya et al. 2023) (e.g. managerial positions contributing to sales pitches, client meetings, etc.) although they belong to the same industry and the expected behaviour (e.g. conduct effective communication) is similar as well. 

According to Carotozzolo et al. (2023) and Thornhill-Miller et al. (2023), the complexity of the definitions of competencies (Kotsiou et al. 2022) makes it challenging for them to be assessed both in terms of reliability (i.e. candidate being assessed should demonstrate consistent competency irrespective of assessment method) and of validity (i.e. candidate should be tested using assessment methods which allow them to demonstrate the competence in the context in which it should be applied). For example, seafarers may be tested for knowledge-based components using traditional assessment methods like pen-and-paper tests, multiple-choice questions, and oral examinations and show consistent results but should be tested for application of skills and competencies in real-world contexts which resemble settings similar to workplace settings (e.g. setting up a simulated fire in a constricted space similar to a fire occurring in a cargo space on ships). 

The literature review, conducted as part of this study, provided recommendations in regard to using ‘authentic’ contexts (Bowers and Sabin 2024; Buasuwan et al. 2022; Raj et al. 2021) which resemble professional scenarios for the training, development, and assessment of skills and competencies. In the context of seafarer education and training, multiple research studies (Ghosh et al. 2020a; Ghosh et al. 2020b; Ghosh and Bowles 2020) have provided empirical evidence to show that the use of authentic pedagogical practices, such as Communities of Practice (QC) (Emad and Roth 2016) or authentic assessment (Ghosh et al. 2020a; 2020b) improved seafarers’ academic achievement and enhanced the development of their workplace skills. The authentic pedagogies can also be used to target and achieve valid and reliable learning outcomes (Ghosh et al. 2016; 2017) ensuring that seafarer graduates are not only able to perform the tasks to standards expected at the workplace but are able to do so consistently in different contextual scenarios. 

### 4. Discussion 

The STCW Code came into force in 1978 and since has been serving the interests of the maritime community in terms of providing global, minimum standards of competence for seafarers intending to find employment on ships. The Code has also undergone revisions in 1995 (since known as STCW’95) and minor amendments in 2011 to meet the requirements of the industry. The focus of this paper is not on declaring the STCW Code as an 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 627 

ineffective instrument but to suggest revisions which will enhance its relevance and effectiveness in the near future. This is especially important as MASS are increasingly introduced, and the skills and competencies required of seafarers increasingly get influenced by technology and changes in the employment trends. 

The literature review conducted for the purposes of this paper revealed that past research (in the context of MASS) has focused on identifying and listing the future skills and competencies predicted to be essential for operating autonomous ships and its systems. There has also been research on ranking the current competencies listed in the STCW Code and future competencies in order of their predicted relevance when MASS is increasingly introduced. Sparse research also exists on using selected competencies (e.g. communication) in a framework to assess seafarers’ competence in specific (e.g. engineering) contexts. However, there was a global absence of literature on structuring future competencies in a framework which may be used as a guidance for seafarer training and professional development readying them for workplace duties. The contribution of this paper is to start a conversation by laying down examples of how the current or future competencies may be outlined in the STCW Code in the form of a skills and competency framework. 

One of the purposes of this literature review was also to highlight key characteristics and features of skills and competency frameworks which may be imbibed by the STCW Code. In this regard, Section 3 highlighted how technical and non-technical units of competence in the STCW Code may be defined with behaviours, levels of expertise, and assessment methods in order to prepare the maritime workforce not only for current roles but also evolving responsibilities. The implication of including all suggestions in the STCW Code is twofold. Firstly, the sophistication and advancement of automation on future ships and the expected extent of seafarer interaction with technology is still vague because of which ALL the required skills cannot be defined clearly (especially for Levels 3 and 4) at this stage. The solution of course is to review the STCW Code progressively and include the skills as they become transparent. Secondly, including all the aspects of the skills and competency frameworksmay detailthe competencies required butmakethe STCWCode a cumbersome document comprising of multiple pages with which all stakeholders would need to familiarise themselves. The solution here would be to identify familiarisation training (possibly a responsibility of the IMO) and introduce it at all levels of stakeholder engagement. 

The STCW Code is currently not a skills and competency framework, and one might argue that it does not need to be. However, if the Code imbibes some of the characteristics of the frameworks, it will provide an outline and describe an ideal set of behaviours and traits for successful workplace performance. Although, the common perception is that qualifications, workplace training, and work experience while simultaneously assessing personal values and behavioural attributes are reliable indicators of professional competence, having a structured framework (notwithstanding the aforementioned parameters), will ensure seafarers perform to the expected standards (MindTools 2023). However, the usability and practicality of using a revised and detailed STCW Code will need to be monitored especially as the knowledge components, training requirements, and assessment practices will evolve over time. It will be imperative to carry out quality checks and auditing processes in training institutes to ensure delivery of training and competence development is at expected standards. This is especially critical for developing nations who may struggle to develop sophisticated training facilities (due to a lack of 

628 S. GHOSH ET AL. 

or limited fund) as expected to deliver training for not only seafarers who will find work on ships (levels 1 and 2) but also those who will operate ships from remote centres (Levels 3 and 4). Further research work must investigate the reality of using existing training facilities (e.g. simulators) or modifying them towards delivering training for future seafarers at a reasonable cost to the stakeholders. 

A well-structured skills and competency framework will provide future seafarers a comprehensive and unambiguous understanding of competencies expected of them. In the context of education and training, gaps found in the knowledge of current seafarers (as they transit from non-autonomous ships to MASS) may be found and addressed through targeted training (in the form of online courses, short or certificate courses, revalidation training, etc.). Including non-technical or soft skill competencies separately from technical competencies and developing them for different levels of proficiency will instil transferable skills in seafarers which will be highly valued across different industries. For example, skills like information technology management, software management, and troubleshooting systems may be valued in any industry heavily influenced by automation. Hence, the STCW Code will not only be useful in the upskilling of seafarers towards the operation of future ships but enable them to find employment in shore-based organisation. Thus, enhancing their value in society as skilled labour. 

### 5. Limitations and the way forward 

It should be acknowledged that the researcher may have inadvertently failed to recognise the relevance of some of the excluded articles (based on the scan through the title, abstract, and body of text) to the purpose of this paper and hence, overlooked some of the characteristics of the skills and competency frameworks which should have been mapped to the STCW Code. 

Although, the literature review presented in this paper is based on the search of papers through the use of three databases (Scopus, Web of Science, and PubMed), it should be acknowledged that the decision to use certain Boolean operators and selective databases may have restricted the discovery of articles. For example, during the literature analysis, the authors discovered terms like ‘models’ and ‘components’ which could have been used along with ‘frameworks’ and ‘characteristics’ for an initial search of articles. Although, in this case, the authors attempt to retrieve more articles using these terms did not result in new results, the possibility of overlooking synonyms of search terms should be accepted. Future research should consider more extensive and inclusive keywords with a focus on identifying missing narratives (Türkistanli 2024) lying behind the limitations of this paper. 

Research can always be approached from a wider perspective and this work claims to be no different. Further work is required in the practical translation of the STCW Code into a usable, practical, and globally acceptable framework which may be found relevant in developing the required skills in the seafarers of the future. A dynamic approach towards continuous improvement should be adopted to finalise the technical competencies with defined set of behaviours (or make the decision to separate them). Recent researches (Bowles, Ghosh, and Thomas 2020; Reynolds, Bowles, and Ghosh 2023) have also stressed on the development of ‘mindsets’ (dispositions, behaviours, and habits to deploy the skills in different contexts) along with technical and non-technical 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 629 

competencies in the workforce of the future. The authors’ interests in pursuing a comprehensive understanding of the new taxonomy in future skills development is worth mentioning in the way forward. 

### 6. Conclusion 

The purpose of this study was to add to the growing literature of research in the area of the skills and competency development for future seafarers who are expected to operate technologically advanced and sophisticated MASS. Since competence development of seafarers has been traditionally governed by the STCW Code, this study distinguished itself from the current literature by conducting a feasibility study in the STCW Code’s suitability to be used as (or revised to be used as) a skills and competency framework to ensure its relevance for the future. 

This paper is based on a literature review conducted for the purpose of revealing past studies which have done a similar feasibility study and revealed a global absence of research on this topic. Recent research has only focused on identifying and listing new skills and competencies which are predicted to be required for future seafarers who will find employment on MASS (at Levels 1 and 2) or operate ships from remote centres (Levels 3 and 4). There is a dearth of research on organising the newly identified skills and competencies into a structured framework. Currently, although not described as a skills and competency framework, the STCW Code has been playing a similar role by providing standards of competence for non-autonomous ship operators. However, the research presented in this study argued that efforts must be put in organising the newly identified skills and competencies into a structured framework which may be used by the maritime stakeholders for training and the competence development of a skilled workforce. An initiative to do so, first required an extensive literature review to investigate if past research has mapped the essential characteristics of skills and competency frameworks to the STCW Code, and to reveal key characteristics of the frameworks which have been used for workforce development in non-maritime industries. This was followed by a review of exemplary sections of the STCW Code to determine if it may be revised, restructured, or amended to include the competencies of the future and repurposed as a skills and competency framework. The mapping exercise revealed that although the Code does address certain elements of a competency framework (e.g. listing the core, functional, and leadership competencies), it needs to modify its current structure and descriptions to define the competencies, describe the levels of proficiency, and outline the expected behavioural attributes explicitly. Modifying the existing STCW Code may also find approval among its current users (IMO members) in comparison to introducing a new skills and competency framework which may be scrutinised, and thus result in delays in acceptance and implementation. A structured and organised framework presents the advantages of not only identifying the knowledge and skills but defines the processes of the work to be done or roles to be performed resulting in a consistent, uniform interpretation by all maritime stakeholders and seafarer graduates with high, expected standards of competence. However, further and extensive research is required to establish not only the practicality of using a restructured STCW Code but also the feasibility of developing facilities (or using the current ones) to deliver the required training in maritime education and training (MET) institutes. 

630 S. GHOSH ET AL. 

### Disclosure statement 

No potential conflict of interest was reported by the author(s). 

### Notes on contributors 

Dr. Samrat Ghosh is the Associate Head of Future Students at the Australian Maritime College. His research focuses on investigating the impact of innovative training and assessment methods in seafarer education to improve students’ academic achievement; and identifying training needs for future ship (autonomous) operators. 

Dr. Reza Emad is a senior lecturer in Maritime Training at the Australian Maritime College. His research focuses on knowing and learning in maritime domain and how it can be theorised. He also studies the cognitive human element integration in maritime industry at sea and in ports. 

Anand Ravi is a current serving ship captain with nearly two decades of experience in the maritime industry. As an IAMU expert working group member, he is currently involved in the comprehensive review of the STCW convention and code. His subject area of interest revolves around identifying key areas of the convention requiring amendments and also modernising blended learning for seafarers. 

### ORCID 

Samrat Ghosh http://orcid.org/0000-0002-4617-6445 

### References 

- Attallah, D., and A. Hasan. 2022. “Approach to Developing a Core Competency Framework for Student Nurses in Saudi Arabia: Results from Delphi Technique.” Nursing Reports 12 (1): 29–38. https://doi.org/10.3390/nursrep12010004. 

- Bowers, D. S., and M. Sabin. 2024. “Demonstrating the Use of a Professional Skills Framework to Support the Assessment of Dispositions in IT Education.” Education and Information Technologies 29 (6): 7595–7632. https://doi.org/10.1007/s10639-023-11933-z. 

- Bowles, M., S. Ghosh, and L. Thomas. 2020. “Future-Proofing Accounting Professionals: Ensuring Graduate Employability and Future Readiness.” The Journal of Teaching and Learning for Graduate Employability 11 (1): 1–21. https://doi.org/10.21153/jtlge2020vol11no1art886. 

- Buasuwan, P., W. Suebnusorn, O. Butkatunyoo, N. Manowaluilou, M. Kaewchinda, U. Lalitpasan, N. Srilapo, et al. 2022. “Re-Envisioning a ‘Skills Framework’ to Meet 21st Century Demans: What Do Young People Need?” Frontiers in Education 8:art. 1004748. https://doi.org/10.3389/feduc. 2022.1004748. 

- Carotozzolo, P., L. A. Mejia-Manzano, G. Sirkis, J. Rodriguez-Ruiz, J. Noguez, J. Membrillo-Hernandez, and P. Vazquez-Villegas. 2023. “A Guide for Generation Z Students to Meet the Future Skills Requirements of Industry 4.0.” In ASEE Annual Conference and Exposition, Conference Proceedings, 25–28 June 2023, Baltimore, Code:191615. 

- Ceylani, E., I. C. Kolcak, and M. S. Solmaz. 2022. “A Ranking of Critical Competcnies for Future Seafarers in the Scope of Digital Transformation.” In Proceedings of the International Association of Maritime Universities Conference, 20–21 October 2022, edited by B. Svilicic and N. Kurshubadze, 206–216. Batumi. 

- Emad, G. R., H. Enshaei, and S. Ghosh. 2021. “Identifying Seafarer Training Needs for Operating Future Autonomous Ships: A Systematic Literature Review.” Australian Journal of Maritime & Ocean Affairs 14 (2): 114–135. https://doi.org/10.1080/18366503.2021.1941725. 

- Emad, G. R., and S. Ghosh. 2023. “Identifying Essential Skills and Comptencies Towards Building a Training Framework for Future Opertaors of Autonomous Ships: A Qualitative Study.” WMU Journal of Maritime & Ocean Affairs 22 (4): 427–445. https://doi.org/10.1007/s13437-023-00310-9. 

AUSTRALIAN JOURNAL OF MARITIME & OCEAN AFFAIRS 631 

- Emad, G. R., and W.-M. Roth. 2009. “Policy as Boundary Object: A New Way to Look at Educational Policy Design and Implementation.” Vocations and Learning 2 (1): 19–35. https://doi.org/10.1007/ s12186-008-9015-0. 

- Emad, G. R., and W.-M. Roth. 2016. “Quasi-Communities: Rethinking Learning in the Adult and Vocational Formal Education.” Instructional Science 44 (6): 583–600. https://doi.org/10.1007/s11251-016-9386-9. 

- Ghosh, S., and M. Bowles. 2020. “Challenges and Implications in Achieving Content Validity of an Authentic Assessment Task Designed to Assess Seafarers’ Leadership and Managerial Skills.” WMU Journal of Maritime Affairs 19 (3): 373–391. https://doi.org/10.1007/s13437-020-00209-9. 

- Ghosh, S., M. Bowles, D. Ranmuthugala, and B. Brooks. 2016. “Authentic Assessment in Seafarer Education: Using Literature Review to Investigate Its’ Validity and Reliability Through Rubrics.” WMU Journal of Maritime Affairs 15 (2): 317–336. https://doi.org/10.1007/s13437-015-0094-0. 

- Ghosh, S., M. Bowles, D. Ranmuthugala, and B. Brooks. 2017. “Improving the Validity and Reliability of Authentic Assessment in Seafarer Education and Training: A Conceptual and Practical Framework to Enhance Resulting Assessment Outcomes.” WMU Journal of Maritime Affairs 16 (3): 455–472. https://doi.org/10.1007/s13437-015-0094-0. 

- Ghosh, S., B. Brooks, D. Ranmuthugala, and M. Bowles. 2014. “Ona Lookout Beyond STCW: Seeking Standards and Context for the Authentic Assessment of Seafarers.” In IAMU AGA 15 Looking Ahead: Innovation in Maritime Education, Training and Research, Launceston, Tasmania, 77–86. Australian Maritime College. 

- Ghosh, S., B. Brooks,D.Ranmuthugala,and M.Bowles. 2020a. “Authentic VersusTraditional Assessment: An Empirical Study Investigating the Difference in Seafarer Students’ Academic Achievement.” The Journal of Navigation 73 (4): 797–812. https://doi.org/10.1017/S0373463319000894. 

- Ghosh, S., B. Brooks, D. Ranmuthugala, and M. Bowles. 2020b. “Investigating the Correlation Between Students’ Perception of Authenticity in Assessment and Their Academic Achievement in the Associated Assessment Tasks.” The Journal of Navigation 74 (2): 293–312. https://doi.org/ 10.1017/S037346332000051X. 

- Ghosh, S., and G. R. Emad. 2023a. “Developing and Implementing a Skills and Competency Framework for MASS Operators: Opportunities and Challenges.” In Proceedings of the International Conference on Maritime Autonomy and Remote Navigation (ICMAR NAV 2023), 27– 30 November 2023, Launceston, Tasmania, EPiC Series in Technology, Vol. 2, edited by G. R. Emad and A. Kataria, 1–7. Australian Maritime College. 

- Ghosh, S., and G. R. Emad. 2023b. “Skills and Competency Framework for Future Autonomous Ship Operators: A Feasibility Study for STCW Code Revision.” In Proceedings of the International Conference on Maritime Autonomy and Remote Navigation (ICMAR NAV 2023), 27–30 November 2023, Launceston, Tasmania, EPiC Series in Technology, Vol. 2, edited by G. R. Emad, and A. Kataria, 8–15. Australian Maritime College. 

- Ghosh, S., and G. R. Emad. 2024. “Identifying Challenges in Designing and Implementing a Skills and Competency Framework for Future Seafarers: A Systematic Literature Review.” Australian Journal of Maritime & Ocean Affairs. https://doi.org/10.1080/18366503.2024.2356365. 

- Gillis, A. S. 2023. Competency Framework. TechTarget: HR Software. 

- Hogg, T., and S. Ghosh. 2016. “Autonomous Merchant Vessels: Examination of Factors That Impact the Effective Implementation of Unmanned Ships.” Australian Journal of Maritime & Ocean Affairs 8 (3): 206–222. https://doi.org/10.1080/18366503.2016.1229244. 

- IMO (International Maritime Organization). 2011. STCW: Including 2010 Manila Amendments. STCW Convention and STCW Code. London: IMO. 

- Johns, M. 2023. Competency Frameworks. Thomas. Accessed January 7, 2024. https://www.thomas. co/resources/type/hr-guides/competency-frameworks. 

- Joya, N., H. Aline, I. Katia, S. Hala, A. Marwan, Z. M. Rony, H. Chadia, and S. Pascale. 2023. “Assessing and Validating the Specialized Competency Framework for Pharmacists in Sales and Marketing (SCF-PSM): A Cross-Sectional Analysis in Lebanon.” Journal of Pharmaceutical Policy and Practice 16 (1): art. No. 128. https://doi.org/10.1186/s40545-023-00638-w. 

- Kansal, J., and S. Singhal. 2018. “Development of a Competency Model for Enhancing the Organisational Effectiveness in a Knowledge-Based Organisation.” International Journal Indian Culture and Business Management 16 (3): 287–299. 

632 S. GHOSH ET AL. 

- Kotsiou, A., D. D. Fajardo-Tovar, T. Cowhitt, L. Major, and R. Wegerif. 2022. “A Scoping Review of Future Skills Frameworks.” Irish Educational Studies 41 (1): 171–186. https://doi.org/10.1080/ 03323315.2021.2022522. 

- Lee, J. D. 2008. “Review of a Pivotal Human Factors Article: Humans and Automation: Use, Misuse, Disuse, Abuse.” Human Factors 50 (3): 404–410. https://doi.org/10.1518/001872008X288547. 

- MacKay, M., C. Ford, L. E. Grant, A. Papadopoulos, and J. E. McWhirter. 2023. “Developing Public Health Competency Statements and Frameworks: A Scoping Review and Thematic Analysis of Approaches.” BMC Public Health 23:2240. https://doi.org/10.1186/s12889-023-17182-6. 

- Mallam, S. C., S. Nazir, and S. K. Renganayagalu. 2019. “Rethinking Maritime Education, Training, and Operations in the Digital Era: Applications for Emerging Immersive Technologies.” Journal of Marine Science and Engineering 7 (12): 428. https://doi.org/10.3390/jmse7120428. 

- Man, Y., M. Lundh, T. Porathe, and S. MacKinnon. 2015. “From Desk to Field-Human Factor Issues in Remote Monitoring and Controlling of Autonomous Unmanned Vessels.” Procedia Manufacturing 3:2674–2681. https://doi.org/10.1016/j.promfg.2015.07.635. 

- MindTools. 2023. Developing a Competency Framework. MindTools. https://www.mindtools.com/ ad66dk2/developing-a-competency-framework. 

- Nusche, D. 2008. “Assessment of Learning Outcomes in Higher Education: A Comparative Review of Selected Practices.” OECD Education Working Paper No. 15. OECD Directorate of Education, 9–10. 

- Perera, A., R. Griffiths, and J. A. Myers. 2022. “Integrative Review of Non-Technical Skills Frameworks to Apply for Air Medical Transfer of Pregnant Women.” Journal of Obstetric, Gynecologic, & Neonatal Nursing 51 (3): 257–277. https://doi.org/10.1016/j.jogn.2022.01.006. 

- Pharmaceutical Society of Australia Ltd. 2016. National Competency Standards Framework for Pharmacists in Australia. Deakin: Pharmaceutical Society of Australia. 

- Popova, H., and A. Yurzhenko. 2019. “Competency Framework as an Instrument to Assess Professional Competency of Future Seafarers.” In CEUR Workshop Proceedings, 15th International Conference on ICT in Education, Research and Industrial Applications: Integration, Harmonization and Knowledge Transfer. Volume 1 Main Conference, ICTERI 2019, 12–15 June 2019, 2387, 409–413, Kherson. 

- Psaraftis, H. N., and C. A. Kontovas. 2020. “Influence and Transparency at the IMO: The Name of the Game.” Maritime Economics & Logistics 22 (2): 151–172. https://doi.org/10.1057/s41278-020-00149-4. 

- Raj, R., M. Sabin, J. Impagliazzo, D. Bowers, M. Daniels, F. Hermans, N. Kiesler, et al. 2021. “Professional Competencies in Computing Education: Pedagogies and Assessment.” In Annual Conference on Innovation and Technology in Computer Science Education, ITiCSE, 2021 Working Group Reports on Innovation and Technology in Computer Science Education, ITiCSE-WGR 2021, 26 June–1 July 2021, 133–161, Paderborn. 

- Reynolds, J., M. Bowles, and S. Ghosh. 2023. “Validating Future-Ready Capability Requirements for Networks and Information Technology: A Case Study.” International Journal of Business and Social Science 14 (1): 27–35. https://doi.org/10.30845/ijbss.v14n1p3. 

- Sharma, A., T. E. Kim, S. Nazir, and C. Chae. 2019. “Catching Up with Time? Examining the STCW Competence Framework for Autonomous Shipping.” In Proceedings of the Ergoship Conference, 24–25, Haugesund, Norway. 

- Streng, M., and B. Kuipers. 2020. “Chapter 7 – Economic, Social, and Environmental Impacts of Autonomous Shipping Strategies.” In Maritime Supply Chains, edited by T. Vanelslander and C. Sys, 135–145. Rotterdam, The Netherlands: Elsevier. 

- Thoma, B., A. Karwowska, L. Samson, N. Labine, H. Waters, M. Giuliani, T. M. Chan, et al. 2023. “Emerging Concepts in the CanMEDS Physician Competency Framework.” Canadian Medical Education Journal 14 (1): 4–12. https://doi.org/10.36834/cmej.75591. 

- Thornhill-Miller, B., A. Camarda, M. Mercier, J.-M. Burkhardt, T. Morisseau, S. Bourgeois-Bougrine, F. Vinchon, et al. 2023. “Creativity, Critical Thinking, Communication, and Collaboration: Assessment, Certification, and Promotion of 21st Century Skills for the Future of Work and Education.” Journal of Intelligence 11 (3): art, no. 54. https://doi.org/10.3390/jintelligence11030054. 

- Türkistanli, T. T. 2024. “Advanced Learning Methods in Maritime Education and Training: A Bibliometric Analysis on the Digitalization of Education and Modern Trends.” Computer Applications in Engineering Education 32 (1): e22690. https://doi.org/10.1002/cae.22690. 

