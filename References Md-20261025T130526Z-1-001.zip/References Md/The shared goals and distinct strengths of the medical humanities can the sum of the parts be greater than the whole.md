

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited.
## Academic Medicine, Vol. 92, No. 12 / December 2017
## 1661
## Invited Commentary
Looking back over the century of
curriculum reforms since 1910 when
Abraham Flexner advocated scientific
training in medical education, one finds
a recurring desire to define a role for
the humanities in medical education
as well. Beginning in the 1960s, faculty
from diverse fields banded together
as the “medical humanities,” a field
of growing cohesion with scholars,
journals, and professional societies
in several countries. Following the
recent inclusion of the Critical Analysis
and Reasoning Skills section in the
## Medical College Admissions Test,
advocates are now encouraging the
inclusion of medical humanities in
the competencies required of medical
students and residents, and in the
content of licensing exams.
## 1
Yet this
work has not been easy. Scholars in
art, literature, history, anthropology,
religious studies, philosophy, and other
disciplines compete with the basic and
clinical sciences for time in a crowded
and shrinking preclinical curriculum,
with funding and faculty positions in
equally scarce supply.
Many of the arguments for the medical
humanities emphasize attributes that
are common across its constituent
disciplines. David Barnard,
## 2(p628)
chair
of the Department of Humanities at
## Pennsylvania State University College
of Medicine, explained in 1994 that the
humanities could examine “questions
of value and meaning within and
around medicine.” By teaching the
medical humanities, medical schools
could foster certain “‘qualities of
mind’: critical abilities, flexibility of
perspective, nondog matism, empathy,
and self-knowledge.”
## 2(p628)
## In 2009, Johanna
Shapiro and colleagues
## 3(p192)
similarly
described how “methods, concepts,
and content from one or more of
the humanities” could be used to
explore questions of illness, suffering,
and healing: “their activities are
interdisciplinary in theory and practice
and necessarily nurture collaboration
among scholars, healers, and patients.”
However, although appeals to inter-
disciplinarity are now ubiquitous in higher
education, they come with certain costs.
We argue that the constituent disciplines
of the medical humanities are not simply
interchangeable parts. They represent
different perspectives and methodologies
that can also make distinct contributions to
medical education. We believe that efforts
to define a role for medical humanities
in medical education should pursue two
strategies in parallel. On the one hand,
advocates of the medical humanities should
continue to make the case for the shared
contributions that the disciplines can make
to medical education, whether those involve
empathy, professionalism, critical reasoning,
or tolerating ambiguity. At the same time,
advocates for the medical humanities should
emphasize the valuable contributions of
each specific discipline in terms that medical
educators can understand.
We will illustrate this point by demon-
strating contributions that our own
discipline, medical history, can offer to
medical education. Historical analysis
contributes essential insights to our
## Acad Med. 2013;92:1661–1664
## Abstract
Since the 1960s, faculty from diverse
fields have banded together under
the banner of the medical humanities,
a term which unites art, literature,
history, anthropology, religious studies,
philosophy, and other disciplines.
Arguments for the relevance of
medical humanities often emphasize
contributions that any of these disciplines
can make to medical education, whether
those involve empathy, professionalism,
critical reasoning, or tolerating ambiguity.
The authors argue that the constituent
disciplines of the medical humanities are
not interchangeable parts, but represent
different perspectives and methodologies
that offer their own distinct contributions
to medical training. Efforts to define a
role for medical humanities in medical
education should pursue two strategies
in parallel. On the one hand, advocates
of the medical humanities should
continue to make the case for the shared
contributions that all of the disciplines
can make to medical education. But
advocates for the medical humanities
should also emphasize the valuable
contributions of each specific discipline,
in terms that medical educators can
understand. The authors illustrate this
point by delineating contributions of
their own discipline, medical history.
Historical analysis contributes essential
insights to the understanding of disease,
therapeutics, and institutions—things
that all physicians must know in order
to be effective as clinicians, just as they
must learn anatomy or pathophysiology.
Analogous but different arguments can
be made for literature, philosophy, and
the other disciplines that constitute the
medical humanities. The field of medical
humanities will be most successful if
it builds on both the shared and the
distinct contributions of its disciplines.
The Shared Goals and Distinct Strengths of
the Medical Humanities: Can the Sum of the
Parts Be Greater Than the Whole?
Jeremy A. Greene, MD, PhD, and David S. Jones, MD, PhD
J.A. Greene is Elizabeth Treide and A. Macgehee
Harvey Professor, Departments of Medicine and the
History of Medicine, and director, Center for Medical
Humanities and Social Medicine, Johns Hopkins
University School of Medicine, Baltimore, Maryland.
D.S. Jones is A. Bernard Ackerman Professor of
the Culture of Medicine, Department of Global
Health and Social Medicine, Harvard Medical School,
and Department of the History of Science, Harvard
University, Boston, Massachusetts; ORCID: http://
orcid.org/0000-0003-0039-7784.
Correspondence should be addressed to Jeremy A.
Greene, Institute of the History of Medicine, Welch
## Medical Library, 1900 E. Monument St., Baltimore,
MD 21205; telephone: (410) 955-4849; e-mail:
greene@jhmi.edu; Twitter: @jgreene2.
Copyright © 2017 by the Association of American
## Medical Colleges
## Acad Med. 2017;92:1661–1664
First published online October 24, 2017
doi: 10.1097/ACM.0000000000001991

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited.
## Invited Commentary
## Academic Medicine, Vol. 92, No. 12 / December 2017
## 1662
understanding of disease, therapeutics,
and institutions—things that all
physicians must know in order to be
effective, just as they must learn anatomy
or pathophysiology. Similar (and often
overlapping) arguments can be made
for literature, philosophy, and the other
disciplines that constitute the medical
humanities.
History and the Medical
## Humanities
Of all the medical humanities, history
of medicine has the longest engagement
with medical education.
## 4
For centuries
physicians turned to the history of
their field in pursuit of both practical
knowledge and professional inspiration.
When the rise of clinical and laboratory
science displaced history from this role
in the late 19th century, physicians and
historians found new justifications for
history in medical education, arguing that
history can ground medicine in its social
contexts, foster intellectual humility,
push back against the reductionism of
the biomedical sciences, and socialize
students into the profession and its ideals.
## Yet, Lester King,
## 5(p28)
speaking at a 1966
Josiah Macy Jr. Foundation conference
on the role of history in medical
education, focused on what he saw as
the fundamental problem: “We cannot
seriously maintain that it makes ‘better’
doctors in any practical sense.”
The crises of medical professionalism of
the 1960s and 1970s focused attention
on the potential value of medical ethics
and medical humanities in medical
education. When Pennsylvania State
University began to plan a new medical
school in 1964, its founding dean
envisioned a curriculum that took the
philosophical, spiritual, and ethical
aspects of medicine as seriously as
the biomedical sciences.
## 6,7
A second
medical humanities program opened
at the University of Texas at Galveston
in 1973, with the goal of “encouraging
intellectual and professional growth,
the cultivation of sound judgment,
and the enlargement of character,
virtues, and skills indispensable to good
doctoring.”
## 8(p1009)
Over the next two
decades, medical humanities programs
appeared throughout the United States,
Canada, and Europe.
## 9
In the preface of a 1995 special issue
of Academic Medicine dedicated to the
medical humanities, Addeane Caelleigh
and Lisa Dittrich
## 10(p757)
rejected the
idea that the humanities were “soft
and fuzzy.” Instead, they saw them as a
set of fields “concerned with the most
difficult areas of human life, the areas
of personal experience through which
we live and understand our lives.” Each
field—ethics, history, law, literature,
philosophy, and religion—also offered
its own methodological and theoretical
contributions. Literature helped students
explore “the human condition in all its
singularity and mystery.”
## 11(p787)
## Religious
studies could “enhance the students’
ability to practice genuinely person-
centered medicine.”
## 12(p811)
History of
medicine provided “a much-needed
context in which to appreciate medicine’s
constant values.”
## 13(p755–756)
By the time of a second special issue
of Academic Medicine in 2003, the
obstacles to this vision had become
clear.
## 9
Individual schools struggled
to instantiate a broad-based field of
medical humanities because they had
faculty expertise only in certain areas.
New York University and Northwestern
University, both strong in literature,
had at the time little engagement with
history of medicine.
## 14,15
## The University
of California, San Francisco, and
Harvard University, strong in history and
anthropology, did not cultivate literature
or religious studies.
## 16
Relations with
bioethics varied substantially.
## 17
Amid these struggles, advocates for
the medical humanities focused on
contributions that could be made by any of
the component disciplines. The important
thing was to have someone doing some
form of humanities, regardless of method,
content, and mode of critical analysis.
Any of the disciplines could help students
explore the experience of illness, suffering,
and healing and help health professionals
become “more self-aware and humane
practitioners.”
## 3(p192)
Specific proposals
often narrowed their aim to a single target
that could be achieved through any of
these fields. The Project to Rebalance and
Integrate Medical Education initiative
(PRIME) sought “to promote humanistic
skills and professional conduct in
physicians,” including both patient-centered
skills and critical thinking.
## 1(p334)
## Ethics
and humanities faculty had to “articulate
a shared vision of how such education
promotes professionalism.”
## 18(p1627)
## Arno
Kumagai and Delese Wear
## 19(p973)
emphasized
another goal,
that of “making strange”—that is,
portraying daily events, habits, practices,
and people through literature and the arts
in a way that disturbs and disrupts one’s
assumptions, perspectives, and ways of
acting so that one sees the self, others, and
the world anew.
Each target could be achieved through
any of the interchangeable disciplines of
the arts and humanities.
The Parts of the Parts Left Out of
the Whole
The notion that all humanities fields
are fungible can help make a medical
humanities curriculum more accessible
to schools with limited faculty: It does
not matter if a given school has an
artist, novelist, or historian, because the
essential contribution is something that
could be provided by any of them. And
yet, by emphasizing the sorts of things
that can be taught by any particular
combination of disciplines, these
proposals can miss other contributions
that these individual fields can make to
medical education. This paradoxically
constrains the claims for the value
of medical humanities in medical
education, relegating them to valuable
but generic tasks such as the cultivation
of professionalism, empathy, or
estrangement.
Although the value of disciplinarity
could be demonstrated with any of
the constituent fields of the medical
humanities, we focus on the one we know
best—history. Although it is certainly
the case that education in history can
foster professionalism and humanism, it
can do much more. As we have argued
elsewhere, history of medicine should
be considered an essential domain of
medical knowledge, with contributions
that are just as important as those offered
by anatomy or biochemistry.
## 4
All medical
educators agree that physicians need to
master the evolving fields of diagnosis,
pathophysiology, and therapeutics, fields
which demand knowledge that cannot
be found in laboratory sciences alone.
Educators also understand that physicians
need to function in a complex health care
system in which medicine is just one part
of broader societal responses to disease.
We have developed a list, by no means
exhaustive, of the key contributions that

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited.
## Invited Commentary
## Academic Medicine, Vol. 92, No. 12 / December 2017
## 1663
history offers medicine (see List 1). These
can be distilled into five basic themes,
the importance of which should be self-
evident:
- Disease changes over time. A thorough
understanding of medicine includes
knowledge of both the changing
burden of disease and the shifting
meanings that shape the impact of
disease on individuals and societies.
- Medicine is a product of history.
Medical knowledge, technology, and
practice change over time. History
facilitates critical perspectives,
demonstrates that innovation is not
always progress, and focuses attention
on the changing values and standards
of what counts as effective therapy.
- Health inequalities persist over time.
Race, ethnicity, gender, and class
each reflect complex intersections
of biological and social processes.
Historical analyses of these categories
can illuminate the causes of persistent
inequalities and their possible
solutions.
- Health care systems are in constant
flux. Social, economic, and political
forces shape the medical profession,
its institutions, and the health-seeking
behaviors of patients in a dynamic
medical marketplace. By explicating
current structures and their
limitations, history can guide efforts at
reform.
- Ethical dilemmas in medical practice
are contingent. By identifying the
social, economic, and political forces
that shape ethical norms, history
provides an essential approach for
understanding and teaching medical
ethics.
Although many of these themes can
also be approached through other
disciplines, they cannot simply be
reduced to empathy, professionalism,
and defamiliarization. For instance,
physicians who would tackle the great
epidemics facing medicine and society
today, whether obesity, opioids, dementia,
or Zika, need to understand why each
has increased in prevalence over time.
If answers to these questions cannot be
found in molecular biology or genetics
alone, they also cannot be found in
philosophy or literature or visual studies.
They require historical analysis. History
does not just convey an attitude toward
medical knowledge and practice. Instead,
historical analysis—just like molecular
biology or pharmacology—offers
fundamental contributions to our
understanding of disease and therapeutic
efficacy, and to our ability to train
students to be effective providers within
complex and changing systems of care.
Equally strong arguments could be
made about the essential contributions
of philosophy, anthropology, literature,
visual studies, or other humanities.
## 20
## It
is possible to make all of these cases in
the current language of competencies.
Beyond professionalism, history can
also contribute to competencies in
medical knowledge, intraprofessional
collaboration, practice-based learning,
and the design and function of health
care systems.
## 4
Other humanities
fields can address competencies in
other domains that history cannot.
Narrative medicine, for example, can
make specific claims in domains of
communication and collaboration.
## 21
## List 1
The Contributions of History to Medical Education
a
-      The burden of disease changes over time. A thorough understanding of disease (something
that all doctors should have!) includes knowledge of the nonreductionist mechanisms that
can account for these changes over time (e.g., social determinants of disease).
-      What counts as disease—definitions, diagnostic practices, and social meanings—is historically
contingent. Physicians need to appreciate the factors that account for how definitions of
disease change over time, and their consequences.
-      Medical therapeutics, and understandings of their efficacy, are dynamic. Good medical care
depends on an understanding of the changing values and evidence reflected in claims of
therapeutic success.
-      Medical knowledge is produced through specific social, economic, and political processes.
History provides critical perspective on the contingency of knowledge production and
circulation, fostering clinicians’ ability to tolerate ambiguity and make decisions in the setting
of incomplete knowledge.
-      Health inequalities, in both the burden of disease and in treatment access and outcome, have
persisted for millennia. History offers essential perspective about the causes of inequalities
and possible solutions.
-      Medicine has influenced—for worse and for better—how race, ethnicity, gender, sexuality,
and class are understood and managed. History offers robust tools for understanding these
dynamics.
-      Medical education, research, and practice take place across disparities in status and power.
History demonstrates how and why this has happened.
-      Medical technologies exist as part of broader social systems. History shows that innovation is
not always progress, that technologies have unanticipated costs and consequences, and why
improvements are not always implemented.
-      The roles of physicians, their professional structures, and the social contexts of practice
change over time. Understanding this history helps physicians navigate their shifting
environments.
-      Hospitals, medical schools, and health care systems are the by-product of a long series of
political struggles and compromises. History explicates the current structures, their limitations,
and prospects for reform.
-      Health-seeking behaviors have changed significantly over time. Historical perspective
allows physicians to be more effective as they work within this dynamic, pluralistic medical
marketplace.
-      Medicine is one of many societal responses to disease in individuals and populations (e.g.,
nursing, public health, social work, religion). History offers perspective on the changing role
of medicine in society.
-      Historical study has shown how individuals’ experiences of their bodies have changed over
time (and across culture). Physicians cannot assume a universal experience of health or
disease.
-      Ethical dilemmas in medical research and practice change over time. History reveals the
specificity of social, economic, and political forces that shape ethical judgments and their
consequences.
a
This list is meant to be suggestive, and it is far from exhaustive. It is a series of talking points for anyone
who wants to make the case for history’s role in medical education. A historian, asked by a dean of medical
education why history matters, could respond with any of these arguments. Any one of them can be the basis
for an informal teaching session or a lecture. Together, they provide an outline of possible courses. The list
also highlights possible areas of research for students who want to engage more seriously with the history of
medicine. Adapted with permission from Jones DS, Greene JA, Duffin J, Warner JH. Making the case for history
in medical education. J Hist Med Allied Sci. 2015;70:623–652.
## 4

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited.
## Invited Commentary
## Academic Medicine, Vol. 92, No. 12 / December 2017
## 1664
## Conclusions
Proponents of evidence-based curriculum
design demand proof that the medical
humanities will make better doctors. But
such proof is seldom demanded from
the basic sciences. When schools reduced
anatomy instruction, no one conducted
follow-up studies to see if the schools still
graduated competent surgeons. When
schools increased time devoted to genetics,
no one asked for evidence that the graduates
were somehow more effective clinicians. As
Ousager and Johannessen
## 22(p988)
pointed out,
“few, if any, aspects of medical education are
able to produce empirically based evidence
of their indispensability in the course
of the education of a physician.” Most
medical schools and accrediting agencies
simply assume the value of anatomy and
biochemistry. If we were to stop and think
carefully about what the medical humanities
can offer across the varied domains of
medical education (e.g., doctors who are
more knowledgeable, thoughtful, ethical,
professional, etc.), then their value—both
on their own and as an organized
consortium—is just as self-evident.
We understand that medical schools face
many pragmatic constraints in supporting
medical humanities. There are not enough
professors of history (or of anthropology,
literature, visual arts, etc.) at medical
schools to ensure that adequate courses
are offered everywhere, tested through
board exams, and enforced through
Liaison Committee on Medical Education
accreditation. But similar challenges also
exist in the basic sciences. Many schools
no longer employ faculty trained in
anatomy or physiology. Many curricula
have moved away from disciplinary
approaches and toward integrated,
problem-based curricula. But despite
these challenges, schools have found ways
to teach the basic science content that
they consider essential. Something similar
should be done in the medical humanities.
For this to succeed, scholars in the
various disciplines of the medical
humanities must articulate the essential
contributions of their fields both
individually and as part of the broader
vision of the medical humanities. Even
though anatomy and biochemistry each
teach students about how the body
works, they are not interchangeable fields.
Similarly, even though history, literature,
and other medical humanities offer vital
perspective on the experience of illness
and the practice of medicine, they also
offer much more.
We have tried to define the crucial
contributions of history, and we call
on other educators to do the same for
other fields in the medical humanities.
When these contributions are clearly
defined, medical schools can respond
appropriately. The case for medical
humanities will be most successful if
it builds on both the shared and the
distinct contributions of its disciplines.
The sum of the parts can be greater than
the whole.
Acknowledgments: The authors would like to
thank the organizers and participants of the
Association of American Medical Colleges
Humanities and Arts Thought Leader Forum,
Washington, DC, July 2017, for feedback on an
earlier version of this Invited Commentary.
Funding/Support: J.A. Greene reports support
from a Greenwall Foundation Faculty Fellowship
in Bioethics. D.S. Jones reports support from a
Scholarly Works grant 1G13LM012053 from the
National Library of Medicine, National Institutes
of Health, Department of Health and Human
## Services.
Other disclosures: None reported.
Ethical approval: Reported as not applicable.
Disclaimer: The views expressed in any written
publication, or other media, do not necessarily
reflect the official policies of the Department of
Health and Human Services, nor does mention
by trade names, commercial practices, or
organizations imply endorsement by the U.S.
## Government.
## References
1 Doukas DJ, McCullough LB, Wear S;
Project to Rebalance and Integrate
Medical Education (PRIME) Investigators.
Perspective: Medical education in medical
ethics and humanities as the foundation for
developing medical professionalism. Acad
## Med. 2012;87:334–341.
2 Barnard D. Making a place for the
humanities in residency education. Acad
## Med. 1994;69:628–630.
## 3 Shapiro J, Coulehan J, Wear D, Montello M.
Medical humanities and their discontents:
Definitions, critiques, and implications. Acad
## Med. 2009;84:192–198.
4 Jones DS, Greene JA, Duffin J, Warner
JH. Making the case for history in
medical education. J Hist Med Allied Sci.
## 2015;70:623–652.
5 King LS. Commentary. In: Blake JB, ed.
Education in the History of Medicine. New
York, NY: Hafner Publishing Company;
## 1968:28–31.
6 Barnard D, Clouser DK. Teaching medical
ethics in its contexts: Penn State College of
## Medicine. Acad Med. 1984;64:743–746.
7 Hawkins AH, Ballard JO, Hufford DJ.
Humanities education at Pennsylvania State
University College of Medicine, Hershey,
## Pennsylvania. Acad Med. 2003;78:1001–1005.
8 Jones AH, Carson RA. Medical humanities
at the University of Texas Medical Branch at
## Galveston. Acad Med. 2003;78:1006–1009.
9 Dittrich LR, ed. Special issue on the medical
humanities. Acad Med. 2003;78:951–1075.
10 Caelleigh AS, Dittrich LR. Preface. Acad Med.
## 1995;70:757.
11 Hunter KM, Charon R, Coulehan JL. The
study of literature in medical education. Acad
## Med. 1995;70:787–794.
12 Barnard D, Dayringer R, Cassel CK. Toward
a person-centered medicine: Religious
studies in the medical curriculum. Acad Med.
## 1995;70:806–813.
13 Cohen JJ. Foreword: The humanities and
medical education. Acad Med. 1995;70:755–
## 756.
14 Krackov SK, Levin RI, Catanesé V, et al.
Medical humanities at New York University
School of Medicine: An array of rich
programs in diverse settings. Acad Med.
## 2003;78:977–982.
15 Montgomery K, Chambers T, Reifler DR.
Humanities education at Northwestern
University’s Feinberg School of Medicine.
## Acad Med. 2003;78:958–962.
16 Bourgois P. University of California, San
Francisco, School of Medicine, Department
of Anthropology, History and Social
## Medicine. Acad Med. 2003;78:1060–1061.
## 17 Charon R, Williams P. Introduction: The
humanities and medical education. Acad
## Med. 1995;70:758–760.
18 Doukas DJ, McCullough LB, Wear S, et al;
Project to Rebalance and Integrate Medical
Education (PRIME) Investigators. The
challenge of promoting professionalism
through medical ethics and humanities
education. Acad Med. 2013;88:1624–1629.
19 Kumagai AK, Wear D. “Making strange”: A
role for the humanities in medical education.
## Acad Med. 2014;89:973–977.
20 Polianski IJ, Fangerau H. Toward “harder”
medical humanities: Moving beyond the
“two cultures” dichotomy. Acad Med.
## 2012;87:121–126.
21 Arntfield SL, Slesar K, Dickson J, Charon
R. Narrative medicine as a means of
training medical students toward residency
competencies. Patient Educ Couns.
## 2013;91:280–286.
## 22 Ousager J, Johannessen H. Humanities
in undergraduate medical education: A
literature review. Acad Med. 2010;85:988–998.