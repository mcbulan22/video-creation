Received: 13 March 2023 Revised: 31 May 2023 Accepted: 15 June 2023 

DOI: 10.1111/medu.15162 



### S T A T E O F T H E S C I E N C E 

A S S E S S M E N T S U P P O R T S 

# Medical competence as a multilayered construct 

Olle ten Cate<sup>1</sup> | Natasha Khursigara-Slattery<sup>2</sup> | Richard L. Cruess<sup>3</sup> | Stanley J. Hamstra<sup>4,5</sup> | Yvonne Steinert<sup>3</sup> | Robert Sternszus<sup>6</sup> 

1University Medical Center Utrecht, Utrecht, The Netherlands 

2Mid-West Intern Network, University of Limerick, Limerick, Ireland 

3Institute of Health Sciences Education, McGill University, Montreal, Quebec, Canada 

4Department of Surgery, University of Toronto, Toronto, Ontario, Canada 

5Holland Bone and Joint Program, Sunnybrook Research Institute, Toronto, Ontario, Canada 

6Department of Pediatrics, Institute of Health Sciences Education, McGill University, Montreal, Quebec, Canada 

##### Correspondence 

Olle ten Cate, PhD, Utrecht Center for Research and Development of Health Professions Education, University Medical Center Utrecht, PO Box # 85500, 3508 GA Utrecht, The Netherlands. Email: t.j.tencate@umcutrecht.nl 

## Abstract 

Background: The conceptualisation of medical competence is central to its use in competency-based medical education. Calls for ‘fixed standards’ with ‘flexible pathways’, recommended in recent reports, require competence to be well defined. Making competence explicit and measurable has, however, been difficult, in part due to a tension between the need for standardisation and the acknowledgment that medical professionals must also be valued as unique individuals. To address these conflicting demands, a multilayered conceptualisation of competence is proposed, with implications for the definition of standards and approaches to assessment. 

The model: Three layers are elaborated. This first is a core layer of canonical knowledge and skill, ‘that, which every professional should possess’, independent of the context of practice. The second layer is context-dependent knowledge, skill, and attitude, visible through practice in health care. The third layer of personalised competence includes personal skills, interests, habits and convictions, integrated with one's personality. This layer, discussed with reference to Vygotsky's concept of Perezhivanie, cognitive load theory, self-determination theory and Maslow's ‘self-actualisation’, may be regarded as the art of medicine. 

We propose that fully matured professional competence requires all three layers, but that the assessment of each layer is different. 

Implications: The assessment of canonical knowledge and skills (Layer 1) can be approached with classical psychometric conditions, that is, similar tests, circumstances and criteria for all. Context-dependent medical competence (Layer 2) must be assessed differently, because conditions of assessment across candidates cannot be standardised. Here, multiple sources of information must be merged and intersubjective expert agreement should ground decisions about progression and level of clinical autonomy of trainees. Competence as the art of medicine (Layer 3) cannot be standardised and should not be assessed with the purpose of permission to practice. The pursuit of personal excellence in this level, however, can be recognised and rewarded. 

> © 2023 The Authors. Medical Education published by Association for the Study of Medical Education and John Wiley & Sons Ltd. 

This is an open access article under the terms of the Creative Commons Attribution-NonCommercial License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited and is not used for commercial purposes. 

Med Educ. 2024;58:93–104. 

wileyonlinelibrary.com/journal/medu 93 

94 

ten CATE ET AL. 

## 1 | INTRODUCTION 

Competency-based education in the health professions has been embraced by educators, programmes and governing bodies in many countries, but the very concept of medical competence has always proven a somewhat elusive and ‘fuzzy’ construct.<sup>1,2</sup> Hodges showed how the definition of competence shifts, depending on the perspective taken in various discourses.<sup>3</sup> Yet there is general agreement that medical competence must be defined, both to determine what, and how much, education is needed to prepare new generations of care providers, and to determine who can, or cannot, be licensed to practice. Definitions like ‘The habitual and judicious use of communication, knowledge, technical skills, clinical reasoning, emotions, values, and reflection in daily practice for the benefit of the individual and community being served’<sup>4</sup> are comprehensive and attractive, yet they do not provide an adequate foundation to determine when, or whether, trainees have become competent enough to practice. Numerous attempts to define competence, competencies and competency-based education<sup>5–9</sup> have met with the criticism of being reductionist and unable to capture the holistic nature of medical competence.<sup>10–15</sup> 

Although the ongoing discourse of what medical competence is may be academically useful and important, it has not been very productive in serving programmes, clinicians and teachers to create curricula and assess medical trainees. Somehow the goal of medical education (a competent physician) must be translated into activities learners need to be able to do tomorrow, next month, next year. The 2010 Carnegie Report on medical education proposed to ‘standardize ’ learning outcomes and individualize learning pathways .<sup>16,17</sup> At the same time, standardised educational outcomes must be reconciled with the recognition that eventually no two practitioners are identical and that medical schools are not factories that ‘produce’ identical graduates. The pursuit to define and use standards to assess competence, begs the question to what extent individual differences can be tolerated in an applied professional discipline that also requires standards for the protection of its consumers. Detailed behavioural competency descriptions, such as those incorporated in the CanMEDS framework<sup>18</sup> or in the ACGME milestones, may read as prescriptive, but they actually leave space for individual difference, be it implicitly.<sup>19</sup> 

The word competence has acquired a normative connotation in graduate medical education as being a minimum level of acceptable proficiency that is compatible with the practice of medicine. While competent was coined by Dreyfus and Dreyfus to have this meaning, being a middle stage of skill development,<sup>20,21</sup> in this essay, we turn back to the more general meaning of the construct of competence, which can be either high or low, appropriate for practice or not. Mastery, excellence, expertise, but also deficiency, all refer to levels of competence. Our quest, however, is to conceptualise competence in a way that allows educators to set standards that can be operationalised and required for all graduates of educational programmes—a basic tenet of competency-based medical education<sup>22–24</sup> —and at the same allows for acceptable individual variation. 

This essay is an attempt to define competence as a multilayered construct that allows for the standardisation that CBME requires, but also values context-dependent differences, and individual differences between practitioners, even in similar contexts.<sup>25</sup> Following Billett, who, in his elaborations of workplace learning, speaks of domains of canonical, situational, and personal occupational knowledge (also named domains of occupational competence or expertise),<sup>26,27</sup> we will distinguish three hierarchical layers: (1) a core layer of canonical competence, (2) a layer of contextual competence and (3) a layer of personalised competence. 

We will maintain that all three layers are important and necessary contributors to medical competence but that they respond differently to the requirement of standardisation and hence must be assessed and valued differently. In addition, the layers are conceptualised as hierarchical, but not completely sequential. For Layer 2, competence of Layer 1 is needed; for Layer 3, competence of Layer 2 is needed but can start to build early. Even personalised competence Layer 3 development can start at an earlier phase, as depicted in Figure 1. 

Canonical competence can and should still grow while contextual competence dominates in a phase of clinical education, and personalised competence can start to emerge early in one's professional development while only predominating in a later phase of development. Yet the distinction between the layers is useful and has implications for the definition of standards and hence for assessment and education. 

In the following paragraphs, we will expand on the nature, significance and consequences of these layers for the definition of standards and for assessment. As the third layer (personalised competence) is novel, we will elaborate on that layer most. 

Table 1 summarises much of what is being elaborated below. The structuring in three columns may suggest that the development of competence in three layers is separate. That suggestion is not our intention. The development of medical competence will always include interactions between its layers, but for the conceptualisation of standards and the approaches to assessment, distinctions are useful. 

## 2 | COMPETENCE AT LAYER 1: CANONICAL, CONTEXT-INDEPENDENT KNOWLEDGE AND SKILL 

There is a justified expectation that every physician should possess core knowledge, needed to understand the general structures and functions of the human body, as well as common mechanisms of pathology and principles of treatment. Until roughly a century ago, a licence in medicine was sufficient for a lifetime of medical practice. However, in Western countries, the medical degree is now an intermediate station en route to specialist training.<sup>28</sup> This first layer regards the more or less undisputed truths and can be called ‘canonical’.<sup>26,29</sup> Canon (from ancient Greek κανων, or ‘reed stick’ to settle disputes at the market place about product dimensions<sup>30</sup> ; also ‘ruler’, ‘measure’ and ‘norm’) means body of principles, rules, standards or norms,<sup>31</sup> 



<!-- Start of picture text -->
preclinical clinical postgraduate post certification<br><!-- End of picture text -->









96 

ten CATE ET AL. 

‘what everyone should know’ or, for physicians, ‘the knowledge which all practitioners would be expected to possess’<sup>26,29</sup> independent of the context in which this knowledge is applied. The canon of ‘undisputed truths’ does not imply that the full body of biomedical knowledge must be mastered by all medical professionals, nor that this body of knowledge remains similar over time; rather, the canon regards at least those elements that are needed for a clear understanding of human physiology and pathology, and for evidence-based practice of diagnosis and treatment. These are the truths that do not depend on any particular context. Although not sufficient to practice health care, canonical competence can be regarded as foundational; in principle, all practitioners should have mastered it and be ready to use and defend it.<sup>32</sup> 

Defining canonical knowledge is not necessarily easy. For individual physicians, required canonical knowledge and skill is generally acquired early but can grow after licensing and specialty certification if needed for practice. The application of standards to practice should therefore not only include the knowledge and skills expected for licensing, often elaborated in national standards; they should also consider the scope that is being practiced, and hence for specialty specific standards. Canonical competence must also be defined within an era of time. What counted as canonical a century ago is not all canonical today. The body of canonical knowledge should be updated regularly, not only because new knowledge is being added, but also because some canonical knowledge may become less useful over time. While biomedical knowledge comes first to mind when considering canonical knowledge, it can be argued that other knowledge, such as some nonnegotiable, core professional norms and values (think of the Hippocratic oath and its derivatives), or knowledge of social determinants of health, also belong to this layer, that is, to ‘what every physician should know’, independent of any context. 

## 3 | COMPETENCE AT LAYER 2: CONTEXTDEPENDENT KNOWLEDGE AND SKILL 

Canonical competence is necessary but not sufficient to qualify for practice. Practice happens in a context requiring adaptation to the environment of practice, to co-workers, to local habits and protocols, and to particular patient populations (e.g., urban versus rural) with additional knowledge and skills.<sup>33</sup> Adaptations can be large (e.g., after a substantive transition to a very different context or country) or small (working with a new colleague, device, protocol, or with patient types with backgrounds not encountered before). Billett called this the situational domain of occupational knowledge.<sup>26</sup> While knowledge is important, this domain must be understood to be broad, including both declarative (knowing what) and procedural (knowing how) knowledge, the latter being particularly prominent in Layer 2. In addition, interaction with context sets conditions for attitude. If competence includes knowledge, skills and attitudes, the second layer of competence draws more heavily on behavioural and attitudinal standards than the first layer. To function adequately in different contexts, there must be a skill to adapt to the context but also a willingness to adapt. When 

evaluating trainees and professionals for adequate practice, norms for professional and humanistic behaviour do not just cover skills but also habits, tendencies and willingness.<sup>34,35</sup> Being trusted with critical health care responsibilities, typically requiring competence of Layers 1 and 2, is supported by attitudinal features such as integrity, agency, reliability, humility; features derived from studies that define conditions for entrustment with critical health care tasks.<sup>36</sup> 

Bates et al. have expanded on contextual competence, explaining how patterns determined by patients, physical environment, clinical practice, educational practice, institutions, community and culture, and geography all shape context,<sup>25,37</sup> stating that ‘standardisation of outcomes, although attractive in the accountability it appears to offer, risks oversimplifying the complex nature of competence, potentially creating a false sense of security about the capability of graduates. This is because competence is, to some extent, inseparable from the context in which it has been developed’.<sup>25</sup> This indivisibility typifies Layer 2. They suggest that developing contextual competence, such as when transitioning to a new hospital, occurs in hierarchical, sequential stages of needs satisfaction, namely (in analogy with Maslow<sup>38</sup> ), physiological needs, practical needs, legitimacy and belonging, competence and autonomy.<sup>39</sup> In 1978, McGaghie et al. also defined the outcome of competency-based medical education to be ‘a healthprofessional who can practice medicine at a defined level of proficiency, in accord with local conditions, to meet local needs’,<sup>40</sup> clearly including contextual competence in its goal. 

## 4 | COMPETENCE AT LAYER 3: PERSONALISED KNOWLEDGE, SKILLS, INTEREST, HABITS AND CONVICTIONS 

Billett maintains that a third dimension, which he called the ‘personal domain of occupational competence’, is indispensable to understand competence.<sup>26</sup> While Bates and Ellaway<sup>37</sup> suggest that personal motivation, prior learning, emotion and cultural background should be included in ‘context’ (thus, the second layer), we propose that the personalised domain is a distinct, separate layer of competence, requiring a different approach to assessment. 

Individual differences between professionals are common, even if they all meet similar standards of competence at Layers 1 and 2. The constructivist view of education explains how the acquisition of new knowledge must build on existing knowledge to be meaningful.<sup>41</sup> Constructivism's central idea is that, in learning, humans actively construct knowledge and that new knowledge requires a foundation from previous learning. This makes learners, and thus professionals unique. No two individuals have a similar cognitive structure or knowledge base, simply because they do not have identical prior learning experiences. They all have ontogenetically (i.e., through their histories) shaped knowledge that depends on personal experiences, mediated by sensory, neural and cognitive systems, in interaction with a social environment.<sup>26</sup> Learning in a clinical workplace, for instance, draws heavily on what Billett has called mimetic learning, a process of observation, imitation and rehearsal, mediated through interaction with the 

97 

ten CATE ET AL. 

environment.<sup>42</sup> What different learners experience, observe, perceive, take from others, learn from mistakes and absorb during clinical education is inherently unique.<sup>43</sup> It builds on, and further creates a distinct professional personality and unique behaviour. As an example, Apramian et al. stressed that surgeons show variation in standard surgical procedures and have their own preferences when conducting surgery.<sup>44–46</sup> Surgical trainees must observe and develop their operative habits watching these attending surgeons' preferences. They must learn to distinguish between non-negotiable surgical principles and negotiable surgical preferences.<sup>44</sup> When surgeons develop their own style, largely after completion of training, and apply their own methods (within the boundaries of the surgical canon and the local context), competence at Layer 3 arises. 

A deeper understanding of this process may benefit from a few different, but related, theoretical perspectives: the construct of Perezhivanie, cognitive load theory, self-determination theory and Maslow's motivational theory. 

A useful construct to capture the process of developmental experiences that lead to the uniqueness of individuals is Perezhivanie, which was deeply studied by Lev Vygotsky, one of the founders of social constructivism. The word, as meant by Vygotsky, is difficult to translate from Russian, but ‘lived experience’ comes close. A more elaborate explanation, as derived from descriptions by Veresov<sup>47</sup> and Gonzalez-Rey,<sup>48</sup> can be expressed as the subjectivity which makes individuals unique in their creative performance, being the resultant of the combined cognitive and emotional experiences, built across one's life time, retained in the long-term memory, and informing one's frame of reference in viewing the world. Experience, emotion and subjectivity are often named as essential ingredients of Perezhivanie. In his pursuit to understand artistic excellence, Vygotsky stressed in his 1925 dissertation ‘The Psychology of Art’ that artists generally build excellence upon technical mastery of skills in art,<sup>49</sup> suggesting a sequence of foundational competence before personal artistic excellence emerges. How one's perezhivanie, that is, one's personal biography, shaped by experiences and emotions, determines the way competence expresses itself in actions and behaviours is likely to hold for the art of patient care, just as it would in artistic painting, theatrical acting, novel writing, musical expression, for a restaurant chef, industrial designer and architect. Vygotsky studied excellence in art, but perezhivanie is a much more general concept.<sup>50</sup> A student of Pavlov, who conceived of teaching as a mechanical, external process, Vygotsky developed a contrasting psychology of learning that focused on individual development, in which personal emotions and experiences are included.<sup>51</sup> Vygotsky's notion that ‘Every idea contains some remnant of the individual's affective relationship to that aspect of reality which it represents’<sup>50</sup> means that cognition alone would insufficiently explain behaviour. Emotions combined with relationality shape individuality (or, in perezhivanie terminology, subjectivity), and experiences iteratively add to that subjectivity. Or, as Gonzalez Rey et al.<sup>48</sup> interpret this, ‘once cognitive and intellectual processes are integrated into subjective configurations, they turn into motivational devices’, that is, lead to further action and new experiences. This sounds highly theoretical, but an example may help. A clinician for example, with a sound 

fund of knowledge, may encounter adverse events in their patient care, leading to strong emotions that shape their individual style in subsequent clinical judgement and practice.<sup>52</sup> Similar subjective experiences may shape personal styles in any profession. 

A different perspective emerges from cognitive load theory. The cognitive resources needed to acquire knowledge and skills are often large, and remain so in an early phase of practice. Newly licensed physicians and junior specialist attendings are known to experience heavy workloads,<sup>53</sup> because they lack the automaticity of thinking and doing to allow for efficient performance. Once repeated, deliberate practice allows for such automaticity, cognitive resources may become available for a more personal approach to professional practice.<sup>54</sup> In technical terms, when germane load needed for learning decreases, intrinsic load for performance has more space.<sup>55</sup> 

The third layer of competence also relates to motivation, satisfaction and enjoyment. Self-determination theory posits that satisfaction of the needs of feeling competent, feeling space to make personal choices in actions and feeling connected to other human beings with mutual trust, stimulates intrinsic motivation in humans.<sup>56,57</sup> In patient care, this state of practice requires a foundation of competence that is not present when learners have not yet reached a minimum competency level, have not yet secured permission for a minimum level of autonomy and have not yet become part of a community with a basic level of mutual trust. But when those conditions are met, the rewards may be great. ‘Self-actualisation’ or the fulfilment of personal potential, was proposed by Maslow as a state allowing for peak experiences, that is reached after other needs have been satisfied (physiological, safety, love and belonging, esteem, competence and aesthetic needs).<sup>38,58</sup> 

These theoretical foundations support the notions of both personalised performance that is intrinsic to the individual, and a culmination at high levels of performance, that transcend the general standards that every professional in a similar community of physicians or specialists should meet. Indeed, as self-determination theory states, individuals like doing what they are good at and satisfying an intrinsic need to feel competent.<sup>57</sup> Professionals are likely to choose pursuing further development in directions they are already good at. This is a critical notion for our model. While in much of education and training for competence at Layers 1 and 2, the effort is directed towards areas where one needs to correct deficiencies related to standards, at Layer 3 the motivation shifts to pursue higher levels of proficiency in areas in which one is already relatively good. Rather than correcting deficiencies, building upon mastery generates gratification and would be typical for the third layer of competence. Here, learning is no longer focused on meeting external standards; rather, it is driven by the desire to meet—and extend—personal standards. 

One can conceptualise Level 3 as the art that personalises practice. While some may question the qualification of this layer as ‘art’, it is the individual touch that a superior professional adds to standard practice which exemplifies it. It extends beyond competence in the more traditional sense, is individualised, and adds quality to performance. The art of medicine (in conjunction with the science of medicine) is old terminology that has never been fully abandoned.<sup>59</sup> It 

98 

ten CATE ET AL. 

highlights the inherent value of diversity that allows professionals to express themselves in their clinical work in a personal, subjective manner that fits with their vision and convictions, built on lived experiences; on their perezhivanie as Vygotsky would say. Diversity as discussed here extends beyond the valuing of under-represented societal groups as a justified diversity pursuit<sup>60</sup> because our focus here is inherently individual. 

## 5 | IMPLICATIONS FOR STANDARDS AND ASSESSMENT 

The significance of the distinction of the three layers of competence lies in the definition of standards and their assessment at each layer. Arguably, in a competency-based model in which completion of a fixed training duration should not be the predominant reason to graduate a student, adequate assessment of competence becomes even more important.<sup>61</sup> In contrast with many other domains, in the health professions there is a dual purpose of assessment of competence. One is to attest whether students meet the objectives to complete education; the other is to grant a licence to practice, that is, to abide by legislation intended to protect the public against errors and malpractice, or, if phrased positively, to provide the population with state-of-the-art quality of health care. This dichotomy (worthy of receiving an academic diploma vs. readiness for patient care practice) reflects a retrospective versus a prospective outlook on the decision to complete training.<sup>62</sup> We will examine its consequences for standards and assessment related to the conceptualisation of competence in the three layers. 

One way to regard assessment is through the lens of the assessment utility formula,<sup>63</sup> which includes reliability, validity, educational impact, acceptability and costs. 

For canonical knowledge and skills, these components have been elaborated well, specifically in the 1970 through 1990s, through standardised knowledge and skills tests (Layer 1).<sup>64</sup> 

Since the turn of the millennium, workplace-based assessment (WBA), aligned with Layer 2 competence, has increasingly been examined using this formula, with methods such as direct observation, case-based discussions, objective structured assessment of technical skills, and multisource feedback.<sup>65,66</sup> More recently, a shift can be seen towards decisions of entrustment with clinical tasks,<sup>67–69</sup> and approaches are being explored to optimise its acceptability and costs.<sup>70</sup> If entrustment with health care tasks is the purpose, then entrustment decisions should lead to increased responsibilities within a health care team, a potentially powerful motivator for learning. This relates to educational impact, if entrustment ‘determinations’ without true consequences are avoided.<sup>71,72</sup> 

‘Assessment’ of competence at Layer 3 has a different nature. It is individualised, and without generalised standards, much of the utility formula does not apply. However, excellence in a chosen domain of expertise, even if informally recognised, can serve as a powerful motor of development, to maintain or further expand one's recognised expertise, which can be considered ‘educational impact’, with high acceptability and at costs that the individual might gladly spend. 

## 5.1 | Layer 1 

Assessment of canonical competence (mostly knowledge) is needed to licence physicians; indeed, even to help define what a physician is, which in part is determined by the canonical knowledge of the profession. The assessment should meet the criteria and approaches of context-independent standards, well conceptualised in the first three levels of Miller's pyramid (‘knows’, ‘knows how’, ‘shows how’), with written tests, online tests and skills tests in standardised, generally simulated, environments.<sup>73</sup> The assessment of this layer of competence can basically be conducted outside the health care environment, can be independent of any context and the unique characteristics of the individual being assessed, to maximise objectivity. Tests should reflect regularly updated standards, to match the development of the foundational canon of medical knowledge, specifically at postgraduate level. 

## 5.2 | Layer 2 

The context-dependent layer of competence draws fully on WBA, as the workplace is the context. The past 20 years have shown a remarkable attention and advancement of WBA methods,<sup>66</sup> but have also shown psychometric problems of WBA. Although the validity, in terms of authenticity, is clearly strong in the workplace, traditional reliability standards can hardly be met.<sup>74</sup> In contrast with canonical competence, assessment of contextual competence cannot be standardised with the purpose to generalise across contexts. Grading students in clerkships with a purpose to rank students (ranking is inherent to traditional reliability theory) is increasingly considered flawed,<sup>75,76</sup> and schools are gradually replacing it by pass/fail decisions<sup>77</sup> and the urge to establish high reliability and generalisability in WBA has shifted to the valuation of expert judgement.<sup>64</sup> Clinicians as experts can judge whether trainees and professionals act well locally by asking: can they apply acquired knowledge in our context? Do they work well in existing teams? Do they know how and when to use local protocols? Do they abide by local rules and procedures? Standards for such situational competence are less easy to define, and assessment cannot use standardised conditions because circumstances continuously change. Rather, clinical supervisors can build a gestalt in their mind about a learner's readiness to practice. Although patients, the public, licensing and accreditation bodies would wish to know which doctors are ‘best’ in practice (not just on written tests), any comparison of WBAs between trainees, even within a hospital, let alone across institutions, jurisdictions and countries, suffers from a lack of reliability.<sup>78,79</sup> Crossley illustrated this by saying: ‘My judgement about the performance of my trainee, based on my interpretation of his performance, with a particular patient or client, with a particular problem, in a particular context today, is always highly meaningful. It says much about my trainee's response to the particulars of the unique patient, problem and context, and it says much about me in terms of my stringency, values and biases. All these things are worthy of exploration. However, it is also important to ask this: Does this judgement have anything to say about my judgement with the same trainee in a completely 

99 

ten CATE ET AL. 

different context, or anyone's judgement about the same trainee in any context?’<sup>80</sup> While experts differ in their judgement, such ‘subjectivity’ in WBA is not necessarily a disadvantage.<sup>81</sup> Traditional proficiency scales may force raters to discard important personal judgement when it does not fit the rubric of the scale. WBA should ideally capture legiti‘ ’<sup>82</sup> mate subjectivity or meaningful idiosyncrasy while discarding unwanted bias.<sup>83</sup> Merging expert judgements of multiple sources, such as in clinical competency committees,<sup>84,85</sup> is needed to arrive at defensible decisions using intersubjective consensus. Those collective decisions do not need to regard a grade on a scale with an inherent purpose to rank learners but rather, can focus on readiness to act in health care. Entrustment decision making for entrustable professional activities<sup>86,87</sup> typically aligns with such assessment of Layer 2 competence. Summative entrustment decisions, with critical impact for both patient safety and learner progress, typically focus on thresholds, such as readiness for unsupervised practice (in postgraduate contexts) or readiness for indirect supervision (in case of medical students)<sup>88</sup> not on ranking learners. While the stakes in assessment of Layer 1 competence typically regard learner progress, in the assessment of Layer 2, the protection of patients is also a critical component. ‘High stakes decisions’ therefore have a different, wider connotation in Layer 2. They must include an estimation of risks for patient safety, which is a prospective judgement.<sup>89</sup> Entrustment decisions must be based on more than technical skill.<sup>90</sup> Ten Cate and Chen<sup>36</sup> have argued that besides capability (activity-specific knowledge, skill and experience; and adaptive expertise), four general features are relevant: integrity (truthful, good intentions and patient-centred); reliability (conscientious, predictable, accountable and responsible); humility (observing limits, willing to ask help and receptive to feedback); and agency (self-confident, proactive towards work, team, safety and self-regulation). This array of features requires thoughtful consideration by observers, dialogues with learners and negotiations within clinical educator teams to arrive at intersubjective judgement and decisions. Entrustment with patient care tasks requires a more holistic picture than rating scales can offer. For example, while in some circumstances, humility is a key feature, in other cases, the learner's proactive agency is more important. Adaptation to contextual demands typically belongs to Layer 2 competence. Assessment of the ability to adapt to new medical environments has not extensively been studied, but promising examples<sup>91–93</sup> and theoretical insights<sup>94,95</sup> are emerging. The binary entrustment decision (yes or no) is a holistic decision that combines the evaluation of competence, the gauging of risks and the granting of autonomy, and can only be made by an examiners who know the learner and who have the authority for patient care in the context of interest.<sup>96</sup> The information determining the decision thus combines contextual features with learner features.<sup>97</sup> All features can weigh in, but there is no formula to predict the outcome of the decision. 

## 5.3 | Layer 3 

Assessment of medical competence at Layer 3 regards personalised knowledge, interest, skill, habits and convictions. It can be qualified as the art of medicine because of the personalised application of canonical 

and context-determined competence. It regards performance beyond the standards that must be met to allow trainees or physicians to practice. At this layer, competence variations arise which, arguably, should all be acceptable and render the definition of external standards for Layer 3 futile. External standards to guard quality and safety of care pertain to Layers 1 and 2. This does not mean that, beyond these standards, every individual must be regarded equal in their development. Ericsson's theoretical model of expertise development distinguishes professionals with automated performance at an acceptable level from those who counteract automaticity, continuously seeking increasing complexity and higher levels of control. The former shows ‘arrested development’; the latter attains high levels of mastery and expertise.<sup>98</sup> While Ericsson's model suggests a unidirectional incremental development, (getting better at what one already does), development of Layer 3 competence can also pertain to new areas of further development. Professionals may also seek niches of practice in which to excel, while other areas remain at the automaticity level. This also exemplifies how ongoing development of competence at this layer shapes an individualised professional identity, with a personal epistemology. Although the focus of our paper is rather on the development of competence than identity formation, the two cannot be fully separated.<sup>99</sup> Competence affects an awareness of identity, and identity shapes the drive for competence development, specifically at Layer 3. 

The question then is: if external standards do not apply at Layer 3, how can excellence, or valued uniqueness, be evaluated? First, it must be acknowledged that those who observe and interact with a professional are directly or indirectly affected by this individual. In other words, a context is shaped both by the individual being assessed and by others who establish the context. Objectivity of standards determined by a local context, even at Layer 2, is inherently complex if the trainee is a team member co-shaping that context.<sup>43,100</sup> As such, context can certainly not serve to provide a standard in any generalisable sense for assessment at Layer 3. Beyond accepted standards of work, it is not easy to establish valid criteria for assessment at Layer 3. Personal development beyond the minimum requirements for all professionals, to rise towards one's unique potential, to become an expert or master following the Dreyfus model,<sup>101,102</sup> or to Ericsson's superior performance after deliberate practice<sup>98</sup> belongs to this domain. A general surgeon interested in cardio-thoracic surgery can specialise and further choose to focus all energy on paediatric cardiac surgery. If deliberate practice is continuously devoted to small domain, other general surgery domains may arrest at just an acceptable level. The narrower the domain of superior expertise, the more unique the experts become, up to the point that there is little sense in developing any standards, that only a tiny expert community can set and evaluate, and maybe still not even agree on. While defining and measuring according to standards (implying criterion referencing) becomes futile, acknowledgment of excellence is not impossible. Unlike sports, where superiority arises from ranking and competition, medical professionals cannot have inter-experts competitions to see who wins. But individuals in the environment, observing and interacting with the professional can still be impressed by superiority (or lack of it), each from their own perspective. Not only has the professional 

100 

ten CATE ET AL. 

to be evaluated unique features, built through perezhivanie, so do the observers. As Vygotsky formulated it for art, ‘We never know why we like or dislike a work of art. Everything we later invent to explain its influence is thought to be a complete rationalisation of unconscious processes.’<sup>48</sup> Appreciation and judgement may in part be an emotion that is not always easy to capture in words and scores.<sup>103</sup> One way to value excellence is to look at a professional's effort to optimise performance. The question about standards at this layer is not “is the individual ready for unsupervised or autonomous practice?”, but “is the individual able, willing and demonstrating the desire to aim for personal excellence? or to show a mindset of growth?”<sup>104</sup> This layer of personalised competence can be demonstrated in interactions with colleagues and learners explaining the what and why of performance (‘… in my experience, X is best…’), in role modelling (‘…watch how I do things…’), and in creative, unique, problem solving, exemplifying the competence at Layer 3 as art.<sup>105</sup> It regards deliberate choices of action within an acceptable space of variation of practice. These choices may be defensible from evidence, personal experience or even convictions grounded in gut feelings that may feel alien to other professionals. Billett speaks of personal mediation of meaning and explains how personal limitations can guide choices in practice (citing hairdressers with specific allergies, navigating their practice using alternative substances).<sup>26</sup> In other words, the personalised competence domain may exploit strengths of the individual and incorporate personal limitations, to define a personal array, scope and methods of practice. The space needed for autonomous development and selfdetermination collides with use of standards set by others<sup>106</sup> ; this holds particularly true for the third layer of competence. In this phase of development one should set (and become able to defend) one's own standards, beyond the standards set by patients, peer and accrediting bodies. While in Layers 1 and 2 the correction deficiencies dominates, in order to meet external standards, Layer 3 has a focus on personal development to excel in chosen areas. The assessment of individuals in this layer of competence should focus on the development and awareness of strengths, limitations, convictions and creative flexibility in practice. A professional can develop to reach excellence by reconciling requirements of practice with their own personal profile. Although assessment is not easy, the environment (colleagues, patients and employers, i.e., naturalistic observers in a naturalistic environment) may discern and value the way the individual has developed and continues to develop towards this individualised, personal excellence, in whatever they need to do. Personal achievements, as reflected in a portfolio or curriculum vitae could help to show some of this pursuit. For this layer, teachers should stimulate, and learners should integrate self-reflection to develop one's own targets and routes for further growth, rather than having goals and standards for the learner being defined externally. 

## 6 | DISCUSSION 

The framework of three layers of competence, although not completely new,<sup>26,27</sup> has not been well elaborated for the health 

professions. The traditional knowledge–skills–attitude distinction<sup>107</sup> does not match the hierarchical nature of our model, but the framework of layers of competence does align with curricula that conceptualise a trilogy of ‘knowing, ‘acting’ and ‘being’ as an outcome of education. This trilogy was recently used to ground the Irish internship curriculum.<sup>108–110</sup> 

We believe this framework is useful to define medical competence because it reconciles tensions between the need for standardised assessment of knowledge and skills and the needs and requirements of the diverse circumstances in which clinicians practice as well as the need to value diversity among medical professionals as independent thinkers.<sup>111</sup> Diversity among learners and professionals should not just be regarded as differences to be mitigated, or a source of measurement error in assessment, causing construct-irrelevant variance, but also as an inherent characteristic of a healthy, dynamic medical workforce. The assessment approaches to the three layers should be different: standardised assessment at Layer 1, collective judgement by trained experts at Layer 2 and valuation of individuality at Layer 3. 

Although a hierarchical, sequential, approach to the development of layers of competence is generally useful, their sequence is not meant to be rigid. In an early phase of professional development, the focus should be on canonical competence. Only after acquisition of knowledge of established canonical ‘truths’ can the uncertainties about biomedical and other relevant knowledge, and hence variation in their application, be addressed. The hierarchical nature of the framework, suggesting a sequential approach to the acquisition of competence, is not a recommendation to return to a ‘Flexnerian’ medical curriculum model in which all basic sciences education must precede clinical training. On the contrary, vertical curricular integration, in which early clinical experience is intertwined with foundational knowledge acquisition has strong assets.<sup>112</sup> However, it should also be remembered that clinical understanding usually requires prior canonical knowledge. Figure 1 was created to visualise this notion. This visualisation is also meant to counter any misconception that our model suggests a complete separation of layers of competence in education or assessment. The integration of layers will happen, as the layers develop in parallel, even if they are still hierarchical (e.g., without prior biomedical knowledge, proper clinical reasoning cannot happen<sup>113</sup> and clinical reasoning may be trained in a classroom setting but in patient care the context requires adaptation<sup>114</sup> ). A medical student in a senior clerkship may still build new canonical knowledge in self-directed learning in the evenings (Layer 1), while finding that contributing to an interprofessional team requires adaptation to local rules and habits (Layer 2), and they may begin to discover personal strengths, interests and convictions (Layer 3). 

Using standards for the assessment of competence may suggest to many lay people that there exists an established body of medical knowledge and skills that suffices for high-quality, safe patient care, and that the mission of medical schools and postgraduate programmes is to ensure that learners acquire this. However, any practicing medical professional knows that this is an over-simplification. There are limitations to the body of biomedical knowledge, causing 

101 

ten CATE ET AL. 

inherent uncertainties in the practice of medicine. Variations cannot simply be divided into correct practice and mistakes or errors. While tolerance for uncertainty and navigating ambiguity is a key component of practice,<sup>115</sup> limitations of the body knowledge must be distinguished from limitations of personal knowledge and skills. Learners must build their own knowledge base and the ‘I don't know’ may only be replaced by the ‘we don't know’ in dialogues with patients if the individual has gained sufficient canonical knowledge. Training students too early for tolerance of uncertainty may risk confusing personal gaps in canonical knowledge with general gaps in the body of biomedical knowledge.<sup>115</sup> At a later stage of development, learners must learn to distinguish variations in practice as being either within the principles of good practice or belonging to the preferences of individual practitioners, that is, to their ‘art of medicine’.<sup>116</sup> This is where tolerance for uncertainty also reflects tolerance for acceptable variations in practice and the acknowledgment that others may differ in their habits and convictions and deserve space for autonomy in practice, one of the conditions for intrinsic motivation.<sup>117</sup> Without this space, the third layer of competence, the pursuit of personal excellence and the feeling of well-being during the practice of professional work<sup>117</sup> cannot thrive. Indeed, if professionals would not possess this layer, the science and practice of medicine would not develop beyond existing standards. 

Our attempt was not to deconstruct competence in competencies, nor to focus on distinguishing tasks that physicians must be entrusted with, but to explain competence as a layered construct that allows a reconciliation of the need for standards for assessment and the need for the development of individualised professional identity. 

#### AUTHOR CONTRIBUTIONS 

Olle ten Cate wrote the first version of this manuscript. All authors critically reviewed the manuscript that led to substantial critical adaptations. The authors engaged in multiple discussion meetings about the manuscript, and all approved of the final version. 

#### ACKNOWLEDGEMENTS 

The first author wishes to acknowledge Dr Anastasia Kurysheva, who studied at Moscow State University and Utrecht University, for valuable conversations about the concept of perezhivanie, and Dr Tavis Apramian and Stephen Billett for helpful correspondences about the manuscript. Both Dr Kurysheva and Dr Billett have given valuable comments on an earlier version of the manuscript. 

#### CONFLICT OF INTEREST STATEMENT 

None. 

#### DATA AVAILABILITY STATEMENT 

Data sharing not applicable to this article as no datasets were generated or analysed during the current study. 

#### ETHICS STATEMENT 

No ethical implications. Ethical review not applicable. 

#### PREVIOUS PRESENTATIONS 

The first author has presented some of this content during the Lord Cohen Lecture for the 2019 Association for the Study of Medical Education Annual Meeting, during an Educational Grand Rounds presentation at the University of California, San Francisco, in October 2021, and at the International Conference of Residency Education, Montreal, October 2022, in a workshop with the co-authors of this manuscript. The first author is a member of the International CBME (ICBME) collaborative. 

#### ORCID 

Olle ten Cate https://orcid.org/0000-0002-6379-8780 Natasha Khursigara-Slattery https://orcid.org/0009-0000-62028752 

Stanley J. Hamstra https://orcid.org/0000-0002-0680-366X Yvonne Steinert https://orcid.org/0000-0001-9933-6732 Robert Sternszus https://orcid.org/0000-0001-8115-5490 

#### REFERENCES 

1. ten Cate O. Competency-based postgraduate medical education: past, present and future. GMS J Med Educ. 2017;34(5):Doc69. doi: 10.3205/ZMA001146 

2. Van der Klink MR, Boon J. Competencies: the triumph of a fuzzy concept. Int J Hum Resour Dev Manag. 2003;3(2):125-137. doi:10. 1504/IJHRDM.2003.002415 

3. Hodges B. The shifting discourses of competence. In: Hodges B, Lingard L, eds. The Question of Competence. Cornell University Press; 2012:14-41. doi:10.7591/9780801465802-005 

4. Epstein RM, Hundert EM. Defining and assessing professional competence. JAMA J am Med Assoc. 2002;287(2):226-235. doi:10.1001/ jama.287.2.226 

5. Morcke AM, Dornan T, Eika B. Outcome (competency) based education: an exploration of its origins, theoretical basis, and empirical evidence. Adv Heal Sci Educ. 2013;18(4):851-863. doi:10.1007/s10459012-9405-9 

6. Harden RM, Crosby JR, Davis MH, Fuller T. AMEE guide no. 14: outcome-based education: part 1—an introduction to outcomebased education. Med Teach. 1999;21(1):7-14. doi:10.1080/ 01421599979969 

7. Albanese MA, Mejicano G, Mullan P, Kokotailo P, Gruppen L. Defining characteristics of educational competencies. Med Educ. 2008; 42(3):248-255. doi:10.1111/j.1365-2923.2007.02996.x 

8. Parent F, Jouquan J, de Ketele JM. CanMEDS and other “competency and outcome-based approaches” in medical education: clarifying the ongoing ambiguity. Adv Heal Sci Educ. 2013;18(1):115-122. doi:10.1007/s10459-012-9402-z 

9. Gruppen LD, Mangrulkar RS, Kolars JC. The promise of competencybased education in the health professions for improving global health. Hum Resour Health Dev J. 2012;10(1):43. doi:10.1186/14784491-10-43 

10. Touchie C, ten Cate O. The promise, perils, problems and progress of competency-based medical education. Med Educ. 2015;50(1):93100. doi:10.1111/medu.12839 

11. Brooks MA. Medical education and the tyranny of competency. Perspect Biol Med. 2009;52(1):90-102. doi:10.1353/pbm.0.0068 

12. Glass JM. Competency based training is a framework for incompetence. BMJ. 2014;348(April):1-2. doi:10.1136/bmj.g2909 

13. Hodges BD. A tea-steeping or i-Doc model for medical education? Acad Med. 2010;85(9 SUPPL):34-44. doi:10.1097/ACM. 0b013e3181f12f32 

102 

ten CATE ET AL. 

14. Grant J. The incapacitating effects of competence: a critique. Adv Heal Sci Educ. 1999;4(3):271-277. doi:10.1023/A:1009845202352 

15. Whitehead CR, Austin Z, Hodges BD. Flower power: the armoured expert in the CanMEDS competency framework? Adv Health Sci Educ Theory Pract. 2011;16(5):681-694. doi:10.1007/s10459-0119277-4 

16. Cooke M, Irby D, O'Brien BC, Dooley-Hash S. Educating physicians: a call for reform of medical school and residency. Jama. 2010; 304(11):1240-1241. doi:10.1001/jama.2010.1351 

17. Irby DM, Cooke M, O'Brien BC. Calls for reform of medical education by the Carnegy Foundation for the Advancement of Teaching: 1910 and 2010. Acad Med. 2010;85(2):220-227. doi:10.1097/ACM. 0b013e3181c88449 

18. Frank JR, Snell LS, Sherbino JD (Eds). CanMEDS 2015 Physician Competency Framework. BioMed Central; 2015. 

19. Edgar L, McLean S, Hamstra S, Holmboe E. The Milestones Guidebook. ACGME; 2020. Accessed December 12, 2022. https://www.acgme. org/globalassets/milestonesguidebook.pdf 

20. Dreyfus HL, Dreyfus SE. Mind Over Machine. Free Press; 1986. 

21. Carraccio CL, Benson BJ, Nixon LJ, Derstine PL. From the educational bench to the clinical bedside: translating the Dreyfus clinical skills. Acad Med. 2008;83(8):761-767. doi:10.1097/ACM. 0b013e31817eb632 

22. Carraccio C, Wolfsthal SD, Englander R, Ferentz K, Martin C. Shifting paradigms: from Flexner to competencies. Acad Med. 2002;77(5): 361-367. doi:10.1097/00001888-200205000-00003 

23. Frank JR, Snell LS, ten Cate O, et al. Competency-based medical education: theory to practice. Med Teach. 2010;32(8):638-645. doi: 10.3109/0142159X.2010.501190 

24. Van Melle E, Frank JR, Holmboe ES, Dagnone D, Stockley D, Sherbino J. A core components framework for evaluating implementation of competency-based medical education programs. Acad Med. 2019;94(7):1002-1009. doi:10.1097/ACM.0000000000002743 

25. Bates J, Schrewe B, Ellaway RH, Teunissen PW, Watling C. Embracing standardisation and contextualisation in medical education. Med Educ. 2019;53(1):15-24. doi:10.1111/medu.13740 

26. Billett S. Developing domains of occupational competence: workplaces and learner agency. In: Mulder M, ed. Competence-Based Vocational and Professional Education. Springer International Publishing Switzerland; 2017:47-66. doi:10.1007/978-3-319-41713-4_2 

27. Billett S, Harteis C, Gruber H. Developing occupational exterise through everyday work activities and interactiins. In: Ericsson K, Hoffman R, Kozbelt A, Williams A, eds. The Cambridge Handbook of Expertise and Expert Performance. 2nd ed. Cambridge University Press; 2018:105-126. doi:10.1017/9781316480748.008 

28. ten Cate O. What is a 21st-century doctor? Rethinking the significance of the medical degree. Acad Med. 2014;89(7):966-969. doi:10. 1097/ACM.0000000000000280 

29. ten Cate O, Billett S. Competency-based medical education: origins, perspectives and potentialities. Med Educ. 2014;48(3):325-332. doi: 10.1111/medu.12355 

30. El VI. Infinito En Un Junco [Papyrus: The Invention of Books in the Ancient World/Papyrus: Een Geschiedenis van de Wereld in Boeken]. Meulenhoff; 2019. 

31. NN. Merriam-Webster Dictionary. 

32. Baron RJ, Coleman CH. Protecting the legitimacy of medical expertise. N Engl J Med. 2023;388(8):676-678. doi:10.1056/ NEJMp2201628 

33. ten Cate O, Snell L, Carraccio C. Medical competence: the interplay between individual ability and the health care environment. Med Teach. 2010;32(8):669-675. doi:10.3109/0142159X.2010.500897 

34. Cruess R, Cruess S, Steinert Y. Teaching Medical Professionalism. Cambridge University Press; 2009. doi:10.1017/CBO9780 511547348 

35. Lee M, Wimmers P, Fung C. Assessing competence in medical humanism: development and validation of the ICARE scale fo assessing humanistic patient care. In: Wimmers P, Mentkowski M, eds. Assessing Competence in Professional Performance across Disciplines and Professions. Springer International Publishing Switzerland; 2016: 393-410. doi:10.1007/978-3-319-30064-1_18 

36. ten Cate O, Chen HC. The ingredients of a rich entrustment decision. Med Teach. 2020;42(12):1413-1420. doi:10.1080/0142159X. 2020.1817348 

37. Bates J, Ellaway RH. Mapping the dark matter of context: a conceptual scoping review. Med Educ. 2016;50(8):807-816. doi:10.1111/ medu.13034 

38. Maslow A. A theory of human motivation. Psychol Rev. 1943;50(4): 370-396. doi:10.1037/h0054346 

39. Teunissen PW, Watling C, Schrewe B, et al. Contextual competence: how residents develop competent performance in new settings. Med Educ. 2021;55(9):1100-1109. doi:10.1111/medu.14517 

40. McGaghie W, Miller G, Sajid A, Telder T. Competency-Based Curriculum Development in Medical Education—An Introduction. World Health Organization; 1978. 

41. Schunk DH. Constructivism. In: Schunk DH, ed. Learning Theories. An Educational Perspective. 6th ed. Pearson Education Inc.; 2012: 228-277. 

42. Billett S. Mimetic Learning at Work. Learning in the Circumstances of Practice. 1st ed. Springer; 2014. doi:10.1007/978-3-319-09277-5_1 

43. Martin L, Blissett S, Johnston B, et al. How workplace-based assessments guide learning in postgraduate education: a scoping review. Med Educ. 2022;57(5):394-405. doi:10.1111/medu.14960 

44. Apramian T, Cristancho S, Watling C, Ott M, Lingard L. Thresholds of principle and preference: exploring procedural variation in postgraduate surgical education. Acad Med. 2015;90(11 Association of American Medical Colleges Medical Education Meeting:S70-S76. doi:10.1097/ACM.0000000000000909 

45. Apramian T, Cristancho S, Sener A, Lingard L. How do thresholds of principle and preference influence surgeon assessments of learner performance? Ann Surg. 2018;268(2):385-390. doi:10.1097/SLA. 0000000000002284 

46. Apramian T, Ott M, Roth K, Lingard L, Tipnis R, Cristancho S. Scut to scholarship: can operative notes be educationally useful? J Surg Educ. 2021;78(1):168-177. doi:10.1016/j.jsurg.2020.07.004 

47. Veresov N. The concept of perezhivanie in cultral-historical theory: content and contexts. In: Fleer M, Gonzalez Rey F, Veresov N, eds. Perzhivanie, Emotions and Subjectivity—Advancing Vygotsky's Legacy. Springer Nature Singapore; 2017:47-70. doi:10.1007/978-981-104534-9_3 

48. González RF. Vygotsky's concept of Perezhivanie in the psychology of art and at the final moment of his work: advancing his legacy. Mind, Cult Act. 2016;23(4):305-314. doi:10.1080/10749039.2016. 1186196 

49. Smagorinsky P. Vygotsky's stage theory: the psychology of art and the actor under the direction of perezhivanie. Mind, Cult Act. 2011; 18(4):319-341. doi:10.1080/10749039.2010.518300 

50. Mok N. On the concept of perezhivanie: A quest for clritical review. In: Fleer M, González Rey F, Veresov N, eds. Perezhivanie, Emotions and Subjectivity. Springer Nature Singapore Pte Ltd; 2017:19-46. doi:10.1007/978-981-10-4534-9_2 

51. Rieber R (Ed). The Collected Works of L.S. Vygotsky. Plenum; 1999. doi:10.1007/978-1-4615-4833-1 

52. Helo S, Moulton CAE. Complications: acknowledging, managing, and coping with human error. Transl Androl Urol. 2017;6(4):773-782. doi: 10.21037/tau.2017.06.28 

53. ten Cate O, Favier RP. Approaching training-practice gaps after the transition: a practice proposal for supervision after training. Front Med. 2022;9(May):1-7. doi:10.3389/fmed.2022.881274 

103 

ten CATE ET AL. 

54. Leung A, Epstein R, Moulton C-A. The competent mind. Beyond cognition. In: Hodges BD, Lingard LA, eds. The Question of Competence. Cornell University Press; 2012:157-176. 

55. Sewell JL, Maggio LA, ten Cate O, van Gog T, Young JQ, O'Sullivan PS. Cognitive load theory for training health professionals in the workplace: a BEME review of studies among diverse professions: BEME guide no. 53. Med Teach. 2019;41(3):256-270. doi:10. 1080/0142159X.2018.1505034 

56. Ryan RM, Deci EL. Self-determination theory and the facilitation of intrinsic motivation, social development, and well-being. Am Psychol. 2000;55(1):68-78. doi:10.1037/0003-066X.55.1.68 

57. Ryan R, Moller A. Competence as central, but not sufficient, for high-quality motivation. In: Elliott A, Dweck C, Yeager J, eds. Handbook of Competence and Motivation. The Guilford Press; 2017: 214-231. 

58. McLeod SA. Maslow's Hierarchy of Needs. SimplyPsychology. Published 2018. Accessed October 18, 2022. https://www. simplypsychology.org/maslow.htm 

59. Cameron IA, Pimlott N. Art of medicine. Can Fam Physician. 2015; 61(9):2015. 

60. Deville C. The suffocating state of physician workforce diversity. JAMA Intern Med. 2020;180(11):1418-1420. doi:10.1128/mBio. 01146-15 

61. Gruppen LD, ten Cate O, Lingard LA, Teunissen PW, Kogan JR. Enhanced requirements for assessment in a competency-based, time-variable medical education system. Acad Med. 2018;93(3):S17S21. doi:10.1097/ACM.0000000000002066 

62. ten Cate O, Carraccio C, Damodaran A, et al. Entrustment decision making: extending Miller's pyramid. Acad Med. 2021;96(2):199-204. doi:10.1097/ACM.0000000000003800 

63. van der Vleuten C. The assessment of professional competence: developments, research and practical implications. Adv Heal Sci Educ. 1996;1(1):41-67. doi:10.1007/BF00596229 

64. Schuwirth LWT, van der Vleuten CPM. A history of assessment in medical education. Adv Heal Sci Educ. 2020;25(5):1045-1056. doi: 10.1007/s10459-020-10003-0 

65. Setna Z, Jha V, Boursicot KAM, Roberts TE. Evaluating the utility of workplace-based assessment tools for speciality training. Best Pract Res Clin Obstet Gynaecol. 2010;24(6):767-782. doi:10.1016/j. bpobgyn.2010.04.003 

66. Holmboe ES, Durning SJ, Hawkins RE (Eds). A Practical Guide to the Evaluation of Clinical Competence. Elsevier; 2018. 

67. Kelleher M, Kinnear B, Sall D, et al. A reliability analysis of entrustment-derived workplace-based assessments. Acad Med. 2020;95(4):616-622. doi:10.1097/ACM.0000000000002997 

68. Liebert CA, Melcer EF, Keehl O, et al. Validity evidence for ENTRUST as an assessment of surgical decision-making for the inguinal hernia Entrustable Professional Activity (EPA). J Surg Educ. 2022;79(6):e202-e212. doi:10.1016/j.jsurg.2022.07.008 

69. Sandhu G, Nikolian VC, Magas CP, et al. OpTrust: validity of a tool assessing intraoperative entrustment behaviors. Ann Surg. 2017; 267(4):670-676. doi:10.1097/SLA.0000000000002235 

70. Marty AP, Linsenmeyer M, George B, Young JQ, Breckwoldt J, ten Cate O. Mobile technologies to support workplace-based assessment for entrustment decisions: guidelines for programs and educators: AMEE guide no. 154. Med Teach. 2023;0(0):1-11. doi:10.1080/ 0142159x.2023.2168527 

71. Ott MC, Pack R, Chin M, Van KJA, Ott M. ‘“The most crushing thing”’: understanding resident assessment burden in a competency- based curriculum. J Grad Med Educ. 2022;14(5):583592. doi:10.4300/JGME-D-22-00050.1 

72. ten Cate O, Jarrett JB. Would I trust or will I trust? The gap between entrustment determinations and entrustment decisions for trainees in pharmacy and other health professions. Pharmacy. 2023;11(3): 107. https://doi.org/10.3390/pharmacy11030107 

73. Miller GE. The assessment of clinical skills/competence/performance. Acad Med. 1990;65(9):S63-S67. doi:10.1097/00001888199009000-00045 

74. Zaidi NLB, Kreiter CD, Castaneda PR, et al. Generalizability of competency assessment scores across and within clerkships: how students, assessors, and clerkships matter. Acad Med. 2018;93(8):12121217. doi:10.1097/ACM.0000000000002262 

75. Hauer KE, Lucey CR. Core clerkship grading: the illusion of objectivity. Acad Med. 2018;94(4):1-472. doi:10.1097/acm.00000 00000002413 

76. Bullock JL, Lai CJ, Lockspeiser T, et al. In pursuit of honors: a multiinstitutional study of students' perceptions of clerkship evaluation and grading. Acad Med. 2019;94(11):S48-S56. doi:10.1097/ACM. 0000000000002905 

77. Hanson JL, Rosenberg AA, Lane JL. Narrative descriptions should replace grades and numerical ratings for clinical performance in medical education in the United States. Front Psychol. 2013;4(November): 668. doi:10.3389/fpsyg.2013.00668 

78. McGill DA, van der Vleuten CPM, Clarke MJ. Supervisor assessment of clinical and professional competence of medical trainees: a reliability study using workplace data and a focused analytical literature review. Adv Heal Sci Educ. 2011;16(3):405-425. doi:10.1007/ s10459-011-9296-1 

79. Govaerts M, van der Vleuten CP. Validity in work-based assessment: expanding our horizons. Med Educ. 2013;47(12):1164-1174. doi:10. 1111/medu.12289 

80. Crossley J. Validity and truth in assessment. Med Educ. 2013;47(12): 1152-1154. doi:10.1111/medu.12317 

81. ten Cate O, Regehr G. The power of subjectivity in the assessment of medical trainees. Acad Med. 2019;94(3):333-337. doi:10.1097/ ACM.0000000000002495 

82. Gingerich A, Kogan J, Yeates P, Govaerts M, Holmboe E. Seeing the “black box” differently: assessor cognition from three research perspectives. Med Educ. 2014;48(11):1055-1068. doi:10.1111/medu. 12546 

83. ten Cate O. Bias or Legitimate Subjectivity in Entrustment? ICE Blog (ICBME Collaborators). Published 2022. Accessed December 21, 2022. https://icenetblog.royalcollege.ca/2022/05/12/bias-orlegitimate-subjectivity-in-entrustment/ 

84. Hauer KE, Edgar L, Hogan SO, Kinnear B, Warm E. The science of effective group process: lessons for clinical competency committees. J Grad Med Educ. 2021;13(2s):59-64. doi:10.4300/JGME-D-2000827.1 

85. Smit MP, de Hoog M, Brackel HJL, ten Cate O, Gemke RJBJ. A national process to enhance the validity of entrustment decisions for Dutch pediatric residents. J Grad Med Educ. 2019;11(4):158-164. doi:10.4300/JGME-D-18-01006 

86. ten Cate O, Hart D, Ankel F, et al. Entrustment decision making in clinical training. Acad Med. 2016;91(2):191-198. doi:10.1097/ACM. 0000000000001044 

87. ten Cate O. Entrustment decision-making in competency-based teaching and assessment in health professions education. Med Sci Educ. 2016;26(S1):5-7. doi:10.1007/s40670-016-0342-8 

88. Touchie C, Kinnear B, Schumacher D, et al. On the validity of summative entrustment decisions. Med Teach. 2021;43(7):780-787. doi: 10.1080/0142159X.2021.1925642 

89. Schumacher DJ, Michelson C, Winn AS, Turner DA, Elshoff E, Kinnear B. Making prospective entrustment decisions: knowing limits, seeking help and defaulting. Med Educ. 2022;56(9):892-900. doi:10.1111/medu.14797 

90. ten Cate O. Entrustment decisions: bringing the patient into the assessment equation. Acad Med. 2017;92(6):736-738. doi:10.1097/ ACM.0000000000001623 

91. Wijnen-Meijer M, Van der Schaaf M, Booij E, et al. An argumentbased approach to the validation of UHTRUST: can we 

104 

ten CATE ET AL. 

measure how recent graduates can be trusted with unfamiliar tasks? Adv Heal Sci Educ. 2013;18(5):1009-1027. doi:10.1007/s10459013-9444-x 

92. Kalet A, Zabar S, Szyld D, et al. A simulated “night-on-call” to assess and address the readiness-for-internship of transitioning medical students. Adv Simul. 2017;2(1):13. doi:10.1186/s41077-017-0046-1 

93. Gamborg ML, Dall Jensen R, Musaeus P, Mylopoulos M. Balancing closure and discovery: adaptive expertise in the workplace. Adv Heal Sci Educ. 2022;27(5):1317-1330. doi:10.21203/rs.3.rs-1656121/v1 

94. Pelgrim E, Hissink E, Bus L, et al. Professionals' adaptive expertise and adaptive performance in educational and workplace settings: an overview of reviews. Adv Heal Sci Educ. 2022;27(5):1245-1263. doi: 10.1007/s10459-022-10190-y 

95. Cheung JJH, Kulasegaram KM. Beyond the tensions within transfer theories: implications for adaptive expertise in the health professions. Adv Heal Sci Educ. 2022;27(5):1293-1315. doi:10.1007/ s10459-022-10174-y 

96. ten Cate O. Entrustment as assessment: recognizing the ability, the right, and the duty to act. J Grad Med Educ. 2016;8(2):261-262. doi: 10.4300/JGME-D-16-00097.1 

97. Hauer KE, Ten Cate O, Boscardin C, Irby DM, Iobst W, O'Sullivan PS. Understanding trust as an essential element of trainee supervision and learning in the workplace. Adv Heal Sci Educ. 2014; 19(3):435-456. 

98. Ericsson KA. The influence of experience and deliberate practice on the development of superior expert performance. In: Ericsson KA, Charness N, Feltovich P, Hoffman R, eds. The Cambridge Handbook of Expertise and Expert Performance. 1st ed. Cambridge University Press; 2006:683-704. doi:10.1017/CBO9780511816796.038 

99. Jarvis-Selinger S, Pratt DD, Regehr G. Competency is not enough: integrating identity formation into the medical education discourse. Acad Med. 2012;87(9):1185-1190. doi:10.1097/ACM. 0b013e3182604968 

100. Billett S. Subjectivity, self and personal agency in learning through and for work. In: Malloch M, Cairns L, Evans K, O'Connor B, eds. The SAGE Handbook of Workplace Learning. SAGE Publications Ltd; 2010:60-72. doi:10.4135/9781446200940.n5 

101. Dreyfus SE. The five-stage model of adult skill acquisition. Bull Sci Technol Soc. 2004;24(3):177-181. doi:10.1177/0270467604264992 

102. Carraccio CL, Benson BJ, Nixon LJ, Derstine PL. From the educational bench to the clinical bedside: translating the Dreyfus developmental model to the learning of clinical skills. J mMed Educ. 2008; 83(8):761-767. doi:10.1097/ACM.0b013e31817eb632 

103. van Enk A, ten Cate O. “Languaging” tacit judgment in formal postgraduate assessment: the documentation of ad hoc and summative entrustment decisions. Perspect Med Educ. 2020;9(6):373-378. doi: 10.1007/s40037-020-00616-x 

104. Richardson D, Kinnear B, Hauer KE, et al. Growth mindset in competency-based medical education. Med Teach. 2021;43(7):751757. doi:10.1080/0142159X.2021.1928036 

105. Weisberg R. Modes of expertise in creative thinking: evidence for case studies. In: Ericsson KA, Charness N, Feltovich PJ, Hoffman R, eds. The Cambridge Handbook of Expertise and Expert Performance. 

Cambridge University Press; 2006:761-787. doi:10.1017/ CBO9780511816796.042 

106. ten Cate OTJ. Why receiving feedback collides with self determination. Adv Heal Sci Educ. 2013;18(4):845-849. doi:10.1007/s10459012-9401-0 

107. Bloom B, Engelhart M, Furst EJ, Hill W, Krathwohl D. Taxonomy of Educational Objectives: The Classification of Educational Goals; Handbook I: Cognitive Domain. Longmans, Green; 1956. 

108. Cameron I, Birkett G. Journey making: applying PSE principles to complex curriculum designs. Processes. 2020;8(3):373. doi:10.3390/ PR8030373 

109. Slattery N. Stakeholder feedback on proposed “be” template and content: dissemination and feedback on a proposed template and content for the “be”. In: Component of the intern curriculum framework; 2022. 

110. Offiah G, Boland J (Eds). Curriculum Framework for the Internship Programme in Ireland. Medical Intern Unit, National Doctors Training and Planning; 2023. 

111. Sternszus R, Slattery NK, Cruess RL, ten Cate O, Hamstra SJ, Steinert Y. Contradictions and opportunities: integrating professional identity formation into competency-based medical education. (submitted). 

112. Wijnen-Meijer M, van den Broek S, Koens F, ten Cate O. Vertical integration in medical education: the broader perspective. BMC Med Educ. 2020;20(1):509. doi:10.1186/s12909-020-02433-6 

113. Norman GR, Monteiro SD, Sherbino J, Ilgen JS, Schmidt HG, Mamede S. The causes of errors in clinical reasoning: cognitive biases, knowledge deficits, and dual process thinking. Acad Med. 2017;92(1):23-30. doi:10.1097/ACM.0000000000001421 

114. Watsjold BK, Ilgen JS, Regehr G. An ecological account of clinical reasoning. Acad Med. 2022;97(11):S80-S86. doi:10.1097/ACM. 0000000000004899 

115. Ilgen JS, Watsjold BK, Regehr G. Is uncertainty tolerance an epiphenomenon? Med Educ. 2022;56(12):1150-1152. doi:10.1111/medu. 14938 

116. Apramian T, Cristancho S, Watling C, Ott M, Lingard L. “Staying in the game”: how procedural variation shapes competence judgments in surgical education. Acad Med. 2016;91(11):S37-S43. doi:10.1097/ ACM.0000000000001364 

117. Ryan RM, Deci EL. Intrinsic and extrinsic motivation from a selfdetermination theory perspective: definitions, theory, practices, and future directions. Contemp Educ Psychol. 2020;61(April):101860. doi:10.1016/j.cedpsych.2020.101860 

How to cite this article: ten Cate O, Khursigara-Slattery N, Cruess RL, Hamstra SJ, Steinert Y, Sternszus R. Medical competence as a multilayered construct. Med Educ. 2024; 58(1):93‐104. doi:10.1111/medu.15162 

