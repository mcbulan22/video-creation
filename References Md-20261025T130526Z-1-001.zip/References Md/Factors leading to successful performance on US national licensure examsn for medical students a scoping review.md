Review 

# **Factors Leading to Successful Performance on U.S. National Licensure Exams for Medical Students: A Scoping Review** 

Maniraj Jeyaraju, MD, Henry Linford, DO, Thiago Bosco Mendes, MD, Christine Caufield-Noll, MLIS, and Sean Tackett, MD, MPH 

## Abstract 

#### **Purpose** 

To synthesize the evidence of the factors leading to successful performance on knowledge-based national licensure exams (NLEs) for medical students. 

#### **Method** 

The authors conducted a scoping review to summarize the peer-reviewed empiric literature that used United States Medical Licensing Examination (USMLE) Step 1 or Step 2 Clinical Knowledge or Comprehensive Osteopathic Medical Licensing Examination (COMLEX) Level 1 or Level 2 Cognitive Evaluation scores as outcomes. The authors searched PubMed and Scopus without date restrictions through April 30, 2021. Two reviewers independently screened and selected studies for inclusion. Data were summarized narratively and with descriptive statistics. 

#### **Results** 

The authors screened 1,185 unique citations and included 233 full-text studies in their review. Of these, 201 (86%) were studies of USMLE exams, 31 (13%) were studies of COMLEX exams, and 1 (0.4%) reported on both. The authors classified 29 studies (12%) as informing NLE preparation, 163 (70%) as attempting to identify predictive variables, and 76 (33%) as using NLE scores for program evaluation. Preparation studies found that the number of practice test items, practice exam scores, and less time in dedicated preparation correlated with higher NLE scores. Use of other commercial resources or study strategies was not consistently associated with higher scores. Predictive studies found the strongest 

relationships between individuals’ performance on past assessments and their NLE scores. 

#### **Conclusions** 

The factors leading to successful performance on knowledge-based NLEs align with well-known principles from the cognitive sciences. Learners build on existing foundations of knowledge (reflected in their prior academic performance) and are likely to learn more efficiently with testing and spaced learning over time. While commercial test preparation resources are ubiquitous, there is no evidence that a single resource gives students a competitive advantage on NLEs. Developing habits of regular and continuous learning is necessary for clinical practice and successful NLE performance. 

**T** here is a growing emphasis on medical education regulation worldwide,<sup>1</sup> and national licensure exams (NLEs) are a key part of regulatory strategies that intend to assure the public that physicians will provide high-quality care.<sup>2,3</sup> Better performance on NLEs has been associated with better patient outcomes<sup>4</sup> and lower chances of being sanctioned by medical boards.<sup>5</sup> 

The United States has had NLEs testing students’ medical knowledge for over a century, as the National Board of Medical Examiners (NBME) began 

Please see the end of this article for information about the authors. 

Correspondence should be addressed to Sean Tackett, Johns Hopkins Bayview Medical Center, 5200 Eastern Ave., MFL Center Tower Suite 2300, Baltimore, MD 21224; telephone: (410) 550-1785; email: stacket1@jhmi.edu. 

Acad Med. 2023;98:136–148. First published online July 19, 2022 _doi: 10.1097/ACM.0000000000004877_ Copyright © 2022 by the Association of American Medical Colleges 

Supplemental digital content for this article is available at http://links.lww.com/ACADMED/B310. 

administering exams for medical students at MD-granting institutions in 1916<sup>6</sup> and the National Board of Osteopathic Medical Examiners (NBOME) for students at DO-granting institutions in 1934.<sup>7</sup> The latest versions of both these NLEs for physicians in the United States are 3-exam series: the NBME’s United States Medical Licensing Examination (USMLE) Steps 1, 2, and 3, which began in 1992, and the NBOME’s Comprehensive Osteopathic Medical Licensing Examination (COMLEX) Levels 1, 2, and 3, which started in 1997–1998. While all 3 exams in each series are required for state licensure, the first 2 are typically taken by medical students, supported by medical schools, and required before postgraduate training. Every year, approximately 70,000–80,000 individuals take the USMLE Step 1 or Step 2 Clinical Knowledge (CK) and 14,000– 15,000 take the COMLEX Level 1 or Level 2 Cognitive Evaluation (CE). 

Over a decade ago, residency program directors in the United States began rating USMLE Step 1 and COMLEX 

1 scores as the most important factor when screening interview applicants.<sup>8</sup> This heightened the stress for all students taking these exams, as their opportunities for residency were tied to their exam scores, and it potentially disadvantaged students from groups historically underrepresented in medicine.<sup>9</sup> As a result, USMLE Step 1 and COMLEX 1 scores were changed from 3-digit to pass/fail reporting in 2022.<sup>9</sup> Yet, in the absence of other national standardized assessments, residency program directors may now begin using USMLE Step 2 CK and COMLEX 2 CE scores as measures to compare applicants amid an overwhelming number of applications.<sup>10</sup> 

Commercial preparation resources for NLEs and skepticism surrounding these tools have been present since at least the 1970s.<sup>11</sup> As pressure to perform on NLEs increased, virtually all students began using commercial resources for test preparation.<sup>12</sup> Test preparation resources are no longer limited to workshops and review books. They now include 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**136** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

multimedia resources and self-assessment practice options, including question banks (Qbanks), which according to principles from the cognitive sciences<sup>13,14</sup> may help students learn more efficiently. Students and schools are likely to continue investing in preparation resources for NLEs to ensure students’ maximum competitiveness for residency positions and to prevent costly NLE failures. 

Given the growing importance of NLEs globally and the ongoing investment in performing well on U.S.-based NLEs, our goal was to synthesize the peer-reviewed literature on the factors leading to successful performance on knowledge-based NLEs for medical students. Such a synthesis could help students prepare more efficiently, help educators develop more effective curricula, and help administrators and policymakers in medical education understand predictive factors to consider in admissions and selections. Because the USMLE and COMLEX exams have the longest histories among NLEs worldwide and the most available evidence, we focused on them. We chose a scoping review methodology to accommodate the breadth and heterogeneity of the literature that could be informative. 

#### **Method** 

We conducted our scoping review and report our findings according to the Preferred Reporting Items for Systematic Reviews and Meta-Analyses Extension for Scoping Reviews guidelines.<sup>15</sup> 

### **Eligibility criteria** 

All peer-reviewed literature that referred to USMLE Step 1 (“Step 1”), USMLE Step 2 CK (“Step 2”), COMLEX Level 1 (“COMLEX 1”), or COMLEX Level 2 CE (“COMLEX 2”) were eligible for inclusion (see Supplemental Digital Appendix 1 at http://links.lww.com/ACADMED/B310 for the complete search strategy). No language or publication date restrictions were applied. 

### **Information sources and search strategy** 

We searched PubMed and Scopus without date restrictions on February 5, 2020, for studies that met the eligibility criteria. We updated the search on April 30, 2021. The search strategy was created collaboratively among the study team members, which included 

an informationist (C.C.-N.), clinician– educators (T.B.M., S.T.), and medical students (M.J., H.L.). The primary concept around which the search strategy was constructed was knowledge-based NLEs, specifically the USMLE and COMLEX series. The initial search strategy was developed for PubMed and adapted to Scopus. Specific search terms and strategies are provided in Supplemental Digital Appendix 1 at http://links.lww.com/ACADMED/B310. 

### **Selection of sources of evidence** 

All titles and abstracts were screened independently by 2 study team members (M.J., H.L., T.B.M., S.T.) using the Covidence software (Covidence, Melbourne, Australia) to determine if the study: (1) was related to Step 1, Step 2, COMLEX 1, or COMLEX 2 and (2) treated exam performance as an outcome. Opinions/commentaries were excluded at this stage. Letters to the editor were eligible for inclusion if they reported empiric findings.<sup>16,17</sup> A study was advanced to the full-text review if at least 1 reviewer felt it met the inclusion criteria. 

The full-text review included those studies we identified during our database search plus any we identified when cross-referencing our set of studies against those that Rashid and colleagues had categorized as outcomes in their scoping review of the literature on the USMLE exams<sup>18</sup> and those that Wu and colleagues had identified in their systematic review of the literature on predictors of performance on Step 1.<sup>19</sup> We supplemented this with a review of the references cited by the studies included in our full-text review. At least 2 study team members (M.J., H.L., T.B.M., S.T.) reviewed each full-text study, and our team collectively achieved consensus on which studies to include. 

During the full-text review, we excluded studies when only NLE subscores were reported, when the hypothesized relationship between a predictor and NLE score was not clear, and when the relationship between a predictor and NLE score was not systematically evaluated. We also excluded 5 studies that correlated COMLEX and USMLE scores<sup>20–24</sup> and 1 meta-analysis that examined Medical College Admission Test (MCAT) and USMLE scores<sup>25</sup> (although we incorporated the relevant studies summarized in this meta-analysis). 

For studies that included data from the USMLE and COMLEX predecessors (NBME/NBOME Parts I and II), we included those for which we could isolate the USMLE or COMLEX data.<sup>26–28</sup> We included quantitative studies that did not perform statistical testing on the relationship between a predictor and NLE score when they encompassed a national or regional population.<sup>29–31</sup> We were open to qualitative studies if they met our inclusion criteria and included 1 case series that described interventions for those who failed the USMLE exams.<sup>32</sup> 

We classified studies that reported both USMLE Step 1 and Step 2 scores or COMLEX 1 and 2 scores for which the predictor occurred after the first level of the exam was completed (e.g., clerkship performance) as predicting the second level of the exam. Just 1 study provided data on Step 1 and Step 2 but correlated the predictor with Step 1 only.<sup>33</sup> 

### **Data charting process and data items** 

After the full-text review, our data extraction plans were revised and finalized. We used the Medical Education Research Study Quality Instrument (MERSQI) to inform our plans.<sup>34</sup> Because MERSQI has 3 domains (type of data, validity evidence for evaluation instrument, and outcome level) that were the same for all our included studies, we did not calculate a total MERSQI score. We extracted sample size, number of schools, and years of data included in each study, and whether the statistical analysis incorporated adjustment for other variables. We also summarized which predictor variables were included and their level of significance when tested for associations with an NLE score. For studies that included more than 1 NLE, we extracted data separately for each. One study team member (M.J., H.L., T.B.M., S.T.) extracted variables from each study, and a second study team member verified their findings. 

### **Synthesis of results** 

After data extraction, the results were synthesized by the lead study team member (S.T.) and reviewed and revised by the other study team members. After reviewing all included studies, we classified them into 3 broad categories: 

- Preparation: Studies on NLE preparation programs or activities intended to improve exam performance 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**137** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

- Predictive: Studies predicting performance on NLEs based on existing demographic or academic measures 

- Program evaluation: Studies using NLE scores as a marker of validation or effectiveness of a curriculum or other program aspect 

These categories were not mutually exclusive. We summarized the preparation studies in detail then did not include them in our summaries of the predictive and program evaluation studies. If a study measured a predictor like learning and study strategies<sup>35,36</sup> but did not tie it to preparation specifically for NLEs, it was not classified as a preparation study. Studies that used NBME or NBOME assessments that were developed to predict student performance (e.g., Comprehensive Basic Science Examination, Comprehensive Basic Science Self-Assessment) but were not used as a preparation strategy were not summarized as preparation studies. One study on a preparation program for students who were retaking Step 1 was summarized as a preparation study,<sup>37</sup> although another that provided cognitive rehabilitation for students who failed Step 1 was considered a program evaluation.<sup>32</sup> 

We included a study in the predictive category when we could extract a specific relationship between a predictor variable and an NLE score. When a single measurement was repeated over time, we recorded it as a predictor variable once for that study.<sup>38–40</sup> We recorded whether a statistically significant association was reported between a predictor and an NLE score in at least 1 analysis and, if there was an attempt at adjusting for covariates, whether the variable was significant in the most sophisticated analysis (e.g., a fully adjusted multivariate model). Studies using interview scores<sup>41–43</sup> or other admissions variables were categorized as predictive studies but not program evaluation studies. Program evaluation studies that examined predictive variables across cohorts<sup>44</sup> and across selected cohorts within a larger study population<sup>45</sup> or school group<sup>27</sup> were also categorized as predictive studies. 

Program evaluation studies included evaluations of curriculum structures and policies, curriculum changes or revisions, and other programs, such as conditional admissions or postbaccalaureate programs connected to a medical 

school. For program evaluation studies, we provide basic characteristics of the program setting and summarize key findings. 

After extracting all variables, we created a taxonomy of the major categories of the variables we had documented (see Supplemental Digital Appendix 2 at http://links.lww.com/ACADMED/ B310 for the variables that fall into each category). Below, we describe data quantitatively at the major category level. 

#### **Results** 

We identified a total of 1,956 citations; of these, 1,185 were unique citations (see Figure 1). We excluded 897 citations during the title and abstract screening, leaving 288 studies to be evaluated for eligibility during the full-text review. We excluded 84 of these studies and added 29 that we found during our reference list hand search, leaving us with 233 included studies. Of these, 201 (86%) were studies of only the USMLE exams (93 Step 1 only, 34 Step 2 only, and 74 both Steps 1 and 2), 31 (13%) were studies of only the COMLEX exams (13 COMLEX 1 only, 7 COMLEX 2 only, and 11 both COMLEX 1 and 2), and 1 (0.4%) reported on the USMLE and COMLEX exams. 

We classified 29 (12%) as preparation studies, 163 (70%) as predictive studies, and 76 (33%) as program evaluation studies. We found 35 (15%) to be both predictive and program evaluation studies, with 1 as predictive only for Step 1 but predictive and program evaluation for Step 2.<sup>46</sup> 

### **Preparation studies** 

Of the 29 preparation studies,<sup>37,47–74</sup> 23 (79%) focused only on Step 1, 4 (14%) on Step 2, 1 (3%) on COMLEX 1, and 1 (3%) on both Step 1 and COMLEX 1. Of all preparation studies, 25 (86%) were done at a single institution, and 17 (59%) used surveys, 1 of which surveyed oral and maxillofacial surgery MD residency program directors about their residents’ preparation habits over a 10-year period. Also, 11 (38%) studies used only existing data (9 used institutional data, 1 data from a Qbank, and 1 data from the social media site Reddit). One (3%) study was a randomized controlled trial, and 18 (62%) studies included an analysis that made an adjustment for 1 or more covariates. 

Of the preparation studies, 17 (59%) examined associations between commercial resources and NLE scores, 16 (55%) examined study strategies and NLE timing, 6 (21%) examined school-based study programs, and 6 (21%) examined other variables (e.g., course materials for study, well-being, study strategies, stress). 

Each preparation study is summarized in detail in Appendix 1. Variables that were analyzed in association with an NLE score in at least 3 studies are depicted in Figure 2. 

**Commercial resources.** Of the 17 studies that examined associations between commercial resources and NLE scores, 13 (76%) included Qbanks, 9 (53%) selfassessments for NLEs, 6 (35%) review books, 5 (29%) courses/programs, and 3 (18%) other resources (2 videos and 1 flashcards). 

Studies that attempted to quantify the number of practice test items that students completed from USMLEoriented Qbanks and/or self-assessment exams found positive associations between increased use of these resources and Step 1 scores in all studies<sup>48,50,60,66,70,71,74</sup> but one.<sup>51</sup> The number of practice test items that students completed from COMLEX-focused Qbanks was not associated with improved Step 1 scores and was associated with worse COMLEX 1 scores.<sup>60</sup> In another study, the subjective rating that a COMLEX Qbank was helpful was associated with lower COMLEX 1 scores in the unadjusted analysis but not in the fully adjusted models.<sup>61</sup> Studies that examined performance on selfassessments found that Qbank percent correct scores<sup>49,72</sup> and practice exam scores were correlated with Step 1 scores.<sup>49,51,60</sup> A greater number of practice tests completed was associated with higher Step 1 scores in 1 study<sup>49</sup> but not in another study,<sup>50</sup> and reported use (vs nonuse) of a practice test was not associated with Step 1 scores in a third study.<sup>52</sup> 

Two studies reported that using other commercial resources had positive associations with NLE scores. Greater use of a commercial review book<sup>48</sup> and more flashcards in 1 platform (but not another)<sup>70</sup> were associated with higher Step 1 scores. The remaining studies did not report positive associations, including 5 studies on the use of commercial review books,<sup>47,50,52,61,69</sup> 5 studies on commercial courses,<sup>47,58,68,69,73</sup> and 2 studies on video resources.<sup>60,61</sup> 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**138** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 



**Figure 1** Flowchart showing the study selection process for a scoping review of the literature through April 30, 2021, on the factors leading to successful performance on U.S. national licensure exams, including USMLE Step 1, USMLE Step 2 Clinical Knowledge, COMLEX Level 1, and COMLEX Level 2 Cognitive Evaluation. Abbreviations: USMLE, United States Medical Licensing Examination; COMLEX, Comprehensive Osteopathic Medical Licensing Examination; NLE, national licensure exam. 

**Study strategies.** The 3 studies that explored when students should begin studying for an NLE found that starting farther in advance of Step 1 or COMLEX 1 was associated with higher scores.<sup>48,61,74</sup> However, among medical students, more time overall spent in dedicated exam preparation was not associated with higher Step 1 scores when overall time was estimated to include time before dedicated preparation,<sup>52,67</sup> hours per day studying during the dedicated preparation period,<sup>48,51,71</sup> or length of the dedicated preparation period.<sup>48,51,72</sup> Two studies found that fewer days spent in dedicated preparation was associated with higher Step 1 scores.<sup>50,71</sup> The only exception was the study that found that weeks spent in dedicated preparation was associated with higher scores for oral and maxillofacial surgery MD residents.<sup>59</sup> Studying in groups was not associated with higher Step 1 scores in all 4 studies that included this variable.<sup>47,61,71,74</sup> For Step 2, a study month was not associated with higher scores,<sup>62</sup> and delaying when Step 2 was taken was associated with lower scores.<sup>63,75</sup> 

**School-based programs.** Studies of school-based preparation programs had mixed results. Most studies described 

peer- or near-peer-led programs, with 2 reporting higher scores for participants<sup>53,55</sup> and 3 reporting no increase in scores.<sup>54,56,74</sup> The only report of a faculty-led program, also the only program for remediation, found higher pass rates for participants.<sup>37</sup> 

### **Predictive studies** 

Of the 163 predictive studies, 114 (70%) provided predictors for Step 1, 76 (47%) for Step 2, 20 (12%) for COMLEX 1, and 16 (10%) for COMLEX 2. In aggregate, 118 (72%) studies reported on MCAT measures, 80 (49%) on curricular assessments, 74 (45%) on college grade point averages, 66 (40%) on student demographics, 53 (33%) on premedical experience and admissions variables, 37 (23%) on NBME/NBOME variables, 29 (18%) on Step 1 predicting Step 2 or COMLEX 1 predicting COMLEX 2, 21 (13%) on medical school variables, and 16 (10%) on other measures. Figure 3 depicts findings from the adjusted analyses across all predictive studies. 

Of the 3 most common predictor categories, significant associations were reported with MCAT scores in 89%– 100% of studies that reported unadjusted 

analyses and in 77%–100% of studies that reported adjusted analyses, with curricular assessments in 93%–100% of studies that reported unadjusted analyses and 80%–100% of studies that reported adjusted analyses, and with college grade point averages in 33%–92% of studies that reported unadjusted analyses and 61%–67% of studies that reported adjusted analyses (see Supplemental Digital Appendix 3 at http://links.lww. com/ACADMED/B310). Premedical experience and admissions variables were significantly associated with NLE scores in the smallest percentage of studies: 0%–54% of studies that reported unadjusted analyses and 0%–43% of studies that reported adjusted analyses (see Supplemental Digital Appendix 3 at http://links.lww.com/ACADMED/ B310). Specific references reporting each variable and its association with USMLE and COMLEX scores can be found in Supplemental Digital Appendices 4–6 at http://links.lww.com/ACADMED/B310. 

### **Program evaluation studies** 

Of the 76 program evaluation studies, 56 (74%) reported on Step 1, 44 (58%) on Step 2, 4 (5%) on COMLEX 1, and 5 (7%) on COMLEX 2. Of all program 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**139** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 



Academic Medicine, Vol. 98, No. 1 / January 2023 

**140** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 



**Figure 3** Variables analyzed for predictive associations with USMLE Step 1, USMLE Step 2 Clinical Knowledge, COMLEX Level 1, and COMLEX Level 2 Cognitive Evaluation exam performance and reported significance in adjusted analyses in studies included in a scoping review of the literature through April 30, 2021, on the factors leading to successful performance on U.S. national licensure exams. Note: The X axis is the number of studies reporting on that variable. Data for unadjusted and adjusted analyses are available in Supplemental Digital Appendix 3 at http://links.lww.com/ACADMED/B310. Abbreviations: USMLE, United States Medical Licensing Examination; COMLEX, Comprehensive Osteopathic Medical Licensing Examination. 

evaluation studies, 24 (32%) compared scores for participants in a curricular track or other program with a reference standard, 15 (20%) looked at relationships between curricular structures (e.g., clerkship sequence) or policies (e.g., grading scale) and NLE performance, 14 (18%) evaluated large curricular changes, 9 (12%) evaluated premedical conditional admission or postbaccalaureate programs, 8 (11%) focused on validating a new curricular assessment, 3 (4%) evaluated course activities, 1 (1%) looked at teaching evaluations, and 1 (1%) reported on a case series detailing cognitive rehabilitation of those who failed NLEs. These were a heterogeneous collection of studies, many of which were not intended to identify predictors of successful performance on NLEs. 

We summarize all 76 program evaluation studies in Supplemental Digital Appendix 7 and all 233 included studies in an index in Supplemental Digital Appendix 8, both available at http://links.lww.com/ ACADMED/B310. 

#### **Discussion** 

In this scoping review, we synthesized findings from 233 peer-reviewed studies to 

describe the evidence of the factors leading to successful performance on the NLEs required for medical students in the United States. We found considerable evidence that indicates that individual assessments are often useful predictors of NLE performance. We also found a large body of research that did not yield insight beyond what is already known from the cognitive sciences and educational principles. 

As we attempted to bring structure to this large body of literature, we classified most studies as attempting to identify predictors of performance on NLEs. Notably, the large, multisite studies that we included consistently estimated that 90% of NLE performance was explained by individual characteristics rather than school-level variables.<sup>76–79</sup> Similarly, individuals’ performance on curricular assessments was associated with NLE scores, including in the largest studies we found,<sup>76–91</sup> while curriculum types or structures were not.<sup>79,86,90,92,93</sup> As schools continue to be concerned about admitting students who will progress without the need for remediation and as they continue to refine models that predict academic achievement,<sup>39,40,94</sup> they should note that the evidence suggests that past academic performance remains 

a robust predictor of future academic performance. The evidence may also suggest that what schools have been doing to influence their students’ NLE performance has had limited impact. 

Commercial test preparation courses were scrutinized almost 20 years ago, with authors arguing that these resources offered little value.<sup>95</sup> Since then, a variety of new test preparation materials have come to market and become ubiquitous, including review books, Qbanks, flashcard platforms, and multimedia resources. Every year, students and schools typically purchase multiple test preparation resources, and students can incur significant out-ofpocket costs.<sup>96</sup> Our study summarizes what is known about how useful these resources are. We found that greater numbers of practice test items completed and higher self-assessment scores consistently correlated with higher Step 1 and COMLEX 1 scores. The remainder of the commercial resources that were studied were not consistently associated with higher NLE scores, and there was no evidence of a relationship between commercial resources use and Step 2 or COMLEX 2 scores. Our study highlights the absence of evidence to indicate that a particular resource would help students develop their knowledge foundation better 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**141** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

than another resource. While commercial vendors might imply that their product will improve NLE scores, such claims should be viewed with skepticism and would need to be studied systematically to be supported. 

In addition to test preparation materials, schools have been offering students 1–2 months for dedicated preparation for their Step 1 and/or COMLEX 1 exams. How schools in the United States ultimately respond to pass/fail reporting of first-level exam scores is unknown, but it seems likely that they will now offer a similar preparation period before Step 2 and COMLEX 2 to ensure their students’ competitiveness on these exams. We found that studies consistently reported that longer time and more intensity in dedicated test preparation were not beneficial. Given that evidence suggests that students suffer during these dedicated preparation periods,<sup>96</sup> this routine practice deserves scrutiny. In contrast, we found that an earlier start time for preparing for NLEs was associated with higher scores. We further found that scores on curricular assessments that precede NLEs were consistently correlated with NLE scores. 

Taken together, these findings suggest that students who spread out their learning are most likely to do well on NLEs and that dedicated preparation periods cannot make up for lost time. Our findings provide guidance to students considering best practices in getting ready for their NLEs and may push educators to ensure that formal curricular activities and assessments help students prepare for NLEs. Our findings also appear to align with the movement to allow first-level exams to be taken during the clerkship years, which may give students more opportunity to integrate their basic and clinical science knowledge.<sup>64,97</sup> 

### **Limitations** 

Important limitations must be considered when reviewing our work. First, we included an informationist (C.C.-N.) on our team and cross-referenced the studies we identified against citations from a recent scoping review of USMLE studies. However, our search strategy might have missed studies that provided additional information, and we did not incorporate evidence from the gray literature. Second, we were often limited by the quality of the data reporting. We wanted to summarize standardized effect sizes, but we could not because they were rarely reported. Lack of clarity in reporting required our 

interpretation of the data described in the included studies; we attempted to ensure consistency in how we approached this process and our data extraction by having multiple team members review studies independently, but our interpretations may be subject to error. Third, our grouping of studies into 3 categories was done inductively and iteratively after reviewing all studies, because our team felt this was most appropriate for the body of literature we reviewed, but others may have derived a different scheme. Fourth, while we quantified the number of studies reporting significant associations as a means of summarizing our findings, this was not intended to be a meta-analysis. We were unable to account for publication bias that may skew toward reporting positive findings. Not all studies were equal in sample size or methodological rigor. Despite the limitations of our quantitative measures, we think that consistency across studies and alignment with known educational principles support our interpretations. Fifth, our findings are likely to apply primarily to assessments of cognitive abilities and may not apply to more holistic assessments that might be incorporated into NLEs, such as clinical skills assessments.<sup>98</sup> 

### **Conclusions** 

Medical students in the United States matriculate with a long record of superior academic achievement. Soon after they begin medical school, they often ask what activities will be “high yield” when preparing for their NLEs, knowing their strong performance on these exams will be critical to securing a residency position that gives them the practice and lifestyle that they want. Schools know they need to support students and want to compete for the best and brightest. Thus, there is overwhelming pressure to dedicate time and money to NLE success. 

Across 233 studies that provide evidence of the factors leading to exam success, the key patterns we noticed align with well-known evidence from the cognitive sciences and educational principles.<sup>14,99</sup> Students build on their existing foundations; those who have demonstrated more knowledge (e.g., performed well on relevant knowledge assessments) are likely to continue building on what they have. Self-assessments can improve knowledge and offer practice opportunities for the types of questions that are on NLEs. Learning takes time; spacing out practice allows for new cognitive 

connections to be made and knowledge to consolidate and elaborate. Students can be reassured that establishing effective habits that support regular and continuous learning will not only help them and their patients when they are in clinical practice but also help them succeed on NLEs. 

_Acknowledgments:_ Christine Caufield-Noll passed away after submission of this manuscript. The authors would like to express their appreciation for her as a colleague and friend over the years. 

_Funding/Support:_ Sean Tackett receives salary support from Osmosis for research and scholarship. Henry Linford was an Osmosis Medical Education Fellow. 

_Other disclosures:_ None reported. 

_Ethical approval:_ Reported as not applicable. 

**M. Jeyaraju** was a medical student, University of Maryland School of Medicine, Baltimore, Maryland, at the time this study was completed. He is now a family medicine resident, University of North Carolina School of Medicine, Chapel Hill, North Carolina; ORCID: https://orcid.org/0000-0003-1170-2422. 

**H. Linford** was a postgraduate year 1 transitional resident, Crozer Health, Upland, Pennsylvania, at the time this study was completed. He is now a psychiatry resident, Texas Institute for Graduate Medical Education and Research, San Antonio, Texas. 

**T. Bosco Mendes** was endocrinologist, Departamento de Medicina Interna, Universidade do Estado de São Paulo (Unesp), Botucatu, São Paulo, Brasil, at the time this study was completed. He is now an internal medicine resident, University of Pittsburgh Medical Center, Pittsburgh, Pennsylvania; ORCID: https://orcid.org/0000-0001-8349-3303. 

**C. Caufield-Noll** was informationist, National Institutes of Health Library, National Institutes of Health, Bethesda, Maryland, at the time this study was completed; ORCID: https://orcid. org/0000-0002-5637-3717. 

**S. Tackett** is associate professor of medicine and international medical education director, Division of General Internal Medicine, Johns Hopkins Bayview Medical Center, Baltimore, Maryland; ORCID: https://orcid.org/0000-0001-5369-7225. 

#### **References** 

- **1** World Health Organization. Global Strategy on Human Resources for Health: Workforce 2030. Geneva, Switzerland: World Health Organization; 2016. 

- **2** Price T, Lynn N, Coombes L, et al. The international landscape of medical licensing examinations: A typology derived from a systematic review. Int J Health Policy Manag. 2018;7:782–790. 

- **3** Archer J, Lynn N, Coombes L, Roberts M, Gale T, Regan de Bere S. The medical licensing examination debate. Regul Gov. 2017;11:315–322. 

- **4** Norcini JJ, Boulet JR, Opalek A, Dauphinee WD. The relationship between licensing examination performance and the outcomes of care by international medical school graduates. Acad Med. 2014;89:1157–1162. 

- **5** Cuddy MM, Young A, Gelman A, et al. Exploring the relationships between USMLE 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**142** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

performance and disciplinary action in practice: A validity study of score inferences from a licensure examination. Acad Med. 2017;92:1780–1785. 

- **21** Slocum PC, Louder JS. How to predict USMLE scores from COMLEX-USA scores: A guide for directors of ACGME-accredited residency programs. J Am Osteopath Assoc. 2006;106:568–569. 

   - **36** Khalil MK, Williams SE, Hawkins HG. The Use of Learning and Study Strategies Inventory (LASSI) to investigate differences between low vs high academically performing medical students. Med Sci Educ. 2020;30:287–292. 

- **6** National Board of Medical Examiners. 100 Years in Service to the Public and the Health Professions. https://www2.nbme.org/ centennial. Accessed June 30, 2022. 

- **22** Sarko J, Svoren E, Katz E. COMLEX-1 and USMLE-1 are not interchangeable examinations. Acad Emerg Med. 2010;17:218–220. 

   - **37** Walters JA, Croen LG, Brown Weissman Z, Reichgott MJ. A small group, problem-based learning approach to preparing students to retake Step 1 of the United States Medical Licensing Examination. Teach Learn Med. 1999;11:85–88. 

- **7** Burnett B. In the Public Trust: The National Board of Osteopathic Medical Examiners 1934-2009. Chicago, IL: National Board of Medical Examiners; 2010. https://www. nbome.org/Content/NBOME/History_of_ NBOME.pdf. Accessed June 30, 2022. 

- **23** Lee AS, Chang L, Feng E, Helf S. Reliability and validity of conversion formulas between Comprehensive Osteopathic Medical Licensing Examination of the United States Level 1 and United States Medical Licensing Examination Step 1. J Grad Med Educ. 2014;6:280–283. 

   - **38** Zhao X, Oppler S, Dunleavy D, Kroopnick M. Validity of four approaches of using repeaters’ MCAT scores in medical school admissions to predict USMLE Step 1 total scores. Acad Med. 2010;85:S64–S67. 

- **8** National Resident Matching Program, Data Release and Research Committee. Results of the 2008 NRMP Program Director Survey. Washington, DC: National Resident Matching Program; 2008. 

- **9** Chaudhry HJ, Katsufrakis PJ, Tallia AF. The USMLE Step 1 decision: An opportunity for medical education and training. JAMA. 2020;323:2017–2018. 

- **24** Sandella JM, Gimpel JR, Smith LL, Boulet JR. The use of COMLEX-USA and USMLE for residency applicant selection. J Grad Med Educ. 2016;8:358–363. 

   - **39** Bigach SD, Winkelman RD, Savakus JC, Papp KK. A novel USMLE Step 1 projection model using a single comprehensive basic science self-assessment taken during a brief intense study period. Med Sci Educ. 2021;31:67–73. 

- **25** Donnon T, Paolucci EO, Violato C. The predictive validity of the MCAT for medical school performance and medical board licensing examinations: A meta-analysis of the published research. Acad Med. 2007;82:100–106. 

   - **40** Wang L, Laird-Fick HS, Parker CJ, Solomon D. Using Markov chain model to evaluate medical students’ trajectory on progress tests and predict USMLE Step 1 scores—A retrospective cohort study in one medical school. BMC Med Educ. 2021;21:200. 

- **10** Makhoul AT, Pontell ME, Kumar NG, Drolet BC. Objective measures needed—Program directors’ perspectives on a pass/fail USMLE Step 1. N Engl J Med. 2020;382:2389–2392. 

   - **26** Callahan CA, Hojat M, Veloski J, Erdmann JB, Gonnella JS. The predictive validity of three versions of the MCAT in relation to performance in medical school, residency, and licensing examinations: A longitudinal study of 36 classes of Jefferson Medical College. Acad Med. 2010;85:980–987. 

- **11** Lewis LA. Commercial national board review programs: A case study at the Medical College of Georgia. JAMA. 1978;240:754–755. 

   - **41** Jerant A, Henderson MC, Griffin E, et al. Do admissions multiple mini-interview and traditional interview scores predict subsequent academic performance? A study of five California medical schools. Acad Med. 2019;94:388–395. 

- **12** Chen DR, Priest KC, Batten JN, Fragoso LE, Reinfeld BI, Laitman BM. Student perspectives on the “Step 1 climate” in preclinical medical education. Acad Med. 2019;94:302–304. 

- **27** Bills JL, VanHouten J, Grundy MM, Chalkley R, Dermody TS. Validity of the Medical College Admission Test for predicting MD– PhD student outcomes. Adv Heal Sci Educ. 2016;21:33–49. 

   - **42** Sesate DB, Milem JF, McIntosh KL, Bryan WP. Coupling admissions and curricular data to predict medical student outcomes. Res High Educ. 2017;58:295–312. 

- **13** Fyfield M, Henderson M, Phillips M. 25 Principles for effective instructional video design. Presented at the Annual Conference of the Australasian Society for Computers in Learning in Tertiary Education, December 2019, Singapore University of Social Sciences, Singapore. 

   - **43** Brent Stansfield R, Kreiter CD. Conditional reliability of admissions interview ratings: Extreme ratings are the most informative. Med Educ. 2007;41:32–38. 

- **28** Meoli FG, Wallace WS, Kaiser-Smith J, Shen L. Relationship of osteopathic medical licensure examinations with undergraduate admission measures and predictive value of identifying future performance in osteopathic principles and practice/osteopathic manipulative medicine courses and rotations. J Osteopath Med. 2002;102:615–620. 

   - **44** Brownfield EL, Blue AV, Powell CK, Geesey ME, Moran WP. Impact of the foundations of clinical medicine course on USMLE scores. J Gen Intern Med. 2008;23:1002–1005. 

- **14** Dunlosky J, Rawson KA, Marsh EJ, Nathan MJ, Willingham DT. Improving students’ learning with effective learning techniques: Promising directions from cognitive and educational psychology. Psychol Sci Public Interest. 2013;14:4–58. 

- **45** Torre DM, Dong T, Schreiber-Gregory D, et al. Exploring the predictors of post-clerkship USMLE Step 1 scores. Teach Learn Med. 2020;32:330–336. 

|Interest. 2013;14:4–58.|**29**Case SM, Swanson DB, Ripkey DR, Bowles<br>|USMLE Step 1 scores. Teach Learn Med.|
|---|---|---|
|**15**Tricco AC, Lillie E, Zarin W, et al. PRISMA<br>extension for scoping reviews (PRISMA-|LT, Melnick DE. Performance of the class of<br>1994 in the new era of USMLE. Acad Med.<br>|2020;32:330–336.<br> **46**Dong T, Copeland A, Gangidine M,<br>|
|ScR): Checklist and explanation. Ann Intern|1996;71:S91–S93.<br>|Schreiber-Gregory D, Ritter EM, Durning<br>|
|Med. 2018;169:467–473.|**30**van Zanten M, Boulet JR. Medical education<br>|SJ. Factors associated with surgery clerkship<br>|
|**16**Le D, Chan D, Barker BR. From patients to<br>test questions: Do clinical clerkships really<br>improve student performance on USMLE<br>Step 1? Acad Med. 2019;94:925.|in the Caribbean: A longitudinal study of<br>United States Medical Licensing Examination<br>performance, 2000-2009. Acad Med.<br>2011;86:231–238.<br>|performance and subsequent USMLE Step<br>scores. J Surg Educ. 2018;75:1200–1205.<br> **47**Tadani RA, Swanson DB, Galbraith RM. A<br>preliminary analysis of diferent approaches<br>|
|**17**Baldwin W, Bankston P, Anderson WM, et al.<br>Can students in a modifed PBL curriculum<br>exceed the national mean on USMLE Part 1?<br>Med Educ. 2002;36:791.<br>|**31**van Zanten M, Boulet JR. Medical education<br>in the Caribbean: Variability in medical<br>school programs and performance of<br>students. Acad Med. 2008;83:S33–S36.<br>|to preparing for the USMLE Step 1. Acad<br>Med. 2000;75:S40–S42.<br> **48**Burk-Rafel J, Santen SA, Purkiss J. Study<br>behaviors and USMLE Step 1 performance:<br>|
|**18**Rashid H, Coppola KM, Lebeau R. Tree<br>decades later: A scoping review of the|**32**Laatsch L. Evaluation and treatment of<br>students with difculties passing the Step<br>|Implications of a student self-directed parallel<br>curriculum. Acad Med. 2017;92:S67–S74.<br>|
|<br>literature related to the United States<br>Medical Licensing Examination. Acad Med.<br>2020;95:S114–S121.|examinations. Acad Med. 2009;84:677–683.<br> **33**Smith SR. Efect of undergraduate college<br>major on performance in medical school.<br>|**49**Seal ZA, Koek W, Sharma R. Correlation of<br>Medical College Admission Test scores and<br>self-assessment materials with the United<br>|
|**19**Wu W, Garcia K, Chandrahas S, Siddiqui|Acad Med. 1998;73:1006–1008.<br>|States Medical Licensing Examination Step 1<br>|
|<br>A, Baronia R, Ibrahim Y. Predictors of<br>performance on USMLE Step 1. Southwest<br>Respir Crit Care Chronicles. 2021;9:63–72.|**34**Reed DA, Cook DA, Beckman TJ, Levine<br>RB, Kern DE, Wright SM. Association<br>between funding and quality of published<br>|performance. Cureus. 2020;12:e7519.<br> **50**Parry S, Pachunka J, Beck Dallaghan GL.<br>Factors predictive of performance on USMLE<br>|
|<br> **20**Chick DA, Friedman HP, Young VB,|medical education research. JAMA.<br>|Step 1: Do commercial study aids improve<br>|
|Solomon D. Relationship between|2007;298:1002–1009.|scores? Med Sci Educ. 2019;29:667–672.|
|<br>COMLEX and USMLE scores among<br>osteopathic medical students who take|**35**West C, Kurz T, Smith S, Graham L. Are<br>study strategies related to medical licensing<br>|**51**Guilbault RWR, Lee SW, Lian B, Choi J.<br>Predictors of USMLE Step 1 outcomes:<br>|
|<br>both examinations. Teach Learn Med.<br>2010;22:3–7.|exam performance? Int J Med Educ.<br>2014;5:199–204.|Charting successful study habits. Med Sci<br>Educ. 2020;30:103–106.|



Academic Medicine, Vol. 98, No. 1 / January 2023 

**143** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

|**52**Cortes-Penfeld NW, Khazanchi R, Talmon|
|---|
|G. Educational and personal opportunity|
|costs of medical student preparation for the|
|United States Medical Licensing Examination|
|Step 1 exam: A single-center study. Cureus.<br>2020;12:e10938.|



- **69** Bonasso P, Lucke-Wold B, Reed Z, Bozek J, Cottrell S. Investigating the impact of preparation strategies on USMLE Step 1 performance. MedEdPublish. 2015;4:5. 

Clinical Subjects: Concurrent and predictive evidence. J Grad Med Educ. 2019;11:521–526. 

      - **85** Li F, Kalinowski KE, Song H, Bates BP. Relationships between the Comprehensive Osteopathic Medical Achievement Test (COMAT) subject examinations and the COMLEX-USA Level 2-Cognitive Evaluation. J Am Osteopath Assoc. 2014;114:714–721. 

   - **70** Deng F, Gluckstein JA, Larsen DP. Studentdirected retrieval practice is a predictor of medical licensing examination performance. Perspect Med Educ. 2015;4:308–313. 

- **53** Alcamo AM, Davids AR, Way DP, Lynn DJ, Vandre DD. The impact of a peer-designed and led USMLE Step 1 review course: Improvement in preparation and scores. Acad Med. 2010;85:S45–S48. 

- **71** Kumar AD, Shah MK, Maley JH, Evron J, Gyftopoulos A, Miller C. Preparing to take the USMLE Step 1: A survey on medical students ’ self-reported study habits. Postgrad Med J. 2015;91:257–261. 

   - **86** Kumar K, Nguyen H, Indurkhya A. Relationship between pathology curricular approaches and performance in the United States Medical Licensing Examination (USMLE), Step 1: A national cross-sectional study. Hum Pathol. 2003;34:417–422. 

- **54** Strowd RE, Beard HR, Gorney B, Russell GB, Lambros A. The impact of process-oriented preparation on high-stakes testing in medical school. Med Sci Educ. 2013;23:588–594. 

   - **72** Giordano C, Hutchinson D, Peppler R. A predictive model for USMLE Step 1 scores. Cureus. 2016;8:e769. 

- **55** Schwartz LF, Lineberry M, Park YS, Kamin CS, Hyderi AA. Development and evaluation of a student-initiated test preparation program for the USMLE Step 1 examination. Teach Learn Med. 2018;30:193–201. 

- **73** Green M, Angoff N, Encandela J. Test anxiety and United States Medical Licensing Examination scores. Clin Teach. 2016;13:142–146. 

   - **87** Kumar K, Indurkhya A. Changes in pathology instruction and student performance on the United States Medical Licensing Examination Step 1, 1995-2000: A nationwide 6-year longitudinal study. Hum Pathol. 2004;35:1435–1439. 

- **56** Dadafarin S, Petersen KH. Randomized trial of a year-long USMLE Step 1 preparation near-peer teaching program. Med Sci Educ. 2021;31:1065–1071. 

- **74** Tanenbaum EJ, Johnson JH, Jordan E, et al. An effective evidence-based student run near-peer support group for the USMLE Step 1 exam. Med Sci Educ. 2016;26:691–699. 

- **88** Holtman MC, Swanson DB, Ripkey DR, Case SM. Using basic science subject tests to identify students at risk for failing Step 1. Acad Med. 2001;76:S48–S51. 

|**57**Pohl CA, Robeson MR, Hojat M, Veloski JJ.|**75**Jurich D, Santen SA, Paniagua M, et al.<br>|Case SM. Using basic science subject tests|
|---|---|---|
|Sooner or later? USMLE Step 1 performance<br>and test administration date at the end of the|Efects of moving the United States Medical<br>Licensing Examination Step 1 afer core|to identify students at risk for failing Step 1.<br>Acad Med. 2001;76:S48–S51.|
|second year. Acad Med. 2002;77:S17–S19.<br>|clerkships on Step 2 Clinical Knowledge<br>|**89**Morrison CA, Ross LP, Fogle T, Butler A,<br>|
|**58**Werner LS, Bull BS. Te efect of three|performance. Acad Med. 2020;95:111–121.|Miller J, Dillon GF. Relationship between|
|commercial coaching courses on Step<br>|**76**Ripkey DR, Swanson DB, Case SM. School-<br>|performance on the NBME Comprehensive<br>|
|One USMLE performance. Med Educ.|to-school diferences in Step 1 performance<br>|Basic Sciences Self-Assessment and USMLE<br>|
|2003;37:527–531.<br>|as a function of curriculum type and<br>|Step 1 for U.S. and Canadian medical school<br>|
|**59**Fagin AP, Engelstad ME. Te efect of oral|use of Step 1 in promotion/graduation|students. Acad Med. 2010;85:S98–101.|
|<br>and maxillofacial surgery curriculum on<br>|requirements. Acad Med. 1998;73:S16–S18.<br>|**90**Hecker K, Violato C. Medical school<br>|
|United States Medical Licensing Examination|**77**Cuddy MM, Swanson DB, Clauser BE. A|curricula: Do curricular approaches afect|
|Step 1 performance. J Oral Maxillofac Surg.|multilevel analysis of examinee gender and<br>|competence in medicine? Fam Med.|
|2019;77:898–903.|USMLE Step 1 performance. Acad Med.|2009;41:420–426.|
|**60**Jackson F, Duane E, Harmon R, Kollar<br>|2008;83:S58–S62.<br>|**91**Julian ER. Validity of the Medical College<br>|
|RA, Rainville NM, Smith RM. Resources<br>|**78**Cuddy MM, Swanson DB, Dillon GF,<br>|Admission Test for predicting medical school<br>|
|that improve medical board licensing<br>examination performance. Cureus.<br>|Holtman MC, Clauser BE. A multilevel<br>analysis of the relationships between selected<br>|performance. Acad Med. 2005;80:910–917.<br> **92**Case SM, Ripkey DR, Swanson DB. Te<br>|
|2019;11:e5927.|examinee characteristics and United States|efects of psychiatry clerkship timing and|
|**61**Vora A, Maltezos N, Alfonzo L, Hernandez<br>|Medical Licensing Examination Step 2<br>|<br>length on measures of performance. Acad<br>|
|N, Calix E, Fernandez MI. Predictors of|Clinical Knowledge performance: Revisiting<br>|Med. 1997;72:S34–S36.<br>|
|scoring at least 600 on COMLEX-USA Level<br>|old fndings and asking new questions. Acad<br>|**93**Kim S, George P. Te relationship between<br>|
|1: Successful preparation strategies. J Am|Med. 2006;81:S103–S107.|preclinical grading and USMLE scores in|
|Osteopath Assoc. 2013;113:164–173.|**79**Hecker K, Violato C. How much do<br>|US allopathic medical schools. Fam Med.|
|**62**Compton S, Schwartz L, Henderson W, Wyte|diferences in medical schools infuence|2018;50:128–131.|
|C. Study month or vacation? Preparing for<br>|<br>student performance? A longitudinal study<br>|**94**Lee MW, Johnson TR, Kibble J. Development<br>|
|USMLE Step 2. Acad Med. 2002;77:733.<br>|employing hierarchical linear modeling.<br>|of statistical models to predict medical<br>|
|**63**Pohl CA, Robeson MR, Veloski J. USMLE<br>|Teach Learn Med. 2008;20:104–113.<br>|student performance on the USMLE Step 1 as<br>|
|Step 2 performance and test administration|**80**Morrison CA, Ross LP, Sample L, Butler A.|a catalyst for deployment of student services.|
|date in the fourth year of medical school.|Relationship between performance on the|Med Sci Educ. 2017;27:663–671.|
|Acad Med. 2004;79:S79–S81.|NBME Comprehensive Clinical Science|**95**McGaghie WC, Downing SM, Kubilius|
|**64**Jurich D, Daniel M, Paniagua M, et al.|Self-Assessment and USMLE Step 2 Clinical|R. What is the impact of commercial|
|Moving the United States Medical Licensing<br>|Knowledge for USMGs and IMGs. Teach|test preparation courses on medical|
|Examination Step 1 afer core clerkships: An<br>|Learn Med. 2014;26:373–378.<br>|examination performance? Teach Learn Med.|
|outcomes analysis. Acad Med. 2019;94:371–377.|**81**Morrison C, Barone M, Baker G, Ross L, Pak|2004;16:202–211.|
|**65**Fetter M Robbs R Cianciolo AT Clerkship|S Investigating the relationship between a|**96**Tackett S Jearaju M Moore J et al Student|
|,  ,  .<br>curriculum design and USMLE Step 2<br>|.<br>clinical science composite score and USMLE<br>|, y ,  ,  .<br>well-being during dedicated preparation for<br>|
|performance: Exploring the impact of self-<br>regulated exam preparation. Med Sci Educ.|Step 2 Clinical Knowledge and Step 3<br>performance. Med Sci Educ. 2020;30:263–269.|USMLE Step 1 and COMLEX Level 1 exams.<br>BMC Med Educ. 2022;22:16.|
|<br>2019;29:265–276.|<br> **82**Baker HH, Foster RW, Bates BP, et al.|**97**Swan Sein A, Daniel M, Fleming A, et al.|
|**66**Banos JH, Pepin ME, Van Wagoner N.|Relationship between academic achievement|Identifying and supporting students to|
|Class-wide access to a commercial Step 1|and COMLEX-USA Level 1 performance:|prevent USMLE Step 1 failures when testing|
|question bank during preclinical organ-|A multisite study. J Am Osteopath Assoc.|follows clerkships: Insights from 9 schools.|
|based modules: A pilot project. Acad Med.|2000;100:238–242.<br>|Acad Med. 2020;95:1338–1345.<br>|
|2018;93:486–490.|**83**Evans P, Goodson LB, Schofman|**98**Huwendiek S, Jung D, Schirlo C, et al. Te|
|**67**Richards BF, Cariaga-Lo L. Curriculum type|<br>SI. Relationship between academic|<br>introduction of a standardised national|
|and sophomore students’ preparation time<br>|achievement and student performance on<br>|licensing exam as a driver of change<br>|
|for the USMLE Step 1 examination. Eval<br>|the Comprehensive Osteopathic Medical<br>|in medical education: A qualitative<br>|
|Health Prof. 1994;17:329–343.<br>’|Licensing Examination-USA Level 2. J Am<br>|study from Switzerland. Med Teach.<br>|
|**68**Zhang C, Rauchwarger A, Toth C, OConnell|Osteopath Assoc. 2003;103:331–336.|2020;42:1163–1170.|
|<br>M. Student USMLE Step 1 preparation and<br>performance. Adv Health Sci Educ Teory|<br> **84**Hudson KM, Tsai TH, Finch C, Dickerman<br>JL, Liu S, Shen L. A validity study of|**99**Oakley B, Rogowsky B, Sejnowski T.<br>Uncommon Sense Teaching. New York, NY:|
|<br>Pract. 2004;9:291–297.|<br>COMLEX-USA Level 2-CE and COMAT|<br>Penguin Random House LLC; 2021.|



Academic Medicine, Vol. 98, No. 1 / January 2023 

**144** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

Appendix 1 **Characteristics of 29 Studies of Preparation Strategies for the USMLE Step 1, USMLE Step 2 Clinical Knowledge, and COMLEX Level 1 Exams Included in a Scoping Review of the Literature Through April 30, 2021, on the Factors Leading to Successful Performance on U.S. National Licensure Exams** 

|**First autho**<br>**year**|**r,**<br>**Exam**|**(s)**<br>**No.**<br>**cohorts**<br>**schools**|**,**<br>**Sample**<br>**size**|**Study summary**|**Key fndings**|**Predictors**|
|---|---|---|---|---|---|---|
|Thadani,<br>2000<sup>47</sup>|S1|1,NR|1,217/<br>3,958 (31%)|Survey of U.S. and<br>Canadian frst-time S1<br>takers to determine<br>what preparation<br>strategies were<br>associated with higher<br>scores|Unadjusted analyses showed that using the<br>USMLE instruction booklet, textbooks, course<br>syllabi, commercial preparation books, and<br>not participating in a commercial course were<br>signifcantly associated with higher S1 scores.<br>Using lecture notes, note-taking services,<br>school USMLE materials, and studying in<br>groups were not signifcantly associated with<br>higher S1 scores. Regression models grouping<br>variables into categories found MCAT score<br>and science GPA accounted for most variance;<br>after adjustment, only textbook use was<br>signifcantly associated with higher S1 scores.|Comm<br>(RB, Prog), St,<br>Other<br>Downloaded from|
|Werner,<br>2003<sup>58</sup>|S1|3,1|468|Retrospective study<br>of school data for<br>participation in a 3-<br>to 4-week live<br>commercial course|<br>Adjusting for NBME CBSE score, regressions<br>showed no difference between commercial<br>course participants and nonparticipants.|Comm (Prog)<br>academic.ou|
|Zhang,<br>2004<sup>68</sup>|S1|1,1|100/<br>148 (68%)|Surveys about<br>participation in a<br>3-week live commercial<br>course|Adjusting for MS2 overall GPA in ANCOVA<br>analyses, there was no difference between<br>commercial course participants and<br>nonparticipants.|Comm (Prog)<br>p.com/acad|
|Bonasso,<br>2015<sup>69</sup>|S1|2,1|164/<br>165 (99%)|Surveys about the timing<br>of S1 and use of 5<br>commercial preparation<br>resources (2 QBs, 2 RBs,<br>1 program)|<br>Unadjusted analyses showed the use of 1 QB<br>and class rank were signifcantly associated<br>with higher S1 scores. The use of 4 other<br>commercial resources and the time interval for<br>taking S1 were not signifcantly associated with<br>higher S1 scores.|<br>Comm (QB, RB,<br>Prog), St<br>emicmedicine/ar|
|Deng,<br>2015<sup>70</sup>|S1|1,1|72/<br>111 (65%)|Surveys about<br>preparation resources<br>used and short items<br>assessing burnout,<br>depression, and test<br>anxiety|Multilinear regressions showed MCAT total<br>score, MS2 honors grades, number of boards-<br>style multiple-choice questions (QBs, SAs),<br>number of FCs from 1 platform, and lower<br>test anxiety were signifcantly associated with<br>higher S1 scores. Burnout, depression, and<br>number of FCs from a second platform were<br>not signifcantly associated with higher S1<br>scores.|Comm<br>(QB, SA, FCs)<br>ticle/98/1/136/8344792|
|Kumar,<br>2015<sup>71</sup>|S1|3,1|256/<br>475 (54%)|Surveys about<br>preparation factors|Unadjusted analyses showed a greater number<br>of practice questions completed and fewer<br>days in dedicated preparation were signifcantly<br>associated with higher S1 scores. Average<br>number of hours per day studying, percentage<br>of study time spent on practice questions, and<br>time spent studying in a group setting were<br>not signifcantly associated with higher S1<br>scores.|<br> <br>Comm (QB), St<br>by guest on 01 Septem|
|Giordano,<br>2016<sup>72</sup>|S1|2,1|81/<br>213 (38%)|Surveys about<br>preparation time,<br>perception of<br>preparedness, resources<br>used, percent correct on<br>QBs, need for fnancial<br>aid, and straight A<br>grades in frst year|Excluding non-signifcant variables from<br>the bivariate analyses (age, gender, MCAT<br>total score, days in dedicated preparation,<br>perception of preparedness), multilinear<br>regressions showed having straight As, lack of<br>fnancial aid, QB percent correct, and NBME<br>CBSE score were signifcantly associated with<br>higher S1 scores.|Comm<br>(QB, SA), St<br>ber 2026|
|Green,<br>2016<sup>73</sup>|S1|1,1|93/<br>101 (92%)|<br>Surveys about<br>participation in a 6-day<br>commercial course and<br>test anxiety|<br>Multilinear regressions showed MCAT total<br>score and lower Westside Test Anxiety scale<br>ratings were signifcantly associated with<br>higher S1 scores. Participation in a commercial<br>course was not signifcantly associated with<br>higher S1 scores.<br>_(A_|Comm (Prog)<br>_ppendix continues)_|



Academic Medicine, Vol. 98, No. 1 / January 2023 

**145** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

## Appendix 1 

(Continued) 

|**First author,**<br>**year**|**Exam**|**(s)**<br>**No.**<br>**cohorts**<br>**schools**|**,**<br>**Sample**<br>**size**|**Study summary**|**Key fndings**|**Predictors**|
|---|---|---|---|---|---|---|
|Tanenbaum,<br>2016<sup>74</sup>|S1|3,1|302/<br>495 (61%)|Surveys about study<br>habits, time, resources|Excluding non-signifcant variables from the<br>bivariate analyses (group study, following<br>near-peer study plan), multilinear regressions<br>showed preclinical GPA, starting study more<br>than 6 months before S1, and doing more<br>than 4,000 combined QB questions were<br>signifcantly associated with higher S1 scores.<br>MCAT total score and S1 preparation resource<br>use for study (vs class resources) were not<br>signifcantly associated with higher S1 scores.<br>|Comm (QB),<br>Sch, St, Other|
|Burk-Rafel,<br>2017<sup>48</sup>|S1|2,1|274/<br>332 (83%)|Surveys about<br>preparation study habits,<br>goals, resource use|<br>Excluding nonsignifcant variables from the<br>bivariate analyses (URiM status, study hours<br>per day, days in dedicated preparation),<br>multilinear regressions showed MCAT total<br>score, preclinical grades, S1 score goal, starting<br>study before dedicated preparation period,<br>number of RB passes, and number of unique<br>practice questions (QBs, self-assessments) were<br>signifcantly associated with higher S1 scores.<br>Sex and number of repeat questions were not<br>signifcantly associated with higher S1 scores.|<br> <br>Comm (QB, SA,<br>RB), St|
|Baños,<br>2018<sup>66</sup>|S1|1,1|181|Retrospective study of<br>data from a commercial<br>QB that was provided to<br>all students for 18 months|<br>Multilinear regressions showed MCAT mean<br>score and number of QB items attempted were<br>associated with higher S1 scores. The beneft<br>appeared greater with lower MCAT scores.|<br>Comm (QB)|
|Seal,<br>2020<sup>49</sup>|S1|NR,NR|399|Retrospective study of<br>data from an anonymous<br>survey on Reddit on<br>practice assessments|Unadjusted analyses showed correlations<br>between each practice assessment score (11<br>NBME CBSSA forms, 2 QB SAs, QB percent<br>correct) and higher S1 scores for students<br>who completed more than 5 practice exams<br>compared to those who completed 5 or fewer<br>practice exams.|Comm (QB, SA)|
|Parry,<br>2019<sup>50</sup>|S1|2,1|170/<br>243 (70%)|Surveys about<br>preparation time and<br>resources|Excluding nonsignifcant variables from<br>the bivariate analyses (RB passes, number<br>of practice tests attempted), multilinear<br>regressions showed preclinical grades and<br>number of times a QB was completed were<br>associated with higher S1 scores. Unadjusted<br>analyses showed greater number of days in<br>dedicated preparation was associated with<br>lower S1 scores.|Comm (QB, SA,<br>RB), St|
|Guilbault,<br>2020<sup>51</sup>|S1|1,1|47/<br>103 (46%)|Surveys about grades,<br>practice test scores,<br>practice items, time<br>studying, and preparation<br>duration|<br>Excluding nonsignifcant variables in the<br>bivariate analyses (percent time doing practice<br>items, hours per day studying), multilinear<br>regressions showed overall preclinical grades<br>and NBME CBSSA scores were signifcantly<br>associated with higher S1 scores. Number<br>of practice items (self-report) and months in<br>dedicated preparation were not signifcantly<br>associated with higher S1 scores.|Comm (QB,<br>SA), St|
|Cortes-Penfeld,<br>2020<sup>52</sup>|S1|1,1|211/<br>388 (54%)|Surveys about<br>preparation time,<br>expenditure, use of<br>14 resources; skipping<br>curricular/extracurricular<br>activities to study; well-<br>being|Unadjusted analyses showed participating<br>in community service, operating a motor<br>vehicle while fatigued, delaying medical care<br>or life events, relationship diffculties, anxiety,<br>depression, or burnout were signifcantly<br>associated with lower S1 scores. Hours per<br>week studying outside of class during the<br>preclinical curriculum; expenditure; resource<br>use; and foregoing research, electives,<br>leadership, or advocacy activities were not<br>signifcantly associated with lower S1 scores.<br>(_A_|Comm (QB, SA,<br>RB), St, Other<br>_ppendix continues_)|



Academic Medicine, Vol. 98, No. 1 / January 2023 

**146** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

## Appendix 1 

(Continued) 

|**First author**<br>**year**|**,**<br>**Exam(s**|**)**<br>**No.**<br>**cohorts**<br>**schools**|**,**<br>**Sample**<br>**size**|**Study summary**|**Key fndings**|**Predictors**|
|---|---|---|---|---|---|---|
|Walters,<br>1999<sup>37</sup>|S1|4,1|53|Retrospective study of<br>school data on taking<br>a 6-week school-based<br>voluntary faculty-led<br>preparation program<br>after failing S1|Unadjusted analyses showed higher pass<br>rates on retaking S1 for course participants<br>compared to those completing an independent<br>study.|<br>Sch|
|Alcamo,<br>2010<sup>53</sup>|S1|1,1|198|Retrospective study<br>of school data on<br>participants attending<br>the majority of 19 weekly<br>sessions in a school-based<br>peer-designed and -led<br>program|Adjusting for MCAT score in ANCOVA<br>analyses, participants had higher S1 scores.|Sch|
|Strowd,<br>2013<sup>54</sup>|S1|5,1|557|Retrospective study of<br>school data comparing 3<br>cohorts who had a<br>school-based peer-<br>designed and -led<br>program to the 2<br>previous cohorts|Unadjusted analyses demonstrated no<br>signifcant difference in S1 scores overall post-<br>vs preprogram implementation. Signifcant<br>post- vs preprogram differences were reported<br>for those in the middle half of MCAT scores<br>but not in other subgroup comparisons (sex,<br>race, age).|<br>Sch|
|Schwartz,<br>2018<sup>55</sup>|S1|5,1|830|Retrospective study of<br>school data comparing 2<br>cohorts with a school-<br>based peer-designed and<br>-led program to 3 previous<br>cohorts|<br>Multilinear regressions found program<br>participation, younger age, male sex, MCAT<br>total score, and undergraduate GPA were<br>associated with higher S1 scores.|Sch|
|Dadafarin,<br>2021<sup>56</sup>|S1|2,1|120|Randomized controlled<br>trial placing students into<br>a school-based near-peer<br>program or<br>no intervention|Adjusting for MCAT score in ANCOVA<br>analyses, there was no difference in S1<br>scores between course participants and<br>nonparticipants.|Sch|
|Richards,<br>1994<sup>67</sup>|S1|1,1|69/<br>102 (68%)|Surveys about study<br>time for S1|Adjusting for MCAT score, practice test scores,<br>and in-class exams in MANCOVA analyses,<br>there was no signifcant association between<br>S1 scores and total time studying.|<br>St|
|Pohl,<br>2002<sup>57</sup>|S1|3,1|627|Retrospective study of<br>school data (scores)<br>divided into 1-week time<br>periods depending on<br>exam date|Adjusting for MCAT science scores and<br>preclinical test scores in ANCOVA analyses,<br>there was no association between time exam<br>taken and S1 scores.|St|
|Fagin,<br>2019<sup>59</sup>|S1|11,32|32/46 (70%)<br>program<br>directors,<br>806 residents|Surveys of U.S. oral and<br>maxillofacial surgery MD<br>program directors on<br>residents’ preparation<br>habits over a 10-year<br>period|Unadjusted analyses showed more weeks<br>given to dedicated preparation was<br>signifcantly associated with higher S1 scores.<br>Curriculum sequence and having some<br>medical school before S1 were not signifcantly<br>associated with higher S1 scores.|<br>St, Other|
|Jackson,<br>2019<sup>60</sup>|S1, C1|1,1|102/<br>171 (60%)|Surveys about resources (3<br>USMLE QBs, 3<br>COMLEX QBs, 6 video<br>resources), practice<br>tests (6 NBME CBSSA<br>forms, 2 NBOME<br>COMSAE forms) for<br>both S1 and C1|<br>Unadjusted analyses showed number of<br>completed items in USMLE QBs and 8 SA<br>form scores correlated with higher S1 scores,<br>but COMLEX QB use, QB in timed mode, and<br>use of video resources did not correlate with<br>higher S1 scores. Number of completed items<br>in USMLE QBs, 8 SA form scores, and QB in<br>timed mode correlated with higher C1 scores,<br>but use of video resources did not correlate<br>with higher C1 scores. Number of completed<br>items in COMLEX QBs correlated with lower<br>C1 scores.<br>(_A_|Comm (QB, SA,<br>Video)<br>_ppendix continues_)|



Academic Medicine, Vol. 98, No. 1 / January 2023 

**147** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

Review 

## Appendix 1 

(Continued) 

|**First author**<br>**year**|**,**<br>**Exam(**|**s)**<br>**No.**<br>**cohort**<br>**school**|**s,**<br>**s**<br>**Sample**<br>**size**|**Study summary**|**Key fndings**|**Predictors**|
|---|---|---|---|---|---|---|
|Vora,<br>2013<sup>61</sup>|C1|1,1|113/<br>152 (74%)|Surveys comparing<br>demographics,<br>preparation time, and<br>resources for students<br>scoring over 600 on C1|Excluding variables_P_> .20 in the bivariate<br>analyses (RB use, commercial lecture videos,<br>class notes, perceived performance, studying<br>alone or in groups), multivariate logistic<br>regressions showed preclinical GPA, MCAT<br>total score, earlier start time, and not rating<br>NBOME COMSAE as most helpful were<br>signifcantly associated with scoring over 600<br>on C1. Sex, race, and rating a QB as most<br>helpful were not signifcantly associated with<br>scoring over 600 on C1.|Comm (QB, SA,<br>Video, RB), St,<br>Other|
|Compton,<br>2002<sup>62</sup>|S2|2,1|167|Retrospective study of<br>school data comparing<br>S2 scores for those who<br>took at least 1 study<br>month prior to S2 and<br>those who did not|Adjusting for S1 score, multilinear regressions<br>found a study month rather than clerkships<br>before S2 was not associated with higher S2<br>scores.|St|
|Pohl,<br>2004<sup>63</sup>|S2|5,1|846|Retrospective study of<br>school data examining<br>relationships between<br>taking S2 during 1 of 10<br>intervals and S2 scores|Excluding nonsignifcant variables from the<br>bivariate analyses (grades in family medicine,<br>psychiatry, and surgery), linear regression was<br>used to predict S2 scores using S1 scores;<br>gender; and grades in medicine, pediatrics, and<br>obstetrics–gynecology and was compared to<br>actual S2 scores by time period, fnding earlier<br>exam timing was associated with higher S2<br>scores.|<br>St|
|Jurich,<br>2020<sup>75</sup>|S2|6,4|3,199|Retrospective study of<br>school data comparing S2<br>scores for 3 cohorts for<br>which S1 was moved<br>after clerkships to 3<br>cohorts before the change|Unadjusted analyses showed no difference in<br>S2 scores after moving S1 after core clerkships<br>and lower scores with a greater number of<br>days between the last core clerkship and S2.|St|
|Fetter,<br>2019<sup>65</sup>|S2|1,1|40/<br>72 (56%)|Surveys including<br>instruments on stress and<br>learning motivation|Unadjusted analyses showed signifcant<br>correlations between 2 of 3 subscales<br>on the Motivated Strategies for Learning<br>Questionnaire (MSLQ) (organization and<br>time/study environmental management)<br>and S2 scores. The MSLQ subscale of effort<br>regulation and the Medical Student Stressor<br>Questionnaire’s 2 subscales were not<br>signifcantly associated with S2 scores.|Other|



Abbreviations: ANCOVA, analysis of covariance; C1, COMLEX Level 1; CBSSA, Comprehensive Basic Science Self-Assessment; CBSE, Comprehensive Basic Science Examination; COMLEX, Comprehensive Osteopathic Medical Licensing Examination; Comm, commercial resource; COMSAE, Comprehensive Osteopathic Medical Self-Assessment Examination; FC, flashcard; GPA, grade point average; MANCOVA, multivariate analysis of covariance; MCAT, Medical College Admission Test; MS2, medical school second year; NBME, National Board of Medical Examiners; NBOME, National Board of Osteopathic Medical Examiners; NR, not reported; Prog, commercial program; QB, question bank; RB, review book; S1, USMLE Step 1; S2, USMLE Step 2 Clinical Knowledge; SA, self-assessment; Sch, school-based program; St, study strategy; URiM, underrepresented in medicine; USMLE, United States Medical Licensing Examination. 

Academic Medicine, Vol. 98, No. 1 / January 2023 

**148** 

Copyright © by the Association of American Medical Colleges. Unauthorized reproduction of this article is prohibited. 

