_Higher Education_ 32: 347-364, 1996. 

347 

~) 1996 _Kluwer Academic Publishers. Printed in the Netherlands._ 

# **Enhancing teaching through constructive alignment** 

### JOHN BIGGS 

_Department of Educational Psychology, Measurement, and Educational Technology, University of Sydney, NSW 2006, Australia_ 

**Abstract.** Two lines of thinking are becoming increasingly important in higher educational practice. The first derives from constructivist learning theory, and the second from the instructional design literature. Constructivism comprises a family of theories but all have in common the centrality of the learner's activities in creating meaning. These and related ideas have important implications for teaching and assessment. Instructional designers for their part have emphasised alignment between the objectives of a course or unit and the targets for assessing student performance. "Constructive alignment" represents a marriage of the two thrusts, constructivism being used as a framework to guide decision-making at all stages in instructional design: in deriving curriculum objectives in terms of performances that represent a suitably high cognitive level, in deciding teaching/learning activities judged to elicit those performances, and to assess and summatively report student performance. The "performances of understanding" nominated in the objectives are thus used to systematically align the teaching methods and the assessment. The process is illustrated with reference to a professional development unit in educational psychology for teachers, but the model may be generalized to most units or programs in higher education. 

# **Thinking about teaching and learning** 

Teachers generally enact their teaching decisions in line with some kind of explicit or, more usually, implicit theory of teaching and learning (Argyris 1976, Ramsden 1992). Argyris (1976) distinguishes between espoused theories, that are held to be those underlying professional practice, and theoriesin-use, that guide practice in the event; professionalism requires the espoused theory to be the theory-in-use. 

Espoused theories as they apply to higher education are broad, encompassing not only theories of teaching and learning, but also theories of the nature of knowledge. Two broad theoretical traditions can be distinguished. The first, _objectivist,_ tradition is based on a dualism between knower and known; knowledge exists independently of the knower, and understanding is coming to know that which already exists (Duffy 1992, Marton in press). Knowledge is seen as decontextualised, so that it can be learned, tested, and applied more or less independently of particular contexts (Brown, Collins & Duguid 1989). Teaching is a matter of transmitting this knowledge, learning of receiving it accurately, storing it, and using it appropriately. This view comprised the 

348 

espoused theory of teaching for many years, and one when looks at much current practice, it is still the dominant theory-in-use. Objectivistic theories, with their links with positivism, are also greatly concerned with quantitative measurement (Cole 1990), a concern that leads to assessment policies and practices that often distort the quality of teaching and learning, and do violence to assumptions about the nature of knowledge (Biggs 1995, 1996a, 1996b, Frederiksen & Collins, 1989; see also below). 

The second tradition rejects dualism, claiming rather that meaning is created by the learner, not imposed by reality or transmitted by direct instruction. This tradition has two streams: _constructivism_ (Duffy & Jonassen 1992, Steffe & Gale 1995), and _phenomenography_ (Marton 1981, in press; Marton & Booth, in press). Constructivism and phenomenography are different in many important respects, but for present purposes they are similar in that both see learning in qualitative not quantitative terms (Cole 1990), and both see the learner as central in the creation of meaning, not the teacher, as the transmitter of knowledge. Phenomenography has had important influences on the improvement of tertiary teaching, but it is conceptually isolated from other developments. Constructivism has a long history in cognitive psychology, and is rapidly becoming the dominant espoused theory in education; it remains, however, to see it as a common theory-in-use in higher education. In this paper, I concentrate on the implications of constructivism for teaching. 

Steffe and Gale (1995) refer to six different schools of constructivism, including cognitive, social constructionism, and postmodemism, each with different implications for educational practice. Nuthall (in press) brings some order to bear by suggesting that cognitive constructivism refers to what goes on in individual minds, with socio-cultural and linguistic versions of constructivism referring more to the contexts and ways in which minds construct knowledge, which is the view taken here. All of these are to be distinguished from naive constructivism, which confuses a theory of learning with a way of classifying teaching methods ("groupwork leads to constructive learning, but lecturing only involves transmission"). 

But whatever particular constructivist theories may variously emphasize, a consensus would be that learners arrive at meaning by actively selecting, and cumulatively constructing, their own knowledge, through both individual and social activity. The learner brings an accumulation of assumptions, motives, intentions, and previous knowledge that envelopes every teaching/learning situation and determines the course and quality of the learning that may take place. The teacher may ignore or use this learner-structured framework, but the centrality of the learner is given. Shuell's deceptively mild expression of this perspective belies its radicalism and its profundity: 

349 

If students are to learn desired outcomes in a reasonably effective manner, then the teacher's fundamental task is to get students to engage in learning activities that are likely to result in their achieving those outcomes ...It is helpful to remember that what the student does is actually more important in determining what is learned than what the teacher does. (Shuell 1986: 429) 

In this paper, I suggest a framework that translates some important features of constructivism into classroom decisions on teaching and assessment. 

## **Constructivism and instructional design** 

There have been many valuable applications of constructivism, particularly to science and math teaching (e.g. Cobb 1994, Driver & Oldham 1986, Driver, Asoko, Leach, Mortimer & Scott 1994, Scardamalia, Bereiter & Lamon 1994, West & Pines 1985), but there have been few attempts to provide a framework that would generalise beyond the contexts or topics for which they were designed. One needs to be careful about this as a prescriptive "constructive method" is contrary to the principles of constructivism. What is involved here 

is not a particular method but an attitude towards teaching which implies a focal awareness of the learner and the learner's world.., each teacher has to tackle the principles and appropriate them within the context of his or her own teaching. (Marton & Booth, in press) 

But how is the teacher to move from a "focal awareness ... of the learner's world", and appropriating principles, to _doing things differently?_ This is the familiar hiatus between espoused theory and theory-in-use. There is currently much concern about actualising the principles of constructivism in a nonprescriptive way. Duffy and Jonassen (1992) claim to be the first to address the link between constructive learning theory and instructional design (ID) (Note 2), but in the event the contributions in that publication tend to be meta-level, exploring the extent to which ID and different versions of constructivism may or may not share common assumptions. The contributors to Steffe and Gale (1995) report specific applications of this or that version of constructivism, which Wood (1995) attempts to bring together in an unexceptionable list of what teachers should do. They should: 

- �9 provide instructional situations that elicit subject appropriate activities 

- �9 view students' conceptions from their (the students') perspectives 

- �9 see "errors" as reflecting the (their) current level of development 

- �9 recognise that substantive learning occurs in periods of conflict, surprise, over periods of time, and through social interaction. 

350 

And so they should, but there is still a large step in putting this to use, in context. 

_Instruction as an internally aligned system_ 

Teaching forms a complex _system_ embracing, at the classroom level, teacher, students, the teaching context, student learning activities, and the outcome; that classroom system is then nested within the larger institutional system (Biggs 1993). In a system, the components interact with each other, working towards a stable equilibrium (von Bertallanffy 1968). Thus, if the set assessment tasks address lower cognitive level activities than those nominated in the curriculum objectives, equilibrium will be achieved at a lower level; the system will be driven by backwash from testing, not by the curriculum (Frederiksen & Collins 1989). Attempts to enhance teaching need to address the system as a whole, not simply add "good" components, such as a new curriculum or methods. 

In designing an instructional system that supports the sort of outcomes the curriculum nominates, Cohen's (1987) idea of "instructional alignment" is useful; when curriculum and assessment methods are aligned, the results of instruction are massively improved; effect sizes based on achievement tests have been reported up to four times greater than in non-aligned instruction (Cohen 1987). Mastery learning is a particularly interesting example. While mastery learning produces positive results when dealing with narrow, quantitatively defined performances, there is no evidence that mastery learning is of value to those interested in achieving broader outcomes (Slavin 1990). Rather, the evidence is that students who are oriented towards deep learning perform badly under mastery learning (Lai & Biggs 1994), because the system supports narrow, low cognitive level goals. The crucial question is: Will the benefits of alignment be so marked when the system is aligned to high cognitive level goals? 

The starting point is to define teaching objectives at a high cognitive level. 

### **From aims to objectives: The descent from rhetoric** 

Tertiary teachers almost universally espouse high level aims for the courses they teach (Entwistle & Percy 1974). However, generalities such as "To think like a mathematician", or "To become a student-centred teacher, sensitive to individual student's needs", do not imply any particular teaching _decisions,_ which leaves other factors, such as student numbers, or administrative convenience, to determine teaching and assessment methods. The mass lecture, and formal examinations, thus continue as the default modes. 

351 

All teachers say they "teach for understanding", but few do in any sustainable way (Perkins & Blythe 1993). One reason is that they do not know how to descend from the rhetoric of their aims to the specific _objebtives_ of a given course or unit (the term "unit" is used henceforward to describe a semesterlength, free-standing component in a program, the summative assessments of which mark student progress through the program). To do so, they need a framework of some kind to help them operationalise what "understanding" might mean in their particular case. 

Many studies point to the hierarchical nature of understanding. The hierarchies of conceptions produced by phenomenographic research (Marton 1981) represent topic by topic descriptions ranging from misunderstanding to articulated understandings of a high order. Entwistle and Entwistle (1992) refer to the "forms of understanding" constructed by students when studying for their examinations, most forms depending on the framework created in the context of the expected mode of assessment. Unger (1993), in asking high school students what it was like to _"really"_ understand something, found a general hierarchy of understanding, ranging from "understanding by remembering" to "performing in novel situations", the latter a form of understanding not reported as occurring in school contexts. 

The Harvard Project Zero team (Gardner 1993, Perkins & Blythe 1993, Unger 1993) focus on the _performative_ aspect of understanding; that if you understand something properly you _act differently_ in contexts involving the content understood, particularly unfamilar contexts. Such "performances of understanding", as they term them, require students to interact thoughtfully with a novel task, to reflect on appropriate feedback, to search to see how they can improve. These performances are not required in most tasks presented in school or even in university. If the course objectives did require such high level understandings, teaching and assessment tasks would need to address them on the principle of alignment, as the performance assessment literature emphasises (e.g. Archbald & Newman 1988, Biggs 1995, Moss 1992). 

Biggs and Collis (1982) describe the growth of competence in terms of, first, a quantitative accrual of the components of a task, which then become qualitatively restructured. SOLO, which stands for the Structure of the Observed Learning Outcome, provides a systematic way of describing how a learner's performance grows in complexity when mastering many academic tasks. Five levels may be distinguished: 

_1. Prestructural._ The task is not attacked appropriately; the student hasn't understood the point. 

_2. Unistructural._ One or a few aspects of the task are picked up and used (understanding as nominal). 

352 

_3. Multistructural._ Several aspects of the task are learned but are treated separately (understanding as knowing about). 

_4. Relational._ The components are integrated into a coherent whole, with each part contributing to the overall meaning (understanding as appreciating relationships). 

_5. Extended abstract._ The integrated whole at the relational level is reconceptualised at a higher level of abstraction, which enables generalisation to a new topic or area, or is turned reflexively on oneself (understanding as far transfer, and as involving metacognition). 

Levels of understanding such as these may be used for structuring curriculum objectives hierarchically. 

_Example_ 

I will illustrate with a psychology unit in the third year of a four year part-time Bachelor of Education program at the University of Hong Kong, designed for in-service primary and secondary teachers wishing to upgrade their Teachers' College qualifications. 82 students were enrolled in the present unit, which was taught by myself and a teaching assistant (Note 3). The general aim was not to teach students about psychology, but to get them to think about teaching and learning, and to enact classroom decision-making, in a way enriched by psychological knowledge. Most units in professional programs could provide parallels. 

It was necessary then to set up a hierarchical list of "performances of understanding" from most desirable to barely satisfactory. This was done using SOLO as a baseline, focusing on verbs (italicised below) to denote a particular quality of performance: 

- (a) Most desirable (extended abstract): metacognitive understanding, students able to use the taught content in order to _reflect_ on their own teaching, _evaluate_ their decisions made in the classroom in terms of theory, and thereby _improve_ their decision-making and practice. Other outcomes: _formulating_ a personal theory of teaching that demonstrably drives decision-making and practice, _generating_ new approaches to teaching on the basis of taught principles and content. 

- (b) Very satisfactory (relational): students can _apply_ course content, and _recognise_ good and poor applications of principles. They "understand" in that course content is used as a theory of teaching that drives action. 

- (c) Moderately satisfactory (multistructural): students understand declaratively, in that they can _discuss_ content meaningfully, they _know about a_ reasonable amount of content, but don't transfer or apply it easily. 

353 

- (d) **Barely satisfactory** (unistructural): sparse understandings, evidence of some effort in the acquisition of terminology; higher level understanding offset by some misunderstandings. 

- (e) Unsatisfactory outcomes: fundamental misunderstandings, lack of effort/involvement in the unit. 

The above objectives form categories that may be used for grading purposes: (a) through (e) becoming "A", "B", "C", "D", and "F", respectively, the highest level exemplified in a student performance becoming that student's final grade. If finer grading within a category is desired, this can easily be accommodated (Biggs 1992). 

In sum, a performative notion of understanding enables teachers to specify the things the students need to _do_ in order to demonstrate particular levels of understanding. A competent teacher should be able to say in what ways a student should perform in order to specifically exemplify the deepest understanding of the content taught, and less satisfactory levels. Criterionreferencing in these terms sets both teaching and assessment agendas. 

What does the teacher need to do in order to facilitate the appearance of these desired performances? 

## **Teaching/learning activities (TLAs)** 

The teaching methods we choose need to engage students in activities that are likely to require them to perform in the way nominated in the curriculum objectives. Let us start by turning the question around. What activities are standard teaching methods most likely to elicit? 

The activities commonly associated with lectures are: listening, interpreting, comprehending, note-taking, reflecting (?). The common thread is _receiving_ in an isolated context. Lecturing itself does little to challenge or question student's interpretations; indeed, students often see implicit encouragement to accept the content and the interpretation given. 

Are these performances ones that university teachers want from their students? Comprehending and summarising certainly are, but only to a point. The real problem with lecturing is that it is normally low on student activity; the student is passive, precisely in the sense that a narrow range of learning-related activities is usually elicited, depending on individual ability and interest. While one student may find in a lecture the keystone for a particular arch of knowledge she is constructing, her neighbour perceives just another brick, which he duly records in his lecture notes. However, high level engagement ought not to be left to serendipity, or to individual student brilliance, but should be actively encouraged by the teacher. In short, if good 

354 

teaching is to stimulate competence rather than to reflect it, teachers need to activate an appropriately wide range of learning-related activities. 

After lecturing, the next most common method is the tutorial, which commonly elicits: elaborating, clarifying, removing misconceptions, challenging established interpretations, seeing how other students interpret concepts or apply their interpretations. There are here the beginnings of a long list of activities not addressed in the lecture, but whether or not the appropriate ones are elicited depends on the group size, and the competence of the tutor. Indeed, it is likely that in most units there would be plenty of high cognitive level activities yet to be activated. 

In theory, it should be possible to select teaching/learning activities (TLAs) that specifically address a desired performance of understanding. It is easier to be negative than positive about this, as a research base does not exist relating TLAs to target performances; it is easier to say what lecturing, for example, does not encourage than what it does. Selecting appropriate TLAs is a matter of experience and judgement. Ideas might be gained from a look at the literature on alternative teaching procedures and techniques (e.g. Gibbs, Habeshaw & Habeshaw 1992; Race & Brown 1993); the Higher Education Bulletins and Newsletters contain short articles of the "This worked for me; why don't you have a go?" variety (e.g. Fleming 1993; Saberton 1985) (both of which also worked for me, see below). It must be emphasised, though, that this should not involve the simple addition of a "good" technique; it is chosen because its function and purpose cohere with one's total teaching system. 

It also helps to recall that the teacher is not the only agent responsible for setting up TLAs. Both individual and social activity play a role in the construction of knowledge: 

1. The _teacher_ has major control over formal teaching activities: lectures, tutorials, laboratories, field excursions, etc. The teacher can also set up formal cooperative activities involving peers, such as discussion groups, brainstorming, or learning partnerships (Saberton 1985), and once the activity has been initiated, the role of peers becomes increasingly important. 

_2. Peer-controlled_ activities range from formal ones, initiated by the teacher, such as various kinds of groupwork (Collier 1985; Johnson & Johnson 1990), or instructions to use learning partners, to informal and spontaneous collaboration by students outside the classroom, which may have positive effects on learning (Tang 1993). 

_3. Self-controlled_ activities, which includes anything that goes under the heading of independent learning and study, including specific strategies for extracting meaning from text such as summarizing and note-taking (Hidi & Anderson 1986, Kirby & Pedwell 1991), general study skills, 

355 

and metacognitive strategy use (Brown, Bransford, Ferrara & Campione 1983). 

Clearly, the learner's spontaneous activities are just as crucial in a constructivist instructional framework as those activities that are in reaction to teaching; the term "teaching/learning activity" or TLA is meant to emphasise just this point. Conventionally, teachers see study skills training, skilled note-taking, and trained or spontaneous use of such metacognitive strategies as planning, monitoring, and self-questioning, as simply not their business. However, students deploy their study strategies within and with reference to a particular teaching context. Teaching study skills without reference to that context may even be counter-productive if it is not supported by the teaching environment (Ramsden, Beswick & Bowden 1986). This suggests we go further, as do Chalmers and Fuller (in press), and embed the learning/study skills relevant to learning particular content in the teaching of that content. This must become an increasingly important issue in distance or "flexible" learning modes. 

## _Example_ 

In the B.Ed. psychology unit, teaching was aligned to the performances italicised in the objectives (see above) with the following TLAs (italicised): 

1. to understand certain psychological concepts (such as expectancyvalue theory of motivation, quantitative and qualitative assessment theory, constructivist learning theory): _notes_ and _readings_ to be read before each class, taken from the recommended text, Biggs and Moore (1993). _Selfaddressed questions_ on basic content: What do I most want to find out in the next class? What is the main point I learned today? What was the main point left unanswered in today's session? (Fleming 1993). Class time was used for clarification and elaboration, sometimes for _mass lecture._ Each student chose a _learning partner_ to help in clarifying and elaborating (Saberton 1985); partners sat next to each other in class, and communicated regularly with each other outside class, in whatever ways they thought might be helpful. 

2. to apply to own teaching: _the learning partner,_ and to extend the range of exposure to different views and professional experiences, _groups_ of around 10 students, teaching in the same general content area. Each group had a question to address, but was basically self-directed, and students had to draw their own conclusions. 

3. to reflect on own teaching: a _diary,_ to record critical learning related incidents, and to reflect upon them. The diary also contained the selfaddressed questions and was part of the assessment. Reflection might also be manifested in a variety of TLAs. 

356 

The point is that a constructivist perspective highlights the need for introducing a range of TLAs, involving teacher, peers, and the individual student as appropriate, so that the higher level objectives have a greater probability of being addressed than if only one teaching method, such as lecturing, is used. 

## **Assessment and grading** 

In deciding the assessment tasks, it is necessary to judge the extent to which they embody the target performances of understanding, and how well they lend themselves to evaluating individual student performances. Again, it would be useful to reverse the question and ask what levels of understanding typical assessment tasks are likely to call out. 

### _Examinations_ 

Tang (1991) asked physiotherapy students what preparation strategies they used for an essay exam. The following were typically reported: rote learning, question spotting, going through past papers, underlining, organising study time and materials, memorising in meaningful context, relating information, visualising patients' conditions, discussing with other students. Few of these activities appear to address high level curriculum objectives. 

The practice of marking examinations "analytically" (by aggregating marks as points are made), which is common in large classes with multiple markers, means that higher level understanding performances tend not to be in focus; students know this, and present with what will be in focus. One student in a grade 11 Ancient History class answered a "compare-and-contrast" question ("In what ways were the reigns of Tutenkhmen and Akhnaten alike and in what ways were they different?") simply by listing the life histories of each (Biggs 1987). She didn't answer the question, but made many points, thereby obtaining the highest mark in the class. Because of the familiar problem of backwash, essay exams typically elicit lower cognitive level performances than most tertiary aims would nominate. The following quotation by a Psychology undergraduate makes this very clear: 

I hate to say it, but what you have got to do is to have a list of 'facts'; you write down the important points and memorize those, then you'll do all right in the test ... If you can give a bit of factual information - so and so did that, and concluded that - for two sides of writing, then you'll get a good mark. Quoted in Ramsden (1984: 144) 

357 

_Short answer and multiple-choice_ 

Short answer examinations, allowing only brief sentences or phrases, are even less likely to elicit high level engagement than the essay. An assumed advantage of the short answer, and the multiple choice test, is that coverage can be extended over more of the unit content, but we should consider the following: 

The greatest enemy of understanding is coverage - I can't repeat that often enough .... Obviously, if people took this aphorism seriously, there would be a total revolution in education, and 95 per cent of what educators do every day would have to be changed. (Gardner 1993: 24) 

Individual items in objective/multiple-choice tests can assess high level thinking, but in practice they rarely go beyond Bloom's comprehension level (Anderson 1972, Marso & Pigge 1991). Indeed, if they are assessing knowledge, it is in terms of the least demanding process, recognition of the correct answer, not even its recall. Both multiple-choice and short answer tests further exemplify an insurmountable problem with quantitative approaches to assessment: the contents of knowledge are treated as having been learned in binary units (correct/incorrect), which are then summed, each unit being seen as equivalent to any other unit. Not only does this reflect a bizarre epistemology, it nudges the student to focus on details: 

There is no need to separate main ideas from details; all are worth one point. And there is no need to assemble these ideas into a coherent summary or to integrate them with anything else because that is not required. (Lohman 1993: 19) 

All the above modes of assessment, then, are inadequate for much tertiary teaching. Apart from the ease with which credit is given for lower level performances than are intended, they suffer from at least two fundamental defects, in terms of constructivist theory: 

- �9 the performances are limited to dealings (be they never so high level) with declarative or propositional knowledge, not with procedural knowledge. This may matter less in tertiary courses that focus exclusively on declarative knowledge, but in professional courses declarative knowledge then becomes the surrogate for procedural or functioning knowledge; the theory-to-practice shift is left up to the student to achieve unaided. 

- �9 the _teacher_ sets the limits of what may fall within the purview of "good learning", so many important or appropriate triggering questions are unlikely to be asked, and much good learning is likely to go unnoticed. If the _student_ is constructing the knowledge, clearly the student is in a 

358 

better position than the teacher to select and report on those constructions. Responding only to highly focused and closed questions posed by the teacher is too limiting. 

In sum, a teacher cannot always anticipate what valid forms students' constructions may take. This is explained in a splendid metaphor for assessment, supplied recently by a student (not from the B.Ed. unit under discussion): 

When I stand in front of a class, I don't see stupid or unteachable learners, but boxes of treasures waiting for us to open. (Cheung Chin-ming, a part-time P.C.Ed. student, University of Hong Kong) 

Let us take this a little further: 

_Teacher:_ How many diamonds have you got? 

_Student:_ I don't have any diamonds. 

_Teacher:_ Then you fail! 

_Student:_ But you didn't ask me about my jade! 

Learners amass treasure, not just diamonds. 

Constructivism strongly implicates the use of an assessment _portfolio,_ where the students select at least some of the evidence that they consider matches the unit objectives. This further implicates the use of self- and peerassessment. In deciding suitable modes of assessment, then, the following issues have to be considered: 

1. What qualities of learning are we looking for; what performances need to be confirmed in the assessment? This question should already be answered in the curriculum objectives and the teaching activities. 

2. Should the assessment be decontextualized or situated? The answer here depends on the nature of the knowledge; procedural knowledge clearly requires enactment in context, while declarative knowledge may or may not, depending on why it is being taught (Biggs 1995). 

3. Who should set the criteria for learning, provide the evidence, and assess how well the evidence addresses the objectives? All three issues could be addressed by teacher, by peers, by the student, or by all collaboratively. 

The permutations and combinations here generate a wide variety of assess- 

ment techniques. The final examination, objective test, and standard assignment, are obviously not the only options for assessing learning. 

## _Example_ 

In the B.Ed. unit, the assessments tasks needed to address a range of levels of understanding: from comprehension, through application, to reflection at a high and personal level; and to produce evidence showing conceptual change and if and how professional decision-making had changed. A _portfolio_ was 

359 

indicated. The students were asked to provide four items giving evidence that learning relevant to the unit objectives had taken place, with a justification for the selection (which in turn provides evidence of the depth of the learner's metacognitive understanding of his or her learning), the remaining items comprising the _diary_ and _answers to the self-addressed questions._ 

A brief indication of how well constructive alignment seemed to work in this unit should be given. The best index is the evidence provided by students that their conceptions and teaching practices had changed. Such evidence came in three main kinds: 

1. Diary entries, and a popular portfolio item, the letter-to-a-friend (Trigwell & Prosser 1990), which gives clear indications of conceptual change and of the quality of reflection (Tang & Biggs 1995). 

2. Evidence of changed classroom practice: portfolio items comprising lessons and lesson plans, assessment items, reports of critical incidents in the classroom, assessments by their own students, etc. 

3. Declarative knowledge about teaching and learning: reviews and critiques e of relevant articles, original concept maps of the unit. 

On this basis, 37 percent of the 82 students produced evidence meeting the criteria for "A" (extended abstract), a further 40 per cent the criterion for "B" (relational), level learning. In other words, over three-quarters of the students were able to demonstrate a level of understanding that went beyond understanding propositional or declarative knowledge as such, to demonstrating that the knowledge changed performances in their everyday professional lives. There may be many reasons why this happened, but the most obvious is that they were required to do so by the design of the unit: the objectives defined the performances, the teaching methods elicited them, and the assessment tasks both confirmed (and no doubt motivated) those performances. 

Space allows only two quotations from students' portfolios to illustrate: considerably more detailed evidence of desired change is given in Biggs (1996b, Chapter 9) and Tang and Biggs (1995). The first is an example of high level professional reflection: 

The biggest point I have learned from this course is my biggest flaw as a teacher, that is, I did not trust my students to be able to behave themselves ... (or)... capable of being responsible for their own learning; and because of this flaw, I made numerous rules in class for them to follow so as to make sure that they "behaved", did all the preparations and planning for them, giving them mountains of homework and short tests to make sure that they revise for their lessons and so on - all rooted from my lack of trust in them! And I dared to blame them for being so passive and dependent when all along I helped to encourage them to be so! 

360 

The next quotation is a gratifying confirmation of alignment at the conceptual level: 

- As Ronald, one of my classmates, said, "They are practising what they preach." His words recall my memory of Michael Fullan's premise in his book _Change forces:_ 

_Faculties of education should not be advocating things for teachers or schools that they are not capable of practising themselves._ 

### **Discussion and conclusions** 

The principle of "constructive alignment" evolved with the decision to use a portfolio to assess the extent to which students felt they had met the unit objectives. This forced them to reflect on what they wanted from the unit, and how they thought they going to get it, which in turn put pressure on the teacher to provide appropriate teaching/learning activities to help them do so. In this way, all components in the system became aligned to the objectives. 

The question is: Can the principle of constructive alignment be generalised from the context of in-service teacher education? I believe so. In fact, the authors of Project Zero are doing exactly that (Gardner 1993, Perkins & Blythe 1993). The key issue is whether the teacher can operationalise desirably high levels of understanding in ways that denote performances that can be elicited by teaching/learning activities, and that can be assessed authentically. It is then a matter of applying the principles of alignment, and of criterion-referencing, that are already well established in the instructional design literature. To the criticism that criterion-referenced assessment is closed, and inimical to the spirit of constructivism (Duffy & Jonassen 1992), one points to the portfolio, where every encouragement is given to students to be divergent and surprising, and indeed they would not have met the "A" criterion had they not been so. 

The model of instruction that emerges is simple, and it makes intuitive sense: 

- �9 teachers need to be clear about what they want their students to learn, and how they would manifest that learning in terms of "performances of understanding". For .example, memorising and paraphrasing are not performances of understanding, recognising an application in a novel context is. 

- �9 the performance objectives thus emerging need to be arranged in a hierarchy from most acceptable to barely satisfactory, which hierarchy becomes the grading system. 

- �9 students need to be placed in situations that are judged likely to elicit the required learnings. 

361 

- �9 students are then required to provide evidence, either by self-set or teacher-set tasks, as appropriate, that their learning can match the stated objectives. Their grade becomes the highest level they can match convincingly. 

Something like an alignment model is assumed in any discussions about good teaching. Course validation, the quality enhancement of tertiary teaching (now a general concern in many countries), and general procedures of staff development use at least implicitly the principles of constructive alignment. Good teachers are expected to be clear about what they want students to learn and what students should have to do in order to demonstrate that they have learned at the appropriate level; they should know and enact ways of getting their students to learn effectively at the desired cognitive level, to be more student-centred in their teaching-learning activities, and more authentic in their assessments. The present model provides a framework for systematically operationalising these _desiderata._ 

There is however an institutional side to this, not to say obligation. The quantitative framework of institutional control, as realised in the managerial model that has recently been imposed on universities in many countries, frequently requires assessment related practices that make the kind of qualitative criterion-referencing that is basic to constructive alignment difficult to implement (Biggs 1996a). Economic rationalism means larger classes, which in conventional thinking means more lecturing and more final exams, especially multiple-choice, rather than groupwork and assignments or other formats that are time-consuming to mark; it need not be so, but it is easy to think that it must. Managerial thinking increasingly requires the reporting of student performance in terms of percentages rather than of letter grades or other qualitative categories; in Australia, many institutions even require gradingon-the-curve. Such procedures strongly discourage qualitative approaches to assessment. There is a real tension here between administrative and academic requirements (Biggs 1996a, 1996b). Academics need to become more proactive, positively _insisting_ that educational considerations should prevail over administrative convenience. 

However, these considerations lead to a different set of issues, which it would be inappropriate to pursue here. My main point is that a working version of constructivism can be integrated with instructional design at three crucial points: the curriculum or unit objectives are clearly stated in terms of content specific levels of understanding that imply appropriate performances, the teaching methods require students to be placed in contexts that will likely elicit those performances, and the assessment tasks address those same performances. On the basis of at least the example given, and of the infer- 

362 

ential evidence from the research literature, the model provides a powerful teaching/learning context. 

### **Notes** 

This paper is elaborated from presentations to the 20th International Conference, Improving University Teaching, Hong Kong, 10-13 July, 1995, and to the Annual Meeting, Hong Kong Educational Research Association, 11-12 November, 1995. I am indebted to Mark Constas and Catherine Tang for discussions helpful in constructing the ideas presented here. 

2 "Instruction" is used here and throughout this paper in the North American sense of systematic teaching, including curriculum and assessment, not in the English sense of direct instruction or training. 

31 acknowledge my great debt to Mabel Sieh, who assisted particularly in the groupwork and the assessment of portfolios, and who provided valuable ongoing feedback during the teaching of the unit. For a more complete description of the unit and its rationale, see Chapter 9, Biggs (1996b). 

### **References** 

|Anderson, R.C. (1972). 'How to construct achievement tests to assess comprehension',_Review_|
|---|
|<br>_of Educational Research_42(2), 145-170.|



- Archbald, D.A. and Newman, E M. (1988). _Beyond Standardised Testing: Assessing Authentic Achievement in the Secondary School._ Reston: National Association of Secondary Principals. 

Argyris, C. (1976). 'Theories of action that inhibit individual learning', _American Psychologist_ 31,638-654. 

Biggs, J.B. (1987). 'Process and outcome in essay writing', _Research and Development in Higher Education_ 9, 114-125. 

Biggs, J.B. (1992). 'A qualitative approach to grading students', _HERDSA News_ 14(3), 3-6. Biggs, J.B. (1993). 'From theory to practice: A cognitive systems approach', _Higher Education Research and Development_ 12, 73-86. 

Biggs, J.B. (1995). 'Assessing for learning: Some dimensions underlying new approaches to educational assessment', _Alberta Journal of Educational Research_ 41, 1-18. Biggs, J.B. (1996a). 'Assessing learning quality: Reconciling institutional, staff and educational demands', _Assessment & Evaluation in Higher Education_ 21, 5-15. 

Biggs, J.B. (ed.) (1996b). _Testing: To Educate or to Select? Education in Hong Kong at the Crossroads._ Hong Kong: Hong Kong Educational Publishing Co. 

Biggs, J.B. and Collis, K.E (1982). _Evaluating the Quality of Learning: The SOLO Taxonomy._ New York: Academic Press. 

Biggs, J.B. and Moore, P.J. (1993). _The Process of Learning._ Sydney: Prentice-Hall Australia. Brown, A.L., Bransford, J.D., Ferrara, R.A. and Campione, J.C. (1983). 'Learning, remembering, nd understanding', in Flavell, J. and Markman, E. (eds.), _Handbook of ChiM Psychology: Cognitive Development_ (Vol. 3). New York: Wiley, pp. 77-166. Brown, J.S., Collins, A. and Duguid, P. (1989). 'Situated cognition and the culture of learning', _Educational Researcher_ 18(1), 32-42. 

- Chalmers, D. and Fuller, R. (in press). _Teaching for Learning at University._ London: Kogan Page. 

Cobb, P. (1994). 'Where is the mind? Constructivist and sociocultural perspectives on mathematical development', _Educational Researcher_ 23(7), 13-20. 

363 

Cohen, S.A. (1987). 'Instructional alignment: Searching for a magic bullet', _Educational Researcher_ 16(8), 16--20. 

- Cole, N.S. (1990). 'Conceptions of educational achievement', _Educational Researcher_ 19(3), 2-7. 

- Collier, K.G. (1985). 'Teaching methods in higher education: The changing scene, with special reference to small-group work', _Higher Education Research and Development_ 4(1), 3-26. 

- Driver, R. and Oldham, V. (1986). 'A constructionist approach to curriculum development in science' _Studies in Science Education_ 13, 105-122. 

- Driver, R., Asoko, H., Leach, J., Mortimer, E. and Scott, P. (1994). 'Constructing scientific knowledge in the classroom', _Educational Researcher_ 23(7), 5-12. 

- Duffy, T.M. (1992). 'New implications for instructional technology' in Duffy, T.M. and D. Jonassen (eds), _Constructivism and the Technology of Instruction: A Conversation_ (pp. 1-16). Hillsdale, NJ: Erlbaum. 

- Duffy, T.M. and D. Jonassen (eds), _Constructivism and the Technology of Instruction: A Conversation._ Hillsdale, NJ: Erlbaum. 

- Entwistle, A. and Entwistle, N. (1992). 'Experiences of understanding in revising for degree examinations', _Learning and Instruction_ 2, 1-22. 

- Entwistle, N. and Percy, K. (1974). 'Critical thinking or conformity? An investigation of the aims and outcomes of higher education', in _Research into Higher Education._ London: Society for Research into Higher Education. 

- Fleming, N. (1993). 'What works and what doesn't in staff development', _HERDSA News_ 15(2), 12-13. 

- Frederiksen, J.R. and Collins, A. (1989). 'A systems approach to educational testing', _Educational Researcher_ 18(9), 27-32. 

- Gardner, H.W. (1993). 'Educating for understanding'. _The American School Board Journal,_ July, 20-24. 

- Gibbs, G., Habeshaw, S. and Habeshaw, T. (1992). _53 Interesting Ways to Teach Large Classes._ Bristol: Technical and Educational Services. 

- Hidi, S. and Anderson, V. (1986). 'Producing written summaries: Task demands, cognitive operations and implications for instruction', _Review of Educational Research,_ 56, 473493. 

- Johnson, D.W. and Johnson, R.T. (1990). _Learning Together and Alone: Co-operation, Competition and lndividualisation._ Englewood Cliffs, NJ: Prentice-Hall. 

- Kirby, J. and Pedwell, D. (1991). 'Students' approaches to summarization', _Educational Psychology,_ 1 I, 297-307. 

- Lai, P. and Biggs, J.B. (1994). 'Who benefits from mastery learning?' _Contemporary Educational Psychology_ 19, 13-23. 

- Lohman, D. (1993). 'Teaching and testing to develop fluid abilities', _Educational Researcher_ 22(7), 1-23. 

- Marso, R.N. and Pigge, EL. (1991). 'An analysis of teacher-made tests: Item-types, cognitive demands, and item construction errors', _Contemporary Educational Psychology,_ 16, 279286. 

- Marton, E (1981). 'Phenomenography - Describing conceptions of the world around us', _Instructional Science,_ 10, 177-200. 

Marton, E (in press). 'Cognosco ergo sum', _Nordisk Pedagogik._ 

- Marton, F. and Booth, S. (in press). 'The learner's experience of learning', in Olsen, D.R. and Torrrance, N. (eds.), _The Handbook of Education and Human Development: New models of Learning, Teaching and Schooling._ Oxford: Blackwell. 

- Moss, P.A. (1992). 'Shifting conceptions of validity in educational measurement: Implications for performance assessment', _Review of Educational Research_ 62, 229-258. 

- Nuthall, G. (in press). 'Understanding student learning and thinking in the classroom', in Biddle, B.J., Good, T.L. and Goodson, I.F. (eds.), _The International Handbook of Teachers and Teaching._ Dordrecht: Kluwer. 

364 

- Perkins, D. and Blythe, T. (1993). 'Understanding up front: A performance approach to testing for understanding', paper presented to Annual Meeting, American Educational Research Association, Atlanta, April. 

- Race, P. and Brown, S. (1993). _500 Tips for Tutors._ London: Kogan Page. 

- Ramsden, P. (1984). 'The context of learning', in Marton, F., Hounsell, D. and Entwistle, N. (eds.), _The Experience of Learning._ Edinburgh: Scottish Academic Press. 

- Ramsden, P. (1992). _Learning to Teach in Higher Education._ London: Routledge. 

- Ramsden, P., Beswick, D. and Bowden, J. (1986). 'Effects of learning skills interventions on first year university students' learning', _Human Learning_ 5, 151-164. 

- Saberton, S. (1985). 'Learning partnerships', _HERDSA News_ 7(1), 3-5. 

- Scardamalia, M., Bereiter, C. and Lamon, M. (1994). 'CSILE: Trying to bring students into World 3', in McGilley, K. (ed.), _Classroom Lessons: Integrating Cognitive Theory and Classroom Practice._ Cambridge, MA: MIT Press, pp. 201-228. 

- Shuell, T.J. (1986). 'Cognitive conceptions of learning', _Review of Educational Research_ 56, 411--436. 

- Slavin, R.E. (1990). 'Mastery learning re-reconsidered', _Review of Educational Research 60,_ 300-302. 

- Steffe, L. and Gale, J. (eds.) (1995). _Constructivism in Education._ Hillsdale, N J: Erlbaum. Tang, K.C.C. (1991). _Effects of Different Assessment Methods on Tertiary Students'Approaches to Studying._ Unpublished PhD Dissertation, University of Hong Kong. 

- Tang, K.C.C. (1993). 'Spontaneous collaborative learning: A new dimension in student learning experience?', _Higher Education Research and Development_ 12, 115-130. 

- Tang, K.C.C. and Biggs, J.B. (1995). 'Letters to a friend: Assessing conceptual change in professional development', paper given to Annual Conference, Higher Education Research and Development Society of Australasia, Rockhampton, July 3-7. 

- Trigwell, K. and Prosser, M. (1990). 'Using student learning outcome measures in the evaluation of teaching', _Research and Development in Higher Education_ 13,390-397. 

- Unger, C. (1993). 'A call for sensitivity: Taking into account students' perspectives of understanding and learning for understanding', paper given to Annual Meeting, American Educational Research Association, Atlanta, 15 April. 

- Von Bertalanffy, L. (1968). _General Systems Theory._ New York: Braziller. 

- West, L. and Pines, A. (eds.) (1985). _Cognitive Structure and Conceptual Change._ Orlando, **FL.:** Academic Press. 

- Wood, T. (1995). 'From alternative epistemologies to practice in education: Rethinking what it means to teach and learn', in Steffe, L. and Gale, J. (eds.), _Constructivism in Education._ Hillsdale, N J: Erlbaum, pp. 331-9). 

