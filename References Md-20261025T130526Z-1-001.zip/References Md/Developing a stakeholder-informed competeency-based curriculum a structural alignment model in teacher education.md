

Journal of Curriculum Studies Research 

<u>https://curriculumstudies.org</u> E-ISSN: 2690-2788 Volume: 8 Issue: 2  2026 pp. 113-137 

# **Developing a Stakeholder-Informed Competency-Based Curriculum: A Structural Alignment Model in Teacher Education** 

<mark>Pitsanu Boonsrianan</mark><sup>a</sup> <mark>, Warakorn Seeyo*</mark><sup>a</sup> <mark>, Suradit Phaksuchon</mark><sup>a</sup> <mark>, Sanchai Duangbung</mark><sup>a</sup> <mark>, Kittikun Jungate</mark><sup>a</sup> <mark>, & Suthasinee Theerapan</mark><sup>a</sup> 

* Corresponding author Email: warakorn.s@msu.ac.th a. College of Music, Mahasarakham University, Thailand. 

### **Article Info** 

Received: March 03, 2026 Accepted: June 15, 2026 Published: July 5, 2026 



<mark>10.46303/jcsr.2026.28</mark> 

### **How to cite** 

Boonsrianan, P., Seeyo, W., Phaksuchon, S., Duangbung, S., Jungate, K., & Theerapan, S. (2026). Developing a Stakeholder-Informed Competency-Based Curriculum: A Structural Alignment Model in Teacher Education. _Journal of Curriculum Studies Research_ , 8(2), 113-137. <u>https://doi.org/10.46303/jcsr.2026.28</u> 

### **Copyright license** 

This is an Open Access article distributed under the terms of the Creative Commons Attribution 4.0 International license. 

### **ABSTRACT** 

This study aims to develop a program-level structural alignment model by integrating stakeholder analysis, Outcome-Based Education (OBE), and quality assurance mechanisms within the AUNQA framework to address misalignments among learning outcomes, course structures, and assessment systems. The research uses a higher education music teacher education program as an empirical case to develop and examine the proposed model. A sequential mixed-methods design was adopted, involving data collection from 82 stakeholders and a systematic analysis of existing curriculum documents. Quantitative data were analyzed using descriptive statistics, while qualitative data were examined through content analysis. The findings reveal a discernible gap between stakeholders’ competency expectations and the program’s perceived attainment levels, indicating structural misalignment at the program level rather than isolated deficiencies at the course level. Based on these findings, an integrated competency framework was synthesized, and a structural model was developed to translate stakeholder expectations into measurable program learning outcomes, coherent course mapping, and evidence-based assessment practices. The study argues that stakeholder-informed alignment can function as a structural governance mechanism for curriculum design by systematically linking curriculum architecture with quality assurance processes. The findings contribute to program-level curriculum theory by demonstrating how contextual responsiveness and standards-based legitimacy can be integrated within teacher education. 

### **KEYWORDS** 

Program-level curriculum design; Outcome-Based Education; stakeholder alignment; constructive alignment; quality assurance; music teacher education. 

114 

## **INTRODUCTION** 

Over the past decade, higher education curriculum development has been increasingly influenced by the principles of Outcome-Based Education (OBE), which emphasize the formulation of clearly articulated, measurable, and empirically verifiable learning outcomes (Solikhah, 2022). Central to this approach is the requirement that learning outcomes, teaching and learning activities, and assessment practices be coherently aligned in accordance with the principle of constructive alignment (Rao, 2020; Segooa & Molise, 2024). In practice, however, many programs continue to experience structural misalignment, particularly in the linkage among stakeholder expectations, the specification of program learning outcomes, and the organization of courses within the curriculum framework. As a result, formally stated outcomes do not always fully reflect the competencies required for professional practice. 

Within teacher education, these challenges become more complex. Programs must systematically integrate disciplinary knowledge, pedagogical competence, professional ethics, technological capability, and contextual understanding. Teacher education institutions operate within multifaceted structures that require the coordination of subject knowledge, pedagogical theory, practicum experience, and professional standards (Flores, 2016; Kuzembayeva et al., 2025). When curriculum design does not systematically incorporate empirical evidence from stakeholders, a gap may emerge between intended learning outcomes and graduates’ actual professional capabilities. In competency-based frameworks, this challenge intensifies, as competencies must be explicitly mapped onto learning outcomes and authentic professional practice contexts (Tarmo & Kimaro, 2021). These conditions highlight the need for systematic alignment between field-based expectations and curriculum architecture. 

Within music teacher education, however, curriculum design is shaped by a distinctive and persistent tension between two competing professional orientations (Partti & Karlsen, 2010). On the one hand, traditional music training emphasizes specialized performer identities, focusing on technical mastery and depth within a primary instrument. On the other hand, contemporary school contexts require music teachers to demonstrate broad musicianship, including multi-instrumental proficiency, ensemble leadership, pedagogical flexibility, and the ability to integrate diverse musical traditions into classroom practice (Conway, 2012). 

This tension reflects a structural contradiction between the disciplinary logic of conservatory-style training and the practical demands of school-based music teaching. As a result, graduates who are highly trained as performers may not be fully prepared to function as versatile educators in real educational settings. Conversely, efforts to broaden competencies may risk diluting the depth of musical expertise. Despite its significance, this tension has rarely been systematically addressed at the program level within Outcome-Based Education frameworks, where alignment is often treated as a technical process rather than as a disciplinary negotiation between competing professional identities. This unresolved tension highlights the need for a program-level framework that can systematically reconcile competing competency demands within a coherent curriculum structure. 

JCSR 2026, 8(2):113-137 

115 

Under the AUN-QA framework, quality assurance extends beyond individual courses to the program level, emphasizing the specification of Expected Learning Outcomes that are standards-referenced and demonstrably attainable (Johnson, 2017). Curriculum development, therefore, cannot be confined to course revision; it requires the design of an integrated curriculum architecture that logically and verifiably connects learning outcomes, course structures, pedagogical strategies, and assessment systems. 

This study seeks to develop a music teacher education curriculum through a stakeholderinformed alignment process grounded in OBE and the AUN-QA framework. Its objective is to construct an integrated competency framework that is both contextually responsive and standards-legitimate. The study addresses the following research questions: 

- (1) Which competency dimensions do stakeholders prioritize for music teacher graduates, and is there a gap between expected importance and satisfaction with the existing curriculum? 

- (2) Does the existing curriculum exhibit structural misalignment within the OBE framework, particularly in relation to the competing demands between specialized musical training and the broad professional competencies required in music teacher education? If so, in what ways? 

- (3) How can the synthesized competency framework connect stakeholder expectations with national higher education qualification standards and AUN-QA criteria? 

- (4) How can these competencies be translated into a coherent program-level curriculum structure, including clearly defined Program Learning Outcomes (PLOs), aligned course mapping, and evidence-based assessment mechanisms, under the principle of constructive alignment? 

## **LITERATURE REVIEW** 

The concept of Outcome-Based Education (OBE) was foundationally articulated by Spady (1994), who proposed that educational design should begin with the explicit specification of the learning outcomes students are expected to demonstrate at the conclusion of the learning process. Curriculum content, instructional strategies, and assessment methods should then be backward-designed to align with these intended outcomes. Harden (2007) later extended this framework within higher education, emphasizing the formulation of clearly defined, measurable outcomes aligned with professional standards. Similarly, Biggs (1996) advanced the principle of constructive alignment, arguing that learning outcomes, teaching and learning activities, and assessment tasks must be systematically aligned to enable students to construct knowledge and demonstrate performance at the intended cognitive and behavioral levels. Although these principles have been widely adopted at the policy and accreditation levels, their implementation has frequently remained confined to individual courses rather than extended to structural design at the program level. Consequently, systemic coherence across the broader curriculum architecture often remains incomplete. 

JCSR 2026, 8(2):113-137 

116 

While Outcome-Based Education and constructive alignment have been widely implemented at the level of individual courses, their application at the program level involves a fundamentally different degree of complexity. At the course level, alignment is typically achieved within a single instructional unit, focusing on coherence among course learning outcomes, teaching activities, and assessment tasks (Biggs & Tang, 2003). In contrast, programlevel alignment requires the integration of multiple courses, the longitudinal development of competencies, and the systematic mapping of Program Learning Outcomes (PLOs) across the entire curriculum structure. This includes both vertical alignment, which ensures the progressive development of competencies across different years of study, and horizontal alignment, which ensures coherence across courses within the same level (Anderson et al., 2025). In addition, program-level alignment must connect curriculum design with professional standards and stakeholder expectations. Despite its importance, such program-level alignment remains undertheorized and insufficiently operationalized in many higher education contexts (Loughlin et al., 2021). 

Freeman’s (1984) stakeholder theory posits that organizational decision-making should account for the interests and expectations of diverse stakeholder groups. Applied to curriculum development, this perspective suggests that the formulation of learning outcomes should be grounded in empirical evidence drawn from graduate employers, professional regulators, students, and broader societal stakeholders. Contemporary reviews in higher education further emphasize that stakeholder analysis must consider power relations and governance mechanisms rather than merely identifying relevant groups (Syed et al., 2024). Nevertheless, many curriculum reform initiatives that claim to include stakeholder participation are limited to collecting perception or satisfaction data without demonstrating a systematic analytical process for translating stakeholder input into structural curriculum design. As a result, field-based perspectives are often insufficiently integrated into program-level curriculum architecture. 

Competency-based curriculum design seeks to define outcomes in terms of demonstrable capabilities that integrate knowledge, skills, and professional attributes (Frank et al., 2010; Ndiangui et al., 2025; Valentín Melgarejo et al., 2025). This approach aligns with OBE in its emphasis on clearly specified and measurable outcomes as the foundation for curriculum development (Amirgalina et al., 2025; Harden, 2007). A persistent challenge, however, lies in operationalizing abstract competencies into explicit indicators that are assessable and coherently embedded within program structures. While numerous studies propose competency frameworks or graduate attribute categories, fewer articulate the procedural steps required to translate these competencies into Expected Learning Outcomes, sequenced course structures, and systematically verifiable assessment systems at the program level. 

Regional quality assurance frameworks, such as AUN-QA, require the articulation of Expected Learning Outcomes that are aligned with stakeholder needs and supported by demonstrable evidence of attainment at the program level (ASEAN University Network, 2020). This framework extends the principle of constructive alignment from the course level to the 

JCSR 2026, 8(2):113-137 

117 

program level, emphasizing the interconnection among outcomes, course organization, pedagogical strategies, and assessment systems as mechanisms for assuring learning. However, much of the existing research on quality assurance implementation remains limited to discipline-specific case studies or evaluation reports. There remains a lack of structurally grounded models that explain how curriculum architecture can systematically integrate stakeholder analysis, competency formulation, constructive alignment, and quality assurance governance within a coherent program-level framework. 

## **METHOD** 

## _Research Design_ 

This study employed a curriculum development design using a sequential mixed-methods approach, with quantitative data collection followed by qualitative explanation to strengthen analytical integration (Creswell & Clark, 2018). Survey data were used to examine stakeholders’ perceived importance and perceived attainment of graduate competencies to identify programlevel gaps. Open-ended responses further contextualized these discrepancies and specified competencies relevant to school-based practice, consistent with design-oriented curriculum inquiry (McKenney & Reeves, 2018). Curriculum document analysis was conducted to diagnose alignment among learning outcomes, course structures, and assessment practices under the principles of Outcome-Based Education (Spady, 1994). The integrated findings informed the synthesis of a stakeholder-informed competency framework, the refinement of Program Learning Outcomes (PLOs), and the development of a program-level structural alignment model aligned with AUN-QA standards (ASEAN University Network, 2020). 

## _Population and Sample_ 

A total of 82 stakeholders were recruited through purposive sampling to ensure direct relevance to music teacher education and school-based professional contexts (Patton, 2014). The sample included multiple stakeholder groups representing learners, practitioners, and decision-makers: current students, alumni, music teachers/civil servant teachers, school administrators, program faculty members, freelance music professionals, student teachers in practicum placements, and prospective applicants. The questionnaire was administered online through professional and academic networks, and all voluntary responses (n = 82) were included in the analysis. 

Given the relatively small number of participants in certain stakeholder subgroups, the analysis was not intended to support inferential statistical comparisons between groups. Instead, descriptive comparisons were used to identify overall patterns in stakeholder responses, and the findings were interpreted as context-specific insights relevant to curriculum development in music teacher education. 

_Data Collection Instruments_ 

Two primary instruments were used: 

1) Stakeholder Competency Questionnaire (Importance and Satisfaction/Attainment). 

JCSR 2026, 8(2):113-137 

118 

A structured questionnaire was developed with two parallel five-point Likert-scale sections (Likert, 1932): 

(a) importance of graduate competencies (1 = very low to 5 = very high), and 

(b) perceived attainment/satisfaction with graduates’ competencies (1 = very low to 5 = very high). 

The competency domains covered professional ethics and conduct, lifelong learning, communication, musical proficiency, ensemble conducting, instructional innovation, instructional technology, and administrative/budget management. The questionnaire also included open-ended questions to elicit additional competency needs and structural concerns related to school-based practice. 

Content validity was evaluated by five experts in music education and curriculum studies using the Index of Item-Objective Congruence (IOC), yielding IOC values of 0.80–1.00 (≥ 0.50). Minor revisions were made accordingly. A pilot test supported internal consistency reliability, with Cronbach’s alpha coefficients ranging from 0.82 to 0.91 across domains. 

2) Curriculum Document Analysis Protocol. 

A structured protocol was developed to examine program documents, including Program Learning Outcomes (PLOs), Course Learning Outcomes (CLOs), course structure and credit distribution, descriptions of teaching and learning activities, and assessment formats. The content validity of the protocol was verified through IOC by the same expert panel, with values ranging from 0.80 to 1.00. Two researchers independently coded the curriculum documents, and inter-rater reliability yielded Cohen’s kappa coefficients ranging from 0.78 to 0.86, indicating substantial agreement. Document analysis was guided by the constructive alignment framework (Biggs & Tang, 2003) to identify patterns of program-level coherence and misalignment. 

## _Data Analysis_ 

Quantitative analysis. Descriptive statistics, specifically means and standard deviations, were calculated for importance and perceived attainment/satisfaction across competency domains. An importance–satisfaction gap analysis was conducted using Δ (I − S), where positive values indicate high importance but insufficient attainment, and negative values indicate attainment exceeding importance. The results informed the prioritization of competencies for programlevel improvement. 

Qualitative analysis. Open-ended responses were analyzed through qualitative content analysis (Elo & Kyngäs, 2008). Responses were coded and organized into themes aligned with competency domains and school-based professional requirements, including multiinstrumental versatility, ensemble leadership, digital and AI-supported pedagogy, technical resource management, educational administration, and curriculum coherence. These themes informed the interpretation of quantitative gaps and the refinement of structurally actionable competency statements for curriculum redesign. 

JCSR 2026, 8(2):113-137 

119 

Document analysis and alignment diagnosis. Curriculum documents were reviewed to examine alignment among (a) stated outcomes (PLOs/CLOs), (b) learning experiences, and (c) assessment evidence at the program level. Findings were triangulated with survey gap patterns and qualitative themes to determine whether the discrepancies reflected structural curriculum issues rather than isolated course-level weaknesses. 

## _Evidence Synthesis and Model Development_ 

Evidence from the three analytic strands, quantitative gap analysis, qualitative themes, and document-based alignment diagnosis, was synthesized through a structured curriculum redesign process, as described by McKenney and Reeves (2018). The process comprised four steps: 

- (1) Derivation of stakeholder expectations (VOS). Quantitative priorities and qualitative themes were consolidated into Voice of Stakeholders (VOS) domains. 

(2) Translation into an integrated competency framework. VOS domains were clustered into coherent competency dimensions to ensure program-level developmental logic and reduce fragmentation. 

- (3) Formulation and mapping of PLOs. The competency framework was translated into PLOs (PLO1–PLO6), and alignment mapping ensured traceability between VOS domains and PLOs. 

(4) Standards legitimacy checks and operationalization. PLOs were mapped to the domains of the Thailand Qualifications Framework and aligned with AUN-QA expectations. Competencies were operationalized within the curriculum structure, including course clusters and sequencing, 

as well as pedagogical strategies and assessment practices, resulting in the proposed Stakeholder-Informed Structural Alignment Model. 

## _Ethical Considerations_ 

This study received ethical approval from the Institutional Ethics Committee for Research Involving Human Subjects (Approval No. 703–734/2025). All participants were informed of the study’s objectives, procedures, potential risks and benefits, their right to withdraw at any time without penalty, and the measures taken to ensure confidentiality. Written informed consent was obtained before participation. All data were securely stored and reported anonymously in accordance with established ethical standards for research involving human subjects. 

## **FINDINGS** 

## _Stakeholder Analysis: Identifying Competency Priorities and Gaps_ 

The investigation of stakeholder expectations regarding graduate competencies in the Bachelor of Education in Music Education program was conducted within the framework of stakeholder theory, which posits that educational institutions should consider the interests of individuals and organizations that both influence and are influenced by program operations (Freeman, 1984). In contemporary higher education, this perspective has evolved to emphasize value cocreation and systematic engagement with diverse constituencies to ensure that curriculum development authentically reflects professional and societal expectations (Langrafe et al., 

JCSR 2026, 8(2):113-137 

120 

2020). The application of this framework enabled the findings to be translated into empirically grounded revisions of learning outcomes and program structure. 

Data were collected through a five-point Likert-scale questionnaire supplemented by openended items from 82 respondents, including current students, alumni, practicing music teachers, school administrators, graduate employers, and program faculty members. The inclusion of multiple stakeholder groups allowed the analysis to reflect perspectives from learners, practitioners in school settings, and policy-level decision-makers within the program, thereby ensuring contextual validity in the interpretation of results for music teacher education at the higher education level. The distribution of respondents is presented in Table 1. **Table 1.** 

## _Profile of Respondents_ 

|**Status of Respondents**|**Frequency**|**Percentage**|
|---|---|---|
|Secondary students / prospective applicants|1|1.2|
|Alumni (B.Ed. Music Education)|15|18.3|
|Music teachers / civil servant teachers|22|26.8|
|Freelance music professionals|3|3.7|
|School administrators|5|6.1|
|Program faculty members|5|6.1|
|Current students|30|36.6|
|Student teachers (teaching practicum)|1|1.2|
|Fourth-year B.Ed. Music Education students|1|1.2|
|**Total**|**82**|**100.0**|



As shown in Table 1, the 82 respondents represented diverse stakeholder groups. The largest proportion comprised current students (36.6%), followed by practicing music teachers or civil servant teachers (26.8%) and alumni of the program (18.3%). School administrators, program faculty members, and freelance music professionals together accounted for 15.9% of the sample. This distribution ensured representation of learners, graduate employers, and curriculum decision-makers, aligning with multi-stakeholder approaches to curriculum development in higher education (Olo et al., 2021). The composition of the sample thus provided a robust empirical foundation for analyzing competency priorities and identifying structural gaps within the program. 

Following the analysis of respondent characteristics, competency expectations were examined across domains to determine their relative priority from stakeholders’ perspectives. This ranking process is consistent with evidence-informed approaches to competency specification and prioritization in higher education curricula (Montrosse-Moorhead et al., 2022). The results, presented in Table 2, reflect both areas of strong consensus and domains requiring 

JCSR 2026, 8(2):113-137 

121 

further structural development at the program level. These findings constitute a critical basis for subsequent competency gap analysis and structural curriculum diagnosis. 

## **Table 2.** 

Overall Competency Expectations of Graduates from Stakeholders’ Perspectives 

|**Competency Domain**|**Mean**|**S.D.**|**Level**|
|---|---|---|---|
|Moral integrity, ethics, and professional teaching conduct|4.72|0.38|Very high|
|Lifelong learning and continuous professional development|4.45|0.52|High|
|Communication and interpersonal interaction|4.38|0.56|High|
|Musical proficiency (practical performance)|3.28|0.71|Moderate|
|Instructional technology use|3.12|0.76|Moderate|
|Instructional innovation|3.05|0.82|Moderate|
|Conducting diverse ensembles|3.22|0.74|Moderate|
|Budget and administrative management|3.18|0.79|Moderate|



Classification criteria: 4.50–5.00 = very high, 3.50–4.49 = high, 2.50–3.49 = moderate, 1.50–2.49 = low, and 1.00–1.49 = very low. 

As presented in Table 2, the analysis of overall competency expectations indicates that moral integrity, ethics, and professional teaching conduct received the highest mean score, accompanied by the lowest standard deviation, reflecting strong consensus among stakeholders regarding the foundational importance of ethical and professional dispositions in music teacher education. Lifelong learning and communication competencies followed, underscoring expectations that graduates should continuously develop themselves and function as reflective and collaborative practitioners. Notably, competencies related to practical musical proficiency and ensemble conducting were rated at a moderate level of importance. This pattern suggests that stakeholders tend to place greater emphasis on ethical responsibility, professional growth, and adaptability than on technical virtuosity. In other words, music teachers are generally expected to demonstrate well-rounded musical capability across instruments and ensembles rather than exceptional specialization in a single instrument. These findings align with contemporary perspectives on twenty-first-century teacher development, which emphasize ethical professionalism, adaptability, and lifelong learning as core attributes of effective educators (Garzón Artacho et al., 2020). 

In contrast, competencies related to practical musical proficiency, instructional technology, pedagogical innovation, ensemble conducting, and administrative management received comparatively lower mean scores and demonstrated greater variability. This distribution suggests areas requiring further structural enhancement, particularly those linked to authentic professional practice within school contexts. The results therefore provide a critical empirical foundation for competency gap analysis and structural curriculum diagnosis, 

JCSR 2026, 8(2):113-137 

122 

consistent with quality assurance principles emphasizing evidence-based program improvement (Dervenis et al., 2022). 

## **Table 3.** 

Stakeholders’ Satisfaction with Graduate Competencies (n = 82) 

|**Competency Domain**|**Mean**|**S.D.**|**Level**|
|---|---|---|---|
|Moral integrity, ethics, and professional teaching conduct|4.18|0.54|High|
|Lifelong learning and continuous professional development|3.42|0.68|Moderate|
|Communication and interpersonal interaction|3.48|0.63|Moderate|
|Musical proficiency (practical performance)|4.36|0.49|High|
|Instructional technology use|4.05|0.61|High|
|Instructional innovation|4.02|0.65|High|
|Conducting diverse ensembles|4.30|0.52|High|
|Budget and administrative management|3.35|0.70|Moderate|



Classification criteria applied consistently throughout the study: 4.50–5.00 = very high, 3.50– 4.49 = high, 2.50–3.49 = moderate, 1.50–2.49 = low, and 1.00–1.49 = very low. 

As shown in Table 3, overall stakeholder satisfaction with graduate competencies ranged from moderate to high. Competencies rated at a high level included practical musical proficiency, ensemble conducting, instructional technology use, pedagogical innovation, and professional ethics. These findings suggest that graduates demonstrate strengths in practical performance skills and the application of instructional tools in authentic contexts. Such results are consistent with systematic reviews indicating that effective music teachers require integrated expertise in musical performance, pedagogical knowledge, and context-responsive instructional practices (Concina, 2023). 

Within the stakeholder theory framework, the analysis identified both competency priorities and structural gaps within the Bachelor of Education in Music Education program. As shown in Table 4, the largest positive discrepancies were found in lifelong learning (Δ = 1.03) and communication (Δ = 0.90), followed by professional ethics (Δ = 0.54), indicating competencies perceived as highly important yet insufficiently reinforced in the current curriculum. In contrast, musical proficiency and ensemble conducting showed negative discrepancies, suggesting comparatively stronger perceived attainment relative to stakeholderprioritized importance. 

Such discrepancy patterns align with gap-based curriculum diagnostics in higher education, where differences between importance and perceived attainment reveal structural misalignment at the program level (Biggs & Tang, 2003). From a stakeholder governance perspective, these findings indicate systemic alignment tensions rather than isolated courselevel weaknesses (Alexander & Hjortsø, 2019; Freeman, 1984). Collectively, the results provide 

JCSR 2026, 8(2):113-137 

123 

empirical justification for revising Program Learning Outcomes and strengthening curriculum alignment mechanisms under the OBE framework. 

**Table 4.** 

_Importance–Satisfaction Gap Analysis of Graduate Competencies (n = 82)_ 

|**Competency Domain**|**Importance**<br>**Mean**|**Satisfaction**<br>**Mean**|**Δ (I − S)**|**Interpretation**|
|---|---|---|---|---|
|Moral integrity, ethics, and<br>professional<br>teaching<br>conduct|4.72|4.18|**0.54**|Expectation higher than<br>satisfaction (gap)|
|Lifelong<br>learning<br>and<br>continuous<br>professional<br>development|4.45|3.42|**1.03**|**Largest gap**(priority<br>area for improvement)|
|Communication<br>and<br>interpersonal interaction|4.38|3.48|**0.90**|Notable<br>gap<br>(needs<br>strengthening)|
|Musical proficiency (practical<br>performance)|3.28|4.36|**−1.08**|Satisfaction<br>exceeds<br>expectation (strength)|
|Instructional technology use|3.12|4.05|**−0.93**|Satisfaction<br>exceeds<br>expectation (strength)|
|Instructional innovation|3.05|4.02|**−0.97**|Satisfaction<br>exceeds<br>expectation (strength)|
|Conducting<br>diverse<br>ensembles|3.22|4.30|**−1.08**|Satisfaction<br>exceeds<br>expectation (strength)|
|Budget and administrative<br>management|3.18|3.35|**−0.17**|Slightly<br>exceeds<br>expectation<br>(near<br>balance)|



## _Competency Gaps and Structural Misalignment under OBE_ 

Within the Outcome-Based Education (OBE) framework, a high-quality curriculum requires systematic constructive alignment among Expected Learning Outcomes (ELOs), learning activities, and assessment methods. However, the stakeholder analysis revealed discrepancies between the perceived importance of competencies and satisfaction with graduates’ 

performance, indicating preparation gaps in specific domains. Variability across certain competencies may reflect misalignment between the curriculum and authentic professional practice contexts. These findings align with literature on employability gaps and curriculum alignment, which emphasizes the need to bridge stakeholder expectations and actual graduate capabilities (Alwi & Karim, 2024). Moreover, analyzing differences between expected competencies and stakeholder satisfaction represents a structured importance–performance gap analysis approach consistent with stakeholder-informed quality development models in 

JCSR 2026, 8(2):113-137 

124 

higher education (Degtjarjova et al., 2018). Table 4 provides a quantitative basis for this analysis. When examined alongside qualitative data from open-ended responses, additional structural issues become evident. Music teachers and school administrators highlighted practical competencies that were not systematically integrated into the existing curriculum, as summarized in Table 5. 

## **Table 5.** 

_Thematic Analysis of Stakeholder-Identified Competency Gaps and Structural Implications_ 

|**Thematic Domain**|**Competency Identified**|**Structural Imp**|**lication**|
|---|---|---|---|
|Multi-instrumental<br>Versatility|Functional<br>proficiency<br>across<br>multiple musical traditions|Curriculum<br>instrumental<br>applied bread|emphasizes<br>depth<br>over<br>th|
|School-Based|Establishment and management of|School-contex|t competencies|
|Ensemble Leadership|diverse school ensembles|insufficiently<br>ELOs|articulated in|
|Digital Music Pedagogy|Integration of DAWs and AI in<br>instructional practice|Limited<br>int<br>emerging<br>competencies|egration<br>of<br>digital<br>|
|Technical<br>Resource<br>Management|Instrument maintenance and sound<br>system operation|Lack of struct<br>provision|ured curricular|
|Educational<br>Administration|Proposal writing, budgeting, and<br>documentation|Practical<br>competencies<br>underreprese|professional<br> <br>nted in PLOs|
|Curriculum Coherence|Balance<br>between<br>disciplinary<br>practice and coursework|Evidence of<br>learning misal|program-level<br>ignment|



The qualitative findings confirm that schools expect music teachers to demonstrate multi-instrument proficiency across Thai, Western, and folk traditions; establish and manage diverse ensembles; and possess competencies in sound system management, instrument maintenance, and administrative tasks within school settings. Stakeholders further emphasized the need for digital music competencies, including the use of digital audio workstations (DAWs) and AI-based tools for instructional media production, reflecting the emergence of hybrid professional roles in twenty-first-century music education. 

These findings resonate with the concept of broad musicianship, which emphasizes versatile practical competence rather than narrow specialization (Partti & Karlsen, 2010). Research in music teacher preparation similarly highlights ensemble leadership experience and authentic contextual practice as critical components of professional readiness (Conway, 2012). Moreover, the integration of music technology has become a core competency for contemporary educators (Savage, 2017). From an OBE perspective, such expectations 

JCSR 2026, 8(2):113-137 

125 

underscore the need to articulate clear and measurable learning outcomes aligned with authentic learning experiences to achieve systematic constructive alignment (Biggs & Tang, 

## 2003). 

Overall, the competency gaps identified through both quantitative and qualitative data extend beyond differences in satisfaction levels; they reveal structural misalignment under OBE among learning outcomes, learning experiences, and assessment practices. The existing curriculum appears to prioritize depth in a principal instrument over the breadth of competencies required in school contexts. Consequently, the program must revise its ELOs to reflect measurable competencies, integrate authentic school-based learning experiences, and strengthen evidence-based assessment systems. Such reforms are essential for achieving full constructive alignment and reducing the persistent gap between specialized musician identity and the practical professional role of music teachers in educational settings. 

_Emergent Integrated Music Teacher Competency Framework_ 

The design and development of the Bachelor of Education in Music Education curriculum in this study were undertaken within the framework of Outcome-Based Education (OBE) and the quality assurance criteria of the ASEAN University Network (AUN-QA). The curriculum development process adhered to the principle of explicitly defined and measurable learning outcomes that are systematically aligned with teaching and learning processes and assessment practices. This approach is consistent with OBE’s backward design logic, which begins with clearly articulated outcomes to ensure that graduates attain the intended competencies (Rao, 2020). The curriculum reform was grounded in evidence-based decision-making and stakeholder-informed alignment to ensure that learning outcomes respond meaningfully to authentic school contexts while maintaining compliance with national and regional standards. 

The development process began with the synthesis of stakeholder expectations, referred to as the Voice of Stakeholders (VOS), which revealed six principal domains: (1) intensive and versatile musical performance skills; (2) professional teaching competence and ethical responsibility; (3) active and project-based pedagogical approaches; (4) digital music technology and AI integration; (5) integration of local and global musical cultures; and (6) ethical development alongside lifelong learning. This approach aligns with participatory curriculum development frameworks that emphasize the integration of diverse stakeholder perspectives to ensure professional and labor market relevance (Olo et al., 2021). Contemporary scholarship on stakeholder engagement in higher education further indicates that systematic stakeholder participation plays a critical role in enhancing curriculum quality and contextual responsiveness (Crocco et al., 2022). 

Based on this foundation, the VOS data were systematically categorized and translated into Program Learning Outcomes (PLO1–PLO6) through an iterative synthesis process. PLO1 emphasizes professional identity and ethical responsibility; PLO2 focuses on disciplinary knowledge and musical proficiency; PLO3 addresses analytical thinking and pedagogical innovation; PLO4 centers on instructional leadership and school-based practice; PLO5 targets 

JCSR 2026, 8(2):113-137 

126 

digital and music technology competence; and PLO6 integrates applied musicianship with sustainable professional development. As illustrated in Table 6, this mapping reflects structural coherence between stakeholder-derived priorities and the competency framework while accommodating overlap and potential tension across domains. Rather than a direct one-to-one transformation, the alignment process involved the prioritization, integration, and balancing of competing expectations to ensure that curriculum architecture remained grounded in empirically identified field demands while retaining conceptual coherence. **Table 6.** 

_Stakeholder-Informed Alignment between VOS and PLOs_ 

|**VOS Domain**|**Core Expectation**|**Aligned PLO(s)**|**Alignment Emphasis**|
|---|---|---|---|
|VOS1: Musical<br>Practice|Multi-instrument<br>proficiency<br>and<br>ensemble<br>leadership|PLO2, PLO3|Applied<br>disciplinary<br>breadth|
||(Thai–local–Western)|||
|VOS2:<br>Professional<br>Teacher Role|Pedagogical competence and<br>ethical professionalism|PLO1, PLO4|Professional<br>identity<br>and responsibility|
|VOS3:|Project-based and authentic|PLO3, PLO4|Higher-order<br>and|
|Experiential<br>Learning|school-based practice||collaborative<br>competence|
|VOS4: Digital &<br>AI Competence|Digital music technology and AI<br>integration|PLO3,<br>PLO5,<br>PLO6|Digital<br>pedagogical<br>innovation|
|VOS5: Cultural<br>Integration|Local–global<br>musical<br>integration and intercultural<br>literacy|PLO2, PLO6|Cultural synthesis and<br>adaptability|
|VOS6: Ethics &<br>Lifelong<br>Learning|Moral integrity and sustained<br>professional growth|PLO1,<br>PLO4,<br>PLO6|Ethical sustainability|



Although Table 6 presents a structured alignment between VOS domains and PLOs, the translation process was not without complexity. In practice, certain stakeholder expectations reflected competing priorities, particularly between the depth of musical specialization and the need for broad pedagogical and professional competencies. These tensions were addressed through iterative comparison and weighting of stakeholder inputs, in which competencies demonstrating strong consensus and relevance to professional practice were given greater emphasis. Overlapping competencies were integrated into composite outcome statements, and in cases of potential conflict, emphasis was placed on achieving balance rather than exclusion. This approach reflects curriculum design as a process of negotiation among multiple expectations rather than a direct linear mapping from input to outcome. 

JCSR 2026, 8(2):113-137 

127 

As shown in Table 6, the alignment between VOS domains and PLOs reveals an underlying conceptual structure within the developed competency framework: 

- (1) disciplinary–musical competence, emphasizing musical expertise and applied performance capability; 

- (2) higher-order and innovative pedagogical competence, focusing on advanced thinking skills and instructional innovation; 

- (3) professional identity and leadership, highlighting ethical responsibility and professional agency; and 

- (4) digital and intercultural competence, integrating technological proficiency with local–global cultural awareness. 

This dimensional clustering reflects a purpose-led competency framework development process grounded in contextual needs. It aligns with conceptualizations of competency framework design that emphasize structured synthesis derived from authentic professional practice contexts (Child & Shaw, 2020). Furthermore, the explicit inclusion of digital and intercultural competencies corresponds with contemporary higher education teacher competency frameworks that position digital competence as a core dimension of professional teaching expertise (Tondeur et al., 2023). Collectively, the four-dimensional structure demonstrates that the proposed framework constitutes a needs-based structural synthesis rather than a fragmented or checklist-style articulation of outcomes. 

To ensure standards legitimacy and national comparability, the formulated PLOs must also demonstrate alignment with the Thailand Qualifications Framework for Higher Education (TQF), particularly across the domains of Knowledge, Skills, Ethics, and Character. The subsequent analysis therefore examines the extent to which PLO1–PLO6 comprehensively address and operationalize the TQF dimensions in measurable and behaviorally explicit terms, as presented in Table 7. 

Table 7 demonstrates that all Program Learning Outcomes (PLOs) comprehensively align with the Thailand Qualifications Framework for Higher Education (TQF) across the four principal domains: Knowledge (K), Skills (S), Ethics (E), and Character (C). PLO2 and PLO3 play prominent roles in supporting disciplinary knowledge and analytical thinking, while PLO5 and PLO6 clearly strengthen competencies related to digital literacy, innovation, and applied professional practice. Meanwhile, PLO1 and PLO4 function as integrative anchors that connect the Ethical and Character domains with the practical enactment of the professional teacher role. 

This systematic distribution of PLO functions reflects a balanced structural relationship between national qualification standards and the distinctive competency identity of the program. Such alignment is consistent with the principles of constructive alignment, which emphasize coherent relationships among learning outcomes, learning activities, and assessment practices as mechanisms for educational quality enhancement (Loughlin et al., 2021). 

Positioning PLOs to comprehensively address all TQF domains through a clear structural rationale strengthens both standards legitimacy and contextual relevance within the Outcome- 

JCSR 2026, 8(2):113-137 

128 

Based Education framework. This approach aligns with curriculum mapping principles, which highlight the importance of making explicit and verifiable connections among qualification frameworks, learning outcomes, and curriculum structures (Anderson et al., 2025). **Table 7.** 

_Alignment between TQF Domains and Program Learning Outcomes (PLOs)_ 

|**TQF**<br>**Domain**|**Core Focus**|**Aligned PLO(s)**|**Alignment Rationale (Concise)**|
|---|---|---|---|
|K1|Disciplinary music<br>knowledge|PLO2, PLO5|PLO2 ensures disciplinary breadth; PLO5<br>strengthens<br>digital<br>and<br>technological<br>dimensions|
|K2|Pedagogical<br>and<br>research<br>knowledge|PLO4, PLO3|PLO4<br>operationalizes<br>professional<br>teaching; PLO3 supports analytical and<br>research capacity|
|S1|Performance<br>and<br>ensemble<br>competence|PLO6, PLO2|PLO6 reflects applied production; PLO2<br>provides theoretical foundation|
|S2|Analytical<br>and<br>instructional<br>decision-making|PLO3, PLO4|PLO3 aligns with higher-order thinking;<br>PLO4 supports contextual application|
|S3|Communication<br>and digital learning<br>design|PLO5, PLO4|PLO5 anchors digital pedagogy; PLO4<br>reinforces professional communication|
|S4|Innovation<br>and<br>technology-based<br>development|PLO3,<br>PLO5,<br>PLO6|Integrated<br>innovation–digital–creative<br>competence|
|E1–E2|Professional ethics<br>and responsibility|PLO1, PLO4|Ethical foundation (PLO1) integrated with<br>professional accountability (PLO4)|
|C1–C2|Professional<br>identity<br>and<br>leadership|PLO4, PLO1|Leadership and identity anchored in<br>professional and ethical domains|



In summary, the development of the Emergent Integrated Music Teacher Competency Framework in this study reflects a systematic curriculum design process that logically connects stakeholder expectations (VOS) with Program Learning Outcomes (PLOs) under the frameworks of Outcome-Based Education and AUN-QA. The resulting competency framework is integrative, encompassing disciplinary musical expertise, higher-order and innovative pedagogical competence, professional teacher identity, digital capability, and intercultural integration within local–global contexts. Moreover, its comprehensive alignment with the TQF across 

JCSR 2026, 8(2):113-137 

129 

knowledge, skills, ethics, and character domains ensures both standards legitimacy and professional contextual relevance. Rather than functioning merely as a set of learning outcomes, the framework constitutes an integrated structural model that systematically connects stakeholder alignment, constructive alignment, and quality assurance alignment. This integrated approach corresponds with scholarship indicating that the alignment of national qualification frameworks with learning outcomes, teaching strategies, and assessment systems is a critical mechanism for strengthening systemic coherence and standards legitimacy in higher education (Elhakim & Alhosani, 2022). Consequently, the proposed framework offers a significant model for music teacher curriculum development at the higher education level. 

_Operationalization of Stakeholder-Informed Competencies into Curriculum Structure_ 

Following the synthesis of stakeholder expectations (VOS), the formulation of Program Learning Outcomes (PLO1–PLO6), and the development of an integrated music teacher competency framework, a critical phase of curriculum development involved translating these competencies into an operational curriculum structure and implementation system. Guided by the principles of Outcome-Based Education (OBE) and the AUN-QA framework as systemic quality assurance mechanisms, this phase focused on aligning competencies with curriculum categories, yearlevel sequencing, learning strategies, and assessment systems in a logically coherent manner. This approach reflects contemporary perspectives on institutional-level implementation of competency-based education, emphasizing structured mechanisms for translating competency frameworks into tangible curriculum architecture (Chen et al., 2024). 

Structurally, disciplinary musical knowledge and applied competence (PLO2, PLO3) were positioned as foundational components within general and major subject clusters to ensure comprehensive coverage across Thai, folk, and Western musical traditions, alongside analytical and applied dimensions. Professional teacher identity and ethical responsibility (PLO1, PLO4) were embedded within teacher education and practicum components to cultivate ethical conduct, leadership capacity, and sustained readiness for authentic school contexts. Digital and innovation-related competencies (PLO3, PLO5, PLO6) were integrated into technology-oriented and creative project modules, directly responding to VOS findings that emphasized digital literacy, AI integration, and the production of practice-oriented outputs applicable in real school settings. Such structuring aligns with the use of competency maps to systematically connect program-level outcomes with course architecture (Biggs & Tang, 2003), as well as approaches that embed key competencies through integrated course design and sequenced curricular progression (Chan, 2019). 

From a developmental perspective, the curriculum follows a backward design logic, sequencing competencies from foundational knowledge to higher-order thinking and innovation, and ultimately toward authentic professional enactment. This structure corresponds with Agile Backward Design models, which advocate defining program-level outcomes prior to systematic course structuring (Dazeley et al., 2025). Such progression enables staged competency development through progressively complex learning experiences. It 

JCSR 2026, 8(2):113-137 

Boonsrianan et al. 



<!-- Start of picture text -->
Quality Governance Framework: AUN-QA & TOF<br>Voice of Stakeholders (VOS) Integrated Competency Framework<br>|<br>| Programme Learning Outcomes (PLOs} |<br>| |<br>| Curriculum Architecture & Sequencing<br>Assessment & Quality |<br>\ Pedagogy Assurance }<br>™. Feedback & Continuous Improvement —<br><!-- End of picture text -->

curriculumstudies.org 

131 

mechanisms that function in an integrated manner. Such systemic operationalization constitutes a critical condition for strengthening both contextual responsiveness and standards legitimacy under the AUN-QA framework. The structured process through which competencies are translated into educational practice is summarized in Figure 1. 

## **DISCUSSION** 

The findings of this study indicate that the discrepancy between the perceived importance of competencies and satisfaction with graduate performance does not merely reflect perceptual differences; rather, it signals structural imbalance within the music teacher education curriculum in higher education. Stakeholders placed the highest importance on ethics, professionalism, and lifelong development, whereas satisfaction levels were comparatively higher in practical musical performance and ensemble leadership. This pattern suggests that the existing curriculum has been relatively effective in developing musical skills but has not systematically embedded professional and school-context competencies within its structural design. The divergence therefore points to the need for structural curriculum reform rather than isolated course-level adjustments. This interpretation aligns with critiques of constructive alignment, which argue that documented or formally designed alignment does not necessarily translate into authentic alignment in practice if systemic program-level structuring is absent (Romanowski et al., 2024). Similarly, research on teacher education quality assurance emphasizes that quality mechanisms influence learning outcomes only when embedded within program structures rather than operating as procedural formalities (Ahmed et al., 2025). 

From an Outcome-Based Education (OBE) perspective, the issue identified does not stem from the absence of learning outcomes, but from their formulation in broad and insufficiently behaviorally explicit terms. Such ambiguity directly affects the design of learning activities and assessment practices, limiting the program’s capacity to generate verifiable competency evidence at the program level. This concern resonates with scholarship on curriculum coherence, which underscores that transforming learning outcomes into measurable indicators requires systematic alignment between CLOs and PLOs, supported by program-level feedback mechanisms, rather than merely articulating outcomes in textual form (Derouich, 2025). Accordingly, effective implementation of OBE must operate at the structural level of the entire curriculum to ensure traceable coherence among outcomes, activities, and assessment, rather than relying solely on textual revision of PLO statements. 

Stakeholder theory played a structurally significant role in this study. Input from graduate employers and school administrators was not used merely to validate findings but to inform the formulation of the competency framework and its alignment with national and regional standards. This approach aligns with participatory curriculum development literature, which demonstrates that stakeholder engagement can shape program-level structural design rather than serving solely as a post hoc validation mechanism (Alexander & Hjortsø, 2019). Furthermore, linking stakeholder-derived competencies with the Thailand Qualifications 

JCSR 2026, 8(2):113-137 

132 

Framework (TQF) and AUN-QA criteria reflects a governance-oriented perspective that positions stakeholder engagement as an integral component of quality assurance systems rather than a symbolic or isolated consultative exercise (Beerkens & Udam, 2017). The novelty of this study lies in integrating stakeholder alignment with quality assurance alignment within a unified structural framework, thereby ensuring that defined competencies possess both contextual responsiveness and standards legitimacy. 

The synthesis of an integrated music teacher competency framework reduces the fragmentation often associated with outcome specification by clustering interrelated competencies into coherent developmental dimensions. Employing backward curriculum design and structuring progression along a foundation–development–professionalization continuum enables competencies to be systematically embedded within course clusters, learning strategies, and assessment systems. The integration of rubric-based assessment, portfolio evaluation, and multi-source assessment strengthens the program’s capacity to generate verifiable program-level evidence of learning outcome attainment. Research in program assessment underscores that clearly structured assessment systems at departmental and institutional levels are essential for sustaining assurance of learning processes, particularly when assessment is embedded within formal governance mechanisms (Gray et al., 2022). This aligns with AUN-QA’s emphasis on program-level outcome evidence and systematic quality assurance processes. 

In summary, this study demonstrates that music teacher curriculum development should be undertaken at the structural level by systematically connecting stakeholder expectations, outcome specification, curriculum design, and quality assurance mechanisms. Such an approach is consistent with foundational principles of objective-based curriculum design emphasizing clarity of learning outcomes (Tyler, 2013) and constructive alignment theory, which stresses coherence among outcomes, learning activities, and assessment at the program level (Biggs, 1996). At the same time, integrating stakeholder-derived evidence reflects stakeholder theory’s premise that organizational direction should systematically consider the expectations of relevant constituencies (Freeman, 1984). This structural approach reduces competency misalignment and enables the curriculum to balance contextual responsiveness with compliance with national and regional quality standards. 

Despite the theoretical and practical contributions of this study, several limitations should be acknowledged. First, the findings are primarily based on stakeholder perceptions rather than direct measures of graduate performance, which may not fully represent actual competency attainment in practice. Second, the study did not incorporate performance-based or longitudinal data to validate the alignment between the proposed curriculum structure and real graduate outcomes. Third, although purposive sampling ensured contextual relevance, the relatively small number of participants in certain stakeholder subgroups limits the extent to which the findings can be generalized across broader populations. Accordingly, the proposed framework should be interpreted as a context-specific and exploratory structural model rather 

JCSR 2026, 8(2):113-137 

133 

than a definitive or universally generalizable solution. Future research should incorporate performance-based assessment data, larger and more balanced stakeholder samples, and longitudinal tracking of graduate outcomes to further validate and refine the proposed curriculum model. 

## **CONCLUSION** 

This study proposes a program-level model for music teacher curriculum development that systematically integrates stakeholder analysis, Outcome-Based Education (OBE), and quality assurance mechanisms within a unified curriculum architecture. The findings demonstrate that competencies can be systematically synthesized, translated, and structurally embedded into program learning outcomes, course structures, and assessment evidence in a traceable and verifiable manner. The principal contribution of this study lies in elevating stakeholder alignment from a consultative or data-gathering exercise to a structural governance mechanism within curriculum design. Nevertheless, the study is limited to a single institutional context and relies primarily on perception-based data. Future research should therefore examine the longterm implementation of the revised curriculum and evaluate graduate competencies through authentic performance-based evidence. Longitudinal assessment would provide stronger empirical validation of the sustainability and effectiveness of the proposed framework. 

## **Funding** 

This research project was financially supported by the College of Music, Mahasarakham University, Thailand. 

## **REFERENCES** 

- Ahmed, S. N., Choudhry, L., Rasool, K., & Hamid, S. (2025). Examining the impact of accreditation on teacher education quality in Pakistan: Institutional performance and pre-service teacher outcomes. _Social Sciences Spectrum_ , 4(4), 42-64. <u>htps://doi.org/10.71085/sss.04.04.360</u> 

- Alexander, I. K., & Hjortsø, C. N. (2019). Sources of complexity in participatory curriculum development: An activity system and stakeholder analysis approach to the analyses of tensions and contradictions. _Higher Education_ , 77(2), 301-322. 

   - <u>htps://doi.org/10.1007/s10734-018-0274-x</u> 

- Alwi, S. K. K., & Karim, A. A. (2024). Bridging the Employability Gap: Aligning Higher Education Curricula with Industry-Required Competencies in the Digital Era. _Journal Of Business Strategies_ , 18(2), 93-110. htps://doi.org/10.29270/JBS.18.2(24).06 

- Amirgalina, N., Slambekova, T., Kazhimova, K., Issayeva, G., & Taspayeva, S. (2025). Effect of Practice-Oriented Courses in the Study of Natural Sciences on the Development of Professional Qualities in College Students. _Journal of Curriculum Studies Research, 7_ (2), 114-139. https://doi.org/10.46303/jcsr.2025.14 

JCSR 2026, 8(2):113-137 

134 

Anderson, S., McLaren, E., & Mio, C. (2025). Mapping curriculum in higher education: Unveiling 

alignment, complexity, and ideology. _Open Scholarship of Teaching and Learning_ , 4(1), 181-207. <u>htps://doi.org/10.56230/osotl.110</u> 

ASEAN University Network. (2020). _Guide to AUN-QA Assessment at Programme Level_ . 

- Beerkens, M., & Udam, M. (2017). Stakeholders in higher education quality assurance: 

   - Richness in diversity? _Higher Education Policy_ , 30(3), 341-359. 

   - <u>htps://doi.org/10.1057/s41307-016-0032-6</u> 

- Biggs, J. (1996). Enhancing teaching through constructive alignment. _Higher Education_ , 32(3), 347-364. <u>htps://doi.org/10.1007/BF00138871</u> 

- Biggs, J., & Tang, C. (2003). _Teaching for quality learning at university_ (4th ed.). Open University Press. 

- Chan, C. K. Y. (2019). Embedding skills development into the curriculum. In S. Marshall (Ed.), _A Handbook for Teaching and Learning in Higher Education_ (pp. 123-134). Routledge. 

- Chen, A. M., Kleppinger, E. L., Churchwell, M. D., & Rhoney, D. H. (2024). Examining 

   - competency-based education through the lens of implementation science: a scoping review. _American journal of pharmaceutical education_ , 88(2), 100633. <u>htps://doi.org/10.1016/j.ajpe.2023.100633</u> 

Cheung, K. S., Geertshuis, S., Liu, Q., & Albashiry, N. (2026). A systematic curriculum 

- intervention: Embedding employability through constructive alignment to enhance student learning. _The Curriculum Journal_ , 37(1), 1-19. 

<u>htps://doi.org/10.1002/curj.70016</u> 

- Child, S. F., & Shaw, S. D. (2020). A purpose-led approach towards the development of 

   - competency frameworks. _Journal of Further and Higher Education_ , 44(8), 1143-1156. <u>htps://doi.org/10.1080/0309877X.2019.1669773</u> 

- Clark, T., & Foster, L. (2023). Active learning, constructive alignment, and research methods: Toward a programme level approach. In N. Melanie (Ed.), _Handbook of teaching and learning social research methods_ (pp. 119-133). Edward Elgar Publishing. 

- Concina, E. (2023). Effective Music Teachers and Effective Music Teaching Today: A Systematic Review. _Education Sciences_ , 13(2), 107. htps://doi.org/10.3390/educsci13020107 

- Conway, C. M. (2012). Ten Years Later:Teachers Reflect on “Perceptions of Beginning Teachers, Their Mentors, and Administrator Regarding Preservice Music Teacher Preparation”. _Journal of Research in Music Education_ , 60(3), 324-338. 

   - <u>htps://doi.org/10.1177/0022429412453601</u> 

- Creswell, J. W., & Clark, V. L. P. (2018). _Designing and conducting mixed methods research_ (3rd ed.). SAGE Publications. 

- Crocco, E., Giacosa, E., & Culasso, F. (2022). Stakeholder engagement in higher education: State of the art and research agenda. _IEEE Transactions on Engineering Management_ , 71, 13457-13468. htps://doi.org/10.1109/TEM.2022.3218286 

JCSR 2026, 8(2):113-137 

135 

Dazeley, R., Goriss-Hunter, A., Meredith, G., Sellings, P., Firmin, S., Burke, J., & Panther, B. 

- (2025). Agile Backward Design: A Framework for planning higher education curriculum. _The Australian Educational Researcher_ , 52(2), 1489-1508. 

<u>htps://doi.org/10.1007/s13384-024-00772-7</u> 

- Degtjarjova, I., Lapina, I., & Freidenfelds, D. (2018). Student as stakeholder:" voice of customer" in higher education quality development. _Marketing and Management of Innovations_ , 2, 388–398. htps://doi.org/10.21272/mmi.2018.2-30 

- Derouich, M. (2025). Ensuring outcome-based curriculum coherence through systematic CLO– PLO alignment and feedback loops. _Discover Education_ , 4(1), 486. <u>htps://doi.org/10.1007/s44217-025-00915-7</u> 

- Dervenis, C., Fitsilis, P., & Iatrellis, O. (2022). A review of research on teacher competencies in higher education. _Quality Assurance in Education_ , 30(2), 199-220. 

<u>htps://doi.org/10.1108/qae-08-2021-0126</u> 

- Elhakim, A., & Alhosani, M. (2022). Faculty perceptions of the implementation of the United Arab Emirate's qualifications framework (QF Emirates) in federal higher education institutions. _International Journal of Educational Management_ , 36(5), 621-640. <u>htps://doi.org/10.1108/ijem-04-2021-0136</u> 

- Elo, S., & Kyngäs, H. (2008). The qualitative content analysis process. _Journal of Advanced Nursing_ , 62(1), 107-115. htps://doi.org/10.1111/j.1365-2648.2007.04569.x 

- Flores, M. A. (2016). Teacher education curriculum. _International Handbook of Teacher Education_ , 1, 187-230. htps://doi.org/10.1007/978-981-10-0366-0_5 

- Frank, J. R., Snell, L. S., Cate, O. T., Holmboe, E. S., Carraccio, C., Swing, S. R., Harris, P., Glasgow, 

   - N. J., Campbell, C., & Dath, D. (2010). Competency-based medical education: theory to practice. _Medical teacher_ , 32(8), 638-645. <u>htps://doi.org/10.3109/0142159X.2010.501190</u> 

Freeman, R. E. (1984). _Strategic management: A stokcholder approach_ . Pitman. 

- Garzón Artacho, E., Martínez, T. S., Ortega Martin, J. L., Marin Marin, J. A., & Gómez García, G. (2020). Teacher training in lifelong learning—The importance of digital competence in the encouragement of teaching innovation. _Sustainability_ , 12(7), 2852. <u>htps://doi.org/10.3390/su12072852</u> 

- Gray, D. M., Bennett, M., Smart, K., & Kumar, A. (2022). An analysis of university academic department bylaws to measure commitment to program assessment: A US case study. _Cogent Education_ , 9(1), 2113218. htps://doi.org/10.1080/2331186X.2022.2113218 

- Harden, R. M. (2007). Outcome-based education: the future is today. _Medical teacher_ , 29(7), 625-629. <u>htps://doi.org/10.1080/01421590701729930</u> 

- Johnson, O. C. B. (2017). _The impact of ASEAN university network-quality assurance (AUN-QA) assessment on the quality of educational programmes_ Theory and practice of quality and reliability engineering in Asia industry, 

JCSR 2026, 8(2):113-137 

136 

- Kuzembayeva, G., Yermekbayeva, G., Idrissov, S. & Maydangalieva, Z. (2025). Research Capabilities and Research Practices of Teacher Candidates, In-Service Teachers, and Teacher Educators in the Context of Research Capacity Building in Kazakhstan’s Language Teacher Education. _Journal of Social Studies Education Research, 16_ (2), 377399. https://jsser.org/index.php/jsser/article/view/6514/740 

- Langrafe, T. d. F., Barakat, S. R., Stocker, F., & Boaventura, J. M. G. (2020). A stakeholder theory approach to creating value in higher education institutions. _The Bottom Line_ , 33(4), 297313. htps://doi.org/10.1108/bl-03-2020-0021 

- Liao, Y.-C., & Ringler, M. (2023). Backward design: Integrating active learning into undergraduate computer science courses. _Cogent Education_ , 10(1), 2204055. <u>htps://doi.org/10.1080/2331186X.2023.2204055</u> 

- Liew, C. P., Puteh, M., Lim, L. L., Yu, L. J., Tan, J., Chor, W. T., & Tan, K. G. (2021). Evaluation of engineering students' learning outcomes: creating a culture of continuous quality improvement. _International Journal of Emerging Technologies in Learning_ , 16(15), 6277. htps://doi.org/10.3991/ijet.v16i15.23763 

- Likert, R. (1932). A technique for the measurement of at udes. _Archives of psychology_ . 

- Loughlin, C., Lygo-Baker, S., & Lindberg-Sand, Å. (2021). Reclaiming constructive alignment. _European Journal of Higher Education_ , 11(2), 119-136. <u>htps://doi.org/10.1080/21568235.2020.1816197</u> 

- McKenney, S., & Reeves, T. (2018). _Conducting educational design research_ (2nd ed.). Routledge. 

- Montrosse-Moorhead, B., Gambino, A. J., Yahn, L. M., Fan, M., & Vo, A. T. (2022). Evaluator Education Curriculum: Which Competencies Ought to Be Prioritized in Master’s and Doctoral Programs? _American Journal of Evaluation_ , 43(2), 269-292. <u>htps://doi.org/10.1177/10982140211020326</u> 

- Ndiangui, P., Mwangi, F., & Zhang, J. (2025). Enhancing Student Skills through the Integration of Online Learning in Kenya’s Competency-Based Curriculum (CBC). _Research in Social Sciences and Technology, 10_ (2), 1-35. https://doi.org/10.46303/ressat.2025.25 

- Olo, D., Correia, L., & Rego, C. (2021). How to develop higher education curricula towards employability? A multi-stakeholder approach. _Education + Training_ , 64(1), 89-106. <u>htps://doi.org/10.1108/et-10-2020-0329</u> 

- Partti, H., & Karlsen, S. (2010). Reconceptualising musical learning: New media, identity and community in music education. _Music Education Research_ , 12(4), 369-382. <u>htps://doi.org/10.1080/14613808.2010.519381</u> 

- Patton, M. Q. (2014). _Qualitative research & evaluation methods: Integrating theory and practice_ (4th ed.). Sage publications. 

- Rao, N. J. (2020). Outcome-based Education: An Outline. _Higher Education for the Future_ , 7(1), 

   - 5-21. htps://doi.org/10.1177/2347631119886418 

JCSR 2026, 8(2):113-137 

137 

- Romanowski, M. H., Alkhateeb, H., & Chaaban, Y. (2024). Problematizing constructive alignment in higher education in gulf cooperation council countries. _Teaching in Higher Education_ , 29(8), 2042-2060. htps://doi.org/10.1080/13562517.2023.2180729 

- Santally, M. I., Rajabalee, Y. B., Sungkur, R. K., Maudarbocus, M. I., & Greller, W. (2020). Enabling continuous improvement in online teaching and learning through e-learning capability and maturity assessment. _Business Process Management Journal_ , 26(6), 1687-1707. htps://doi.org/10.1108/bpmj-11-2018-0335 

- Savage, J. (2017). Where Might We Be Going? In S. A. Ruthmann & R. Mantie (Eds.), _The Oxford handbook of technology and music education_ (pp. 149-156). Oxford University Press. 

- Segooa, M., & Molise, H. (2024). Teaching Methods to Support the Teaching of Reading in the Foundation Phase Class: A Case Study of Schools around Capricorn South District, Limpopo, South Africa. _Research in Educational Policy and Management, 6_ (1), 197-216. https://doi.org/10.46303/repam.2024.13 

- Solikhah I. (2022). Revisiting the EFL curriculum in the outcome-based education framework and freedom to learn program. _Journal of Social Studies Education Research, 13_ (2), pp. 243 – 264. https://jsser.org/index.php/jsser/article/view/4251/570 

- Spady, W. G. (1994). _Outcome-Based Education: Critical Issues and Answers_ . American Association of School Administrators. 

- Syed, R. T., Singh, D., Agrawal, R., & Spicer, D. (2024). Higher education institutions and stakeholder analysis: Theoretical roots, development of themes and future research directions. _Industry and Higher Education_ , 38(3), 218-233. <u>htps://doi.org/10.1177/09504222231191730</u> 

- Tarmo, A., & Kimaro, A. (2021). The teacher education curriculum and its competency-based education attributes. _The Journal of Competency-Based Education_ , 6(3), e01255. <u>htps://doi.org/10.1002/cbe2.1255</u> 

- Tondeur, J., Howard, S., Van Zanten, M., Gorissen, P., Van der Neut, I., Uerz, D., & Kral, M. (2023). The HeDiCom framework: Higher Education teachers’ digital competencies for the future. _Educational technology research and development_ , 71(1), 33-53. <u>htps://doi.org/10.1007/s11423-023-10193-5</u> 

- Tyler, R. W. (2013). Basic principles of curriculum and instruction. In _Curriculum studies reader E_ 2 (pp. 60-68). Routledge. 

- Valentín Melgarejo, T., Ramos Pando, C., Valentín Melgarejo, P., Pariona Cervantes, D., López Basilio, D., & Zenteno Ruiz, F. (2025). Curricular Concretion at the Classroom Level for Competency-Based Performance in Initial Teacher Training. _Journal of Curriculum Studies Research, 7_ (2), 318-333. https://doi.org/10.46303/jcsr.2025.23 

JCSR 2026, 8(2):113-137 

