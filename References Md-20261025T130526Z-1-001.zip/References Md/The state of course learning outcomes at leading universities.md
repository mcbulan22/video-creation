

Full Terms & Conditions of access and use can be found at
http://www.tandfonline.com/action/journalInformation?journalCode=cshe20
Download by: [Australian National University]Date: 31 October 2017, At: 07:46
Studies in Higher Education
ISSN: 0307-5079 (Print) 1470-174X (Online) Journal homepage: http://www.tandfonline.com/loi/cshe20
The state of course learning outcomes at leading
universities
## Kevin Schoepp
To cite this article: Kevin Schoepp (2017): The state of course learning outcomes at leading
universities, Studies in Higher Education, DOI: 10.1080/03075079.2017.1392500
To link to this article:  http://dx.doi.org/10.1080/03075079.2017.1392500
Published online: 24 Oct 2017.
Submit your article to this journal
Article views: 42
View related articles
View Crossmark data

The state of course learning outcomes at leading universities
## Kevin Schoepp
Center of Academic Excellence, Jumeira University, Dubai, UAE
## ABSTRACT
Within higher education, the importance of learning outcomes has
become well-established. They are expected to guide the teaching and
learning process, assessment, and curriculum development, while at the
same time act as foundational elements to transitions towards national
qualifications frameworks, competency-based education, and international
partnerships such as the Bologna agreement. However, as essential as
learning outcomes have become, very little is known about the quality
of learning outcomes within courses. Through a content analysis of
publicly available syllabi, this paper examines course learning outcomes
from some of the leading teaching universities in the world. Results of
this exploratory study indicate that the quality of learning outcomes is
quite poor, and that a great deal of work is required until most
outcomes would be aligned with internationally accepted best practices.
## KEYWORDS
Assessment; education;
student-centered learning;
learning objectives; bloom
## Introduction
As a concept, learning outcomes within higher education are firmly becoming established as an inter-
national norm (Proitz et al.2017). No longer can learning outcomes be considered a passing fad that
faculty members or administrators can ignore. Whereas only a few years ago learning outcomes were
seen strictly as the purview of education faculty, with increased demands for transparency, account-
ability, and employability, transitions towards national qualifications frameworks, competency-based
education, and the Bologna agreement, learning outcomes now appear to be within the scope of all
higher education. Learning outcomes are representative of, or even catalyst towards, the larger tran-
sition to student-centered learning (Adam2002; Ewell2005). Partially driven by the massification of
higher education, well-crafted learning outcomes can lay the groundwork for a more student-cen-
tered classroom and foster alignment between learning, activities, and assessment (Biggs and
## Tang2011).
Though Havnes and Proitz (2016) question whether or not a shared understanding of how learn-
ing outcomes should be written is even possible, as the learning outcomes movement has matured, a
consensus surrounding the characteristics of well-written learning outcomes has emerged. While
some differences exist, and there are varying degrees of guidance and expectations provided,
most universities, accreditors, national and international higher education, and pedagogically
focussed organizations agree on the use of a student-centered introductory stem, the use of concrete
or operational verbs, and a focus on what students should know or do by the end of a unit of learning.
Given this shared understanding, questions about the current state of course learning outcomes
should be asked and leading universities seem the logical starting point to ask such questions.
The current paper addresses questions concerning the quality of course learning outcomes from
10 of the world’s leading teaching universities. It will examine the degree to which a sample of their
© 2017 Society for Research into Higher Education
CONTACTKevin Schoeppkevinschoepp@gmail.comCenter of Academic Excellence, Jumeira University, Al Khail Road, Exit
24, Latifa Bint Hamdan Street (West), PO Box 555532, Dubai, UAE
## STUDIES IN HIGHER EDUCATION, 2017
https://doi.org/10.1080/03075079.2017.1392500
Downloaded by [Australian National University] at 07:46 31 October 2017

course learning outcomes located from publicly available syllabi adhere to international best prac-
tices of writing learning outcomes because, as Adelman (2015) stated, faculty need to pay close atten-
tion to the language of their learning outcomes. Where learning outcomes do not follow best
practices, the paper will then identify where the learning outcomes fail to meet expectations.
Learning outcomes understood
Over 20 years ago Allan (1996) wrote about the development of the learning outcomes in higher edu-
cation and chronicled the transition from objectives, seen to be tarnished from behaviorist underpin-
nings, to the development of subject-specific outcomes, more student-centered in nature. She
described that
there is a dichotomy between learning and teaching intentions, but the process of defining and expressing learn-
ing outcomes should enable lecturers to reflect upon what they intend their students to learn and thereby articu-
late the relationship between what they teach and what students do, in fact, learn. This presupposes that the
learning outcomes are clearly expressed, in a form which enables learners to know at the commencement of
a course...what it is they are expected to achieve. (104)
Later, Harden (2002) discussed the differences between learning outcomes and objectives in medical
education and re-affirmed that learning outcomes focus on what is learned, not what the intentions
of teaching are. Over time, these understandings have become accepted and implemented through-
out higher education.
From an American perspective, the regional accreditor Western Association of Schools and Col-
leges (WASC), defines a learning outcome as‘a concise statement of what the student should
know or be able to do’(WASC Outcome section,n.d.). The UK’s Higher Education Academy (HEA)
defines learning outcomes as‘the skills and knowledge that a student should possess on successful
completion of a course of study’(Higher Education Academy para. 1,2015). Both organizations also
go further to provide guidance as to how learning outcomes should be written. WASC states that
well-articulated learning outcomes demonstrate how students achieve an outcome and that to do
this, non-measurable verbs such as appreciate, learn, and know should be avoided in favor of mea-
surable verbs such as describe, analyze, or create (WASC n. d.) In a more thorough manner, the HEA
offers considerable guidance as to how to write effective learning outcomes. Guidance about use of
active verbs, consideration of assessments, implementation of a student-centered introductory stem,
and examples of good learning outcomes are all provided (Overton2010). A number of the univer-
sities used in the present study also offer similar guidelines to their faculty into how to draft learning
outcomes (see, e.g. Lappn.d.; Stanford Universityn.d.; Yale University2016.).
The standard definition that I use in faculty development workshops is that learning outcomes are
statements that specify, in measurable terms, what a student will know or be able to do as the result
of having successfully completed a unit of learning. This means that learning outcomes are written
from the perspective of a learner, rather than from the perspective of the teacher. I explain the impor-
tance of learning outcomes by stating that their clear articulation communicates expected standards
of performance and serves as a foundation for curriculum development and assessment of the teach-
ing and learning process. Though rooted in the behaviorist approach to learning (Melton1996), the
focus is on active learning principles. My definition and justification have been developed over years
of professional practice and are aligned with international norms.
To manage the development of effective learning outcomes I often present a set of writing guide-
lines which describe things to do and things to avoid (seeTable 1). Besides the guidelines, providing
examples of poor and good learning outcomes demonstrates what type of learning outcomes should
be avoided and what type should be created (seeTable 2). The exemplars also serve as the appli-
cation of the learning outcome writing guidelines.
Although the language of learning outcomes is becoming well-established, their remains some
confusion over like terms, most often the terms goals or objectives. The differences between these
## 2K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

terms, though not the focus of this paper, can enhance an understanding of what learning outcomes
are and are not. Goals are conceptualized as broader constructs than learning outcomes, more often
associated with programs. Suskie (2009) describes them as statements of what faculty and programs
are aiming to achieve both internally and externally to the teaching process. Statements about a
desire to have all students complete a professional internshipwould be a goal. Objectives on the
other hand, are drafted from the perspective of a teacher and represent the process leading to an
outcome (Suskie). They are a specific statement expressing teaching intention (Allan1996;
Kennedy2006). A phrase liketeach the strengths and weaknesses of quantitative methodsrepresents
an objective.
Literature review
Statements like‘learning outcomes currently play an increasingly important role in higher education’
(Melton1996, 409) remain pertinent today, and yet very little is known about the actual state of learn-
ing outcomes in higher education. Through Proitz (2015) content analysis of Norwegian government
documents we know that learning outcomes language appeared in about 2000, peaked about a
decade later, and has now stabilized as a commonly used language. To date, the most comprehensive
analysis of learning outcomes at universities comes from the UK Quality Assurance Agency’s (QAA)
Institutional Audit (Quality Assurance Agency2009). In this audit of 76 institutions and their learning
outcomes, the overall finding was that nearly all had identifiable learning outcomes. However, out-
comes were at times too generic or were lacking in differentiation between levels to be of much use.
More recently, Dobbins et al. (2016) found that faculty from there different schools in a single insti-
tution used learning outcomes to drive their course design and delivery, but they also found that
Table 1.Guidelines for learning outcomes.
Begin with a consistent short stem:
•Students will be able to...
•Students can...
•At course completion students...
Avoid needlessly wordy stems:
•Students will be able to demonstrate the ability to calculate...
•Students will be able to demonstrate a capacity to...
Accurately represent the specific contents of a course
Must be set at the appropriate level of cognitive and behavioral level
State the desired student performance/behavior using concrete action, or operational, verbs such as create, apply, interpret,
describe, identify, categorize
Avoids verbs that are difficult to measure like understand, know, learn, appreciate, become aware of, and experience
Should be limited to one, and very rarely more than two, related verbs
Should number between 4 and 8
Can be effectively measured and assessed
Table 2.Examples of course learning outcomes.
PoorGood
Students will be familiar with research methods in marketing.   Students can critically review the methodology of a research
study published in a marketing journal.
Be introduced to the most commonly used lab equipment in
environment health.
Students can safely and efficiently operate standard
environmental health laboratory equipment.
Students will be able to demonstrate an ability to discuss the
impact of new technology.
Students will be able to critically evaluate the impact of new
technology on E-commerce activities.
Know how to develop an ILP for a child with a learning
disability. Know how to implement an ILP. Know how to
evaluate the ILP.
Students will be able to design, implement, and evaluate the
effectiveness of an individual learning plan for a child with a
learning disability.
Students understand a text’s formal features in light of social,
historical, and psychological concepts.
Students construct coherent arguments that interpret a text’s
formal features in light of social, historical, and psychological
concepts.
## STUDIES IN HIGHER EDUCATION3
Downloaded by [Australian National University] at 07:46 31 October 2017

there were still faculty members resistant to learning outcomes because they viewed them as an
encroachment of the managerialist approach into higher education. A debate clearly exists in
higher education as to whether learning outcomes are a driver in the paradigm shift from teaching
to learning (Ewell2005) or if it is an accountability tool (Proitz2015). It is this tension that appears to
be the cynosure of much of the current learning outcomes literature.
From the teaching and learning perspective, the learning outcomes movement was seen as a way
to transform higher education teaching to be more student-centered (Adam2002; Ewell2005). Early
on, Otter (1992) saw that learning outcomes could better focus faculty on the type of learning they
wanted students to achieve. Similarly, Allan (1996, concluding remarks section) later recognized the
potential to use‘learning outcomes to view learning from the perspective of the learner, rather than
the lecturer, and thereby to enrich the quality of learning.’As positive as this potential seems, more
recent research has found that the more traditional approach still dominated regardless of what was
stated in course syllabi (Nasrallah2014). She discovered that there was a misalignment between
stated university goals, promoted student-centered teaching methods and classroom practices in
that they remained very teacher-centered. Nasrallah (2014, 268) felt that‘although the learning out-
comes occupy a section on the syllabus, they do not indicate a shift in teaching towards a student-
centered environment that is intended to empower today’s learners.’In a similar manner, Hadjianas-
tasis (2016), set out to examine whether or not learning outcomes were meaningful or just a box
ticking exercise in which faculty engaged through a survey of early career academics, Hadjianastasis
found that faculty believed learning outcomes useful for their teaching, but a misconception
emerged in that learning outcomes were often thought of as nothing more than a table of contents
for a course, not learning outcomes as purported by the UK’s QAA.
The other aspect of learning outcomes is that they are now used as an administrative and account-
ability mechanism through qualifications frameworks, transfer agreements, and international assess-
ment projects like AHELO. Havnes and Proitz (2016) warned that emphasizing this feature of learning
outcomes can weaken their impact on transforming teaching and learning processes to more
student-centered approaches, and learning outcomes end up‘as policy devices to support mobility,
assure accountability and promote political initiatives’(220). Though proponents like Proitz (2015)
posit that the learning outcomes movement places student learning at heart of higher education,
there is clearly a tension between pedagogy implications and managerialism. In the early 2000’s,
Hussey and Smith (2003) argued that the positive focus on student learning gained from learning
outcomes needed to be reclaimed from the monitoring and audit mechanisms that had come to
dominate the learning outcomes conversation. They argued that learning outcomes needed to be
flexible and framed in general terms, so that they could better reflect‘the practical realities of teach-
ing’(359). As the perceived tension between learning outcomes as a pedagogical tool or monitoring
mechanism continued to grow, Hussey and Smith (2008) distinguished between types of learning
outcomes. From this analysis, they put forth that learning outcomes at the course level had
become too precise and not of much use. Sin (2014) recently compared the realities of understanding
and enactment of learning outcomes across three Bologna nations. Findings questioned the assump-
tion of policy-makers‘that the implementation of learning outcomes as degree and course descrip-
tors will automatically trigger a shift to student centered learning’(1833-1834).
Research questions
While common guidelines and expectations toward how to craft effective learning outcomes now
exist, the degree to which these are being applied remains unknown. If these guidelines are
indeed meaningful, it is natural to investigate the publicly displayed learning outcomes from
leading teaching universities. Because of this, the research questions guiding this study are as follows:
(1) What is the current state of learning outcomes in courses at 10 leading teaching universities?
(2) Where weaknesses in learning outcomes exist, what types of problems occur?
## 4K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

(3) Is the research method employed a suitable mechanism to answer the previous research ques-
tions, and does it establish a benchmark for further study?
## Method
This research project employed a content analysis because it provides the framework to systemati-
cally examine key documentation and determine their meaning (Busch et al.2012). The key docu-
mentation in this study was course syllabi and the meaning was determined from the learning
outcomes listed within each of the courses. As is the case in a content analysis, the steps taken in
this study were to determine the research questions, choose the documents for examination,
develop a coding mechanism, and then analyze and interpret the results (Gall, Borg, and Gall
1996). To conduct this research, syllabi containing learning outcomes from 10 of the world’s
leading universities were located, and the learning outcomes where then analyzed manually for
their adherence to accepted best practices as demonstrated throughTables 1and 2. However,
although two key elements of good learning outcomes are that they accurately represent the specific
contents of a course and are set at the appropriate level of cognitive and behavioral level, these
guidelines were not included in the analysis because a syllabus rarely offers sufficient content to
make these judgments. In some cases, a review of teaching materials and student work would be
necessary for such an evaluation. Nevertheless, a course syllabus containing learning outcomes
does offer adequate information to analyze the technical quality of the outcomes.
## Sample
The selection of the sample involved two phases. The first phase was the selection of the 10 univer-
sities, while the second phase was locating appropriate syllabi from those institutions. The institutions
that made up the sample were selected from data provided by both the Times Higher Education
(THE) World University Rankings 2016–2017 (Times Higher Education2016) and the 2016 QS Univer-
sity Rankings (QS Top Universities2016)–only English-speaking universities were included in order
to complete the analysis of learning outcomes. For the THE, the rankings were filtered from high to
low according to the Teaching criteria which accounts for 30% of the total score. For the QS, the rank-
ings were filtered from high to low according to the student-to-faculty ratio, which they purport
measures teaching quality and accounts for 20% of the total score. However, as Zha (2016) noted,
the efficacy of these criteria are questionable since they are only proxies for teaching quality. None-
theless, they remain key measures that impact international rankings. Starting from the top ranking
and progressing downward, the two lists were compared and where there was overlap, an institution
was selected to be one of the 10. The final set of 10 should be considered a list of the leading English-
medium teaching universities as identified by 2 of the leading ranking bodies. The institutions chosen
are not controversial and are commonly the overall top ranked universities in various ranking tables.
Only institutions from the US and the UK emerged from the tables and given the commitment to
learning outcomes from both the US regional accreditors and the UK’s QAA this seemed a justified
sample. The universities selected were the California Institute of Technology (CalTech), Stanford Uni-
versity, University of Cambridge, Massachusetts Institute of Technology (MIT), University of Oxford,
Yale University, Columbia University, Imperial College London (ICL), University of Pennsylvania
(UPenn), and John Hopkins University.
Once the list of universities was generated, recent, publicly available syllabi from each of the insti-
tutions were sought since syllabi are where the sets of course learning outcomes are expected to be
located. The goal was to collect 5 recent undergraduate or graduate course syllabi from the 10 uni-
versities for a total sample of 50 syllabi. Given the guideline of about 6 learning outcomes per course
(Lindholm2009), a sample of 300 learning outcomes was possible. Google was primarily used to
search for syllabi and a variety of search strings were employed depending on levels of success
## STUDIES IN HIGHER EDUCATION5
Downloaded by [Australian National University] at 07:46 31 October 2017

experienced. Example search strings included but were not limited to Imperial College of London syl-
labus, Massachusetts Institute of Technology course syllabus, MIT syllabus, Columbia University sylla-
bus pdf, Stanford University Syllabus filetype:pdf past year, and UPenn course syllabus. Often,
locating one syllabus at an institution would lead to others, or on-site navigation would lead to
the discovery of other syllabi. Only one syllabus per faculty member was included and no preference
for college, department, or program was considered. This meant that syllabi were gathered from
numerous disciplines including Economics, Math, Linguistics, Engineering, Sociology, Computer
Science, Japanese, Nursing, Business, Psychology, and Accounting. Discipline was not a consideration
in syllabi because at the macro level (US regional accreditor and UK QAA), similar expectations exist
across disciplines. It is not as though linguistic program are exempt from using learning outcomes
while engineers are not.
All syllabi were reviewed for the existence of course learning outcomes, and if learning outcomes
were present, the syllabus was retained. If course learning outcomes were not present, the syllabus
was discarded. The determination of the presence of learning outcomes was quite flexible in that
whether embedded in paragraphs or termed course goals or objectives, they were included in the
sample if the statements seemed to be learning outcomes. Nonetheless, far more syllabi were
found to have no discernable learning outcomes, than had learning outcomes. In cases where learn-
ing outcomes were absent, the syllabi generally listed a set of course topics instead of outcomes.
In total, having collected no more than 5 syllabi from any single institution, 42 syllabi with learning
outcomes were found and included in the final data set. CalTech, MIT, University of Oxford, UPenn,
and Stanford University were the institutions where less than five syllabi with discernable learning
outcomes were identified. Most importantly, these 42 syllabi led to a total of 174 learning outcomes
that could be analyzed. Though less than initially sought, this number was thought to be sufficient to
gauge the current state of learning outcomes at the institutions under examination. It also reflected
the fact that the content analysis proved challenging since numerous syllabi did not include learning
outcomes.
Analysis and results
From the 10 universities targeted, none had more than 5 courses selected and only CalTech and MIT
had a low of 3 course syllabi utilized (seeFigure 1). Of the 174 learning outcomes which were located,
Oxford provided the lowest number at 10, while Columbia supplied a high of 25 (seeFigure 1).
At the most basic level, the issue of whether or not learning outcomes could be identified within
the syllabi needed to be addressed. This meant that learning outcomes should have been clearly
labeled in the syllabus through a heading likeLearning Outcomes- Student will be able to:or
Figure 1.Number of courses and learning outcomes.
## 6K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

COURSE LEARNING OBJECTIVES- Students who successfully complete this course will be able to:, rather
than being directly embedded as sentences within a paragraph making them a challenge to identify.
I found that 76% (32/42) of courses had the learning outcomes clearly displayed. Given the guideline
that an appropriate number of learning outcomes per course is between 4 and 8, 50% (21/42) of the
courses fell within this parameter, and 61% (106/174) of the total learning outcomes were grouped in
this way. The highest number of learning outcomes in a single course was 12 and the least was
- However, in the course with 12 learning outcomes, each learning outcome was actually many
learning outcomes in one. Though there were 12 bulleted learning outcomes, within each of these
a number of additional learning outcomes were listed. For example:Analyze worst-case running
times of algorithms using asymptotic analysis. Compare the asymptotic behaviors of functions obtained
by elementary composition of polynomials, exponentials, and logarithmic functions. Describe the relative
merits of worst-, average-, and best-case analysis.Though there was clearly an attempt to group the
outcomes according to an overarching concept, this was not successful since an outcome such as
describe the relative merits of worst-, average-, and best-case analysislacks the required specificity to
link it only to asymptotic analysis. As written, it could be an outcome for a number of unrelated con-
cepts. I made the decision to consider these bulleted outcomes as a single poorly crafted outcome
rather than a multitude of poorly written outcomes which would have skewed the data.
The analysis of most consequence is whether the individual learning outcomes were fine as
written, or whether they should be re-written to better follow the best practices. This was an itera-
tive process in which learning outcomes from eachcourse were read and re-read in order to estab-
lish a representative coding framework that emerged as good, non-measurable verb, lacking or
having too much specificity, and non-measurable with accompanying specificity issues (when
more than one verb was present in a learning outcome, the more cognitively demanding verb
was considered).
Table 3provides example learning outcomes that demonstrate the types of problems that were
coded. Ignoring whether or not the learning outcomes were clearly labeled, numbered between 4
and 8, or had a student-centered introductory stem, the analysis showed that fully 60% (104/174)
of the learning outcomes would need to be re-written if this were a quality assurance check.
With 70 (40%) of the learning outcomes being fine as written, the 104 requiring edits from using
non-measurable verbs, lacking or having too much specificity, or having a combination of a non-mea-
surable verb and lacking or having too much specificity, were distributed as shown inFigure 2. By far,
the largest area of concern was the use of verbs or phrases which were not measurable (n= 67), speci-
ficity was less of a concern (n= 24), and having a combination of a non-measurable verb and lacking
or having too much specificity was coded only 13 times. Overall, a great deal of improvement is
needed to raise the learning outcomes to a level of accepted best practices. This is especially true
considering that the degree to which the learning outcomes accurately represent the specific
Table 3.Problems with learning outcomes.
Learning outcomeProblem
To learn and appreciate linear algebra and discrete mathematicsNon-measurable verb
Familiarity with debates over how language is represented in the mindNon-measurable verb
Able to analyze and report on material learnedSpecificity–lack of
Apply statistical tools to make inference about a single binomial proportion or two sample
proportions using–approximate confidence intervals–hypotheses testing using approximate
or exact methods–calculation of power, sample sizes and detectable effect sizes
Specificity–too much
Will have a basic understanding of the marketing concept, the marketing mix (product, place,
promotion and price), segmentation, targeting, positioning, customer value, branding, services
marketing, global marketing, marketing metrics, consumer and business behavior, ethics and
social responsibility in marketing, market planning, market research and competitive analysis
Non-measurable and specificity
issues (Too much)
Knowledge of contemporary issuesNon-measurable and specificity
issues (too little)
## STUDIES IN HIGHER EDUCATION7
Downloaded by [Australian National University] at 07:46 31 October 2017

contents of a course or are set at the appropriate level of cognitive or behavioral level cannot be ana-
lyzed through a multi-disciplinary syllabus investigation.
Adding the criteria of the learning outcomes being labeled, having a student-centered stem, and
numbering between 4 and 8, to the existing analysis, only 11% (19/174) of the learning outcomes
would not require edits. At course level, only 7% courses (3/42) had a good set of learning outcomes
following all best practices. Examples of some of these quality learning outcomes from the three
exemplar courses are (for readability purposes, the phrase,Students will be able tohas been used
for all introductory stems):
Students will be able to...
## .
Identify the major events and accounting decisions behind the numbers reported in financial
statements.
## .
Apply control volume analysis and the integral momentum equation to estimate the forces pro-
duced by aerospace propulsion systems.
## .
Translate simple problems involving mechatronic control systems into a form which can be solved
using standard mathematical methods.
Even with the many weaknesses noted, within the majority of courses there were often examples of
well-crafted learning outcomes. Of the 42 courses investigated, 55% (23/42) had at least one well-
crafted learning outcome. Examples of these included:
Students will be able to...
## .
Identify strategies to eating a healthy diet in different cultural and environmental settings.
## .
Deconstruct a broad problem into logical units and pick a strategy for analysis based on the struc-
ture of the data.
## .
Critically assess policies, programs, and proposals that are aimed at promoting urban sustainability
## .
Estimate the efficiency of simple algorithms, using the notions of average-case, worse-case, and
amortised costs.
## .
Describe the roles biostatistics serves in public health and biomedical research.
## .
Describe the activities of civil engineers, their duty to act in the public interest, and the role of pro-
fessional institutions.
Figure 2.Learning outcomes quality.
## 8K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

Of the 70 learning outcomes that were fine as written, a further analysis into their verbs utilized
was conducted because as Adelman (2015, 7) stated‘the verb is the center, fulcrum, engine of a learn-
ing outcome statement.’A total of 39 different verbs were used in the 70 learning outcomes.Figure 3
is a word cloud of all 39 verbs, and the size of the verb in the cloud indicates the relative number of
times a verb was employed in the learning outcomes. Apply, being the largest verb was employed on
eight separate occasions, describe and assess occurred five times, estimate appeared 4 times, analyze
and evaluate followed with three instances, while all other verbs appeared once or twice.
In terms of the cognitive levels represented by the 70 total instances of the verbs, an analysis using
Bloom’s Taxonomy of Educational Objectives within the Cognitive Domain (Bloom et al.1956) found
Figure 3.Word cloud of verbs.
Figure 4.Learning outcomes on Bloom’s taxonomy.
## STUDIES IN HIGHER EDUCATION9
Downloaded by [Australian National University] at 07:46 31 October 2017

that the middle order dominated (seefigure 4)–Bloom’s taxonomy is a hierarchical model that
ranges from lower order to higher order thinking–knowledge, comprehension, application, analysis,
synthesis, evaluation, and is often used to classify learning outcomes. The middle order categories of
application and analysis accounted for 47% (33/70) of all the learning outcomes, the lowest order
level of knowledge only emerged 3% (2/70) of the time, and the highest order category of evaluation
occurred at a rate of 19% (13/70). Similar to the earlier analysis of the quality of the learning out-
comes, this was an iterative process in which each of the verbs was read and re-read in context of
the learning outcome in order to make an accurate coding decision and assign it to one of
Bloom’s levels. Though Otter (1992) described how Bloom’s taxonomy helped the development of
learning outcomes, the iterative process was required because as Stanny (2016) has noted, all
verbs do not unambiguously align to Bloom’s level- language is flexible.
## Discussion
In answering the first two research questions, the two that dealt with the current state of learning
outcomes and where problems in the learning outcomes occurred, the results of this research indi-
cate that major improvements are required in the way learning outcomes are displayed and crafted
within courses. Though just over three quarters of learning outcomes were clearly displayed, only half
of all courses had what is normally considered a standard number of learning outcomes. If learning
outcomes are to be meaningful, there cannot be too many since assessment and coverage can
become a concern. If there are too few learning outcomes, a course might not be accomplishing
enough or the outcomes might be too broad to be of use. However, as both Sin (2014) and Hadjia-
nastasis (2016) noted, faculty need to have a clear understanding that learning outcomes are not
merely a list of course topics if this is to occur. Having all courses clearly display the expected
number of learning outcomes should be the minimum expectation from institutions, especially
from institutions purported to be the world’s leading teaching institutions.
In terms of the quality of learning outcomes in courses and ignoring the best practice guidelines of
4–8 clearly labeled learning outcomes that have a student-centered introductory stem, that 60% fail
to meet a level of accepted best practice is dreadful given the learning outcomes work that has been
underway for years. It may be a demonstration that the resistance noted by Havnes and Proitz (2016)
remains very prevalent, or that confusion remains (Sin2014; Hadjianastasis2016). The main problem
of learning outcomes–that verbs or verb phrases are not measurable–shows that non-operational
or abstract verbs like appreciate, understand, develop, recognize, consider, reflect, review, observe,
and realize dominate written learning outcomes. If the verb cannot be effectively measured, it is
of little use to faculty or students. Finally, taking into consideration all of the best practice guidelines,
the picture becomes even more dire since only 3 courses containing 19 learning outcomes could be
considered exemplars. However, on a more positive note over half of the courses did have at least
one well-crafted learning outcome, so there is something to build upon.
In the 40% of learning outcomes that were labeled as fine without considering the guidelines of 4–
8 clearly labeled learning outcomes that have a student-centered introductory stem, 39 different
verbs were utilized. Adelman (2015) posits that there are more than 120 verbs that can be used to
meaningfully describe the outcomes of learning, so there is a great deal of potential vocabulary
that remains untapped. In addition, that higher order thinking is a universal expectation of a univer-
sity education, more verbs that represent Bloom’s more cognitively advanced levels of synthesis and
evaluation must be implemented past the current level of 27%. Overall, the portrait of learning out-
comes within courses at the leading teaching universities in the world, even with pockets of best
practice and elements to build upon, is quite dismal.
The final research question asked whether the method employed was suitable and whether or not
it establishes a benchmark for further study. The answer to this two-pronged question is undeniably
yes. Though the results demonstrated major weaknesses in the current state of learning outcomes,
the sampling method or a similar one, could be scaled up massively to include more institutions and
## 10K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

learning outcomes. Alternatively, any single university could conduct a content analysis of syllabi
within their own institution in order to learn their own strengths and weaknesses. This could, in all
likelihood, be done without access restrictions to syllabi that is experienced externally.
Limitations and further research
There are a number of limitations that must be considered when reading the results of this research
study. First, the sampling method utilizing 10 of the leading teaching universities takes at face value
that the teaching proxies purported by the ranking bodies are legitimate. Zha (2016) has recently
questioned this assumption. Second, the sampling method only yielded 174 total learning outcomes
from a population of thousands. However, full access to the pool of learning outcomes would in all
likelihood be impossible to achieve. As an exploratory study, enough has been learned to further
expand this line of research because if learning outcomes truly matter, their prevalence and
quality also matter and are worthy of investigation.
A logical next phase in this research may be to select specific samples from Education depart-
ments since they may be better informed about learning outcomes. How or if the implementation
and understanding of learning outcomes differs between Education and other disciplines may
bring forth some interesting results.
## Conclusion
The bleak findings from this study lead one to ask a number of questions. First, it is essential to ask
about the real importance of well-crafted learning outcomes to higher education. If most courses
and nearly all learning outcomes within courses fail to meet best practice guidelines, perhaps the
entire concept of learning outcomes is overblown. While the desire to have learning outcomes lead
to a focus on what is learned rather than what is taught is noble, perhaps current levels of resistance
and confusion make this highly unlikely. Second, do the findings suggest that the teaching proxies used
by the ranking bodies are actually invalid and unreliable? Zha (2016  ) believed this to be the case and
saw that the development of more effective measures for teaching and learning should be a priority.
Though this is certainly contentious, this examination of learning outcomes failed to provide any evi-
dence that good teaching and learning is occurring at these leading universities. In fact, the inability to
craft quality learning outcomes suggests that a meaningful measure of learning outcome attainment,
would be impossible to implement at this time. Third, should different universities, perhaps those with
missions targeting quality teaching like McMaster or Loughborough University, be used to provide a
more meaningful sample? Finally, do results point to a need for a far more concerted effort to get
faculty understanding the vital role that effective learning outcomes can play in the development
and delivery of courses and programs, while at the same time, emphasizing the student and their learn-
ing as key? This remains a challenging and long-term task. As Adam (2008  , 17) stated
the writing and implementation of learning outcomes is a formidable task that involves a huge staff development
process as well as cost implications in terms of time and money. It is a massive undertaking...and this often takes
years to accomplish.
Such undertakings need to be framed within the realization that there are both accountability and
student-centered learning facets to the learning outcomes movement (Dobbins et al.2016), but it
is the learning aspect that will resonate best with teaching faculty. Whatever the cause of the
current state of learning outcomes in course syllabi, this research has demonstrated that at the
most basic level, there remains an inability to write quality learning outcomes at the world’s
leading universities.
Disclosure statement
No potential conflict of interest was reported by the authors.
## STUDIES IN HIGHER EDUCATION11
Downloaded by [Australian National University] at 07:46 31 October 2017

## ORCID
## Kevin Schoepphttp://orcid.org/0000-0003-0118-6401
## References
Adam, S.2002.“Using Learning Outcomes.”Paper presented at the United Kingdom Bologna seminar, Heriot-Watt
University, July 1–2. http://www.aic.lv/bolona/Bologna/Bol_semin/Edinburgh/S_Adam_Bacgrerep_presentation.pdf.
Adam, S.2008.“Learning Outcomes Current Developments in Europe: Update on the Issues and Applications of Learning
Outcomes Associated with the Bologna Process.”Paper presented at the Bologna seminar: The Scottish experience,
Heriot-Watt University, February 21–22. https://www.ulb.ac.be/unica/docs/ECVET_Edinburgh_Feb08_Adams.pdf
Adelman, C.2015.To Imagine a Verb: The Language and Syntax of Learning Outcomes Statements(National Institute for
Learning Outcomes Assessment Occasional Paper No. 24).http://learningoutcomesassessment.org/documents/
OccasionalPaper24.pdf.
Allan, J.1996.“Learning Outcomes in Higher Education.”Studies in Higher Education21 (1): 93–108.doi:10.1080/
## 03075079612331381487.
Biggs, J., and C. Tang.2011.Teaching for Quality Learning at University. 4th ed. Maidenhead: McGraw-Hill.
Bloom, B. S., M. D. Englehart, E. J. Furst, W. H. Hill, and D. R. Krathwohl.1956.Taxonomy of Educational Objectives.
## Handbook 1: Cognitive Domain. New York: Longmans.
Busch, C., P. S. De Maret, T. Flynn, R. Kellum, S. Le, B. Meyers, M. Saunders, R. White, and M. Palmquist.2012.“Writing@CSU:
Content Analysis.”Accessed November 20, 2016.http://writing.colostate.edu/guides/guide.cfm?guideid = 61.
Dobbins, K., S. Brooks, J. Scott, M. Rawlinson, and R. I. Norman.2016.“Understanding and Enacting Learning Outcomes:
The Academic’s Perspective.”Studies in Higher Education41 (7): 1217–1235.doi:10.1080/03075079.2014.966668.
Ewell, P.2005.“Applying Learning Outcomes to Higher Education: An Overview”. Paper presented at the Hong Kong
University Grants Committee, National Center for Higher Education Management Systems.http://www.cetl.hku.hk/
wp-content/uploads/2016/08/OBA_1st_report.pdf.
Gall, M. D., W. R. Borg, and J. P. Gall.1996.Educational Research: An Introduction. Toronto: Longman.
Hadjianastasis, M.2016.“Learnin
g Outcomes in Higher Education: Assumptions, Positions and the Views of Early-Career
Staff in the UK System.”Studies in Higher Education,1–17 doi:10.1080/03075079.2016.1141402.
Harden, R. M.2002.“Learning Outcomes and Instructional Objectives: Is There a Difference?”Medical Teacher24 (2): 151–
- doi:10.1080/0142159022020687.
Havnes, A., and T. S. Proitz.2016.“Why Use Learning Outcomes in Higher Education? Exploring the Grounds for Academic
Resistance and Reclaiming the Value of Unexpected Learning.”Educational Assessment, Evaluation and Accountability,
28 (3): 205–23. doi:10.1007/s11092-016-9243-z.
Higher Education Academy.2015.“Learning Outcomes and Objectives.”Accessed November 21, 2016.https://www.
heacademy.ac.uk/enhancement/definitions/learning-objectives-and-outcomes
Hussey, T., and P. Smith.2003.“The Uses of Learning Outcomes.”Teaching in Higher Education8 (3): 357–368. doi:10.1080/
## 13562510309399.
Hussey, T., and P. Smith.2008.“Learning Outcomes: A Conceptual Analysis.”Teaching in Higher Education13 (1): 107–15.
doi:10.1080/13562510701794159.
Kennedy, D.2006.“Writing Learning Outcomes: A Practical Guide.”Accessed November 21, 2016.https://cora.ucc.ie/
bitstream/handle/10468/1613/A%20Learning%20Outcomes%20Book%20D%20Kennedy.pdf?sequence =
1&isAllowed = y.
Lapp, I.n.d.“Guide for Writing Learning Objectives.”Accessed November 22, 2016.https://www.mailman.columbia.edu/
sites/default/files/legacy/Guide%20for%20Writing%20Learning%20Objectives%20(Mailman%20School%20of%
20Public%20Health).pdf.
Lindholm, J. A.2009.“UCLA Guidelines for Developing and Assessing Student Learning Outcomes for Undergraduate
Majors.”Accessed November 22, 2016.http://www.wasc.ucla.edu/eer_endnotes/Learning_Outcomes_Guidelines.pdf.
Melton, R.1996.“Learning
Outcomes for Higher Education: Some Key Issues.”British Journal of Educational Studies,44 (4):
## 409–25.
Nasrallah, R.2014.“Learning Outcomes’Role in Higher Education Teaching.”Education, Business and Society:
Contemporary Middle Eastern Issues7 (4): 257–76. doi:10.1108/EBS-03-2014-0016.
Otter, S.1992.Learning Outcomes in Higher Education: A Developmental Project Report. Department of Employment.
Overton, T.2010.Primer: Writing Learning Outcomes. Higher Education Academy. Accessed November 22, 2016.https://
www.heacademy.ac.uk/system/files/writing_learning_outcomes.pdf.
Proitz, T. S.2015.“Learning Outcomes as a Key Concept in Policy Documents Throughout Policy Changes.”Scandinavian
Journal of Educational Research59 (3): 275–96. doi:10.1080/00313831.2014.904418.
Proitz, T. S., A. Havnes, M. Briggs, and I. Scott.2017.“Learning Outcomes in Professional Contexts in Higher Education.”
European Journal of Education52 (1): 31–43. doi:10.1111/ejed.12207.
## 12K. SCHOEPP
Downloaded by [Australian National University] at 07:46 31 October 2017

QS Top Universities.2016.“QS World University Rankings: Methodology.”Accessed December 20, 2016.http://www.
topuniversities.com/qs-world-university-rankings/methodology.
Quality Assurance Agency.2009.“Outcomes from Institutional Audit: 2007- 09.”Accessed November 22, 2016.http://
www.qaa.ac.uk/en/Publications/Documents/outcomes-from-institutional-audit-2007-9-assessment-and-feedback.
pdf.
Sin, C.2014.“Lost in Translation: The Meaning of Learning Outcomes Across National and Institutional Policy Contexts.”
Studies in Higher Education39 (10): 1823–37. doi:10.1080/03075079.2013.806463.
Stanford University.n.d.“Creating Learning Outcomes.”Accessed March 15, 2017.http://web.stanford.edu/dept/pres-
provost/irds/assessment/downloads/CLO.pdf.
Stanny, C. J.2016.“Reevaluating Bloom’s Taxonomy: What Measurable Verbs Can and Cannot Say About Student
Learning.”Education Sciences6 (4), 37doi:10.3390/educsci6040037.
Suskie, L.2009.Assessing Student Learning: A Common Sense Guide. San Francisco, CA: Jossey-Bass.
Times Higher Education.2016.“World University Rankings 2016-2017 Methodology.”Accessed March 15, 2016.https://
www.timeshighereducation.com/world-university-rankings/methodology-world-university-rankings-2016-2017
WASC Senior College and University Commission.n.d.“WSCUC Glossary.”Accessed January 5, 2017.https://www.
wascsenior.org/content/wasc-glossary.
Yale University.2016.“Writing Intended Learning Outcomes.”Accessed January 5, 2017.http://ctl.yale.edu/
IntendedLearningOutcomes.
Zha, Q.2016.“University Rankings in Perspective.”Inside Higher Ed, December 4.https://www.insidehighered.com/
blogs/world-view/university-rankings-perspective.
## STUDIES IN HIGHER EDUCATION13
Downloaded by [Australian National University] at 07:46 31 October 2017