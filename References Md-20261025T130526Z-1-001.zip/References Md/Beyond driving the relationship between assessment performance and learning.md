> Received: 31 May 2018 <u>| Revised: 10 October 2018 | Accepted: 11 June 2019</u> DOI: 10.1111/medu.13935 

S TAT E O F T H E S C I E N C E 

# **Beyond ‘driving’: The relationship between assessment, performance and learning** 

## **Ian M. Scott** 

Centre for Health Education Scholarship, The University of British Columbia, Vancouver, British Columbia, Canada 

##### **Correspondence** 

Ian M. Scott, Centre for Health Education Scholarship, The University of British Columbia, 429-2194 Health Sciences Mall, Vancouver, BC V6T 1Z3, Canada. Email: ianscott@interchange.ubc.ca 

### **Abstract** 

**Objective:** Is the statement ‘assessment drives learning’ a myth? 

**Background:** Instructors create assessments and students respond to these assessments. Although such responses are often labelled indications of learning, the responses educators observe can also be considered a performance. When responses are aligned with generating stable changes, then assessment drives learning. When responses are not aligned with stable changes, we must consider them to be something else: a performance put on partially or fully for the sake of implying capability rather than actual learning. The alignment between the assessments educators create and the way students respond to these assessments is determined by the actions students take in our curriculum, in preparation for our assessments and after engaging with our assessments. 

**Conclusions:** Not all assessments need to or should support learning, but when we assume all assessments ‘drive learning’, we endorse the myth that assessment is necessarily a formative aspect of our curricula. When we create assessments that encourage performance activities such as cramming, competing for tutorial airtime and impression management in the clinical setting we drive students to a performance. By thinking about how our students, institutions, curricula and assessments support learning and how well they support performance, we can modify and more fully align our curricular and assessment efforts to support learners in achieving their (and our) desired outcome. So, is the phrase ‘assessment drives learning’ a myth? This paper will conclude that it often is but we as educators must, through our leadership, move this myth towards a reality. 

### **1** | **INTRODUCTION** 

As a medical educator who sits at curriculum tables, I often hear calls for testing to ensure that students ‘learn it’; after all, everyone knows that assessment drives learning. Doesn't it? As educators, we spend significant time, effort and money to create, analyse, standardise and secure assessments. Our students also spend significant time, effort and money in response to our assessments. In the face of these costs, we must ask if our assessments are in fact driving our students to learn. 

Swanson and Case<sup>1</sup> have advised us to ‘Grab students by the tests and their hearts and minds will follow’. However, there are 

recognised challenges in the ways we conceptualise the role of assessments, and expectations regarding how assessments affect learning have evolved over time. As long ago as 1961, Miller<sup>2</sup> stated simply that the central purpose of a test was to stimulate students to study. In 1996, van der Vleuten<sup>3</sup> noted that there are trade- offs when constructing assessments and that the content, format, timing and feedback of assessments all affect the degree to which they can be used for learning. In 2011, Norcini et al<sup>4</sup> called for assessments to support both judgements of ability and learning. Most recently, Watling and Ginsburg<sup>5</sup> suggest that as educators, we must embrace an improvement model of learning and working so that performance is replaced by striving for improvement as a professional. 

© 2019 John Wiley & Sons Ltd and The Association<sup><u>|</u></sup> **1** for the Study of Medical Education 

_Medical Education._ 2019;00:1–6. 

wileyonlinelibrary.com/journal/medu 

**2** **<u>|</u>** 

SCOTT 

Given this increasingly nuanced thinking about assessments, it would be folly to argue that our assessments always drive our learners towards learning. James argues, in fact, that assessment practices have only a tenuous or partial relationship to learning.<sup>6</sup> It would be equal folly, however, to assume our assessments never drive our learners towards learning. By examining the mismatch between assessment and learning we may come to a better understanding of why ‘assessment drives learning’ should be regarded as a myth when stated as a universal truth. Doing so will allow us to better understand and better communicate the ways in which our assessments can support learning. 

In the following section, I will discuss how our assessments may drive our learners towards performance rather than towards learning. Subsequently, I will offer recommendations for moving our students, contexts and assessment practices away from supporting performances towards supporting learning. 

### **2** | **PERFORMANCE AND LEARNING** 

Learning is a stable change in knowledge or behaviour that results from practice or other forms of experience.<sup>7</sup> Instructors create assessments and students respond to these assessments with an action or performance. Although these responses to assessments are often labelled indications of learning, the responses educators observe may represent something else entirely. When responses are aligned with generating stable changes in knowledge or behaviour, then assessment drives learning. When responses are not aligned with generating stable changes in knowledge or behaviour, we must consider them to be performance put on for the sake of demonstrating or implying a particular capability rather than learning. Alignment with learning or performance is determined by the actions students take in preparation for the assessment and the ways students choose to act during and after the assessments. 

In 1928 Dewey noted that students must feel a sense of purpose in their learning to avoid mental slavery.<sup>8</sup> Mental slavery may be the pursuit of high marks or positive feedback and can include learners acting to create positive reputations. This purposeful seeking of reward over learning is the undesired consequence of assessment, when students seek to demonstrate high performance to the detriment of learning. In the following paragraphs, I will outline four examples in which the behaviour elicited by assessments might be better perceived as performance. 

Long- term recall is more effective when studying is spread out over time (ie distributed practice) than when it takes place in one continuous period.<sup>9</sup> Student ‘cramming’ (ie massed practice or intensive study just before an examination) rewards performance over learning. When infrequent high- stakes examinations are used to assess learning, cramming can prioritise performance and potentially punish students who seek to learn material for long- term retention.<sup>9</sup> Thus, although it may appear that learning has occurred, rewarding performance in students who cram can impede long- term retention 

and the capacity to apply the material in future settings, thereby promoting the very opposite of learning. 

In small group interactions, students’ impression management can similarly reward performance at the expense of learning. In such settings, a faculty member is usually responsible for assessing students. In response to this assessment, students seek ‘tutorial air time’ by demonstrating some knowledge early in the tutorial to ensure that the faculty member notices them in an effort to influence their assessment.<sup>10,11</sup> As educators, we may believe we have designed our tutorials to allow students the opportunity to apply their knowledge, to develop and explore team- based care competencies and to engage in retrieval- based knowledge acquisition. If we assess the amounts of student participation as proxies for these above learning activities, however, we may undermine these intentions by rewarding performance, thus impeding the very learning the tutorials were developed to enable. 

Students’ impression management can also impair learning in clinical settings. Here, students who focus on performing for their supervisors or their peers rather than caring for their patients can impair their clinical decision making, their own wellness and even patient safety.<sup>12,13</sup> This student focus on ‘measuring up’ is socially constructed and determined by the cues that instructors and the learning setting give to students.<sup>12</sup> When these environments are constructed to reward performance, students will perform. In such situations, students actively work to manage the clinical teaching setting and use sophisticated strategies to manage their preceptors and the situation to maintain a positive image.<sup>14,15</sup> Students who adopt a performance approach can be rewarded for their apparent competence by telling the supervisor what they want to hear rather than focusing on learning about their patient's illness and dedicating themselves to caring for their patients.<sup>14,15</sup> In addition, the concept of clinical auditioning, the act of gaining access to training opportunities, a desired residency position, or to procure a reference letter, is an all too familiar aspect of medical training culture and speaks to how the training system can be constructed to reward performance.<sup>16</sup> 

Lastly, performances in response to assessments can pervert the way students think about patients by shifting patients from a means to learn through caring to a barrier to success. As Gormley et al<sup>17</sup> note, the objective structured clinical examinations (OSCEs) ‘… may be driving learning in the wrong direction’. They ask us to consider the social and cultural messages that assessments such as OSCEs give students. Satisfying the OSCE checklist can result in a high score on the assessment but may represent poor patient care. The OSCE can give students the message that in a clinical encounter it is more important to appear good than do well. 

### **3** | **MOVING FORWARD** 

Although few would deny that we need assessments to allow us to grade or certify learners, it should also be rare that one would suggest our current assessment practices cannot support learning. The 

**3** **<u>|</u>** 

SCOTT 

issue highlighted in this paper is that we cannot assume assessments support learning in all cases. In the face of this assessment problem, there are actions we can take to support how our students, institutions, curriculum, assessments and feedback can better support learning. What follows is a number of examples in each of these domains, offered with an aim of providing recommendations regarding how each might be manipulated towards enabling assessments that lead to learning. 

### **3.1** | **Students** 

Elliot and Dweck offer one way to grapple with the performance versus learning dichotomy in their work on learner mindsets. They propose that individuals can adopt two types of goal orientations in achievement situations: growth and mastery, and performance and fixed orientations.<sup>18,19</sup> Students demonstrate a growth orientation when their goals focus on personal development (ie mastery of the material or task to be learned). By contrast, students demonstrate a performance orientation when their goals focus on seeking positive assessments of their competence and they look to avoid negative judgements. Holding one of these two opposing mindsets at any given time has considerable implications for how students will behave in response to assessment challenges. Learners can have both fixed and growth mindsets at different points in time, and which mindset is invoked depends on the learning and assessment context. Having a growth mindset supports learning and avoids resistance when students do not know an answer, make an error, experience failure or are anxious.<sup>18,19</sup> 

We can help foster a growth mindset in our students by explaining and modelling that a growth mindset is a lifelong activity that entails taking on challenges, sticking to those challenges and learning from them in the pursuit of competence, rather than simply modelling our own successful performance. Focusing on process rather than outcome and being open about struggles we had when learning material that we are now trying to teach can also help students by dispelling the myth that a growth mindset is represented simply by having an open mind or being a nice person.<sup>20</sup> Although a review of the literature on supporting growth mindset is beyond the scope of this article, there is increasing evidence that exposing our students to mindset concepts and providing them with a way to frame their approach to learning when addressing both assessment and non- assessment challenges can promote learning over performance.<sup>21,22</sup> 

### **3.2** | **Institutions** 

Organisations that make reflective practice overt can promote a learning orientation for the individuals who work and learn in those institutions.<sup>23,24</sup> Teunissen and Bok argue that both individual and organisational efforts that support a learning outlook are required to support lifelong learning.<sup>24</sup> Klein et al<sup>25</sup> suggest that although schools can teach students to have a growth mindset orientation, if the culture of the clinical setting is competitive, with individuals 

primarily valued for their performances, any gains in supporting a learning perspective will be lost. In addition, settings that are primarily focused on performance lead to poorer outcomes amongst those with both learning and performance orientations.<sup>26</sup> The literature suggests that student development in learning settings needs to be based on explicit values that are clearly demonstrated in all, not some, learning environments.<sup>27,28</sup> Institutional culture is the sum total of the assumptions, beliefs and values as expressed by ‘what is done, how it is done, and who is doing it’ within an institution.<sup>29</sup> Through supported participation in the workplace that feeds into the institution's assessment strategies, students can be helped to focus on learning how to care for patients rather than how to perform for assessors.<sup>12,30,31</sup> 

To influence culture it is helpful to consider how institutional change takes place. In this regard, Kotter's 1996 model has demonstrated sustained use and accumulation of evidence.<sup>32,33</sup> The eight steps Kotter outlines for change are: establish a sense of urgency, form coalitions, create a vision for change, communicate that vision, empower others to enact the vision, plan for and create shortterm wins, consolidate improvements and institutionalise new approaches.<sup>34</sup> This process is not easy or quick to enact but by taking steps to promote a learning vision, an institution can move towards creating a culture of learning that will pay dividends in terms of the degree to which students treat their assessments as opportunities for learning. Although it can be challenging to change the culture of an institution, exploring the explicit and tacit messages that our institution gives students may help us begin to purposefully create and manage a change process that supports learning in the face of our assessments.<sup>35</sup> 

### **3.3** | **Curriculum** 

A curriculum that explicitly supports future practice supports current learning.<sup>36</sup> Although no school would claim they are teaching students material that does not support future practice, students can be further motivated to learn when they see the connection between current learning and future tasks. Many motivational theories support the importance of this future task value.<sup>37</sup> For example, subjective expectancy- value theories identify two key independent factors that influence behaviour: the expectancy of success and the degree to which students perceive there to be intrinsic value in doing the task (task value).<sup>37</sup> Demonstrating to students that what they are being assessed on now will support future practice may motivate students to more fully engage in learning those tasks to enable better future practice, rather than simply prioritising current performance.<sup>24</sup> 

It is also worth thinking about the juxtaposition between effective learning strategies and assessment practices to determine how the latter can more directly support curriculum planning. Dunlosky et al<sup>9</sup> have recently outlined how to improve students’ learning with effective instructional and studying techniques. These techniques range from interleaved and non- massed learning to practice testing. It is valuable to consider how these strategies could be embedded 

**4** **<u>|</u>** 

SCOTT 

in assessment practices to take advantage of their learning affordances. For example, a spiral curriculum can facilitate both interleaved and non- massed learning, which in turn supports long- term recall.<sup>9,38</sup> Frequent testing or other situations that require information recall (eg small group learning) can analogously facilitate longterm recall.<sup>39,40</sup> It is important to note that these instructional and study techniques could support either performance or learning depending on how they are deployed. 

### **3.4** | **Assessment** 

Although this paper suggests that assessment does not always drive learning, it is important to examine how our assessment protocols themselves can be deployed to drive learning. It is well established, after all, that testing can support learning through requiring the act of information recall.<sup>39,40</sup> How that act is elicited, however, appears to matter. Factors that support better memory through test- enhanced learning include repeated testing with appropriate spacing intervals, use of production tests (short- answer, fill- in- the- blank, essay, etc.) and the provision of feedback that is appropriately timed.<sup>40-42</sup> 

To understand these features it is important to note that the field has moved away from using the term test- enhanced learning to the more encompassing term recall- enhanced learning. Recall can include scenarios in which students present information in a small group problem- based setting, when they seek to diagnose a patient's illness or when they are asked to perform a procedure or answer an oral question posed by an attending physician.<sup>43</sup> In other words, it is not the act of completing a formal test that directly supports learning but the act of recall that supports the mnemonic effects driving this phenomenon. Does the robustness of test- enhanced learning undermine the claim that ‘assessment drives learning’ is a myth? Yes and no. Yes, because assessments can support learning through the direct and indirect effects of being prompted to recall information. No, because assessments in most programmes do not use production tests that are offered repeatedly with appropriate spacing supported by appropriate feedback. To take full advantage of the recall- enhanced learning effect, we should also consider the other contexts in which recall is integral to our curriculum and recognise that these non- formal assessment settings provide important opportunities for students to engage in ‘testing’. One caveat, as identified by Watling and Ginsburg,<sup>5</sup> is that public assessments do not just entail the collection of data; rather, these assessments are embedded in a complex social setting. Embedded social factors demand that we be careful that our programmes do not become ‘recall mills’ with little time spent on other forms of learning or attention to student development. 

### **3.5** | **Feedback** 

Black and Williams have argued that ensuring assessments are focused on learning requires a clearer distinction between grading students and providing formative feedback.<sup>44</sup> Beyond this distinction, 

there have been calls for the development of formative assessment theory that takes into account issues of both pedagogy and psychology.<sup>44,45</sup> Recently Watling and Ginsburg have noted the need for a clarity of assessment purpose if we wish to foster a ‘culture of improvement rather than a culture of performance’.<sup>5</sup> To adopt a culture of improvement it will be important to utilise some features of effective feedback.<sup>46-50</sup> Feedback practices that support learning are numerous, including: the presentation of elaborated feedback in manageable units in order not to overwhelm the learner; offering explicit guidance to novices or struggling students during the learning process (hints may not be as helpful as more explicit, directive feedback); and attention to timing (with more immediate feedback for difficult tasks and delayed feedback for relatively simple tasks). 

In addition, there are feedback practices in the clinical setting that are associated with strong evidence of effectiveness.<sup>48</sup> As a process, this literature suggests the need to treat feedback as a conversation rather than as a commodity. As content, feedback works best when tailored to the individual trainee, includes reinforcement of key points done well, involves collaborative generation of strategies to improve the quality of work, and supports increased self- awareness. Feedback should ideally focus on how the task was carried out and how that type of task should or might be carried out, as well as being actionable, enabling the trainee to construct strategies for improvement. 

Elaborating on the notion of students being active participants in the co- construction of learning plans, Boud<sup>51</sup> suggests that assessment activities should be directed in such a way as to enable students to undertake self- assessment in their future practice. Once our learners leave our institutions they will not be taking our examinations, seeking bedside observations from our faculty members or engaging in our OSCEs. Instead, they will (hopefully) be wondering if they are competent, if they are acting professionally, are caring enough and are being compassionate. In other words, we should think of our feedback strategies as a means through which to give students in our programmes the approaches to determine if they have the knowledge, skills and attitudes to serve the communities they are working in and to address any deficiencies they identify.<sup>52</sup> Integrating self- regulated learning skills into a programme of learning will further support patient- informed lifelong learning.<sup>53-56</sup> A growing number of educators are calling for the incorporation of coaching strategies that support learning and development in learners in both current programmes and future practice as a means to address a number of the learning and feedback challenges we are now grappling with.<sup>5</sup> 

### **4** | **CONCLUSIONS** 

As we become more explicit about the intent of our assessments, we need to think of our assessments as an integrated part of the curriculum and not just something we do after or separately from other aspects of instruction. Assessment needs to support and be supported by the curriculum if we wish assessment to support learning. We, therefore, need to start thinking about designing our 

**5** **<u>|</u>** 

SCOTT 

assessments, feedback and even coaching in tandem with student development, institutional culture and curriculum design, as well as looking forward to our learners’ ultimate practices. McGaghie asks and answers, ‘… how shall we design an educational environment that produces maximum learning outcomes among all trainees? The answer is to create … a curriculum and assessment plan—that promotes mastery level achievement among all learners’.<sup>57</sup> These considerations add complexity to the ways we plan, develop, apply and interpret our assessments but such considerations are vital to the future of our students and more importantly our patients. 

Does assessment drive learning? Yes, it can, but only through active and purposeful engagement with our learners, our institutions, our curriculum and the appropriate use of assessments and feedback. Through this active and purposeful engagement, we will be more likely to ride with our students towards learning rather than drive our students towards performance. 

#### **ACKNOWLEDGMENTS** 

Thanks to Joanna Bates, Glenn Regehr, Renate Kahlke and Deborah Butler for reading earlier versions of this paper and for their constructive suggestions. 

#### **CONFLICT OF INTERESTS** 

No conflicts of interest. 

#### **AUTHOR CONTRIBUTIONS** 

As the sole author, IS affirms that they satisfy the following four criteria: (a) substantial contributions to the conception or design of the work, or the acquisition, analysis or interpretation of data for the work; (b) drafting the work or revising it critically for important intellectual content; (c) final approval of the version to be published, and (d) agreement to be accountable for all aspects of the work in ensuring that questions related to the accuracy or integrity of any part of the work are appropriately investigated and resolved. 

#### **ETHICAL APPROVAL** 

No human subjects were used so ethical approval was not required. 

#### **ORCID** 

_Ian M. Scott_ https://orcid.org/0000-0003-0396-0966 

#### **REFERENCES** 

1. Swanson DB, Case SM. Assessment in basic science instruction: directions for practice and research. _Adv Health Sci Educ Theory Pract_ 1997; **2** (1):71-84. 

2. Miller GE. _Teaching and Learning in Medical School_ . Cambridge, MA: Harvard University Press; 1961:304. 

3. Van Der Vleuten CP. The assessment of professional competence: developments, research and practical implications. _Adv Health Sci Educ Theory Pract_ 1996; **1** (1):41-67. 

4. Norcini J, Anderson B, Bollela V, et al. Criteria for good assessment: consensus statement and recommendations from the Ottawa 2010 Conference. _Med Teach_ 2011; **33** (3):206-214. 

5. Watling CJ, Ginsburg S. Assessment, feedback and the alchemy of learning. _Med Educ_ 2019; **53** (1):76-85. 

6. James M. Assessment, teaching and theories of learning. In: Gardner J, ed. _Assessment and Learning_ . London, UK: SAGE Publications Ltd; 2006:47-60. 

7. Schunk DH. _Learning Theories: An Educational Perspective_ . Boston, MA: Pearson Education Inc; 2012:561. 

8. Dewey J. _Experience and Education, 60th Anniversary Edition_ . West Lafayette, IN: Kappa Delta Pi; 1998:181. 

9. Dunlosky J, Rawson KA, Marsh EJ, Nathan MJ, Willingham DT. Improving students’ learning with effective learning techniques: promising directions from cognitive and educational psychology. _Psychol Sci Public Interest_ 2013; **14** (1):4-58. 

10. Steinert Y. Student perceptions of effective small group teaching. _Med Educ_ 2004; **38** (3):286-293. 

11. Steinert Y. Twelve tips for effective small- group teaching in the health professions. _Med Teach_ 1996; **18** (3):203-207. 

12. LaDonna KA, Hatala R, Lingard L, Voyer S, Watling C. Staging a performance: learners’ perceptions about direct observation during residency. _Med Educ_ 2017; **51** (5):498-510. 

13. Patel P, Martimianakis MA, Zilbert NR, Mui C, Hammond Mobilio M, Kitto S, Moulton CA. Fake it ‘til you make it: pressures to measure up in surgical training. _Acad Med_ 2018; **93** (5):769-774. 

14. McGaghie WC. Evaluation apprehension and impression management in clinical medical education. _Acad Med_ 2018; **93** (5):685-686. 

15. Lo L, Regehr G. Medical students’ understanding of directed questioning by their clinical preceptors. _Teach Learn Med_ 2017; **29** (1): 5-12. 

16. Higgins E, Newman L, Halligan K, Miller M, Schwab S, Kosowicz L. Do audition electives impact match success? _Med Educ Online_ 2016; **21** :31325. 

17. Gormley GJ, Hodges BD, McNaughton N, Johnston JL. The show must go on? Patients, props and pedagogy in the theatre of the OSCE. _Med Educ_ 2016; **50** (12):1237-1240. 

18. Elliott ES, Dweck CS. Goals: an approach to motivation and achievement. _J Pers Soc Psychol_ 1988; **54** (1):5-12. 

19. Dweck CS. _Mindset: The New Psychology of Success_ . New York, NY: Random House; 2006:277. 

20. Yeager DS, Dweck CS. Mindsets that promote resilience: when students believe that personal characteristics can be developed. _Educ Psychol_ 2012; **47** (4):302-314. 

21. Dweck CS. _Self-Theories: Their Role in Motivation, Personality, and Development_ . New York, NY: Psychology Press; 1999:194. 

22. Johnson DW, Johnson RT. An educational psychology success story: social interdependence theory and cooperative learning. _Educ Researcher_ 2009; **38** (5):365-379. 

23. Frankford DM, Patterson MA, Konrad TR. Transforming practice organizations to foster lifelong learning and commitment to medical professionalism. _Acad Med_ 2000; **75** (7):708-717. 

24. Teunissen PW, Bok HGJ. Believing is seeing: how people's beliefs influence goals, emotions and behaviour. _Med Educ_ 2013; **47** (11):1064-1072. 

25. Klein J, Delany C, Fischer MD, Smallwood D, Trumble S. A growth mindset approach to preparing trainees for medical error. _BMJ Qual Saf_ 2017; **26** (9):771-774. 

26. Tabernero C, Wood R. Implicit theories versus the social construal of ability in self- regulation and performance on a complex task. _Organ Behav Hum Decis Process_ 1999; **78** (2):104-127. 

**6** **<u>|</u>** 

SCOTT 

27. MacNeil AJ, Prater DL, Busch S. The effects of school culture and climate on student achievement. _Int J Leadership Educ_ 2009; **12** (1):73-84. 

28. Howe A. Professional development in undergraduate medical curricula – the key to the door of a new culture? _Med Educ_ 2002; **36** (4):353-359. 

29. Bridges W. _Managing Transitions: Making the Most of Change_ . Cambridge, MA: Da Capo; 2003:164. 

30. Dornan T. Experience- based learning: a model linking the processes and outcomes of medical students workplace learning. _Med Educ_ 2007; **41** (1):84-91. 

31. Van de Wiel MWJ, van den Bossche P, Janssen S, Jossberger H. Exploring deliberate practice in medicine: how do physicians learn in the workplace? _Adv Health Sci Educ_ 2011; **16** (1):81-95. 

32. Shafiq H, Malo JL, Habashy S, Appelbaum SH. Back to the future: revisiting Kotter's 1996 change model. _J Manage Dev_ 2012; **31** (8):764-782. 

33. Schein EH. _Organizational Culture and Leadership_ , 3rd edn. San Francisco, LA: Jossey-Bass; 2004:437. 

34. Kotter JP. _Leading Change_ . Boston, MA: Harvard Business School Press; 1996:187. 

35. Kezar A, Eckel PD. The effect of institutional culture on change strategies in higher education: universal principles or culturally responsive concepts? _J High Educ_ 2002; **73** (4):435-460. 

36. Mylopoulos M, Woods N. Preparing medical students for future learning using basic science instruction. _Med Educ_ 2014; **48** (7):667-673. 

37. Cook DA, Artino AR Jr. Motivation to learn: an overview of contemporary theories. _Med Educ_ 2016; **50** (10):997-1014. 

38. Harden RM. What is a spiral curriculum? _Med Teach_ 1999; **21** (2):141-143. 

39. Larsen DP, Butler AC. Test-enhanced learning. In: Walsh K, ed. _Oxford Textbook of Medical Education_ . Oxford, UK: Oxford University Press; 2013:443-452. 

   45. Taras M. Assessment – summative and formative – some theoretical reflections. _Br J Educ Stud_ 2005; **53** (4):466-478. 

   46. Shute VJ. Focus on formative feedback. _Rev Educ Res_ 2008; **78** (1):153-189. 

   47. Nicol DJ, Macfarlane-Dick D. Formative assessment and selfregulated learning: a model and seven principles of good feedback practice. _Stud High Educ_ 2006; **31** (2):199-218. 

   48. Lefroy J, Watling C, Teunissen PW, Brand P. Guidelines: the do's, don'ts and don't knows of feedback for clinical education. _Perspect Med Educ_ 2015; **4** (6):284-299. 

   49. Ridder JMM, McGaghie WC, Stokking KM, ten Cate OT. Variables that affect the process and outcome of feedback, relevant for medical training: a meta- review. _Med Educ_ 2015; **49** (7):658-673. 

   50. Ryan A, McColl GJ, O'Brien R, Chiavaroli N, Judd T, Finch S, Swanson D. Tensions in post- examination feedback: information for learning versus potential for harm. _Med Educ_ 2017; **51** (9):963-973. 

   51. Boud D. Sustainable assessment: rethinking assessment for the learning society. _Stud Contin Educ_ 2000; **22** (2):151-167. 

   52. Boud D, Falchikov N. Aligning assessment with long- term learning. _Assess Eval High Educ_ 2006; **31** (4):399-413. 

   53. Sandars J, Cleary TJ. Self- regulation theory: applications to medical education: AMEE Guide No. 58. _Med Teach_ 2011; **33** (11):875-886. 

   54. Brydges R, Butler D. A reflective analysis of medical education research on self- regulation in learning and practice. _Med Educ_ 2012; **46** (1):71-79. 

   55. Schumacher DJ, Englander R, Carraccio C. Developing the master learner: applying learning theory to the learner, the teacher, and the learning environment. _Acad Med_ 2013; **88** (11):1635-1645. 

   56. Brydges R, Dubrowski A, Regehr G. A new concept of unsupervised learning: directed self- guided learning in the health professions. _Acad Med_ 2010; **85** (Suppl 10):S49-55. 

   57. McGaghie WC. Mastery learning: it is time for medical education to join the 21st century. _Acad Med_ 2015; **90** (11):1438-1441. 

40. Larsen DP, Butler AC, Roediger HL 3rd. Test- enhanced learning in medical education. _Med Educ_ 2008; **42** (10):959-966. 

41. Butler AC, Roediger HL. Feedback enhances the positive effects and reduces the negative effects of multiple- choice testing. _Mem Cognit_ 2008; **36** (3):604-616. 

42. Bangert-Drowns RL, Kulik C-LC, Kulik JA, Morgan M. The instructional effect of feedback in test- like events. _Rev Educ Res_ 1991; **61** (2):213-238. 

**How to cite this article:** Scott IM. Beyond ‘driving’: The relationship between assessment, performance and ~~learning.~~ _~~Med Educ~~_ ~~. 2019;00:1–6.~~ ~~<u>https ://doi.org/10.1111/</u>~~ <u>medu.13935</u> 

43. Larsen DP, Dornan T. Quizzes and conversations: exploring the role of retrieval in medical education. _Med Educ_ 2013; **47** (12):1236-1241. 

44. Black P, Wiliam D. Assessment and classroom learning. _Assess Educ_ 1998; **5** (1):7-74. 

