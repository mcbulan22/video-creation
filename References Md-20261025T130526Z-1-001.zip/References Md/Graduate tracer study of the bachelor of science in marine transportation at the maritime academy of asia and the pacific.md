**MARITIME ACADEMY OF ASIA AND THE PACIFIC KAMAYA POINT** Associated Marine Officers’ and Seamen’s Union of the Philippines – PTGWO - ITF Kamaya Point, Brgy. Alas-asin, Mariveles, Bataan 

F-020 Issue 0 Rev. 0 15 January 2016 



# **Graduate Tracer Study of the Bachelor of Science in Marine Transportation at the Maritime Academy of Asia and the Pacific** 

C/M Renante Garcia<sup>**1**</sup> **,** Janice Vergara<sup>**2**</sup> & Capt. Januario Lansang, Jr.<sup>**3**</sup> **_1,3_** _Department of Academics, MAAP_ **_2_** _Academics Research Unit, Maritime Academy of Asia and the Pacific (MAAP)_ _<u>jkwvergara.aru.maap@gmail.com</u>_ 

**_Abstract:_** _For continual improvement, this research aimed to obtain feedback from graduates of Bachelor of Science in Marine Transportation (BSMT) and make the program more responsive to the needs of the industry. A MAAP-customized graduate tracer survey was used to generate data from graduates in 2003 to 2012. SPSS was employed to calculate statistics such as frequency counts, percentage, and Chi square analysis and Cramer’s V. Results showed that the respondents are generally satisfied with the study provisions and conditions that MAAP provides. Skills and knowledge gained from the Academy were also deemed to be very relevant to jobs; most especially critical thinking and managerial/ leadership. With respect to employment, all of the respondents are currently employed; 49% on-board ships and 51% toggle between sea-based and maritime land-based jobs. Majority of them obtained their first seagoing jobs through the Academy’s placement office. Most of the alumni were able to board their first vessel after graduation in nine (9) months or less, mostly as cadets while others as operational level officers and ratings. Moreover, profile variables such as age, sex, year graduated, OIC licensure examination performance, and study provisions and conditions are significantly associated with some areas of employability. Further, relevance of knowledge and skills is significantly associated with waiting time before first seagoing job and professional success as a mariner. Specifically, theoretical and managerial/leadership are most related to their professional success. This study recommends further studies and development programs to enhance relevant study provisions and conditions and knowledge and skills._ 

**_Keywords:_** _Employability, graduate tracer study, BSMT._ 

## **1. Introduction** 

Over the years, the Philippines has been recognized as the manning capital of the world, supplying over 25% of the world’s maritime fleet. In 2010, the BIMCO/ISF Manpower 

Update reports a notable increase in manpower supply from the Philippines along with other Far East countries. 

Seafaring as a profession is still very attractive and provides gainful employment to many Filipinos and no doubt immensely contributes to the economy (Francisco, 2005). In fact, Peña (2000) quoted maritime education as a “winner course” because graduates of this program are readily acceptable for employment abroad. However, the extent to which these graduates remain competitive,  considering the increasing global maritime demands, is the accountability of quality education (Ramirez, 2001). While employability revolves primarily around individual’s characteristics, personal circumstances and external factors in the labor market, education plays a key role in the ability of graduates to gain and maintain employment (Kabir, 2014). 

Recently, the maritime higher education institutions (MHEIs) and maritime education and training institutions (METIs) are faced with issues on the quality and competitiveness of their graduates. Also, BIMCO stressed the importance of well qualified and high caliber seafarers capable of adapting to change and handling a wide range of tasks now required of their profession in the shipping industry. 

The success of the Philippine maritime manpower industry largely depends on the quality of maritime education and training. Maritime schools need to reconsider their mission of preparing their students for the seafaring profession in the light of changes in the local and international markets; new knowledge and skills to adapt to changing job demands; and dealing with an increasingly 

MAAP Research Journal 

Page 1 

competitive international maritime labor pool. They should work closely with the other maritime stakeholders – the industry leaders, government agencies, and the seafarers themselves to improve their ability to produce graduates who are potential officers of the highest caliber. (Magsaysay-Ho, 2005). 

In the light of ensuring relevant, efficient and quality maritime education and training as a key to increasing competitiveness in the international shipping industry, the Maritime Academy of Asia and the Pacific (MAAP) pursues graduate tracer studies, impact analysis tools, that aim to assess the employability of its graduates. This is conducted to get valuable information for the development of the school, to evaluate the relevance of higher education, to contribute to the accreditation process and to inform students, parents, teachers and administrators (Schomburg, 2003) 

As a maritime higher education institution, MAAP aims to ensure the employability of its graduates in the world shipping business. To this end, an employability analysis of the ten (10) batches of graduates from the academy is being worked on. This study gathered relevant data which will be used to devise measures or programs for the continual quality improvement of the curriculum to ensure that students are well-prepared to face the challenges of the seafaring profession. 

### **1.1. Statement of the problem** 

The study primarily aims to address the following question: “How may the personal and educational variables affect the employability status of the graduates of Bachelor of Science in Marine Transportation (BSMT) at the Maritime Academy of Asia and the Pacific (MAAP), Mariveles, Bataan from 2003 to 2012.” 

Specifically, the study aims to answer the following questions: 

1. What is the profile of the respondents in terms of the following: 

   - 1.1 Personal Variables: Sex, Age, Civil Status, Religion, Urbanity (location), Dialect, and Region or origin; and 

   - 1.2 Educational Variables: Year of graduation; OIC licensure examination performance;  Reasons for taking the course; Adequacy of 

      - educational preparation before college, and; Study provisions and study conditions experienced? 

2. How do the respondents perceive the relevance of the skills and knowledge acquired at MAAP to their respective job? 

3. How may the status of employability of the respondents be described in terms of the following: 

   - 3.1 Current occupation; 

   - 3.2 Approaches in getting first seagoing jobs; 

   - 3.3 Waiting time on first seagoing job placement after graduation; 

   - 3.4 Average length of service per embarkation; 

   - 3.5 Initial Position held on-board 

   - 3.6 Present Position/s held on-board; 

   - 3.7 Current license/rank; 

   - 3.8 Initial gross monthly salary in the first job; 

   - 3.9 Present salary; 

   - 3.10 Reasons for staying on the job, and; 

   - 3.11 Professional Success? 

4. Are there personal profile variables that are significantly associated with the status of employability of respondents? 

5. Is there a significant relationship between the educational profile variables and the employability status of the respondents? 

6. Is there a significant relationship between the relevance of skills and knowledge acquired from the academy and the status of employability of the respondents? 

### **1.2. Significance of the study** 

Institutionally, the management could utilize the results of the study in formulating development plans or curriculum revisions to better improve the quality of maritime education and training that the academy provides. They will be better equipped with key labor market information and employability of graduates needed for improving the degree program. Further, the tracing of graduates might help establish co-operation/contacts between the academy and the alumni who may help evaluate the relevance of the BSMT program and contribute to the accreditation process. Perceptions of graduates towards the effectiveness of the academic programs, infrastructure, services and administrative 

MAAP Research Journal 

Page 2 

systems of the institution of learning are useful for the industry. 

Indirectly, the maritime industry would benefit from the result of the study as the cooperation between the maritime education and shipping industry sectors would ensure that quality and competent graduates are absorbed by the industry. Hence, lesser problems or concerns when it comes to the competence of officers and accidents due to human error can be minimized. The shipping managers/owners would be ascertained of the quality of maritime deck and engine officers that they would be hiring to man their international vessels. 

Also, the maritime students, who are the future marine deck and engine officers, would benefit from the study as the results would guide them to better prepare for the industry where they would be engaging in. Awareness of the knowledge and skills required on board would prompt the students to be more studious to ascertain their job placement and lifelong career as seafarers. 

On the other hand, the findings of this study will provide a relevant reference for other researchers interested in working on the employability of graduates, particularly maritime graduates. 

### **1.3. Scope and delimitation** 

The study is focused on the employability analysis of the first 10 batches of MAAP BSMT graduates or alumni. This study utilized a graduate tracer survey accomplished by the class of 2003 to class 2012 respondents through personal interview, letters, e-mails, or other electronic means. This study is limited to available MAAP alumni who responded to the request of the researcher within the time frame, during the Academic Year 2014-2015. 

### **1.4. Literature review** 

_Graduate employability._ Employability is defined as “a set of skills, knowledge and personal attributes that make an individual more likely to secure and be successful in their chosen occupation for their own benefit, the workforce, the community and the economy” (Moreland, 2006). In securing a job, a graduate must be equipped with most of the skills desired by the employer and the ability to participate and 

contribute to the knowledge economy by applying what they learned in higher education and also improve their social standing and the country’s economy (Paadi, 2014). 

One of the major concerns of higher education institutions today is connecting education and employability. To better understand these concepts, the researcher draws on various theories about the impact of education in connection with graduate employability. One of these theories is the human capital theory that argues that education provides productive skills to individuals. With respect education, this theory  posits that education provides knowledge and skills that have a direct influence on the productivity of workers (Becker, 2002). Nevertheless, it must be noted that employability is the product of a complex mixture of different factors located in the labor market, in universities, in the recruitment procedures of businesses, in the economic policies implemented by the government and in the personal/social characteristics of individual graduates (Smetherham, 2003). 

_Maritime Education and Training._ Maritime stakeholders are actively involved in the whole process of improving Filipino standards in the maritime industry. As MET providers, maritime institutions should refocus their programs towards developing more officer caliber cadets/cadettes with the necessary technical and social skills needed in the industry and develop seafarers who possess what the international shipping community tagged as STCW skills (San Pedro, 2009). 

Maambong (2008) studied the perceptions and compliance among maritime schools of the policies, standards and guidelines for maritime education in the Philippines. He suggested various vital basis for the future improvement and development of the maritime curricula to CHED as the government agency tasked to supervise both public and private higher education institutions. He also said that it is high time for the maritime schools and their assessors and faculty to realize that failure to comply with STCW and CHED requirements on the proper implementation of the competency-based curriculum would be reasons for the delay of the 

MAAP Research Journal 

Page 3 

completion of the baccalaureate maritime program. 

### **1.5 Conceptual framework** 

Figure 1 demonstrates the research paradigm of the study. 

held on-board, current license/rank, initial gross monthly salary in the first job; present salary, reasons for staying on the job, and professional success. 

### **1.6. Hypotheses of the study** 

The following hypotheses were formulated: 

|**Personal Variables**<br> Gender|**Employability Status**<br> Current Occupation<br>|
|---|---|
| Age<br> Civil status<br> Dialect<br> Religion<br> Urbanity<br> Region| Approaches in getting<br>first seagoing jobs<br> Waiting time on first<br>sea-going job<br>placement after<br>graduation<br> Average length of|
|**Education Variables**|service per<br>|
| Year of Graduation|embarkation|
| OICNW Licensure| Initial Position on|
|exam performance|board<br>|
| Reasons for taking the<br>course| Present Position on<br>board|
| Adequacy of| Current License/Rank<br>|
|preparation before<br>studying at MAAP| Initial Salary during<br>first job|
| Study Conditions and| Present salary|
|Provisions| Reasons for staying|
|**Relevance of Acquired**|on the job|
|**Knowledge and Skills**<br>**in College (at MAAP)**| Professional Success|



**Figure 1. Research Paradigm** 

The research paradigm shows that the BSMT graduates, manifested personal and educational variables relevant to their employment status. This study conceptualized the existence of association among the personal and educational variables, relevance of acquired knowledge and skills in college, and employability status of graduates. Personal variables include gender, age, civil status, dialect, religion, urbanity and region of origin, while educational variables consist of Officer in Charge of Navigational Watch (OIC-NW) licensure examination performance, reasons for taking the course, adequacy of preparation before studying at MAAP, and study conditions and provisions experienced. 

On the other hand, employability indicators include current occupation, approaches in getting first seagoing jobs, waiting time on first seagoing job placement after graduation, average length of service per embarkation, initial position held on-board; present position 

1. There are no significant relationships among the personal variables and the employability status of the respondents; 

2. There are no significant relationships among the educational variables and the employability status of the respondents, and; 

3. There are no significant relationships between the relevance of knowledge and skills acquired at MAAP and the graduates’ employability status. 

## **2. Methodology** 

This study used descriptive design as it describes the events that happened and characteristics of the alumni of MAAP during the study period. It utilizes the descriptivesurvey approach where a survey questionnaire was used to gather feedback from the respondent. It also utilized correlation design to determine the existence of relationships among certain variables such as the profile variables and those relating to employability status of the responding alumni. 

The respondents of this study were 100 Bachelor of Science in Marine Transportation (BSMT) graduates from the year 2003 to 2012, the first ten (10) batches produced by MAAP. 

The primary research instrument utilized in this study is a structured questionnaire, adapted from the CHED graduate tracer survey form, involving questions on personal and performance background, employability status, and opinions on the relevance of education acquired to the respondent’s jobs. 

Data gathering for this study was carried out by the MAAP Alumni Office which is responsible in tracking the whereabouts of the graduates. The questionnaires were sent to the respondents via email, which is a convenient and fast way of communication. Respondents were also able to respond to the questionnaire 

MAAP Research Journal 

Page 4 

during the Annual MAAP Alumni Parade. However, due to the difficulty of reaching graduates who are mostly abroad or on-board vessels, only 100 respondents were obtained after an extended data gathering period during the Academic Year 2014-2015. 

The data collected were encoded and statistically analyzed using the statistical software called SPSS version 18. Statistical tools such as frequency, percentage, and mean were used depending on the nature of the data. Chi square analysis and Cramer’s V were used to analyze relationships of nominal variables such as profile variables and some employability status variables like occupation. Based on Rea & Parker (2014), Cramer’s V coefficient is interpreted such that a value below 0.10 indicates a negligible association; 0.10 to 0.19 weak association; 0.20 to 0.39 moderate association; 0.40 to 0.59 relatively strong association; 0.60 to 0.79 strong association, and; 0.80 to 1.00 very strong association. Correlation analysis was also utilized. In interpretation correlation coefficients, this study utilized the following (Garcia, et. al., 2011): 

Value Interpretation (Relationship) ±0.90 – ±1.00 Very high correlation; Very significant ±0.70 - ±0.89 High correlation; Significant ±0.40 - ±0.69 Moderate correlation; Average ±0.20 - ±0.39 Low correlation; Small 0.19 and below Very low correlation; Almost none 

## **3. Results** 

35% use their native languages across the country such as Cebuano, Ilocano, Kapampangan, Ilonggo, Bisaya, Hiligaynon, Kankanaey (a Cordilleran dialect), Ivatan, Pangasinan and foreign languages (German and Indonesian). 

As regards the urbanity of the respondents, 59% claimed that they grew in the cities or urban areas while 41% in municipalities or rural areas. As reflected in Table 2, it can be surmised that the alumni respondents came from varied regions across the country. The top region is Central Luzon (Region III) with 26% of the respondents; followed by CALABARZON (Region IV-A) with 20% and then National Capital Region (NCR) with 12%. 

### **3.1.2 Educational Experience** 

The educational experience includes variables such as year of graduation, reasons for taking the BSMT course, adequacy of educational preparation before entering college, problems encountered while studying at MAAP, study provisions and conditions, PRC OICNavigational Watch Licensure Examination performance,  and reasons for pursuing advanced education. _Year of graduation_ . All the classes are represented. Fifty nine percent (59%) of the respondents are graduates of the first five classes of MAAP (Class 2003 to Class 2007) while 41% are from the second five classes who graduated from 2008 to 2012. 

### **3.1 Profile of the respondents** 

### **3.1.1 Personal Profiles** 

Fifty two percent (52%) of the respondents are 30 to 34 years of age, 39% are 24 to 29 years old and 9% is 35 to 39 years old. The majority or 95% of them are males while only five percent (5%) are females. With respect to civil status, 58% are still single while 41% are married. 

In terms of religious affiliation, the majority or 86% of the respondents are Catholics while 14% are Protestants such as Born Again, Christian sects, Anglican, Baptist, and Presbyterian. 

With respect to the dialect, majority or 65% of the respondents are Tagalog while the other 

_Reasons for taking the course._ The top reason cited by the alumni for taking BSMT at MAAP is scholarship as mentioned by 68% of the respondents. This is followed by prospect for immediate employment with 44% of the respondents. Next is influenced by parents/relatives (40%) and then prospect of attractive compensation (36%). It is presumed that economics is a major reason for taking BSMT course, but they are also concerned with getting better prospect for employment and career opportunities. 

_Adequacy of Educational Preparation before Entering the Course._ When asked if the educational preparation of the respondents are adequate before taking up BSMT, 83% claimed that it is adequate, nine percent (9%) not adequate, and eight percent (8%) uncertain. 

MAAP Research Journal 

Page 5 

_Problems Encountered While Studying at MAAP_ . Twenty four percent (24%) of the respondents claimed that they have no problem encountered with studying at MAAP while 38% did not respond to this question. Most problems mentioned are experienced during the early stage of their schooling where they are still adjusting to their new environment and the semi-regimented/leadership scheme with rigorous academic programs. Homesickness was listed as the top problem encountered by the students, especially during their first year level. This is followed by food and water. Since the students are housed inside and MAAP is providing for their meals, students do not have the luxury of eating the food they are used to or food they wanted to eat. It is only after their fourth class year that students are allowed to buy from the slop chest or from the ASTC canteen, though choices are also limited. The respondents also mentioned academics-related problems. One problem mentioned is the lack of practical applications since they have limited use of the simulators and other facilities. One respondent also mentioned problem having to cope with general education courses such as Filipino and Social Science instead of focusing on maritime education courses.  Other problems encountered by the respondents are related to their semi-regimented training, time management/pressure, sponsorship, and personal or family matters. 

_Study Provisions and Study Conditions Experienced._ It can be noted that alumni from Classes 2008 to 2012 provided relatively higher ratings compared to the first five (5) batches. However, both of these groups provided the highest mean rating of 4.36 and 4.73, respectively, on the length of study in the academy. 

For the first five (5) batches of respondents, the next highest mean rating  of 4.32 is testing/grading system; followed by contact with fellow students (with mean of 4.29) and then teaching quality of lecturers/teachers (with mean of 4.25). On the other hand, their lowest mean of 3.98 is on chances to participate in research and extension projects. Nonetheless, the alumni of Classes 2003 to 2005 provided good ratings on all the study provisions and conditions in Table 5. 

For the alumni of classes 2008 to 2012 (second five-batches), study provisions and conditions such as the length of study in the academy (4.73), course content of major subject (4.63), design/structure of degree program (4.58), and contact with fellow students (4.58) are considered very good. 

Overall, length of study in the academy obtained the highest total mean of 4.51 (very good) while the lowest total mean of 4.02 (good) on chances to participate in research and extension projects. 

Further, the younger graduates are more satisfied with their overall experience at the academy as indicated by their mean of 4.55 compared to those older ones with 4.32. Statistically, both groups have good overall study provisions and conditions by composite means of 4.21 for graduates of 2003 to 2007 and 4.45 for graduates from 2008 to 2012. 

_OIC-Navigational Watchkeeping licensure examination performance._ With respect to PRC licensure examination, the majority or 86% of the respondents has passed their first attempt at getting OIC-Navigational Watch license. As shown in Table 6, 56% of the respondents obtained 70 to 79% passing rate while 30% got 80 to 90% passing rate. Twelve percent (12% ) of the respondents were not able to pass their first PRC take but were able to eventually pass after another one or more attempts. 

_Training(s)/Advance Studies Attended After College._ Maritime graduates or even long time maritime professionals are compelled to pursue advanced studies if they wanted to continue their career on-board international vessels. Seafarers are mandated to comply with international standards such as the requirements brought about by the International Convention on Standards of Training, Certification and Watchkeeping for Seafarers (STCW). Also, the BIMCO/ISF Manpower 2010 Update, a recognized and credible report in the maritime world, stressed the importance of well qualified and high caliber seafarers capable of adapting to change and handling wide  range of tasks now required of their profession in the shipping industry. <mark>Thus, M</mark> AAP alumni are compelled to pursue advanced studies through maritime 

MAAP Research Journal 

Page 6 

trainings in various accredited maritime training agencies for professional development and promotion. 

### **3.2. Relevance of Knowledge and Skills Acquired at MAAP in Jobs** 

The respondents, as a whole, considered the skills and knowledge they gained from MAAP to be very relevant, having a total composite mean of 4.56. The respondents provided the highest total mean of 4.63 on critical thinking, and then managerial/leadership with 4.62, indicating very relevant. Their lowest total mean of 4.44 is on theoretical knowledge and skills which is considered relevant. 

Specifically, for the first five (5) batches of graduates, human relations knowledge and skills obtained the highest mean relevance of 4.61 (very relevant) while the lowest mean of 4.31 is on theoretical knowledge and skills. As shown, knowledge and skills in human relations, managerial/leadership, communication, and critical thinking are very relevant while technical, theoretical and problem solving are only relevant. 

For the second five (5) batches of graduates, all of the knowledge and skills are very relevant to the jobs of the respondents, most especially critical thinking with the highest mean of 4.78 and then managerial/leadership with a mean of 4.68. On the contrary, the lowest mean of 4.60 is on human relations knowledge and skills, although this suggests high relevance to respective jobs. 

### **3.3. Status of employability of the graduates** 

Employment here means any type of work performed or services rendered in exchange for compensation under a contract of hire which create the employer and employee relations. From the deck alumni surveyed, 98% are currently employed while two percent (2%) are employed but on vacation. 

_Occupation of Seafarers._ Forty nine percent (49%) of the deck alumni are currently working on-board ships; 40% are in toggling between sea-based jobs and maritime land-based jobs such as a training or shipping managers in shipping companies and training centers, and; 

11% are instructors or facilitators in maritime schools or training centers. 

When asked if their first job is related to the course they took up in college, 100% of the respondents claimed that these are related as they have taken jobs in the maritime industry. While not all may be working on-board, all of them are engaged in the industry, particularly in the maritime education and training sector and in the recruitment/manning agencies. 

When asked if their current job is their first job after college, 35% answered yes and 23% said no while others did not respond to this question. 

_Approaches in Getting First Seagoing Job Placements._ The majority or 74% of the Alumni obtained their first seagoing job with the help of the school’s job placement office – the Department of Shipboard Training (DST). Also, 12% reported that they were able to obtain first employment as walk in applicants; 12% as recommended by someone, and three percent (3%) through family business. 

_Waiting time on first seagoing job placement after graduation._ Twenty five percent of the alumni were able to board their first vessel after graduation in less than three (3) months after graduation, 19% for three (3) to six (6) months, and 23% for six (6) to nine (9) months. Also, 20% were able to board their first vessel after nine (9) to 12 months while nine percent (9%) waited for over a year. It can be surmised that 67% of the respondents were able to board their first vessel up to nine (9) months while 29% for over that period. This result is better compared to the AIMS tracer study for its alumni for 1994-1995 to 2003-2004 where 67% have waiting time of at least one (1) year after graduation and 24% who reached up to two (2) years of waiting before getting a job (Paderanga, 2009). 

_Average Length of Service Per Embarkation._ Forty six percent (46%) of the respondents have an average length of service per embarkation of seven (7) to nine (9) months while 25% for five (5) to six (6) months. Only nine percent (9%) have an average seagoing contract of less than five (5) months while 13% for over nine (9) months to one (1) year. 

MAAP Research Journal 

Page 7 

_Initial and Present Positions Held in Board._ On their first seagoing contract after graduation, only 17% reported that they boarded their vessels as operational level officers. Most or 72% of them claimed that they boarded as cadets while 11% as ratings. 

In their present positions during the survey period, the majority or 82% of the respondents were already operational level officers, 17% were management level officers, and only one percent (1%) was a rating. 

Considering their initial position, 81% of the alumni who initially boarded their vessels as cadets are operational level officers while 19% are now management level officers. For those who initially boarded their vessels as ratings, 82% are now operational level officers and nine percent (9%) are now management level officers. For those who started as operational level officers, 94% are still operational level officers who are probably second officers while only six percent (6%) are management level officers. 

_Current license/rank._ 41% of the respondents are management level officers (Chief Mate and Captain) while 51% of them are operational level officers (third and second mates). 

_Initial and Present Gross Monthly Earnings as Seafarers._ In terms of initial pay on first seagoing career, a majority or 65% of the alumni claimed that they boarded as cadets. Twenty three percent (23%) have an initial pay of $1,000 to $2,000 while 12% earned $2,001 to $4,000. Their initial pay is estimated to be an average of $1,010. 

With respect to present pay, a rough average of $3,600 can be estimated. Four (4) of the 100 respondents are still earning below $1,000. These respondents have taken land-based jobs which are way below their usual pay on board ships. Also, four percent (4%) are earning $1,000 to $2,000 while 21% are receiving salaries of $ 2,001 to $3,000. Moreover, 41% are getting $3,001 to $4,000 while 30% are receiving over $4,000. 

It can be surmised that most or 91% of the alumni have increased earnings from their first seagoing contract to present while nine percent (9%) decreased. These respondents have opted to get land-based jobs to be with their families and/or to rest from their usual seafaring practice even with lower salaries. 

_Reasons for Staying on the Job._ The majority or 72% of the respondents are staying in their jobs because of salaries and benefits. The second most cited reason is career challenge which is mentioned by 49% of the respondents and the third one is related to course or program of study which is according to 36%. The other reasons include related to special skill, proximity to residence, peer influence, and family influence. 

_Professional Success._ For the alumni of classes 2003 to 2007, the composite mean of 3.94 suggests that they are satisfied with the different dimensions of their professions. They are most satisfied with job prestige having the highest mean of 4.12, and then followed by salary with a mean of 4.05. Their lowest mean rating of 3.68 is on awards and recognition and then on fringe benefits with a mean of 3.86. 

For the alumni of classes 2008 to 2012, their highest mean rating of 4.21 is on their work tasks. This is followed by job prestige with a mean of 4.15. On the other hand, their lowest mean of 3.60 is also on awards and recognition and then work environment with a mean of 3.92. 

As a whole, the respondents are satisfied with all the dimensions of their profession as suggested by the mean ratings reflected in Table 15. The respondents are most satisfied with respect to job prestige having a total composite mean of 4.13; followed by work tasks with a mean of 4.09. In contrast, they are least satisfied with awards and recognition with a total composite mean of 3.65 and fringe benefit with a mean of 3.93. 

### **3.4. Personal profile variables and status of employability** 

Age group is significantly associated with the current occupation of the respondents as suggested by the significant chi square value of 10.64. Also, Cramer’s V value of 0.33 suggests a moderate association between these variables. To a moderate extent, younger seafarers tend to 

MAAP Research Journal 

Page 8 

continue to take sea-based work while older ones for alternating seagoing and land based jobs and full land based jobs. 

Also, sex is associated with the current occupation of the respondents as suggested by the chi-square value of 12.92 significant at 0.002 as well as the Cramer’s V Coefficient of 0.36 which is also significant at 0.002. This coefficient suggests a moderate association. When the crosstabulation of data was analyzed, it was found that more males opt to work on purely sea-based jobs while more women tend to work land based jobs or shifting between sea and land based occupations. 

On the other hand, age and waiting time before first seagoing job are significantly associated as indicated by the chi square value of 9.12 significant at 0.03. The Cramer’s V coefficient of 0.31 implies moderate association. To a moderate extent, younger respondents have a longer period of time waiting before boarding their first vessels compared to the older ones. Forty four percent (44%) of the respondents who a 24 to 29 years old has waited for nine (9) months or longer before their first seagoing contract while 21% of those who are aging from 30 to 39 years old have also waited for the same period of time. Also, 34% of the respondents who are in their 20s have six (6) months or less waiting time while 54% of those who are in their 30s also have the same six (6) months or less waiting before first embarkation. 

Similarly, age is significantly associated with the initial job level as implied by the significant chi square value of 9.89. The Cramer’s V coefficient of 0.31 suggests a moderate association. More of the older respondents started out as ratings while more of the younger ones boarded their first vessels as operational level officers. <mark>Likewise, age is significantly related to license/rank having a chi square value of 12.87 significant at 0.005 and significant Cramer’s V coefficient of 0.37. This also suggests a moderate association.</mark> 

The other profile variables are not associated with status of employability in terms of occupation, waiting time before first seagoing job, initial job level, and level/rank of the respondents. 

Also, the profile variables such as age, sex, civil status, religion, region, and urbanity are not significantly associated with the specific areas of employability such as average length of embarkation, present job level, initial and present salaries, and perceived professional success as seafarers. 

In a tracer study on maritime graduates at the Asian Institute of Maritime Studies, Paderanga (2007) found that the employability of graduates in terms of waiting time for job after graduation and after filing of application does not depend on the alumni’s personal attributes or having a seaman father, but on other factors such as, skills and knowledge acquired from the school, previous work experience, character/attitude, reputation of the school from which the graduate obtained his degree and the demand of the labor industry. 

### **3.5. Educational variables and status of respondent’s employability** 

The class of the respondents is associated with their present occupation based on the significant chi square value of 10.66 and the moderate Cramer’s V coefficient of 0.33. From the crosstabulation of variables, it can be noted that the proportion of alumni who are still active purely in seagoing jobs is greater for classes 2008 to 2012 compared to classes 2003 to 2007. In contrast, more alumni from classes 2003 to 2007 toggle between sea-based and land-based maritime jobs compared to those of classes 2008 to 2012. 

Further, the significant chi square value of 12.50 and Cramer’s V coefficient of 0.36 suggests a moderate relationship between the year graduated and waiting time before the first seagoing job. More proportion of the respondents from class 2008 to 2012 have waiting time of nine (9) months or longer compared to those from class 2003 to 2007 which waited for the same period of time before boarding international vessels. 

Similarly, year graduated is significantly associated with both initial and present job levels as suggested by the significant chi square and Cramer’s V coefficient. 

Moreover, year graduated is significantly related to the license of the respondents as 

MAAP Research Journal 

Page 9 

suggested by the significant chi square value of 15.00 and relatively strong Cramer’s V coefficient of 0.40. More proportions of the respondents from classes 2003 to 2007 are of higher ranks/licenses (management level) while more respondents from classes 2008 to 2012 are of lesser ranks/licenses (operational level). 

On the other hand, year graduated is not significantly associated with average length of embarkation,  initial and present salaries, and perceived professional success as suggested by the not significant chi square values and negligible Cramer’s V coefficients. 

Only occupation is significantly associated with the OIC licensure performance of the respondents. This is indicated by the chi square value of 4.01 significant at 0.05 and the Cramer’s V coefficient of 0.20. This suggests a moderate relation wherein to a moderate extent, a more proportion of those who initially failed the licensure examination are working on landbased jobs while more percentage of those who passed are toggling between land and sea-based jobs. 

Study provisions and conditions experienced is significantly associated with waiting time before first sea-going job and perceived professional success while it is not significantly related to the other aspects of employability. 

As shown, the p-value associated with chi square value of 5.98 is significant for the dependent variable - waiting time before first sea-going job. This relationship is considered to be moderate as suggested by the Cramer’s V coefficient of 0.25.  When the crosstabulation was analyzed, it was found that more proportion of respondents who have a lower rating for their study provisions and conditions at MAAP were able to board six (6) months or less while more percentage of those with a higher rating for their study provisions and conditions were able to board their first vessel after over six (6) months. 

Interestingly, study provisions and conditions is significantly associated with perceived professional success as indicated by the chi-square value of 27.45. The Cramer’s V coefficient of 0.53 suggests a relatively strong association between these variables. The majority of the respondents with lower 

perceived professional success have lower study provisions and conditions experienced while most of those with very high professional success have very good ratings on their study provisions and conditions. 

The result suggests that study provisions and conditions at MAAP are significant in the employability of the graduates, particularly in terms of waiting before first seagoing career and professional success. This coincides with the findings of Paderanga (2007) where the traditional role of the school of equipping its students with adequate and appropriate knowledge, skills, and competencies are important components of the employability of its graduates. 

Relevance of knowledge and skills obtained in college is only significantly associated with waiting time before the first seagoing job and with professional success as a navigator. Waiting time is moderately associated with relevance of knowledge and skills as indicated by the Cramer’s V coefficient of 0.35. Also, there is a moderate relationship between the relevance of knowledge and skills to professional success of the respondents as suggested by the Cramer’s V coefficient of 0.39. The majority of the respondents who have excellent professional success considered their knowledge and skills to be very relevant in their professions. 

Using Spearman Rho correlation analysis, it can be confirmed that the mean perception of the respondents on the relevance of knowledge and skills acquired at MAAP is moderately related to the professional success of the respondents having a correlation coefficient of 0.46. In a tracer study conducted in Kenya, knowledge, attitudes and skills acquired during the study at the university is associated with their present jobs (Kimani, 2002). 

With respect to the specific areas, although theoretical knowledge and skills is the least relevant to jobs, it seems to be the most related to professional success having a moderate correlation coefficient of 0.43. This is followed by managerial/leadership knowledge and skills with a correlation coefficient of 0.42, and then communication, knowledge and skills with a correlation coefficient of 0.40. 

MAAP Research Journal 

Page 10 

On the other hand, the least correlated areas with professional success are human relations and problem solving knowledge and skills, both with low correlation coefficients of 0.34. 

## **4. Discusssions** 

### **4.1. Summary and Conclusions** 

In terms of personal profile, the majority of the respondents are males with age ranging from 24 to 39. Fifty eight percent are single and 41% are married. The majority of them are Tagalogs and Roman Catholics. Also, 59% are from urban areas while 41% hail from rural areas. Almost all of the regions in the country are represented by the respondents. 

With respect to their educational experience at MAAP, 59% of the respondents represents the first five (5) classes (2003 to 2007) and 41% from the second five (5) graduates (2008 to 2012) of the academy. The top reasons cited by the alumni for taking BSMT at MAAP are scholarship and prospect for immediate employment. The majority of them claimed that they have adequate educational preparation before taking up BSMT. In terms of study provisions and conditions, the respondents are most satisfied with their length of study in the academy while least satisfied on chances to participate in research and extension projects. The majority of them have passed their first attempt at getting OIC-Navigational Watch license. Moreover, MAAP alumni undergo various maritime trainings after graduation for professional development and promotion. 

On the other hand, the respondents considered the skills and knowledge they gained from MAAP to be very relevant to their jobs. They considered critical thinking and then managerial/leadership as the most relevant areas while theoretical knowledge and skills are the least. 

In terms of employability, 98% of the deck alumni are currently employed while two percent (2%) is employed but on vacation. Forty nine percent (49%) of them are currently working on-board ships; 40% are in toggling between sea-based and maritime land-based jobs such as a training or shipping managers in shipping companies and training centers, and; 11% as instructors or facilitators in maritime 

schools or training centers. With respect to getting their first seagoing job, the majority of the Alumni obtained their first seagoing job with the help of the school’s job placement office – the Department of Shipboard Training (DST). Sixty seven percent (67%) of the alumni were able to board their first vessel after graduation in less than three (3) months to nine (9) months after graduation while 29% for over nine months. On their first seagoing contract after graduation, 72% cited that they have boarded their ships as cadets, 17% as operational level officers and 11% as ratings. At present, 82% of them are already operational level officers, 17% management level officers, and only one percent (1%) rating. Their initial pay is estimated to be an average of $1,010 while their current salary is roughly an average of $3,600.00. In terms of license, 41% of the respondents are management level officers (Chief Mate and Captain) while 51% of them are operational level officers (third and second mates). Overall, the respondents considered themselves professionally successful most especially in terms of job prestige and work task and least on awards and recognition and fringe benefit. 

With respect to the relationship of personal profiles and status of employability, age is moderately associated with occupation, waiting time before first seagoing job, initial job level, and license. Sex is also moderately associated with the occupation of the respondents. 

On the relationship of educational variables and status of respondent’s employability, year graduated is significantly associated with occupation, waiting time before first seagoing job, initial and present job levels, and current license/rank. The OIC licensure examination performance is also moderately associated with the occupation of the respondents. Moreover, study provisions and conditions are significantly associated with waiting time before first seagoing job, license, and professional success. 

Further, the perceived relevance of knowledge and skills of the respondents is moderately and significantly associated with waiting time before first seagoing job and professional success as a mariner. Specifically, theoretical and managerial/leadership 

MAAP Research Journal 

Page 11 

knowledge and skills are most related with their professional success. 

### **4.2. Recommendations** 

In the light of the findings of this study, the following are recommended. 

1. Strengthen involvement of students in research and extension projects as part of their study provisions and conditions. 

2. Enhance the critical thinking and management/leadership knowledge and skills of the students as the graduates considered these to be the most relevant to their jobs. The theoretical aspect of student learning should also be improved to make it more relevant to their profession. 

3. While OIC licensure examination performance is also moderately associated with occupation, further study should be conducted on these variables considering the new examination system by the Maritime Industry Authority (MARINA). 

4. Maritime schools should provide more focus on the study provisions and conditions that they are providing to their students, especially that this is significantly related to the graduates’ employability more particularly on professional success. 

5. Closer attention should be provided for the enhancement of knowledge and skills, especially theoretical and managerial/ leadership, of the students as this is significantly associated with waiting time before first seagoing job and professional success. 

6. Validate the research findings to ensure solid ground in recommending measures for improvement in the academy. A study should include more respondents and additional variables such as academic performance and values. 

7. Conduct further study on the interrelationship of the different aspects of employability of the graduates specifically on their professional success. 

## **5. Acknowledgements** 

The authors gratefully acknowledge the support of the Top Management in the completion of this study. They are also indebted to the MAAP Alumni Office for the assistance in the data gathering for this research. 

## **6. References** 

- Baltic and International Maritime Council (BIMCO), _BIMCO/ISF Manpower Update 2010._ Retrieved at http://www.marisec.org/resources/manpower201 0update.htm. 

- Becker, Gary S. (2002). Human Capital, _The Concise Encyclopedia of Economics._ (2002) Retrieved at http://www.econlib.org/library/Enc/HumanCapita l. 

- Francisco, Josephine (2005). “Papers on the Manning Industry: Filipino Association for Mariners Employment (FAME)”. Conference on Philippine Maritime Affairs (January 20-21, 2005). _JBLF Education Review_ , Vol. XV. Nos. 1 & 2., 2005. 

- Garcia, et.al. (2011). Research (Simplified Guide to Thesis Writing). Booklore Publishing Corporation, Philippines. 

- Jimenez-San Pedro, Merle (2009). “Chinese seafarers: RP’s biggest threat?”, _Marino World Magazine,_ Issue 13, 1<sup>st</sup> Quarter 2009. 

- Kabir, MD Manjurul (2014). "Enhancement of seafarers' employability through capacity building in maritime education and training (MET): a case study of Bangladesh". World Maritime University Dissertations. Paper 465. 

- Kimani, Gerald, “Graduates’ Perception of University Programmes and their Relevance in Employment: University of Nairobe (1991 – 1998)”. Africa Development, 30 (1&2), 2002. 

- Maambong, Christopher P. (2008). “The Policies, Standards and Guidelines for Maritime Education in the Philippines, Perceptions and Compliance Among Maritime Schools”, _MEOAP Today._ Vol II 6<sup>th</sup> Ed. March 2008. 

- Magsaysay-Ho, Doris Teresa (2005). Papers on the Manning Industry: Philippine Seafarers Promotion Council, Conference on Philippine Maritime Affairs (January 20-21, 2005), _JBLF Education Review_ , Vol. XV. Nos. 1 & 2, 2005. 

MAAP Research Journal 

Page 12 

Moreland, N. (2006). Entrepreneurship and Higher Education: An Employee Perspective. ESECT, York, _Learning and employability Series_ . 

- Paler-Calmorin, Laurentina & Calmorin, Melchor A. Methods of Research and Thesis Writing. 1<sup>st</sup> ed., (Rex Printing Company, Inc. Quezon City. 1995). 

- Paadi, Kelebogile (2014). Perceptions on Employability Skills Necessary to Enhance Human Resource Management Graduates Prospects of Securing a Relevant Place in the Labor Market. European ScientificJournal August 2014 /SPECIAL/edition/e - ISSN1857- 7431. 

- Peña, Reynaldo T. (2000), PRC Board Exams and Globalization. A Newspaper Article (Educator Speak) in Manila Bulletin, February 6, 2000. 

<mark>Ramirez, V. E. (2001). Philippine maritime and nursing education: Benchmarking with APEC best practices.</mark> _<mark>Available at: pascn.pids. gov. ph/DiscList/d01/s01-13. pd</mark>_ <mark>.</mark> 

- <mark>Rea, L. M., & Parker, R. A. (2014).</mark> _<mark>Designing and conducting survey research: A comprehensive guide</mark>_ <mark>. John Wiley & Sons.</mark> 

- Schomburg, 2003. Handbook for Graduate Tracer Studies. Centre for Research on Higher Education and Work. University of Kassel, Moenchebergstrasse 17, 34109 Kassel, Germany. P.39. 

MAAP Research Journal 

Page 13 

