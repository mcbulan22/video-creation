2010; 32: 496–499 



# Assessment steers learning down the right road: of on Impact progress testing licensing examination performance 

GEOFF NORMAN<sup>1</sup> , ALAN NEVILLE<sup>1</sup> , JENNIFER M. BLAKE<sup>2</sup> & BARBER MUELLER<sup>1</sup> 1McMaster University, Canada, 2University of Toronto, Canada 

## Abstract 

Although it is generally accepted that assessment steers learning, this is generally viewed as an undesirable side effect. Recent evidence suggests otherwise. Experimental studies have shown that periodic formative assessments can enhance learning over equivalent time spent in study (Roediger & Karpicke 2006). However, positive effects of assessment at a curriculum level have not been demonstrated. Progress tests are a periodic formative assessment designed to enhance learning by providing objective and cumulative feedback, and by identifying a subgroup of students who require additional remediation. McMaster adopted the progress test methods in 1992–1993, as a consequence of poor performance on a national licensing examination. This article shows the positive effect of this innovation, which amounts to an immediate increase of about one-half standard deviation in examination scores, and a consistent upward trend in performance. The immediate effect of introducing objective tests was a reduction in failure rate on the licensing examination from 19% to 4.5%. Various reasons for this improvement in performance are discussed. 

## Introduction 

Assessment steers learning. This statement is viewed by most as a well-proven, self-evident truth, despite the fact that supportive evidence is quite limited (Newble & Jaeger 1983). Further, the statement is frequently framed as a cause for despair, for example as an illustration of the tyranny of multiple choice questions in encouraging students to ‘‘memorize facts.’’ Perhaps because of fear of (un)intended consequences, many newer problem-based learning (PBL) schools have avoided any form of final examinations (Blake et al. 1996) and instead emphasize self and peer assessment. 

There is a strategic reason to encourage self-assessment, in that it is a critical component of lifelong learning, which is central to health professionals’ strategies for remaining current and up to date over their career. However, there is recent evidence that suggests that it is time to re-think some of these assumptions. First, while assessment may well have consequences for learning, these may be neither negative nor unintended. In fact, at least two recent experimental studies have shown a net benefit of assessment on learning. Marsh et al. (2007) showed that repeated multiple choice tests led to enhanced recall as much as weeks later compared to an equivalent time spent on reviewing material. The effect was present for cued recall (open-ended, short answer) questions, for higher order questions and for generalizations. Interestingly, although multiple choice questions are often criticized because they encourage mindless guessing, guessed wrong answers were unlikely to be remembered and used in 

## Practice points 

|. Assessment can|have positive|effects on learning|
|---|---|---|
|. Self-assessment|is not a good|way to assess knowledge|
|. Students<br>need<br>performance|objective|feedback<br>to<br>improve|
|. Introduction of|progress test|for feedback at McMaster|
|reduced failure|rate by <sup>3</sup><br>/<br>4 (19–|4.5%)|



later tests, whereas wrong answers derived from reasoning or personal experience were much more likely to be used (incorrectly) later. A recent study in medicine has confirmed these findings, showing that repeated multiple choice tests led to better retention than an equivalent time spent studying the same material (Larsen et al. 2009). 

Thus, while assessment may well steer learning, this can have positive consequences in terms of enhanced meaningful learning. But what about the consequences of replacing testing with self-assessment and self-directed learning? However, desirable this may appear, recent evidence strongly suggests that the goal of molding our students into self-assessing, selfdirected, lifelong learners is about as achievable as molding oil. Eva and Regehr (2005) have reviewed many studies that consistently show that students are poor at making judgments of strengths and weaknesses. Davis et al. (2006) conducted a systematic review of physician self-assessment skills, and came to the same negative conclusion. 

Why does external testing succeed where learning based on self-assessment fails? One possibility is that external 

Correspondence: Geoff Norman, McMaster University, CE&B, MDCL 3519, 1200 Main St. W, Hamilton, ON L8S 4L8, Canada. Tel: 905-5259140; fax: 905-5727099; email: norman@mcmaster.ca 



496 

ISSN 0142–159X print/ISSN 1466–187X online/10/060496–4 � 2010 Informa Healthcare Ltd. 

DOI: 10.3109/0142159X.2010.486063 

Progress test and licensing exam 

objective tests provide an opportunity for consistent and informative feedback that is missing in self-assessment (Kulhavy 1977; Brangert-Drowns et al. 1991; Larsen et al. 2008). If that is the case, then the use of external tests is consistent with the educational practice that emphasizes the critical role of feedback. Eva and Regehr (2005) came to a similar conclusion, recommending that useful self-assessment is likely to derive from an openness to feedback from other sources. 

Of course, rarely are learners entirely dependent on their own assessment. Far more commonly, students in PBL curricula are encouraged to engage in self, peer and tutor assessment based on the performance in the tutorial. However, evidence suggests that in its usual form, peer and tutor assessment has no more value than self-assessment, rarely providing the specific feedback needed to enhance learning. 

In light of these findings, it can now be seen that curriculum design that is directed at reducing the steering effect of objective assessment by entirely eliminating their use may be misguided. A more enlightened approach would be to devise strategies to maximize the benefit of objective testing on learning, while avoiding the negative consequences. 

Similar considerations led the medical schools at Maastricht, the Netherlands and independently, University of Missouri, Kansas City, to devise an application of objective testing called ‘‘Progress Tests’’ as described in other papers in this issue. We believe their goal was to implement progress tests primarily for summative assessment, while trying to avoid any negative consequences. However, in view of the recent experimental evidence about the benefits of periodic testing for learning, at least in the short term, it is possible that the feedback derived from periodic objective testing such as progress tests may show tangible benefits in learning gains over longer time periods. This article is an examination of the long-term beneficial effect of progress testing on student learning. However, to set the stage it is necessary to explore the local circumstances at McMaster that led to the implementation of progress testing. 

## The McMaster situation ca. 1990 

All Canadian graduates must sit for a written examination, the Medical Council of Canada, examination, as a condition of eligibility for licensure. At the time, the Licentiate of the Medical Council of Canada (LMCC) was a 700 item, multiple choice, norm-referenced test. It has since become a computerbased, adaptive, criterion-referenced test of about 300 items, with a smaller ‘‘Clinical Decision-Making’’ written test (Bordage & Page 1995), but these changes are evolutionary and do not affect the study to be described. Results have always been reported in a common form, based on the distribution of scores of first-time Canadian graduates, set at a mean of 500 and standard deviation of 100. Until introduction of Item Response Theory (IRT) approaches and criterionreferenced measurement in the early 2000s, the curve was adjusted to a fixed failure rate in this cohort of 4.5%. 

McMaster was the first problem-based school, with the first class entering in 1969. Consistent with the culture at this time, 

the school opted to eliminate multiple choice examinations (or any other form of examination) in favor of self, peer, and tutor assessment, believing that such methods were more humane and potentially more valuable, as well as providing a useful model for professional learning. 

Beginning with the second graduating class, McMaster’s failure rate tended to be above the national average, and classes graduating after 1980, after a major curriculum change (MacDonald et al. 1989), had failure rates consistently far exceeding the national average, and in 1989, reaching 19%, more than four times the national average. Such performance did not go unnoticed, and three studies were conducted, beginning in 1974, to determine whether these failures were detectable based on written tutor summary evaluations. All the results were negative; we were unable to determine which students were likely to fail in the licensing exam based on incourse performance judged by tutors. 

Consequently, when the performance of the 1989 class caused a local crisis, one solution was to develop or modify measures that would identify students with problems. As a stopgap solution, the classes of 1990 and 1991 were offered an LMCC practice test developed by the University of Toronto. While this was used by about three-fourths of the class, who paid $25 to sit for the examination, feedback was not linked to LMCC performance. Consequently, when we offered the test, we actually used the test from the previous year, and provided students with feedback based on the specific performance on the previous class (e.g. ‘‘Your mark was 220. Students in last year’s class who got this score on the practice test had a 25% failure rate’’). In 1990, the failure rate dropped to 5%. 

However, providing feedback, based on an external examination written 2 months prior to the licensing examination, appeared to precisely institutionalize the kind of exambased cramming we were trying to avoid. Consequently, we were led to the progress test as a longer-term solution more consistent with the educational culture (Blake et al. 1996). Basically, it is a multiple choice test, administered three times per year, of length 180 items drawn at random from a fixed item pool of about 3000 items. Students are provided detailed feedback about their performance, in terms of items attempted, items correct, and score, with reference to the means of the three classes. 

## Research question 

The question addressed in this article is whether the introduction of progress testing had a positive impact of this innovation on LMCC performance. 

## Methodology 

The nature of the intervention was that it had to be administered to the entire class – no control group design was possible. However, by expanding the design to include multiple years, we were able to use a design called an ‘‘interrupted time-series’’ design (Cook & Campbell 1979). 

The basic idea is similar to a one group –pre-/post-test design, except for an important difference. In this study, we have available nine ‘‘pre-test’’ cohorts, the classes writing the 



497 



<!-- Start of picture text -->
sn<br>| a<br>a B | @Pre PT<br>550 a |<br>LJ a BPost PT<br>LT|<br>ty+.<br>+<br>400<br>1981 1986 1991 1996 2001 2006<br><!-- End of picture text -->



<!-- Start of picture text -->
[SSS<br><!-- End of picture text -->

x ( x( 

x( ) x ( 



<!-- Start of picture text -->
RIGHTS Lit k4><br><!-- End of picture text -->

RIGHTS Lit k4> 

Progress test and licensing exam 

see a gradually accelerating curve. Instead, we see an initial discontinuity and then an initially rapid change that gradually flattens out. 

(c) The improvement resulted from a change in faculty attitude toward the LMCC examination. 

While the poor licensing exam performance in 1989 did result in a change in faculty attitude, and a new chair of the program (JB) was appointed concurrent with this change, nevertheless, the initiative to endorse the Toronto Practice test and provide specific feedback was not a consequence of a wholesale policy change in the faculty; rather it was a small initiative endorsed by a few faculty only. Nevertheless, the fact that these initiatives were undertaken can be viewed as a clear signal that faculty actually did care about how the students did on the LMCC, that it was important to do well, and the failure rate was unacceptable. 

While none of these alternatives can be ruled out, we believe the most parsimonious explanation is simply that, for the first-time in the school’s history, students were receiving useful feedback relating their knowledge to their classmates and to the performance on the examination. Also, in turn, this assessment was driving the idea of learning in a positive sense. 

## Conclusion 

The study has shown, using a unique time-series like design, that the implementation of an objective formative progress test can have large and lasting consequences for performance in a national licensing examination. 

Declaration of interest: The authors report no conflicts of interest. The authors alone are responsible for the content and writing of the article. 

## Notes on contributors 

GEOFF NORMAN, PhD, is an assistant dean for educational research at McMaster. He, with Jenny Blake, was instrumental in introducing progress testing at McMaster. 

JENNY BLAKE, MD, is currently a professor of Obstetrics and Gynecology at University of Toronto and Sunnybrook Hospital. She is a McMaster graduate and was chair of the MD Program when she took on implementation of the progress test. 

ALAN NEVILLE, MD, is a professor of Medicine and currently chair of the MD Program. He has been responsible for many innovations at McMaster, including introducing the recent COMPASS curriculum. 

C. BARBER MUELLER, MD, was the first chair of Surgery at McMaster. He was instrumental in the design of the progress test and locating and reviewing test items. 

## References 

- Bangert-Drowns RL, Kulik CC, Kulik JA, Morgan M. 1991. The instructional effect of feedback in test-like events. Rev Educ Res 61:213–238. 

- Blake JM, Norman GR, Keane DR, Mueller CB, Cunnington J, Didyk N. 1996. Introducing progress testing in McMaster University’s problembased medical curriculum: Psychometric properties and effect on learning. Acad Med 71:1002–1007. 

- Bordage G, Page G. 1995. The Medical Council of Canada’s key features project: A more valid written examination of clinical decision-making skills. Acad Med 70:104–110. 

- Cook TD, Campbell DT. 1979. Quasi experimentation: Design and analysis for field settings. Boston, MA: Houghton Mifflin Company. 

- Davis DA, Mazmanian PE, Fordis M, Van Harrison R, Thorpe KE, Perrier L. 2006. Accuracy of physician self-assessment compared with observed measures of competence: A systematic review. JAMA 296:1094–1102. 

- Eva KW, Regehr G. 2005. Self-assessment in the health professions: A reformulation and research agenda. Acad Med 80:S45–S54. 

- Kulhavy RW. 1977. Feedback in written instruction. Rev Educ Res 47:211–232. 

- Larsen DP, Butler AC, Roediger HL. 2008. Test-enhanced learning in medical education. Med Educ 42:959–966. 

- Larsen DP, Butler AC, Roediger HL. 2009. Repeated testing improves longterm retention relative to repeated study: A randomised controlled trial. Med Educ 43:1174–1181. 

- MacDonald PJ, Chong JP, Chongtrakul P, Neufeld VR, Tugwell P, Chambers LW, Pickering RJ, Oates MJ. 1989. Setting educational priorities for learning the concepts of population health. Med Educ 23:429–439. 

- Marsh EJ, Roediger HL, Bjork RJ, Bjork EL. 2007. The memorial consequences of multiple-choice testing. Psychon Bull Rev 14:194–199. 

- Newble DI, Jaeger K. 1983. The effect of assessments and examinations on the learning of medical students. Med Educ 17:165–171. 

- Roediger HL III, Karpicke JD. 2006. Test-enhanced learning: Taking memory tests improves long-term retention. Psychol Sci 17:249–255. 



499 

