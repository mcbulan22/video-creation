_206_ 



# Learning Outcomes, Instruction, and Assessment Alignment: The case at two Ethiopian Universities 

Firdissa Jebessa Aga (PhD), Associate Professor firdissa.jebessa@aau.edu.et ORCID: 0000-0001-6602-9541 

Institute of Educational Research, Addis Ababa University P.O.Box: 1176 Addis Ababa, Ethiopia 

### **Abstract** 

Constructive alignment of instruction, Learning Outcomes (LOs), and assessment has become a hallmark of assuring the quality of student learning at all levels. Particularly at HEIs, proper alignment of the three guarantees students’ mastery of the required competencies. The purpose of this study was, therefore, to examine the extent to which learning outcomes and learning activities were aligned with instruction, and assessment practices. The study employed a quantitative approach. Data were collected using two sorts of questionnaires from 72 teachers and 94 students at two purposely selected Ethiopian universities. The results have shown that the expected alignment was to a little extent. Specifically, the level of: 1) guiding teachinglearning by a clearly articulated LOs; 2) aligning LO, teaching/instruction, and assessment; 3) guaranteeing learners' awarded grades signify learning outcomes; and 4) aligning the assessed tasks (knowledge, skills, and attitude) to a clearly articulated LOs for the levels of achievement were not to the required level-implying that very little conscious efforts were made to constructively align LOs, instruction, and assessment to bring quality learning. It has, therefore, been recommended that all pertinent parties should make determined efforts to guarantee proper alignment of LOs, instruction, and assessment to result in quality learning of students. 

**Keywords:** Alignment, Learning outcomes, Instruction, Assessment, Quality Student Learning 

## **_1. Introductory and Theoretical Background of the study_** 

The current accountability landscape calls for " new and different thinking about assessment and learning, the identities of teachers and students, and what is involved in using and creating new knowledge” (WyattSmith, Klenowski, & Calbert, 2014: ii). Within such a call, assessment is a vital element as it reveals how well learners have achieved what teachers and/or countries want them to achieve, while the instructional process ensures that they have achieved the requirements set out in curricula. This then demands guaranteeing alignment of learning outcomes, instruction, and assessment in a way they reinforce one another towards achieving the required competencies, that is, measured achievements in terms of vocational, job specific, and inquiry skills. 

In the context of laying the foundation for competency education, Pace and Worthen (2014:5) argue that educators need new skills to “[a]lign instruction to the explicit, measurable, transferable learning objectives”. HCPS (nd. P.1) also has the view that instructional expertise should align “curriculum, instructional strategies 

_IJRP 2023, 135(1), 206-217; doi: 10.47119/10.47119/IJRP10013511020235573_ 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_207_ 



and assessments” for the purpose of ensuring student mastery of the required competencies for the standards. Bloxham, and Boyd (2007, citing Biggs 1996) have also indicated that the notion of matching course objectives with assessment underpins the concept of constructive alignment, basing on course design methodology, and emphasizing the centrality of intended learning outcomes, in a way teaching and assessment are compatible and act to support one another. 

Moreover, Cunningham, Key, and Capron (2016:13) have the view that “[a]ligning the learning activities to the competencies, objectives, and assessments is essential”. Along this, clearly defined competencies need to be linked to assessments, and assessments need to be linked to external measures like career-relevant learning outcomes, which some sources consider as curriculum alignment. 

Curriculum alignment for SUFSD (nd. P.2) “is the agreement and degree to which the written, the taught, and the assessed curricula are aligned”. SUFSD asserts that “adherence to a tightly aligned curriculum will result in higher student achievement and that the linkages provide directed instructional focus. As the same source further indicates, 

Curriculum principles are to be translated in documents, instructional practices, and student assessments through the development of an aligned written, taught, and assessed curriculum system. A comprehensive system provides for a strong directional focus for instruction to facilitate the design, delivery, and assessment of the curriculum…. (P.1). 

As to SUFSD (nd. P.2), an articulated and aligned curriculum exists when teachers are teaching the written curriculum; when assessments are aligned to the written and taught curriculum; and the written curriculum is used to guide decisions about materials, tests, and professional development. 

By implication, constructive alignment of written, taught, and tested curriculum guarantees effective student learning. Written curriculum deals with defining the intended learning outcomes (aligned to common core learning standards) that students are to achieve and teachers are to teach. Taught curriculum deals with the delivery of the written curriculum, including the units of study, lesson plans, and/or suggested instructional approaches for teaching the written curriculum; and tested curriculum deals with evaluating the written and taught curriculum to ascertain students’ mastery of the pre-defined and stated LOs. 

The notion of curriculum alignment, though differently termed by different educators, deals with proper conformation of the intended LOs, instruction, and assessment to bring apposite quality Assessment for Learning (AfL) wherein interactions, and identifications of areas for learning improvement become realworld cultures of the entire education system. 

Assessment for learning, which is built on the foundations of formative assessment, is “the process of seeking and interpreting evidence for use by learners and their teachers to decide where the learners are in their learning, where they need to go and how best to get there” (ARG, 2002, cited in Wyatt-Smith, Klenowski & Calbert, 2014:50). 

AfL, therefore, capitalizes the formative assessment intent that builds students’ “learning to learn” skills by: 1) placing emphasis on the process of teaching and learning, and actively involving students in that process; 2) building students’ skills for peer- and self-assessment; 3) helping students understand their own learning; and developing appropriate strategies for learning to learn (CERI, 2008:2). Consequently, AfL has been accepted universally as a crucial strategy to enhance the quality of student learning. As to Wyatt-Smith, Klenowski, and Calbert (2014:23, citing Willis, 2011), AfL has the assumption that when learners know what they are learning, how well they are learning it and how to improve their learning, they will develop identities as autonomous learners by negotiating through the dynamic interactivity of the curriculum, pedagogy and assessment message systems. In AfL, understanding participant perspectives is essential in expediting interactions and supporting teachers who are seeking to develop learner agency, that is ‘the sociocultural mediated capacity to act’ (Ahern 2001, cited in Wyatt-Smith, Klenowski, & Calbert, 2014). 

Consequently, AfL has become a hallmark for the constructive alignment of learning outcomes, instruction and assessment. Though the case may differ from country to country, “the notion of constructive 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_208_ 



alignment between learning outcomes and assessment” is at the heart of the UK Quality Assurance Agency (QAA, 2006) (Bloxham, & Boyd, 2007:4-5). 

When it comes to the Ethiopian context, curriculum standards are set, assessment modalities are put in place in which expected learning outcomes are pre-defined and stated in national and institutional curricula. Higher learning institutions in Ethiopia have, therefore, given a serious consideration to competency-based learning and assessment related to LOs (AAU, 2014a; 2014b). Instructors in Ethiopian Higher education Institutions (HEIs) are, therefore, acquainted with competency-based learning and assessment, and modularization<sup>*</sup> through Higher Diploma Program (HDP). HDP is a practice-based training program for teacher educators at higher education institutions in Ethiopia. Basically, HDP has one year duration whereby teachers attend 2 hours discussion classes for 2 days per week, supplemented with additional classroom observations and secondary school visits for a week or two. Recently, Addis Ababa University (AAU) has customized the Program to its context by reducing the duration to a maximum of intensive four months by integrating different competencies, truncating redundant topics, and arranging intensive schedules. Assessment is an integral part in both cases (the National framework and that of Addis Ababa University). Whereas the National framework on HDP has four modules dealing with ‘Reflective Teacher Educator,’ ‘Developing Active Learning,’ ‘Improving Assessment,’ and ‘Action Research, Making a Difference’ (MoE, 2006); that of AAU has five modules dealing with Understanding Higher Education, Modularization and Modular Curriculum, Managing Learning and Assessment, Subject Area Teaching, and Action Research and Field-based Learning (AAU, 2014a). 

Particularly, Module three on _Managing Learning and Assessment_ presents basic elements of assessment with assessment rationales, principles, methods, importance and grading procedures. Instructors are, therefore, aware of assessment practices and tenets. 

AAU (2014a:58) suggests that a variety of assessment methods should be designed to satisfy all LOs.  In designing or redesigning modules, it is, therefore, vital to identify and reach a consensus by instructors and academic leadership on appropriate parameters of assessment; and decide which can be left to individual teachers or subject coordinators. Concerning the general provisions on examinations, AAU (2019: 78 [Article 82, No. 821]) indicates that: 

Student learning shall be assessed in a variety of ways/continuous assessment in the form of tests, assignments, presentations, etc. to determine the final grade earned. This shall account for 50% of the total module/course grade. The remaining 50% shall be allotted for a final exam conducted at the end of module/course delivery. Instructors shall monitor the student’s academic performance by keeping track of records. 

The same document (No. 82.4) further indicates that: 

A module…as a matter of routine, shall include information on components of continuous assessment providing the distribution of grade points with a performance assessment criterion among various types of exams and other works in percentage terms. A copy of the module/course outline shall be submitted to the academic unit concerned at the beginning of each course and shall be distributed to students upon approval by the department. 

In the same vein, AAU (2014 a: 35-36) presents the following points concerning the assessment of the modular curriculum: 

* A processes of designing and implementing a module which is a specific and self-contained learning resource, a specific unit of study or block of learning which is separately assessed (AAU, 2014a). 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_209_ 



- 1) performance of learners in a module should be evaluated in relation to the achievement of the modular-objectives (criterion-referenced) rather than on competitive basis (norm-referenced) and normal distributions; 

- 2) the old system of using the normal curve for determining grades should be replaced by initial planning of correspondence between number-grades and letter- grades while determining the latter; 

- 3) failing grades for a module can be determined by learner performance below 60 percent of the total. it is suggested, however, that each instructor with the consultation of his/her department can modify the suggested grading scale; 

- 4) assessment of student work should be continuous, valid, and reliable; and 

- 5) there should be a meaningful and effective system of evaluating, revising, up- grading or phasing out academic programs (AAU, 2014 a: 35-36). 

Overall, many of the available national and institutional curricula documents and/or guidelines advocate that students achieve the requirements set out in criterion-referenced assessment modalities, and master the LOs which are inherent within the modalities, and achieve learning with understanding. These in turn call for the alignment of competency-based outcomes and learning activities with assessment; and intentionally designing curricula around competencies with explicit, measurable, transferable LOs and integrating it with instruction, and assessment. The needs for the said alignment, design and integration have come with the growing body of research into higher education assessment on which academics, leaders and policy makers can begin to build robust policy and practice decisions (Bloxham & Boyd, 2007:15). Equally, we are witnessing that universities are becoming accountable for the quality of their assessed graduates. Universities can no longer exist in a state of privileged seclusion/separation from the society it serves, and can no longer be regarded as a safe haven wherein institutional autonomy and academic freedom obscure accountability for inefficiencies including poor assessment practices. By implication, alignment of learning outcomes, instruction, and assessment have been taken as quests for ensuring quality of student learning at HEIs in the country. 

Our age is witnessing the need for quality learning whereby students achieve learning with understanding by mastering the requirements set out in written curricula through proper instruction and assessment. The prevailing practices, nonetheless, show that “very little conscious efforts were made to align competency-based outcomes and learning activities with assessment in Ethiopian HEIs” (Author, 2021:12). As a result, there is no assurance whether the written curricula are authentically taught, are used to guide decisions about materials, tests, and professional development (SUFSD, nd.). The prevalent practices, therefore, result in a backwash effect wherein just assessment determines what and how students learn more than the curriculum does. Similarly, a poorly aligned and unintegrated system-where the test does not reflect the learning outcomes set out will result in inappropriate surface learning (Biggs, 2003; Brown & Knight, 1994). 

Equally, assessment tasks may not be assessing what they are supposed to assess. They may be assessing lower-level understanding of the material, and may be failing to assess the stated outcomes of a program of study. Similarly, anxiety-provoking assessment is associated with a surface approach to learning by students (Bloxham & Boyd, 2007). 

Moreover, each of the different purposes of assessment may emphasize different principles and is hindered by others. Consequently, there are dilemmas and tensions that the different purposes of assessment create, needing resolutions. Bloxham and Boyd (2007) highlight the conflicts that accrue from the varying purposes of assessment leading to juggling the different intentions of assessment, concentrating on some purposes over others-all of which can distort the value of assessment in universities. 

Inherent within the foregoing discussions is the fact that there is a conflicting nature of established principles underlying sound assessment practices and consequently assessment problems haven’t gone away. 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_210_ 



By implication, there is a dire need to examine integration level of curricula, instruction, and assessment to promote learning with understanding; and the way item quality and fair distribution are assured as per difficulty levels in assessment practices in Ethiopian universities. 

Paradoxically, nonetheless, the concerns about the assessment system are not widely shared among stakeholders. As a result, “assessment is still not the high-profile issue which it should be, given the argument that is assessment arrangements which determine the curriculum in action” (Brown & Knight, 1994:46). 

It is, therefore, my conviction that assessment research serves as a basis for enhancement of assessment practices. Enhanced assessment practices in turn heightens the quality and amount of learning achieved by students, and serves as intrinsically motivating factor for students and lead to better retention of the competencies which they can apply in other settings (Bloxham & Boyd, 2007). The need for the study was, therefore, born out of the intuited doubts on the alignments of the required elements set out in competencybased learning and criterion-referenced assessment modalities to enhance learning with understanding. 

With the purpose to gauge whether students actually achieve mastery of the required competences (measured achievements) for the levels within university settings, the study aimed at examining the extent to which learning outcomes and learning activities were aligned with instruction, and assessment practices. The study employed a quantitative approach. 

## **2. The Research Methodology** 

Quantitative data<sup>†</sup> were collected using two sorts of questionnaires from 161 subjects (72 teachers and 94 students) at two purposively selected Ethiopian universities. For the sake of anonymity, the universities have been labeled as U1, and U2. Whereas U1 was selected based on its age and productivity in offering postgraduate programs, U2 was selected for a convenience purpose. The data were generated both from the teachers and students using close-ended questions of the questionnaires. All the returned copies of the questionnaires were numbered as: TR1-TR72 and SR1-SR94, representing respectively teacher respondents and student respondents. They were entered into the Statistical Package for the Social Sciences (SPSS) software version 23; and presented, analyzed, interpreted, and discussed. 

## **3. Results and Discussions** 

Whereas 190 copies of the questionnaires were dispatched at the two universities, just 166 subjects (72 teachers and 94 students) were returned. Forty-nine and twenty-three of the teachers were respectively from U1 and U2. Similarly, 53 and 41 of the student respondents were respectively from U1 and U 2. 

Of the 53 student respondents from U1, 5 were PhD students from other universities studying at the University; and two of them indicated that they were not employees of any university. 

### _3.1. Biodate of the Respondents_ 

Student- and teacher- respondents were requested respectively to indicate their study programs and qualifications. Whereas 85 of the students and 71 of the teachers properly filled and returned, respectively 9 and 1 were missing systems as can be seen from Table 1. 

> † The data for this article is part of an extended study, from which another article on another theme has been published. 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_211_ 



Table 1: The students’ study programs or levels and Teachers’ Qualification 

|||Students’ study<br>|programs<br>|Teachers’Qual<br>|ification<br>|
|---|---|---|---|---|---|
|||Frequency|%|Frequency|%|
|Valid|MA|52|61|19|27|
||PhD|33|39|52|73|
||Total|85|100|71|100|
|Missing|System|9||1||
|Total||94|100|72|100|



Table 1 shows that 52(61%) and 33(39%) of the students were respectively attending MA and PhD programs. It can further be seen from the Table that the majority (73%) of the teacher respondents had a PhD qualification followed by 27% master’s degree holders. Five copies of the student questionnaires, nevertheless, were jettisoned as they were not properly filled. In analyzing the data, therefore, 161 (72 from teachers and 89 from students) of the properly filled copies of the questionnaires have been used. 

Requested to indicate their teaching/research experiences in years, all the teachers and 85 of the students responded properly whereas 4 was a missing system from that of the students. 

Table 2: Respondents’ teaching/research experience in years 

||Experiences|Frequency|Valid Percent|
|---|---|---|---|
|Valid|Under 3|14|9|
||3-6 Years|21|13|
||7-10 Years|26|17|
||Above 10 Years|96|61|
||Total|157|100.0|
|Missing|System|4||
|Total||161||



Table 2 shows that the majority of the respondents had teaching/research experiences of above 10 years. As can be seen from the Table, 96 (61%) of them had teaching/research experience of above 10 years. A further separate frequency analysis for the same has shown that all those who had under 3 years of teaching/research experiences were student respondents. Of those who had above 10 years of teaching/research experience, 85% and 43% respectively were teachers and students. 

Teacher respondents were also requested to indicate their respective ranks and the results have been shown in Table 3. 

Table 3: Teacher respondents’ Ranks 

|Rank|Frequency|Valid Percent|
|---|---|---|
|Associate Professor|13|18|
|Assistant Professor|41|57|
|Senior Lecturer|4|6|
|Lecturer|13|18|
|Assistant Lecturer|1|1|
|Total|72|100|



Table 3 shows that the majority (57%) of the respondents had the rank of assistant professorship, followed by 

_www.ijrp.org_ 



_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_213_ 



Table 4 presents a combined frequency and Descriptive Statistics on the level of alignment of LO, Instruction, and assessment tasks. The overall means of all except one item fall in between little and medium. The only exception is the extent to which subject assessment is integrated into an overall plan for course assessment was rated 3.59% with SD, that is, closer to greatly. Predominantly, the extent to which teachinglearning is guided by clearly articulated learning outcomes, and learners' awarded grades signify learning outcomes were rated low with the average mean of 2.72% and 2.77% and SD 0.752 and 0.719 respectively. The Table further shows results of the frequencies that 65 and 58 of the respondents respectively indicated the extent to which teaching-learning was guided by clearly articulated learning outcomes, and teaching/instruction and assessment were aligned to a little extent. The majority of the respondents, however, rated the alignment level of LO, Instruction, and assessment tasks to be to a medium extent. More specifically, 89, 88, 86, 57, and 56 of the respondents respectively indicated that alignment of learning activities with assessment, learning outcomes signification of learners' awarded grades, assessment tasks’/contents’ level of clearly measuring the required learning domain(s), alignment of assessment tasks/contents with learning outcomes, and embedment of assessment tasks/contents in the teaching learning process were to a medium extent. On the other hand, 59 of the respondents rated the extent to which subject assessment is integrated into an overall plan for course assessment as to a greater extent. 

A critical look at the Table shows that an insignificant number of the respondents rated the alignment of LO, Instruction, and assessment tasks to the required level. In short, alignment of LO, Instruction, and assessment tasks was not made greatly, and very greatly. 

Overall, the majority 68(44%) of the respondents rated the alignment of LO, Instruction, and assessment tasks to a medium level, followed by 42 (27%) to a Little extent; and just 37 (25%) and 5(3%) respectively rated as greatly and very greatly. 

Furthermore, the extent to which assessed tasks (knowledge, skills, and attitude) are aligned to clearly articulate learning outcomes for the levels of achievement was explored using alternatives ranging from Very little to Very Greatly. Whereas 30 was a missing system, the results from 131 respondents have been presented in Table 5. 

Table 5: Alignment of the assessed tasks (knowledge, skills, and attitude) to clearly articulated learning outcomes 

||||Frequency|Percent|Valid Percent|
|---|---|---|---|---|---|
|To what extent are the assessed|Valid|Verylittle|4|2.5|3.1|
|tasks (knowledge, skills, and attitude)||Little|23|14.3|17.6|
|aligned to clearly articulated learning||Medium|64|39.8|48.9|
|outcomes (if at all) for levels of<br>||Greatly|40|24.8|30.5|
|achievement?||Total|131|81.4|100.0|
||Missing|System|30|18.6||
||Total||161|100.0||



As can be seen from Table 5, the majority (64) of the respondents rated the extent to which assessment tasks (knowledge, skills, and attitude) were aligned to clearly articulate learning outcomes for levels of achievement as medium, followed by 40 and 23 respondents respectively rated as greatly and little. Whereas the respondents who rated very little, no one rated as very greatly. 

In both cases that is Table 4 and Table 5, alignment of LO, Instruction, and assessment tasks; and alignment of assessed tasks (knowledge, skills, and attitude) to a clearly articulated learning outcomes for the levels of achievement were not to the required levels. In both cases, an insignificant number of the respondents rated the highness of the said alignments, whereas the majority rated the lowness of the case. 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_214_ 



## **4. Conclusions** 

The fact that the majority of the respondents had above 10 years of teaching/research experiences, reasonable qualification, and rank shows that they are appropriate to sensibly judge the level of alignment of LO, instruction, and assessment. Equally, the very high reliability of the items with the Cronbach's Alpha of .905 indicates that all the items in the questionnaires are highly correlated and are internally consistent for generating dependable evidence on the level of the said alignments. 

The alignment level of LO, instruction, and assessment was, nonetheless, majorly _to a little extent and_ to a _medium extent._ There were shortfalls to guide teaching-learning by a clearly articulated learning outcomes; to guarantee learners' awarded grades signify learning outcomes; to greatly align teaching/instruction and assessment, and the assessed tasks (knowledge, skills, and attitude) to a clearly articulated learning outcomes for the levels of achievement; and to embed assessment tasks/contents in curricula design, in the teaching learning process. 

The observed states of the level of alignments were in contravention to the supposed need for “connecting teaching, learning and curriculum” (Wyatt-Smith, Klenowski, & Calbert, 2014:23) for ensuring high quality learning of students. Wyatt-Smith, Klenowski, and Calbert, (2014:25, citing Moss 2008), have the view that “curriculum, pedagogy and assessment practices can both expand or close down the possibilities of belonging within and becoming a competent and valued learner. 

Learning in this view is “understood as participation rather than purely cognitive acquisition, conceptions of what counts as evidence of learning also changes” (Wyatt-Smith, Klenowski, & Calbert, 2014:25). Participatory learning comes when assessment tasks are consciously embedded in the learning process, and when sustained efforts are made by faculties to review their assessment practices (James, Mcinnis, & Devlin, 2002). In such an environment, the “the grades awarded … to students on their achievement make a direct link between the intended learning outcomes and students’ actual performance on assessment tasks” (James, Mcinnis, & Devlin, 2002:18). Evidently, therefore, the environment stands supportive for bringing constructive alignments of the elements, and for putting in place inbuilt accountability (vertically as well as horizontally) for checking whether responsibilities have been discharged to bring a positive effect on student achievement (Wyatt-Smith, Klenowski, & Calbert, 2014:74). Whereas vertical’ accountability deals with upward answerability to institutional hierarchies, horizontal accountability deals with colleagues’ or peers’ working in teams and being accountable to each other with a vested interest  of improving their knowledge, attitudes and skills so as to mount to a greater differentiation of instructions thereby yielding higher student performance levels (Wyatt-Smith, Klenowski, & Calbert, 2014:83). 

In principle, teaching-learning should be momentarily guided by clearly articulated learning outcomes; learners' awarded grades should undoubtedly signify learning outcomes; and assessed tasks (knowledge, skills, and attitude) should certainly be aligned to clearly articulate learning outcomes for the levels of achievement. This implies a need for constructive alignment of written curriculum, LOs, taught contents, and assessed LOs as can be depicted from Figure 1. 

_www.ijrp.org_ 

& 



<!-- Start of picture text -->
&<br><!-- End of picture text -->



<!-- Start of picture text -->
Learning<br>Outcomes<br>(LOs)<br>Assessed Taught<br>LOs Contents<br><!-- End of picture text -->

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_216_ 



## **Declaration of competing interest** 

No competing interest; and I hereby declare and confirm that: 

- 1) no any financial and personal relationships with other people or organizations that could inappropriately influence (bias) my work; 

- 2) no any such as employment, consultancies, stock ownership, honoraria, paid expert testimony, patent applications/ registrations, and grants or other funding related to my work; 

- 3) the material doesn’t belongs to any government organization; and 

- 4) no any objects owned by third parties. 

### **Reference** 

- AAU [Addis Ababa University], 2019. _Addis Ababa University Senate Legislation_ (available at file:///C:/Users/user/AppData/Local/Temp/AAU%20Senate%20Legis-lation%20of%202019.pdf) 

- AAU, 2014 a. Higher Diploma Program: Module two: Modularization and Modular Curriculum (Up) 

AAU, 2014 b. Higher diploma Program: Module Three: Managing Learning and Assessment (Up) Biggs, John (2003). Teaching for Quality Learning at university (2<sup>nd</sup> . Ed.). UK: The Cromwell Press 

- Bloxham, Sue; and Boyd, Pete (2007). Developing Effective Assessment in Higher Education: a practical guide. England: Open University Press. 

- Brown, Sally; and Knight, P., 1994. _Assessing Learners in Higher Education._ London & Newyork: RoutledgeFalmer. 

- CERI [Center for Educational Research and Innovation], 2008. _Assessment for Learning: Formative Assessment_ (Available at https://www.academia.edu/27908509/Assessment for Learning-FormativeAssessment) 

- Cunningham, J.; Key, E.; and Capron, R., 2016. An evaluation of competency-based education programs: _A study of the development process of competency-based programs_ . _https://doi.org/10.1002/cbe2.1025_ 

- Firdissa J. 2021. Learning Assessment Practices in Ethiopian Universities: Quests versus Upheavals. In Research in Education Assessment and Learning, 6(2), 1-14, ISSN: 1947-5497, doi.org/10.37906/real.2021.6 1 

- HCPS [Hillsborough County Public Schools], nd. School Leadership Framework   (available at www.sdhc.k12.fl.us/hpp/) 

- James, R., Mcinnis, C., and Devlin, M., 2002. _Assessing Learning in Australian Universities_ . Victoria Australia: Centre for the Study of Higher Education, ISBN 0 7340 2902 0 

- MoE [Ministry of Education], 2006. Higher Diploma for Teacher Educators. _A Training Portfolio_ (unpublished). 

- Pace, L.; and Worthen, M., 2014. Laying the Foundation for Competency Education: A Policy Guide for the Next Generation Educator Workforce. (Retrieved of 17 February 2021 from https://files.eric.ed.gov/fulltext/ED557752.pdf:) 

- Sanga, Ph. L., 2016. Implications of Teacher Educators’ Practices in Assessment for Student Learning in Tanzania. In Makerere Journal of Higher Education, 8 (1), 1–24; DOI: http://dx.doi.org/10.4314/majohe.v8i1.1 

SUFSD [Spackenkill Union Free School District], nd. Curriculum, Instruction, and 

   - Assessment Handbook (available at https://www.spackenkillschools.org/) 

- Wyatt-Smith, C; Klenowski, V.; and Calbert, P. [eds.], 2014. _Designing Assessment for Quality Learning:_ 

_www.ijrp.org_ 

_Firdissa Jebessa Aga / International Journal of Research Publications (IJRP.ORG)_ 

_217_ 



_The Enabling Power of Assessmen_ t. New York: Springer Science, DOI 10.1007/978-94-007-5902-2 

_www.ijrp.org_ 

