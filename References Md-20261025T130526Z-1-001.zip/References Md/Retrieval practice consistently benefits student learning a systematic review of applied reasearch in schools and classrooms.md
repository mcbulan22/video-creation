Educational Psychology Review https://doi.org/10.1007/s10648-021-09595-9 REVIEW ARTICLE 



Retrieval Practice Consistently Benefits Student Learning: a Systematic Review of Applied Research in Schools and Classrooms 

Pooja K. Agarwal<sup>1</sup> & Ludmila D. Nunes<sup>2</sup> & Janell R. Blunt<sup>3</sup> 



Accepted: 11 January 2021/ 

# The Author(s), under exclusive licence to Springer Science+Business Media, LLC part of Springer Nature 2021 

### Abstract 

Given the growing interest in retrieval practice among educators, it is valuable to know when retrieval practice does and does not improve student learning—particularly for educators who have limited classroom time and resources. In this literature review, we developed a narrow operational definition for “classroom research” compared to previous reviews of the literature. We screened nearly 2000 abstracts and systematically coded 50 experiments to establish a clearer picture of benefits from retrieval practice in real world educational settings. Our review yielded 49 effect sizes and a total n = 5374, the majority of which (57%) revealed medium or large benefits from retrieval practice. We found that retrieval practice improved learning for a variety of education levels, content areas, experimental designs, final test delays, retrieval and final test formats, and timing of retrieval practice and feedback; however, only 6% of experiments were conducted in nonWEIRD countries. Based on our review of the literature, we make eight recommendations for future research and provide educators with a better understanding of the robust benefits of retrieval practice across a range of school and classroom settings. 

Keywords Retrieval practice<sup>.</sup> Learning<sup>.</sup> Classroom<sup>.</sup> Schools<sup>.</sup> Applied research<sup>.</sup> Testing effect 

— As researchers have demonstrated for more than a century, retrieval practice the act of recalling — previously learned information improves long-term learning and memory. For example, simply retrieving a trivia fact (e.g., what was the name of the ship of Charles Darwin’s famous voyage?) helps students remember this fact better than if they simply re-read it multiple times.<sup>1</sup> 

In a landmark study on retrieval practice by Roediger and Karpicke (2006b), college students read brief passages (e.g., about sea otters, the solar system, etc.) and either engaged in re-reading the passages or retrieval practice (i.e., free recall by writing down everything they 

> 1The name of the ship of Charles Darwin’s famous voyage is the Beagle. 

> * Pooja K. Agarwal pagarwal@berklee.edu 

Extended author information available on the last page of the article 

Educational Psychology Review 

could remember from the passage). After a five-minute delay, students performed better on a free recall test after initially re-reading, but after a one-week delay, their performance was greater when they engaged in initial retrieval practice by freely recalling the passage. 

Early research on the use of retrieval practice as a strategy to improve long-term learning found consistent benefits from retrieval practice (e.g., Gates 1917; Glover 1989; Myers 1914; Spitzer 1939). Revived by Roediger and Karpicke (2006b), this area of research has been progressing rapidly. In particular, scientists have been extending research from laboratory settings to educational settings, with demonstrated benefits for student learning ranging from primary school to medical school, and content areas ranging from math and science to history and foreign languages (Dunlosky et al. 2013). Researchers are increasingly urging educators to apply retrieval practice in the classroom (Agarwal and Bain 2019; Brown et al. 2014; Butler and Carpenter 2015; Dunlosky and Rawson 2019; Fazio and Marsh 2019; Karpicke et al. 2016; Nunes and Karpicke 2015; Roediger and Butler 2011; Weinstein et al. 2018). In tandem, educators are increasingly implementing retrieval practice using a variety of methods including multiple-choice online apps, frequent recall prompts, and quizzes during lectures. 

Given the growing interest in retrieval practice among educators, it is valuable to know — when retrieval practice does and does not improve student learning particularly for educators who have limited classroom time and resources. From a scientific standpoint, it is also valuable to have a clear understanding of the literature to date in order to inform future research. 

To address these pursuits for both educators and researchers, we developed a narrow operational definition for “classroom research” compared to previous reviews of the literature. Using our definition and detailed search syntax, we screened nearly 2000 studies and coded 50 experiments drawn from research on retrieval practice, conducted in classroom settings. 

# Aims of the Present Study 

## Aim 1: Compare Apples to Apples Using Narrower Review Criteria 

The first aim of the present review was to compare classroom studies that examined the effects of retrieval practice, while applying a narrower set of inclusion criteria than used in prior reviews or meta-analyses. In order to inform future research (aim 2) and clarify recommendations for educators (aim 3), we included only classroom studies in which retrieval practice was administered individually and in person; in other words, we did not include studies conducted in laboratory settings, studies with collaborative retrieval, nor studies in which retrieval practice was administered online. 

To date, reviews and meta-analyses of research on retrieval practice have typically included a mix of studies drawn from both laboratory and applied settings (Adesope et al. 2017; Bangert-Drowns et al. 1991; Brame and Biel 2015; Dunlosky et al. 2013; Eisenkraemer et al. 2013; Green et al. 2018; Karpicke and Grimaldi 2012; McLaughlin and Coderre 2015; Nguyen and McDaniel 2015; Pyc et al. 2014; Rowland 2014). For example, Adesope et al. (2017) conducted a meta-analysis of 217 research studies on retrieval practice, of which 11% were from classroom settings (p. 666). While informative for research purposes, what works in — the laboratory does not necessarily work in the classroom and vice versa. As Adesope et al. observed in their own meta-analysis, “In light of potential confounds, comparison of classroom and laboratory effect sizes should be interpreted with caution” (p. 687). 

Educational Psychology Review 

Even when meta-analyses and reviews were restricted to research in applied settings, the format and implementation of retrieval practice for included studies varied widely. For example, in the 23 studies included in the literature review by Moreira et al. (2019), materials ranged from encyclopedia passages (Jaeger et al. 2015) to TV recordings (Cranney et al. 2009). One study included in the Moreira et al. review was conducted in the classroom, but students worked individually at computer stations (Lipko-Speed et al. 2014). Another study was carried out after the course had concluded (Carpenter et al. 2009). 

Of the studies included in meta-analyses by Schwieren et al. (2017); 19 studies) and Sotola and Crede (2020; 52 studies), students engaged in unsupervised online retrieval practice (Burdo and O’Dwyer 2015; Daniel and Broida 2004; Kibble 2007), collaborative retrieval practice (Bojnova and Oigara 2011; Vojdanoska et al. 2010), and retrieval practice in computer labs after the classroom lecture (Wiklund-Hörnqvist et al. 2014). 

While prior reviews and meta-analyses have increased our overall understanding of the benefits of retrieval practice across a variety of educationally relevant materials and conditions, recommendations drawn from such widely varying circumstances may lack the specificity required for actual classroom practice. As an alternative, we present a comprehensive database search capturing more published articles than previous reviews. We also used narrow screening criteria to ensure that the classroom studies manipulated retrieval practice under comparable real world conditions. 

As an additional cause for concern regarding the existing literature, recent works have pointed out several shortcomings of meta-analytical methods, including the use of random effects models, when data to be analyzed are complex (e.g., Carter et al. 2019; McShane and Böckenholdt 2020; Tipton et al. 2019). Applied research is inherently complex and messy, with challenges and confounds that are difficult to control. For example, some of the studies in the present review included multiple retrieval practice conditions compared against the same control condition, one retrieval practice condition compared against multiple control conditions, or data that were collapsed across conditions—all of which render the effect sizes computed non-independent. In addition, research has shown that the reproducibility of mean effect sizes derived from meta-analyses is low (Lakens et al. 2016). 

Furthermore, reporting of data has been inconsistent in prior reviews. For example, Adesope et al. (2017) and Rowland (2014) reported mean weighted effect sizes, but they did not report effect sizes or confidence intervals for individual studies. Similarly, Brame and Biel (2015), Green et al. (2018), and Moreira et al. (2019) did not report effect sizes for individual studies. Bangert-Drowns et al. (1991) reported effect sizes for individual studies, but they did not report sample sizes nor confidence intervals around the effect sizes. 

Thus, reviews and meta-analyses in this area of applied research should be considered with caution. In consideration of these challenges—a mix of settings, varied formats of retrieval practice, wide-ranging implementation methods, and statistical concerns—we felt that conditions across the 50 experiments included in the present review were too varied for a meta-analytic approach. Even under our narrowed inclusion criteria, seldom was there a consistent retrieval practice format or implementation method, a group of subjects without attrition, a perfectly controlled experimental condition or dependent measure, or a singular effect of interest. 

For these reasons, in lieu of a meta-analysis that collapses effect sizes over a wide variety of applied experiments, we report effect sizes for each individual comparison in forest plots (Figs. 3, 4, 5, and 6) and also in the Appendix. Because we include sample sizes, effect sizes, and confidence intervals for each individual study and comparison (when data were available to calculate them), the present review provides a more accurate understanding of the conditions under which retrieval practice benefits learning compared to prior reviews. 

Educational Psychology Review 

Our operational definition of retrieval practice was as follows: an active attempt by a student to recall or recognize, and then reconstruct, their memory of knowledge during initial learning. While this is sometimes referred to as the “testing effect,” we chose to use the phrase “retrieval practice” in our review of classroom research for a few reasons. 

First, the term “retrieval practice” has become more commonly used in the research literature to encompass various forms of retrieval during initial learning, including both recall and recognition (e.g., Karpicke 2012). 

Second, retrieval practice in the classroom takes many forms that differ from the typical notion of a test. For example, across the 50 experiments included in our review, students engaged in a variety of retrieval practice activities, including free recall, short answer quizzes, multiple-choice quizzes, and quizzes with standardized patients. These low-stakes or no-stakes classroom learning activities were seldom referred to as “tests” by the authors of the studies. In addition, consider the increasing use of educational apps for retrieval practice, such as Kahoot and Quizlet, which bear very little resemblance to traditional tests. 

Third, the terms “testing,” “testing effect,” and “test-enhanced learning” create confusion with unrelated educational activities such as summative assessments and standardized testing (Agarwal and Bain 2019). As such, our operational definition and terminology highlight that it is the process of practicing retrieval (the active attempt) that shapes learning, not tests. 

After screening nearly 2000 abstracts, 50 experiments drawn from 37 studies met our full screening criteria, in which we required classroom-relevant materials, retrieval practice by students individually, and implementation during class periods under the supervision of the instructor or researcher. Critically, we compared classroom studies only (apples to apples), rather than drawing comparisons across both classroom and laboratory settings (apples to oranges). We feel that our narrowed criteria provide greater specificity in terms of directions for future research (aim 2) and recommendations for classroom implementation (aim 3). 

## Aim 2: Inform Future Directions for Research on Retrieval Practice 

A second aim of the present review was to inform future directions for research on retrieval practice. In order to construct the most thorough review of the literature possible, we developed precise search syntax for five databases: PsycINFO, PsycARTICLES, ERIC, Web of Science, and PubMed (see Table 1). While our screening criteria were narrower compared to previous reviews, our systematic search yielded more classroom-specific peerreviewed publications (37 studies in the present review of the literature) when compared to the number of studies included in previous reviews (e.g., 30 studies in Adesope et al. 2017; 23 studies in Moreira et al. 2019; 19 studies in Schwieren et al. 2017). 

It is possible that the greater number of studies in our review, compared to previous reviews, may be due to a more recent search of the literature. Still, using our methodology, we found a few classroom studies that were not included in previous literature reviews, albeit having been published before those reviews (e.g., Graham 1999; Kromann et al. 2009; Narloch et al. 2006). In this way, we feel that our systematic review contributes a comprehensive record of research to date, which better informs future directions for applied research on retrieval practice. 

Specifically, we investigated unresolved questions in the research literature on retrieval practice. For example, is there an optimal frequency of retrieval practice to improve student learning in classroom settings? Do all content areas and educational levels (e.g., K-12, undergraduate, and medical school) benefit from retrieval practice? Which is more beneficial for student learning, multiple-choice or short answer retrieval practice? To foreshadow our results, we 

Educational Psychology Review 

examined these possible moderating variables by categorizing the 50 included experiments across various characteristics (e.g., education level, experimental design, sample size). We present effect sizes for each individual experiment in forest plots (Figs. 3, 4, 5, and 6) and also in the Appendix. 

Typically, we think of laboratory research as informing applications of cognitive psychology in real-world settings. The opposite is also true: Research conducted in real-world settings can inform basic research in laboratory settings. For example, are benefits from retrieval practice modulated by incentives? Researchers have examined this question in laboratory experiments with foreign language vocabulary, but have found inconsistent results (e.g., Abel and Bäuml 2020; Kang and Pashler 2014). Meanwhile, in the real world, students’ performance on retrieval practice and final tests typically count toward course grades; in most of the studies included in the present review (66%), this was the case. In contrast to previous reviews of retrieval practice research in classrooms (e.g., Sotola and Crede 2020), we intentionally included grades as a moderating variable in our coding system. With a better understanding of motivational factors in the classroom in the present review, researchers can more effectively examine these factors in the laboratory. 

## Aim 3: Clarify Recommendations for Classroom Implementation of Retrieval Practice 

In order to provide recommendations for classroom implementation of retrieval practice, we systematically coded conditions of interest to educators (see the Appendix and http://osf.io/ mz2ks for the complete coding). For example, educators express a number of concerns regarding implementation, particularly the use of multiple-choice questions and the optimal timing for feedback (Agarwal and Bain 2019). In both of these examples, laboratory and applied research suggest mixed approaches (Adesope et al. 2017). Additional conditions of interest in the present review included: 

- & Education level (e.g., K-12, college/university, medical school) 

- & Content area (e.g., psychology, medicine, and history) 

- & Comparison conditions (e.g., reviewing material, lessons without quizzes, infrequent high stakes exams) 

- & Retrieval practice timing (e.g., every class, once a week, once a month) 

- & Length of delay between the last retrieval opportunity and the final test (e.g., days or weeks) 

- & Format for initial retrieval practice and final test (e.g., multiple-choice, short answer, free recall) 

- & Feedback timing (e.g., immediate, delayed, no feedback) 

Our narrower review criteria also allowed us to examine the benefits of retrieval practice under conditions found in real-world classrooms—but uncommon in laboratory studies—including research with diverse student populations and situations in which performance on retrieval practice counted toward students’ course grades. 

# Considerations for Applied Research in Classrooms 

## Definition of “Classroom” Research 

The primary aim of the present review was to examine the literature on retrieval practice research conducted in classrooms. But how does one define a “classroom?” Classrooms, 

Educational Psychology Review 

particularly in the present day, take a variety of forms (e.g., small seminars, large lecture halls, and online) and include a variety of activities (e.g., lectures, group projects, and discussion). For example, 14% of all students in higher education (more than 5.8 million students) take the entirety of their courses online (Allen et al. 2016). 

In addition, retrieval practice is inherent to classroom instruction: teachers pose questions during class, students retrieve knowledge during group discussion, and students retrieve during course exams. If we were to consider any classroom settings in which retrieval practice takes place, such a review would be far too broad to draw conclusions for future research and practical implementation. Thus, defining what constitutes a classroom for the purpose of this review required careful consideration. 

Consider a study conducted by Herbert Spitzer in 1939. More than 3500 children across the state of Iowa were asked to read passages about peanuts and bamboo, which were followed by zero, one, two, or three multiple-choice tests administered in the classroom. After two months, final test performance was greater for students who engaged in retrieval practice compared to students who did not receive initial retrieval practice. 

While this study by Spitzer (1939) was conducted with school-age children in classrooms, Spitzer himself observed, “The learning was of little practical use to the children” (p. 655). This study is a valuable demonstration of the benefits of retrieval practice in an applied setting, but it is also an instance in which educational research deviated from typical classroom instruction; namely, the materials were irrelevant to what students were learning in class (see also Myers 1914). 

As a second example, consider a study by Sennhenn-Kirchner et al. (2016). Dental students completed a four-hour course on suturing skills, which was followed by retrieval practice using a suture simulation pad, either collaboratively in pairs or individually. On a final test approximately one month later, students in the collaborative retrieval group outperformed students who had engaged in retrieval practice individually. 

In Sennhenn-Kirchner et al. (2016), the information to be learned and the format of retrieval practice was typical of dental education. However, in the collaborative retrieval condition, it is possible that one student led suture practice while the other student watched and did not engage in retrieval practice. The extent to which all students engaged in retrieval practice was not measured and could not be guaranteed by the researchers or instructors. 

In order to ascertain trends and draw conclusions from the growing literature on retrieval practice, we limited our definition of “classroom” research using the following guidelines: 

- & Relevant course materials: Information to be learned for research purposes was the same as, or directly related to, assigned course materials 

- & Individual, not collaborative: All students engaged in retrieval practice individually under the supervision of researchers and instructors 

- & Closed-book, not open-book: All retrieval practice took place without the use of notes, external learning aids, or the internet 

## Comparison Conditions for Experiments in Classroom Settings 

When it comes to control conditions in research on learning, it is critical to compare what students do and also for how long. In laboratory experiments, retrieval practice is typically compared to re-studying, particularly to ensure that time spent with materials is equated across 

Educational Psychology Review 

conditions (e.g., Roediger and Karpicke 2006b). In classroom experiments, the comparison to retrieval practice is typically “business as usual,” where a teacher lectures on the same material, but without quizzes (Khanna and Cortese 2016). 

For all studies reviewed in the present study, students spent approximately the same amount of time with materials between the retrieval practice intervention and comparison conditions. For example, in Freda and Lipp (2016), classes consisted of lectures with quizzes vs. lectures without quizzes. In Kromann et al. (2010), students received quizzes on simulated cardiac arrest scenarios or they received lecture presentations of the scenarios. In Roediger et al. (2011)), using a within-student design, questions over half the material were presented on quizzes and the final exam, whereas questions on the remaining material appeared only on the final exam (non-quizzed items). 

In the present review, we chose to include two studies in which the comparison of interest was dosage, where researchers directly manipulated quantity, or the number of opportunities for retrieval practice (Dunlosky et al. 2013). We included experiments by Foss and Pirozzolo (2017), in which retrieval practice in the form of 4–8 exams was compared to learning after 2– 3 exams. We also included an experiment by Leeming (2002), in which quizzes administered during every class were compared to four exams over the course of the semester. All remaining studies included in the present review (35 studies) did not directly manipulate dosage and many did not report dosage of retrieval practice at all. 

Intertwined with dosage of retrieval practice are timing and spacing, which presents a few challenges—especially in classroom research. First, different dosages of retrieval practice imply different retrieval practice timings (e.g., every class vs. every week represents a higher dosage but also a different implementation schedule). In this way, dosage can be easily confounded with spacing (e.g., quizzes every class means more retrieval practice, but less spacing than once per week). Second, higher dosage should result in more learning, but we also know that increased spacing can result in more learning (McDaniel et al. 2011). Third, many of the studies included in our review confounded dosage, timing, and spacing, or they did not report whether repeated retrieval opportunities included the same items (a requirement for spaced practice). Thus, because we could not code for dosage or spacing, we coded for retrieval practice timing across the studies (e.g., whether students generally engaged in retrieval practice daily, weekly, monthly). 

We chose to exclude studies in which the primary comparison of interest was between two (or more) types of retrieval practice. For example, we excluded experiments by Carpenter et al. (2016; they compared retrieval practice via drawing diagrams vs. labeling diagrams); Niedermeyer and Sullivan (1972; they compared three vs. four multiple-choice test alternatives); Rohrer et al. (2020); they compared blocked vs. interleaved retrieval practice); Weinstein et al. (2016, experiment 3); they compared quiz questions interspersed during lectures or at the end of lectures). This growing area of applied research on optimal types of retrieval practice awaits a future review of the literature. 

Note that in the present review, we do not refer to “control conditions” or “control groups.” Instead, we refer to “comparison conditions” and “comparison groups.” What may be considered an appropriate control group in one classroom setting may not be appropriate in another; thus, we did not restrict whether a control had to take a specific form of re-studying, representation, repetition, concept mapping, or alternative “non-retrieval” conditions (see also Kornell et al. 2012). 

Educational Psychology Review 

## Internal and External Validity in Applied Research 

Applied research, particularly on student learning and memory, brings with it a number of uncontrolled variables and circumstances. These variables for both students and teachers—such as absences, external motivators, and commitments outside the classroom—can affect internal validity and fidelity of implementation, or the extent to which an intervention is implemented in accordance with the procedure (O’Donnell 2008). 

A common characterization of laboratory and classroom research is that laboratory research is regarded as high on internal validity (free from errors in the experiment) and low on external validity (findings do not generalize to the real world), while classroom research is low on internal validity and high on external validity. Even so, as Anderson et al. (1999) argue, individual studies may be high or low on internal and external validity; validity cannot be defined simply based on whether a study was conducted in a lab or a classroom. 

In addition, in any situation in which retrieval practice was implemented without supervision, it is impossible to know whether it conformed to our operational definition. Thus, in order to maintain fidelity of implementation and internal validity as much as possible, our inclusion criteria required that all instructional activities, retrieval practice, and assessments took place in person under the supervision of the researcher or the instructor, in person, and not online. 

By screening nearly 2000 abstracts and systematically reviewing 50 experiments conducted in classrooms, we aimed to establish a clearer picture of benefits from retrieval practice in realworld educational settings. We developed specific search syntax and operationalized classroom research, investigated unresolved questions in the research literature, and developed research-based recommendations for the implementation of retrieval practice for educators. 

# Methods 

## Literature Search 

We conducted a literature search in January 2018 for empirical research on retrieval practice conducted in school and classroom settings. We developed search syntax for five databases (PsycINFO, PsycARTICLES, ERIC, Web of Science, and PubMed), using different combinations of keywords including retrieval practice, testing effect, course, and teach (see Table 1 for a complete description of the search syntax used for each database). We also performed a backwards search using the reference lists of the abstracts that passed both initial and detail screenings, but the backwards search did not reveal any new abstracts. Our literature search yielded a total of 1810 abstracts. We used Zotero (2020, http://www.zotero.org), an opensource research tool for reference management, to organize and download abstracts. 

## Initial Screening Criteria 

Initial screening of 1810 abstracts was conducted to ensure that research met the following criteria for inclusion in the present review: 

Educational Psychology Review 

Table 1 Search syntax used and number of abstracts screened 

|Database|Search syntax|Number of<br>abstracts|
|---|---|---|
|PsycINFO, PsycARTICLES,<br>and ERIC<br>Web of Science<br>PubMed<br>Total number of abstracts<br>screened|(retriev* pract* OR testing effect OR“test* effect”OR<br>test-enhanc*) AND (class* OR course* OR teach* OR clinical)<br>((“retrieval practice”OR“testing effect”OR test-enhanc*) AND<br>(class* OR course* OR teach*))<br>(((((retrieval practice[Text Word]) OR testing effect[Text Word])<br>OR test effect[Text Word]) OR test-enhanced[Text Word]))<br>AND ((((class[Text Word]) OR course[Text Word]) OR<br>teach[Text Word]) OR clinical[Text Word])|1447<br>230<br>133<br>1810|



Research must be published in, or in press at, a peer-reviewed journal at the time of our search. Abstracts from conference proceedings, dissertations, or non-peer reviewed journals were excluded. Literature reviews were also excluded. 

Research must be empirical, with at least two conditions (i.e., a retrieval practice intervention and a comparison) and at least one final test phase (i.e., a retention measure after retrieval practice). Abstracts indicating that findings were based on observational, survey, correlational, or other qualitative methods were excluded. 

Research must be conducted with typical student populations. Abstracts indicating that research was conducted with patient populations were excluded. For example, participants in Coyne et al. (2015) were traumatic brain injury patients and participants in Viveiros et al. (2017) were patients with heart failure. 

Research must include a measurement of retention of information as the dependent variable. Abstracts indicating that the dependent variable was test anxiety or students’ preferred study strategies were excluded (e.g., Agarwal et al. 2014; Hartwig and Dunlosky 2012; Karpicke et al. 2009). 

As shown in Fig. 1, a total of 1623 abstracts were excluded from the review following initial screening. Seven abstracts that were not available for full-text download were also excluded during initial screening. 

## Detailed Screening 

Detailed screening of the remaining 180 abstracts was conducted using the following criteria: 

Procedurally, all instructional activities, retrieval practice, and assessments must take place in person during class periods under the supervision of the instructor or researcher. For example, research conducted in laboratories (Lipko-Speed et al. 2014) or online (Becker-Blease and Bostwick 2016) was excluded. Retrieval practice carried out after the course ended was also excluded (e.g., Carpenter et al. 2009). Furthermore, retrieval practice must be completed by individual students (i.e., research conducted in collaborative groups was excluded; e.g., Vojdanoska et al. 2010) and controlled by the instructor (i.e., research where retrieval practice was self-regulated using flashcards was excluded; e.g., Rawson et al. 2013). 

In terms of materials, information to be learned must be the same as, or directly related to, assigned course materials that students would be learning in the absence of researchers. For example, Duchastel (1979) had students memorize passages about solar power that were not part of course materials; thus, it was excluded from the present review. In addition, the retrieval 



<!-- Start of picture text -->
Abstracts identified through database searches in 2018:<br>1,447 from PsycINFO, PsychARTICLES, and ERIC<br>133 from PubMed<br>230 from Web of Science<br>(n= 1,810)<br>Abstracts excluded after<br>initial screening<br>(n = 1,623)<br>—l*"=<br>Full-text not available<br>for download<br>(n=7)<br>Full-text articles retrieved for detailed screening<br>(n= 180)<br>Articles excluded that<br>did not meet one or more<br>of the inclusion criteria<br>(n= 85)<br>"="<br>Articles excluded after<br>additional discussion<br>among the authors<br>(n= 58)<br>Articles included in the review (n = 37)<br>Experiments selected for inclusion (n = 50)<br>Effect sizes (Cohen’s d) calculated (n = 49)<br><!-- End of picture text -->

va Springer 

Educational Psychology Review 

practice (e.g., multiple-choice or short answer); (m) the provision of feedback after retrieval practice (e.g., immediate or delayed); (n) the format of the final test; and (o) whether final test performance counted toward students’ grades. When any variables to be coded were ambiguous, two or more of the present authors coded the experiment independently and resolved discrepancies. 

## Effect Size Calculations 

When coding or calculating effect sizes, we used performance on the final test that occurred in closest proximity to the last instance of retrieval practice to avoid practice effects. For example, in Roediger et al. (2011), middle school students completed retention tests at the end of each chapter and also at the end of the semester; thus, effect sizes from Roediger et al. are reported based on chapter test performance only. 

Across the 50 experiments coded, we derived 49 effect sizes (Cohen’s d). For 24 comparisons, data were insufficiently reported to calculate an effect size. Whenever possible, we calculated the effect sizes and corresponding confidence intervals around the effect sizes. We did so even when the original study reported effect sizes because (a) only one study reported confidence intervals around effect sizes (McDermott et al. 2014) and (b) this ensured consistency in the way the effect sizes were calculated. Note that our calculated effect sizes did not match all of the effect sizes reported in the original articles, although that appears to be common as researchers use different formulas to calculate effect sizes (Pan and Rickard 2018). This is true especially for within-subject designs, for which the correlation between data must be accounted for. 

For between-subjects designs, effect sizes and respective 95% confidence intervals were calculated from a reported or derivable t statistic and a reported or derivable sample size, or from reported or derivable sample sizes, means, and standard deviations. For within-subject designs, effect sizes were calculated from a reported or derivable t statistic and a reported or derivable sample size. To compute the effect sizes and 95% confidence intervals around them, we used the MBESS package for R (functions ci.sm and ci.smd for within- and betweensubject designs, respectively; Kelley 2007a, 2007b, 2017). 

We focus our discussion of effect sizes on our calculated Cohen’s ds and we categorized obtained effect sizes as large, medium, and small using Cohen’s (1988) standards. Large effect sizes were defined as d > 0.80; medium effects were 0.50 < d < 0.80; small effects were 0.20 < d < 0.50; very small effects were 0.00 < d < 0.20; and negative effects were d < 0.00. The forest plots depicted in Figs. 3, 4, 5, and 6 allow for a visual representation of the effect sizes and their precision (i.e., narrower confidence intervals indicate more precise effects than wider confidence intervals). 

# Results 

Coding for all experiments is available in the Appendix, as well as on the Open Science Framework (2020, http://osf.io/mz2ks/). Across the 50 experiments coded in the present review, the total sample size was n = 5374 (sample size not reported for Graham 1999). Altogether, experiments coded ranged across a number of factors: 

- & Education levels ranged from elementary school to medical school (e.g., Goossens et al. 2016 and Larsen et al. 2013a, respectively) 



<!-- Start of picture text -->
Negative<br>Very Small Effect<br>Effect 6%<br>2%<br>Large Effect<br>33%<br>Small Effect<br>35%<br>Medium Effect<br>24%<br><!-- End of picture text -->

va Springer 



<!-- Start of picture text -->
McDermottet al., 2014, Exp. 2 (quizzesvs. no quizzes) —————————S— 2.19 (1.71, 2.66}<br>‘Stenlunddeescoumtal,et al.,tl,20620172042 63 (quizzes(zs (esvs. discussionve rowve owi wig) t h feedback;) complex test) a—_——_ _ ——__ — _- ee senn73.ssetisa.s0M1.54 (0.99, 2.08} 248<br>‘Agarwal, 2019, Exp. 3 (mixed quizzes vs. not quizzed;fact test) ——__—___ 1.45 [1.15, 1.75]<br>Dirkxet al., 2014 (STST vs.SSSS; fact test) ee 1.42 (0.70, 2.13]<br>Agarwal, 2019, Exp. 3 (mixed quizzes vs. not quizzed: higher order test) ————_ 1.30 [1.01, 1.59]<br>‘Steniund et al., 2017 (quizzes vs. discussion without feedback; complex test) SS 1.06 (0.54, 1.59]<br>Dirkxet al., 2014 (STST vs. SSSS; application test) oo 0.96 (0.28, 1.63]<br>Roediger et al., 2011, Exp. 2 (quizzes vs. not quizzed) a 0.96 (0.66, 1.25]<br>Bjork et al., 2014 (identical-repeatquiz vs. not quizzed) ——— 0.94 (0.81, 1.06)<br>McDanielet al., 2011, Exp. 2a (delayed quizzes vs. not quizzed) ———_—_—_— 0.89 [0.60, 1.18]<br>‘Agarwal,McDermott2019,et al.,Exp. 2014,3 (higher Exp. 1aorder quiz es vs. (MC qui z zes vs. notnot quiquiz ed; z zed; SAhigher test)order test) ———_—————_+—_- 0.0. 8 74 (0 (0 .5 29 , 1. 2108 )<br>LarsenRoediger et al.,et al.,2013(b) 2011, (SPExp. quiz 2 (quizzes vs. reviewvs. re-study)sheet; written test) SS——————— 0.8 30 (0. 54 4, 1.1 2}5]<br>Bjorket al., 2014 (conceptual-repeat quiz vs. not quizzed) —_— 0.78 (0.66, 0.89)<br>Larsen et al., 2013(b) (written quiz vs. review sheet; written test) ——————* 0.72 (0.37, 1.06}<br>Slr<br>Larsen et al., 2013(a)201 (ee. (quizzes without seff-explanation deco wt dio vs. study withe)self-expian.) ee—— 0.70oraeats24(0.38, 1.01}<br>es<br>Larsentlet al.,2096,2013(b)£2(SP(gequiz vs. review sheet;tw wt)SP test) —_____.___2 oes(o140.69 (0.35, 128 1.03),<br>‘Stenlund et al., 2017 (quizzes vs. discussion with feedback; fact test) —_—_—_—a\sXOsJ—OO" 0.69 (0.20, 1.18}<br>Larsenet a, 2009 (quizzes vs. review sheet) —_—_+—___—_. 0.62 (027, 0.96)<br>Jones et al., 2016, Exp. 1 (quizzes vs. rainbow writing) _—_—— 0.60 (0.03, 1.18]<br>‘McDanielet al., 2011, Exp. 2b (delayed quizzes vs. not quizzed) $< 0.58 (0.29, 0.87}<br>Kromannet al., 2011 (quizzes vs. not quizzed) — 0.55 [0.21, 0.89}<br>‘McDanielet al., 2011, Exp. 2b (immediatequizzes vs. not quizzed) ——_e—__ 0.53 (0.25, 0.82)<br>Lanel‘McDanielet al.,219)2011, Exp.ze2a (immediatewh elroyquizzes vs. not quizzed)wihran) —__.__—_e—___. oasoi8.790.48 (0.22, 0.74)<br>‘McDermottLeong, 202et a.,(izes 2014, Exp. 1adass.(short answerese quizzes eas)vs. not quizzed: SA test) a———+—__. 0.48oar(oo.004(0.17, 0.79),<br>SonMeta Ras 21 (zee rsetet ih pet ants) a oss(ov7.07<br>Karpickeet27 al., (izes2014, Exp. ve azn3 (concept map teshennphnorsretrieval vs. re-study) ——__.____——<—<—— oso.0.42 (0.20, 0820.65}<br>‘ShapiroKromannet al., 2010 (quizzes vs. not quizzed) 0.39 [-0.02, 0.79]<br>Khanna & Gordon, 2012 (quizzes vs. not quizzed) ———— 0.38 (0.25, 0.52}<br>Larsensera,et 208& al., Cortese, ungraded2013(b)2016 (written (ungradedze.quiz vs. quizzes izes)review vs.sheet; no quizzSP t es t)) — ———>—— 0.36os2en030.33 (0.0 23 , 0.6 0749}5)<br>lena & Cates, 2018 gad ze vr zs) 028208 08<br>Graham, 1999 (quizzev . s not quizzed) —e—. 0.27 (0.09, 0.44)<br>Foss& Pirozzolo, 2017, Exp. 3 (frequent exams vs. two exams) 0.25 [-0.23, 0.73]<br>Bekkink et al., 2012 (quizzev s . not quizzed) —<—7—— 0.26 (0.03, 0.45}<br>Foss& Pirozzolo, 2017, Exp. 4 (frequent quizzes vs. fewer quizzes) 0.21 [-0.12, 0.55)<br>‘Son& Rivas, 2016 (quizzes vs. review sheet; transfer test) 0.14 [-0.14, 0.42)<br>‘Tuet al., 2017 (quizzev s .not quizzed) 0.24 [-0.67, 0.19}<br>Khanna, 2015 (graded quizzev s . no quizzes) 0.27 [-0.68, 0.14]<br>Michae's, 2017 (uniors/seniors) 0.30 [-1.05, 0.46)<br>7 cS 2 7<br>Effect Size (Cohen'sd)<br><!-- End of picture text -->

g) Springer 

Educational Psychology Review 

Table 2 Distribution of experiments (k) by moderating variables 

||Total number of experiments|
|---|---|
|Education level (k=50)||
|Elementary school|5|
|Middle school|12|
|High school|3|
|Undergraduate|20|
|Medical school|10|
|Content area (k=51)||
|Science|19|
|Psychology|16|
|History|5|
|Skills-based (CPR, dental diagnosis, nursing skills)|5|
|Spelling and vocabulary|4|
|Mathematics (statistics)|2|
|Type of comparison condition (k=50)||
|Re-read material|19|
|Lessons without quizzes|14|
|Non-quizzed items on the final test|12|
|Fewer opportunities for retrieval practice|5|
|Experimental design (k=50)||
|Within-student|29|
|Between-students without random assignment|12|
|Between-students with random assignment|9|
|Sample size (k=49)||
|Fewer than 100 students|32|
|Greater than 100 students|17|
|Location (k=50)||
|WEIRD countries (USA, Denmark, Netherlands, Sweden)|47|
|Non-WEIRD countries (Pakistan, Taiwan, Turkey)|3|



The total number of experiments reported under content area is k = 51 because Karpicke et al. (2014, experiment 3) included content from both science and history. The total number of experiments reported under sample size is k = 49 because it was not reported by Graham (1999). When an experiment included more than one comparison condition, the number of experiments listed refers to the type of condition in which time spent with material was similar or equivalent to time spent engaged in retrieval practice 

lessons without retrieval practice (k = 14), and when lessons included retrieval practice, but comparison performance was measured on non-quizzed items on a final test (k = 12). Only five experiments included a comparison condition of fewer opportunities for retrieval practice (e.g., comparing two exams vs. weekly quizzes); experiments using this type of comparison yielded small and very small effect sizes. Considering recent recommendations for educators to provide frequent retrieval practice in their already established lessons and course structure (Agarwal and Bain 2019), more research needs to examine the extent to which the quantity of retrieval practice modulates benefits on learning compared to infrequent exams. 

In sum, the majority of experiments revealed medium to large effect sizes, indicating that retrieval practice consistently improves learning in schools and classrooms for a variety of education levels and content areas, under diverse comparison conditions. 

As shown in Table 2 and the Appendix, a majority of experiments were conducted withinstudent (k = 29). Twelve experiments were conducted between-students without random assignment, and nine experiments were conducted between-students with random assignment. Considering the logistical challenges and ethical concerns of random assignment in applied 



<!-- Start of picture text -->
ElementaryJonesKarpickeesJonesetet al.,etal.,201. al.,School2016,2016,2014,Exp.Exp.Exp.21 (quizze (quizzes(ine3 (conceptvvs. s . r rainbowm a towpinbowretrieval writing)writing)i) vs. re-study) a——————————————s— a 0.69 0. ser079 2486042 (0. 0320(0.14, ,  1.23)01 . 18]65)<br>Middle School<br>Agarwal,certMcDermott‘Agarwal, 2019,eteoal.,Exp. 2014,2043 (mixedExp. 22 (quizzesquizzesaden vs.vs. re-study) not nos)quizzed;fact test) _— trots1.581.45 [1.15, [1.19,201.97]1.75]<br>Roediger et2019, al, Exp.2011, 3 Exp.(mixed2 ( quizz eses vs.  nono t quizzed ;) higher order test) +———— 0 961 . 30 [1.010.66 , 1. 59]25)<br>Agarwal,‘McDaniel‘McDermottRoedigerMcDaniel‘McDaniel2019,etet al.,etetet a., al.,al., al., 2011, 2011,Exp. 2011,2011, 2014,3 Exp. (higherExp.Exp.Exp.Exp. 2 2b2a2b(quizzes order (delayed1a(delayed(immediate(MC quizzequizzes vs.quizzesquizzes re-study)quizzesvs.v . s vs.vs. not quizzed)notnot vs.quizzed:not quizzed) quizzed:not quizzed)higherSAtest)order test) ——_e#—__.etai——————.—__—_ 0.0.830.8900.580.53 8 74 (0.54,(0.60, (0.5 (0.29,(0.25,29 , 0.87)1.18] 1. 1.12]0.82]2108 ]<br>‘McDanielet a., 2011, Exp. 2a (immediate quizzes vs. not quizzed) ooo 0.48 (0.22, 0.74)<br>McDermott et al., 2014, Exp. 1a (short answer quizzes vs. not quizzed;SA test) ——<<<—$_——« 0.48 (0.17, 0.79}<br>High School<br>OvalStk‘Stenlund et al.,204(STS2017 (quizzes oe S55vs. discussionet with feedback; complex test) $<Sa 1,54apm (0.99, 29 2.08]<br>Diet el 21 (ste. ds.sn wt etc cones) —— roses 15<br>Sioned (TST 88S apaton te) Eo ose 028 1<br>Stoned t all , 207  q( d zee ve.acodee n  wouih dctock at ——ss o mpat.i23seoan 18<br>UndergraduateSi et, 2014 (ica pn i i) — oo, 10<br>Birkel, 20 ceppet i rte) — 0709808<br>Leeming, 2002 (quizzes every class vs. 4 course exams) a 0.47(0.01, 0.94)<br>‘Son & Rivas, 2016 (quizzes vs. review sheet; test with repeated questions) ———_s———_— 0.45 (0.17, 0.73]<br>Michaels, 2017 (quizzes vs. no quizzes; freshmen/sophomores) —— 0.44 (0.07, 0.82]<br>‘ShapiroKhannaKhanna,&& Gordon,Cortese, 20122016 (ungraded(quizzes vs. not quizzes quizzed) vs. no quizzes) Sr— s—:———— 0.380.36 0.03,(0.25, 0.69) 0.2]<br>Khanna &2015Cortese, (ungraded2016 (gradquizz e ds vs.quizzesno quizzes)vs. no quizzes) 0. 2832 [-0.0 59 , 0. 7261 ]<br>Graham, 1999 (quizzes vs. not quizzed) ——— 0.27 (0.09, 0.44)<br>Foss & Pirozzolo,<br>‘SonFoss& &  Rivas, Pirozzolo, 20162017,2017,(quizzes Exp. 4 (frequent quizzes Exp. 3 (frequentvs. review sheet; examstransfer vs. vs.two fewertest) exams) quizzes) 0.25 0. 1421 [-0.23, 0.73) [-0.1 42 , 0. 5542 )<br>fer,Michaels, 2052017 (juniors/seniors)aedazn oz) -0271298,014-0.30 [-1.05, 0.46]<br>Medical School<br>Larsen et al., 2013(b) (SP quiz vs. review sheet; SP test) — 0.80 (0.44, 1.15)<br>Larsen et al., 2013(b) (written quiz vs. review sheet; written test) Oe 0.72 (0.37, 1.06)<br>Larsen et al., 2013(a) (quizzes with self-explanation vs. study with self-explan.) —_——_—<—<—_— 0.7 (0.38, 1.01]<br>Larsen et al., 2013(b) (SP quiz vs. review sheet; written test) a 0.69 (0.35, 1.03)<br>LarsenKorrmet tl204al., 2009 (quizzes(ee vs. reviewet sheet)zed ———_—_—_—_—_—_——=————a 0.62085 (0.27, 0.96) (21,089<br>LarsenLarsenKromannetet al.,etal., al,2013(b)2013(a)2010 (quizzes (quizzes(written vs.quizwithoutnotvs. quizzed)reviewself-explanationsheet; SP test)vs. study with self-explan.) ey—e 0.390.480.33 [-0.02,(0.18,(0.02, 0.77]00 . 79},65]<br>Bekkink‘Tuet al.,et2017al.,  (quizzes2012 (quizzesvs. not vs. quizzed)not quizzed) —>— 0.240.24 (0.03,[-0.67,0.45)0.19}<br>a 7 TS 2 TS<br>EffectSize (Cohen's d)<br><!-- End of picture text -->

g) Springer 

Educational Psychology Review 

conducted in WEIRD countries (western, educated, industrialized, rich, democratic countries; Rad et al. 2018). Only three out of 50 experiments (6%) drew samples from schools outside the USA and Western Europe, representing 6% of the total sample size in our review (n = 266 out of n = 5374). The three experiments conducted in non-WEIRD countries were from Pakistan, Taiwan, and Turkey. Of these three, one experiment was conducted at the undergraduate level and two were conducted at medical schools. In other words, all experiments at the elementary, middle, and high school levels included in our review were conducted in WEIRD countries. To foreshadow our General Discussion, applied research on retrieval practice is needed with diverse student populations from non-WEIRD countries in order to provide accurate recommendations for educators globally. 

Additional research with larger and more diverse sample sizes would further our understanding of the benefits of retrieval practice in educational settings. In addition, measures of individual differences could be included to examine whether there are optimal conditions for retrieval practice depending on, for example, working memory, prior knowledge, intelligence, and mind wandering (Agarwal et al. 2017; Francis et al. 2020; Minear et al. 2018; Pachai et al. 2016). 

## Retrieval Practice Timing and Delay Before the Final Test 

As shown in Table 3, retrieval practice was typically provided at least once per week (k = 19) or every 2–3 weeks (k = 15). In a few experiments (k = 6), retrieval practice was provided multiple times throughout the semester, but specific timing was not reported. In the remaining experiments, retrieval practice was provided within a single session (k = 10). Because effect sizes were evenly distributed across a range of timings (see Appendix), we recommend educators provide students with opportunities for retrieval practice regardless of the precise timing. 

The most common delay between the last opportunity for retrieval practice and the final test was a 1–3-day delay (k = 20; see Table 3). The next most frequent delay was when a final – exam occurred at the end of the semester or conclusion of the course, after approximately 6 15 weeks, although a specific delay was not reported (k = 14). Effect sizes were larger following a 1–3-day delay, while smaller following an end-of-semester delay (see Appendix). In other words, shorter delays led to a larger benefit from retrieval practice in classroom settings. However, in laboratory research, the opposite effect has been shown— longer delays lead to a larger benefit (Carpenter and Agarwal 2020; Roediger and Karpicke 2006a). For both theoretical and practical considerations, we encourage future research where a range of delays between retrieval practice and final tests are directly manipulated. 

## Retrieval Practice Format and Final Test Format 

As shown in Table 4, the most common formats for retrieval practice were multiple-choice (k = 27) and short answer (k = 17). Similarly, the majority of final test formats were multiplechoice (k = 31) and short answer (k = 15). As displayed in Fig. 5, effect sizes were larger when retrieval practice and final test formats matched (multiple-choice or short answer). When an experiment included multiple formats (e.g., multiple-choice retrieval practice followed by a short answer final test; k = 11), effect sizes were smaller. The transfer appropriate processing framework may account for these findings, where a match between initial and final processing typically promotes learning (Morris et al. 1977). As such, we recommend both multiple-choice 

Educational Psychology Review 

Table 3 Distribution of experiments (k) by retrieval practice timing and final test delay 

||Total number of experiments|
|---|---|
|Retrieval practice timing (k=50)||
|Single session|10|
|At least once per week|19|
|At least once every 2–3 weeks|15|
|Multiple times throughout the semester (duration not specified)|6|
|Delay between retrieval practice and final test (k=50)||
|Immediate|4|
|1–3-day delay|20|
|1–2-week delay|7|
|Multiple exams throughout the semester (timing not specified)|5|
|One exam at the end of the semester or course (6–15-week delay)|14|



and short answer formats for retrieval practice, and a match with final test format may be optimal for promoting student learning. 

When students engage in retrieval practice, a common concern is that they are simply learning the test questions and answers (i.e., a practice effect). Thus, we investigated whether questions during retrieval practice were typically rephrased or verbatim on the final test. For nearly half of the experiments reviewed, questions were rephrased (k = 22), which was most common at the undergraduate and medical school levels. Effect sizes were generally smaller for experiments with rephrased questions compared to experiments with verbatim or repeated questions. Because transfer of knowledge following retrieval practice remains a challenge in the classroom and in the literature (Agarwal 2019; Butler 2010; Pan and Rickard 2018), we encourage more research on retrieval practice and transfer specifically in applied settings. Transfer is, after all, a “holy grail” of education (Pan and Agarwal 2020). 

Table 4 Distribution of experiments (k) by retrieval practice format and final test format 

||Total number of experiments|
|---|---|
|Retrieval practice format (k=62)||
|Multiple-choice|27|
|Short answer|17|
|Free recall|6|
|Cued recall, fill-in-the-blank, or matching|6|
|Simulated diagnoses|5|
|Retrieval format not reported|1|
|Final test format (k=64)||
|Multiple-choice|31|
|Short answer|15|
|Free recall or essay|9|
|Cued recall, fill-in-the-blank, or matching|4|
|Simulated diagnoses|5|
|Final test questions (k=50)||
|Rephrased|22|
|Verbatim|28|
|Final test scores counted toward students’grades (k=50)||
|Yes|33|
|No|15|
|Not reported or unavailable|2|



The total number of experiments reported for retrieval practice format and final test format is greater than k = 50 because some experiments included multiple formats 



<!-- Start of picture text -->
Multiple-Choice Retrieval Practice and Final Tests<br>Agarwal, 2019, Exp. 3 (mixed quizzes vs. not quizzed; fact test) — 1.45 [1.15, 1.75)<br>Agarwal, 2019, Exp. 3 (mixed quizzes vs. notquizzed;higher order test) ——_—-——— 1.30 (1.01, 1.59}<br>Roedigeret al., 2011, Exp. 2 (quizzev . s not quizzed) rs 0.96 (0.66, 1.25)<br>McDanielBjorket al., et 2014al.,  (identical-repeat2011, Exp. 2a (delayedquiz vs.quizzes not quizzed) vs. not quizzed) ——_—_——ti 0. 8994 (0. 8160 , 1. 18)06]<br>McDermottet al.,2014, Exp. 1a (MC quizzes vs. not quizzed; SA test) -->e 0.87 (0.52, 1.21]<br>Agarwal, 2019, Exp. 3 (higher order quizzes vs. not quizzed; higher order test) a a 0.84 (0.59, 1.08)<br>RoedigerGioMcDaniel‘McDanielotal,et et  2044al., al .,., 2011, 2011, (cncatabeapetExp. Exp.  2 2b  (quizzes ( delayedimmediate vs.quizzes re-study) quizzesct vs.vs.ize) notnot quizzed)quizzed) _———So————— 0.83iene 0.5 83 (0.54, (0.2 95 ,  ann 1.12] 0.8 7]2)<br>McDanielet al., 2011, Exp. 2a (immediate quizzes vs. not quizzed) ———— ee 0.48 (0.22, 0.74)<br>‘Son& Rivas, 2016 (quizzesvs. review sheet; test with repeated questions) ——_— 0.45 (0.17, 0.73]<br>‘Shapiro& Gordon, 2012 (quizzev s . not quizzed) — ~— 0.38 (0.25, 0.52}<br>‘Khanna & Cortese, 2016 (ungraded quizzes vs. no quizzes) ——$————— 0.36 (0.03, 0.69}<br>Khanna, 2015 (ungraded quizzes vs. no quizzes) 0.32 [-0.09, 0.72]<br>Khanna& Cortese, 2016 (graded quizzes vs. no quizzes) 0.28 [-0.05, 0.61]<br>‘SonTet,& Rivas, 20172016(amv. (quizzes coz)vs. review sheet; transfer test) 0240.14 (087,040[-0.14, 0.42]<br>‘Khanna, 2015 (graded quizzes vs. no quizzes) 0.27 [-0.68, 0.14}<br>Short Answer Retrieval Practice and Final Tests<br>McDermottet a, 2014, Exp. 2 (quizzes vs. no quizzes) rs 2.49 1.71, 2.66)<br>‘StenlundMcDermottet etal., al.,20172014, (quizzes Exp.2vs. (quizzesdiscussionvs. re-study)with feedback; complex test) ————_ — _—_ — _—_ — _—_—s—aXNSX—OO ——— 1.5 48 [ 10 . 19 9,  12 . 9708 ]<br>iibcol<br>‘StenlundLarsenPexwlsanietetal.,atal.,2013(b)2017iretttc(quizzes(SP quizSaes6208 vs. vs. discussion ertiain review odsheet;withoutes). SP  feedback;test) complex test) OO_—e— ee cb0.80ieenaig1.06 (0.54,(0.44,aass 1.15]1.59]<br>‘Stenlund et al., 2017 (quizzes vs. discussion without feedback; fact test) _O3™m 0.72 (0.21, 1.23]<br>Larsenet al., 2013(b) (written quiz vs. review sheet; written test) ———_e—_— 0.72 (0.37, 1.06}<br>Larsen‘Stenlundet al.,et al.,2013(b)2017 (quizzes (SP quiz vs. vs. review discussionsheet; with written feedback;test)fact test) ——— — ————_ — —_—>_< 0.69 (0. 3520 , 1. 0318 ]<br>ier200 cin veh Sea re ieee<br>sieteLarsen  e204: Ete te ne les ert ghana CAND ——<——— oass7.078<br>Foss & et Pirozzolo, al., 2013(b)2017, (written Exp.  quiz4 (frequent vs. review sheet;quizzes vs. SPfewer test)quizzes) ——_—_— 0.210.33 (0.02,[-0.12, 0.60.5 ] 5 )<br>Multiple Retrieval Practice and Final Test Formats<br>‘KromannLarsenet al, 2013(a) (quizzes with sel-explanationvs. study with set-explan.) ——__+—____ 07 (0.38, 1.01)<br>Larsen etetal., al.,2013(a) (quizzes2011 (quizzes vs.withoutnot quizzed)self-explanation vs. study with self-explan.)_ --oem——_—_——— 0. 4855 (0. 2118 , 0. 8977 )<br>Leeming, 2002 (quizzes every class vs. 4 course exams) [$e 0.47 (0.01, 0.94)<br>KarpickeMichaels,‘Kromannrine, etet20171900al.,al., gee(quizzes2014,2010 (quizzeExp.vs.3 (conceptnov quizzes; s . not mapquizzed) freshmretri e valn/sophomores)vs. re-study) sa——————a 0.390.440.42 (0.07,[-0.02,(0.2,  0.82}0.65)0.79]<br>Foss & Pirozzolo, 2017, Exp.va nt 3 (frequentand) exams vs. two exams) —s— 0. 50 2 71009, [-0.23, 044)0.73}<br>sions:ata Gai vn aio) —=— eadonay<br>‘Michaels, 2017 (uniors/seniors) -0.30 1.05, 0.46]<br>Free Recall Retrieval Practice and Final Tests<br>PereJoneset al,2016,e eieeExp. 2 (quizzeeeonev . s rainbow writing)aea ee—_——— eS 0.69mene(0.14, 1.23)<br>Jones et al., 2016, Exp. 1 (quizzes vs. rainbow writing) 1 0.60 (0.03, 1.18)<br>a<br>EffectSize (Cohen's d)<br><!-- End of picture text -->

va Springer 



<!-- Start of picture text -->
Immediate Feedback<br>McDermottet al., 2014, Exp. 2 (quizzesvs. no quizzes) —_—_—_—_—————. 2.19(1.71, 2.66]<br>Jones et al., 2016, Exp. 3 (quizzev s . rainbow writing) I TS 1.61 (0.73, 2.48)<br>McDermott et al., 2014, Exp. 2 (quizzes vs. re-study) ——_—_—_——— 1.58[1.19, 1.97]<br>‘Stenlundcarve, 2019,et al., 2017und (quizzes vs. discussioncon ekwithrt feedback;ck at)complex test) 7—_—_—_—_—_—_—_——ig 1.54145(848,(0.99, 2.08)178<br>Agarwal,‘Stenlund et2019, al., Exp.2017 (quizze3 (mixed quizzesv s . discussionvs. notwithoutquizzed;feedback;higher ordercomplex test) test) —___—oo _o— 1. 0630 (1(0 . 5401 , 1.5 9)9]<br>Roedigeret al., 2011, Exp. 2 (quizzev s . not quizzed) —_—— 0,96 (0.66, 1.25}<br>McCordol,201, Exp 20 lyed zee ve etzd) —. 20pm, 119<br>Agarwal,McDermottet al., 2014, Exp. 1a (MC quizzes vs. not quizzed; SA test) —_—_—_—_—_—_———_—— 0.87 (0.52, 1.21)<br>Roediger et2019,al., Exp.2011, 3 (higherExp. 2 (quizzes order quizzes vs. re-study) vs. not quizzed; higher order test) —=$=$_e— 0.8 43 (0.5 94 , 1. 08}12]<br>Larsenet al., 2013(b) (SP quiz vs. review sheet; SP test) _ oe 0.80 (0.44, 1.15)<br>Larsenet al., 2013(b) (written quiz vs. review sheet; written test) a 0.72 (0.37, 1.06}<br>‘Stenlundet al., 2017 (quizzes vs. discussionwithout feedback; fact test) —_——$——_—_—_—_——— 0.72 (0.21, 1.23)<br>Larsen et al., 2013(a) (quizzes with self-explanation vs. study with self-expian.) —_—_—_—_—_——_———— 0.70 (0.38, 1.01)<br>Joneset al., 2016, Exp. 2 (quizzev s . rainbow writing) 7 oe” 0.69 (0.14, 1.23)<br>Larsenet al,2013(b) (SP quiz vs. review sheet; written test) —_—_——— 0.69 (0.35, 1.03}<br>‘SteniundLarsen etet al.,al.,20092017(quizzes (quizzesvs.vs.reviewdiscussionsheet)with feedback; fact test) _—_—_— _ —eo—————_ 0.6 92 (0.2 07 ,  10 . 1896 }<br>McDanielJoneset al, et al.,2016,2011, Exp.Exp.1 (quizzes2b (delayedvs. rainbowquizzes writi vs. n otg) quizzed) aee 0. 6058 (0. 0329 ,  10 . 18)87)<br>‘McDanielKromannet al,, 2011 (quizzes vs. notquizzed) ——__—__— 0.55 (0.21, 0.89)<br>Larsen et al.,et al, 2011,2013(a) (quizzesExp. 2b (immediatewithout self-explanationquizzes vs. notvs. quizzed)study withself-explan.) —_————ea 0. 5348 (0. 2518 , 0. 8277 )<br>‘McDanielet al., 2011, Exp. 2a (immediatequizzes vs. not quizzed) —$————— 0.48 (0.22, 0.74)<br>eDemotot<br>Looming, a, 2014, 5p 1a (tot newerusenet quizzed Aa) —<—$ —— o4s,o.7,0279<br>Son & Rivas,2002 (quizzes2016 (quizzes everyvs. class reviewvs.sheet;4 coursetest exams)with repeated questions) _—————_—— 0.4 57 (0. 1701 , 0. 7394 )<br>‘Michaels, 2017 (quizzesvs. no quizzes; freshmen/sophomores) ——————— 0.44 (0.07, 0.82)<br>KromannShapiro et al., 2010 (quizzes vs. not quizzed) 0.39 [-0.02, 0.79)<br>Khanna & Gordon, 2012 (quizzes vs. not quizzed) —_——_— 0.38 (0.25, 0.52}<br>Larsen et& Cortese, al., 2013(b)2016 (written (ungraded quizzesquiz vs. reviewvs.sheet;no quizzSP t es t)) -->e——~rs 0.3 63 (0.0 32 , 0 .69),.65}<br>Khanna, 2015 (ungradedquizzes vs. no quizzes) 0.32 [-0.09, 0.72)<br>Khanna& Cortese, 2016 (graded quizzes vs. no quizzes) 0.28 [-0.05, 0.61)<br>Graham, 1999 (quizzes vs. not quizzed) ——_—— 0.27 (0.09, 0.44)<br>‘Son & Rivas, 2016 (quizzev s . review sheet; transft e st)r 0.14 [-0.14, 0.42)<br>‘Tuet al., 2017 (quizzev s . not quizzed) 0.24 [-0.67, 0.19}<br>Khanna, 2015 (graded quizzev s . no quizzes) 0.27 [-0.68, 0.14)<br>Michaels, 2017 (juniors/seniors) -0.30 [-1.05, 0.46}<br>Delayed Feedback<br>BjorkBjork etet al.,al., 20142014 (identical-repeat (conceptual-repeatquizquiz vs.vs. not not quizzed) quizzed) —j—a a 0. 9478 (0. 8166 ,  10 . 06)89)<br>NoDiceFeedbacka, 2014 (STST ve.SSSS:fc ost ee tuaqor0.249<br>Caceta<br>Karpicke 204 (STET ve. S888; ppt est) ee oz, 189<br>Foss & Pirozzolo,et al., 2014,2017,Exp.Exp.3 (concept map3 (requent exams retrie v s.al vs. r two e -study)xams) ——$———— 0.250.42 (0.20[-0.23 ,  0.65)0.73}<br>Bekkink et al., 2012 (quizzes vs. not quizzed) — es 0.24 (0.03, 0.45)<br>Foss & Pirozzolo, 2017, Exp. 4 (frequent quizzes vs. fewer quizzes) 0.21 [-0.12, 0.55)<br>“948 aa 42S<br>EffectSize (Cohen's d)<br><!-- End of picture text -->

g) Springer 

Educational Psychology Review 

The majority of effect sizes (57%) from studies reviewed were medium or large (Cohen’s d; Fig. 2). 

As is the case for all systematic reviews, ours is subject to publication bias, when studies with positive outcomes tend to be published to a greater extent than studies with negative outcomes (Augusteijn et al. 2019; Simmons et al. 2011). As stated by Ferguson and Heene (2012), “[publication bias] is a systemic discipline-wide problem” in psychology. Specific to research on retrieval practice in classrooms, our search did not return any studies published before 1999 that met our criteria for inclusion. Furthermore, we did not include unpublished studies, as the inclusion of unpublished studies can be ill-defined and thus not reduce publication bias (Ferguson and Heene 2012). Also, new research on retrieval practice in classroom settings has been published since our search in January 2018 (e.g., Gurung and Burns 2019). We did, however, find a number of studies that were not included in previous reviews of research on retrieval practice. We hope that by making our literature review and Appendix publicly available (http://osf.io/mz2ks), we will increase access to research in this field for both researchers and educators, a small step toward addressing publication bias. 

## Future Directions for Research on Retrieval Practice 

Our second aim was to inform future research examining retrieval practice. Following our review of the literature, we provide eight recommendations. 

First, the field needs more applied research investigating varying delays between retrieval practice and the final test. We found larger effect sizes at shorter delays (1– 3 days) and smaller effect sizes at longer delays (end of the semester). In other words, results from our review of the literature indicate the opposite of what is typically found in laboratory studies, where benefits from retrieval practice are larger after longer delays (Carpenter and Agarwal 2020; Roediger and Karpicke 2006a). One possible explanation for this discrepancy is that the delays in classroom settings are much longer than in laboratory settings. In the review of the literature on retrieval practice by Adesope et al. (2017), the majority of studies (64%) had a delay of six or fewer days. Therefore, it may be the case that benefits from retrieval practice increase in the first few days, and then taper off as delays approach weeks or months. For both theoretical and practical considerations, we encourage future research where a range of delays between retrieval practice and final tests are directly manipulated, ideally ranging from days to weeks to months. Courses administered online may be particularly suitable for this type of research. 

Second, classroom research specifically investigating the provision and timing of feedback is needed. Although feedback is a key component of educational settings, classroom studies that directly manipulated feedback (e.g., immediate vs. delayed) were notably absent from our literature search. The benefits of immediate vs. delayed feedback also remain unclear in laboratory research Agarwal et al. 2012; Kulik and Kulik 1988; Metcalfe et al. 2009; Mullet et al. 2014). As was the case for our first recommendation, it is of both theoretical and practical importance to fully understand whether immediate or delayed feedback produces the largest benefits for student learning. One consideration to keep in mind is that delayed feedback can present logistical challenges in classroom settings. Online classes, on the other hand, provide an opportunity to examine delayed feedback with fewer logistical challenges (Butler et al. 2014). 

Educational Psychology Review 

Third, comparison conditions for future research on retrieval practice should more closely mirror common classroom practices. We found that many studies in our literature review compared retrieval practice to re-reading. It has been well established in both laboratory and applied research (including research in the current review) that retrieval practice significantly increases student learning when compared to re-read exposure controls (e.g., Atabek Yigit et al. 2014; Dunlosky et al. 2013; McDermott et al. 2014; Roediger and Karpicke 2006a). More stringent and realistic comparisons to retrieval practice in classroom settings include traditional lectures, flipped classroom activities, think-pair-share discussions, and student presentations (DeLozier and Rhodes 2017). 

Fourth, future research should also examine factors unique to applied settings including class size (e.g., lecture classes vs. small classes), whether retrieval practice was anticipated (e.g., “pop quiz” vs. announced in advance), whether the final test was cumulative, and whether performance on initial retrieval practice counted toward students’ grades. We coded whether final test performance counted toward students’ grades, but information regarding grading procedures for initial retrieval practice was not reported in most studies. 

Fifth, additional research is needed in non-science content areas, such as skills-based learning, mathematics, the humanities (writing, literature, essays), and foreign language vocabulary. Thirty-five out of the 50 experiments reviewed were conducted in science or psychology courses. We were particularly surprised that none of the experiments meeting our screening criteria included foreign language learning, considering the frequent use of these materials in laboratory experiments (Dunlosky et al. 2013). 

Sixth, applied research in education should also take into account the role of the teacher-researcher as a modulating factor for student learning outcomes, also known as the Hawthorne Effect or “participant reactivity” (Diaper 1990; Paradis and Sutkin 2017). This information was inconsistently reported in the studies reviewed, unfortunately. When reported, we found that instructors at the undergraduate level tended to also be the researchers (e.g., Batsell et al. 2017; Leeming 2002; Lyle and Crawford 2011; Saville et al. 2012), whereas instructors at the K-12 level were not the researchers (e.g., Agarwal 2019; Karpicke et al. 2014; McDaniel et al. 2011, 2013; McDermott et al. 2014; Roediger et al. 2011). As such, the role of the teacher-researcher may have contributed to smaller effect sizes in undergraduate classrooms (Fig. 4). Another possibility for smaller effect sizes at the undergraduate level may be due to larger sample sizes or the more frequent use of rephrased questions on final tests. Follow-up studies specifically comparing K-12, undergraduate, and medical school students could shed light on whether benefits from retrieval practice are modulated by age in applied settings. 

Seventh, collaborative retrieval and online quizzes are common in educational settings and it would be beneficial to know when and how they increase student learning. While conducting our literature search, we found numerous educational studies conducted under online or collaborative conditions. While these studies were outside the scope of our review (both areas of research warrant their own literature reviews), they can add to our understanding of retrieval practice in real world settings. With online learning, for example, instructors have more control and flexibility over the provision, timing, and frequency of retrieval practice and feedback (Butler et al. 2014). With collaborative retrieval, a literature review could highlight optimal collaborative groups for a range of ages, content areas, and metacognitive skills (de Carvalho Filho 2010). 

As our final recommendation, applied research on retrieval practice must be conducted with diverse student populations. We found that only three out of 50 experiments that met our 

Educational Psychology Review 

screening criteria were conducted outside the USA and Western Europe (Turkey, Pakistan, and Taiwan), while 94% of classroom research on retrieval practice was conducted in WEIRD countries (western, educated, industrialized, rich, democratic countries; Henrich et al. 2010). The discrepancy is clear: non-WEIRD countries account for 88% of the global population, but only 6% of the sample from the studies reviewed were from non-WEIRD countries (Bauer 2020; Rad et al. 2018). 

Based on findings from the present review—retrieval practice consistently improved learning across a range of ages, content areas, formats, etc. in WEIRD countries—it stands to reason that retrieval practice would similarly benefit student learning in nonWEIRD countries. In line with this reasoning, recent research conducted in nonWEIRD countries suggests that retrieval practice improves learning for elementary school children in Brazil (de Lima and Jaeger 2020) and also for college students in Hungary (Racsmány et al. 2018), countries that are considered to be low in educational attainment (OECD 2020). In addition, self-reported study strategies used by students in Brazil are similar to study strategies used by students in the USA (Ekuni et al. 2020), and researchers have found limited cross-cultural differences on measures of working memory (Adams and Hitch 1997; Lan et al. 2011), a cognitive process engaged during retrieval practice (Agarwal et al. 2017). 

While research suggests that retrieval practice may benefit long-term learning for all learners (WEIRD and non-WEIRD), implementation by students and educators may be affected by cultural norms. For example, van Egmond, Kühnen, and Li (2013) found that the definition of academic learning varies by culture: in Western cultures, learning is attributed to the cognitive domain, whereas in Eastern cultures, learning is associated with the development of the person as a whole; thus, it may be the case that retrieval practice could be implemented more frequently in Western cultures consistent with a cognitive approach. Tweed and Lehman (2002) suggested that ideals of learning that are predominantly Western (Socratic) or more Eastern (Confucian) influence students’ approaches toward learning, including motivation, effort, and memorization, all of which are contributing factors to the implementation of retrieval practice (Agarwal and Bain 2019). Furthermore, Western cultures are considered individualistic or independent because they focus on standing out and being unique, whereas Eastern cultures are considered collectivist or interdependent because they focus on maintaining harmony within the group (Markus and Kitayama 1991); to speculate, this could affect the extent to which educators implement individual vs. collaborative retrieval practice. Considering these cultural dynamics, it is possible that the implementation of retrieval practice in WEIRD countries may be vastly different from implementation in non-WEIRD countries, subsequently modulating benefits from retrieval practice on student learning. 

Lastly, we encourage research on retrieval practice with non-WEIRD students because an overreliance on WEIRD samples can produce false claims about human psychology and behavior (Henrich et al. 2010). For example, Henrich and colleagues found that individuals from WEIRD countries exhibit divergent behaviors compared to the rest of the world, even for domains that were previously considered to be universal, such as visual perception, cooperation, spatial reasoning, and moral reasoning. As a second example, the autobiographical reminiscence bump is considered to be a basic memory process, and yet the content of memories differs for individualistic vs. collectivist cultures (Conway et al. 2005). Third, Segall et al. (1966) found that 

Educational Psychology Review 

the San foragers of the Kalahari were immune to the well-known Muller-Lyer visual illusion, which was previously thought to be fundamental to the human species. If these researchers had not tested non-WEIRD samples, we might still hold the conviction that all humans are susceptible to the same patterns of behavior. 

For these reasons, it would be shortsighted to assume that what is beneficial for learning in WEIRD countries is beneficial for learning in non-WEIRD countries. Applied research on retrieval practice is needed with students from non-WEIRD countries if we are to provide accurate recommendations, based on empirical evidence, for educators and students globally. As a starting point, we urge researchers to report key demographics, including students’ age, gender, location, and type of school (e.g., public, private, rural, urban). If researchers are to provide practical recommendations for educators regarding retrieval practice, then student demographics must be taken into account (Rad et al. 2018). Educators are eager to know whether retrieval practice would be beneficial for their specific student population, and also whether these benefits generalize to all classrooms. 

## Recommendations for Classroom Implementation of Retrieval Practice 

Our third and final aim for the literature review was to identify practical recommendations for educators as they implement retrieval practice in their classrooms. We had anticipated the emergence of optimal conditions for retrieval practice: content areas, formats, timing, and so on. However, we did not find any singular or specifically optimal conditions; instead, we found that nearly all conditions in schools and classrooms yielded a benefit from retrieval practice. 

We conclude that educators should implement retrieval practice, with less concern about the precise format or timing of retrieval interventions. Almost all effect sizes (46 out of 49 Cohen’s d) indicated a positive benefit from retrieval practice under wideranging conditions, and retrieval practice improved student learning to a greater extent than time spent on other classroom activities (e.g., reviewing material, lectures without quizzes). 

We hope that this literature review provides educators with an accessible resource when considering implementation of retrieval practice. In our Appendix (available at http://osf.io/mz2ks), we have included details for each of the 50 experiments, broken down by education level, content area, effect sizes, and more. Educators can explore the retrieval practice research that has been conducted under similar conditions as their own classroom or school, to inform teaching strategies, professional development, and curriculum development. By implementing retrieval practice in schools and classrooms, scientists and educators can bridge the gap between research and practice—and most importantly, transform students’ long-term learning. 

Educational Psychology Review 

|al<br>or<br>n -<br>*)<br> m<br>Sample<br>Size<br>in Final<br>Analyses<br>88<br>98<br>84|64|404<br>372|
|---|---|---|
|Experiment<br>Design<br>(within- <br>b e t w e e<br>students)<br>Asterisk (<br>indicates<br>r a n d o <br>assignment<br>Within<br>Within<br>Between*|Between|Between*<br>Within|
|Course Topic<br>World History<br>Introduction to<br>Chemistry<br>Endocrinology|Introduction to<br>Psychology|Introduction to<br>Pathology|
|Overall<br>Content<br>Area<br> History<br> Science<br>Science|Psychology|Science<br> Psychology|
|Education<br>Level<br>Middle School <br>Undergraduate <br>Medical<br>School|Undergraduate|Medical<br>School<br>Undergraduate|
|nducted in classroom settings<br>Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>1.45 [1.15, 1.75] (mixed quizzes<br>vs. not quizzed;<br>fact test)<br>1.30 [1.01, 1.59] (mixed quizzes<br>vs. not quizzed;<br>higher order test)<br>0.84 [0.59, 1.08] (higher order<br>quizzes vs. not quizzed;<br>higher order test)<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>Numerical benefit<br>from retrieval practice*|Numerical benefit<br>from retrieval practice*|0.24 [0.03, 0.45]|
|iments on retrieval practice co<br>Comparison Condition(s)<br>Questions on the final<br>assessment only<br>Studied a review sheet<br>No review sheet<br>Lessons without quizzes|Textbook reading without<br>quizzes|Lessons without quizzes|
|omparison of 50 exper<br>Retrieval Practice<br>Intervention<br>Quizzes with mixed<br>(fact and higher<br>order) questions<br>Quizzes with higher<br>order questions<br>Quizzes with<br>feedback<br>Quizzes without<br>feedback<br>Quizzes<br>x|Textbook reading<br>with in-class<br>|quizzes<br>Quizzes|
|Table 5 A c<br>Abbreviated<br>Citation<br>Agarwal<br>2019,<br>Experi-<br>ment 3<br>Atabek Yigit<br>et al.<br>2014<br>Ayyub and<br>Mahboob<br><br>Appendi|2017<br>Batsell et al.<br>2017|Bekkink et<br>al.2012|



Educational Psychology Review 

|Experimental<br>Design<br>(within- or<br>b e t w e e n -<br>students)<br>Asterisk (*)<br>indicates<br>r a n d o m<br>assignment<br>Sample<br>Size<br>in Final<br>Analyses<br>s<br>Between*<br>38<br>Within<br>66<br>Within<br>125<br>Within<br>60|
|---|
|Course Topic<br>Research Method<br>in Psychology<br>cs<br>Statistics<br>Anatomy and<br>Physiology<br>Anatomy and<br>Physiology<br>Anatomy and<br>Physiology|
|Overall<br>Content<br>Area<br>Mathemati<br> Science<br> Science<br> Science|
|Education<br>Level<br> <br>High School<br>Undergraduate<br>Undergraduate<br>Undergraduate|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>0.94 [0.81, 1.06] (identical-repeat<br>quizzes vs. not quizzed)<br>0.78 [0.66, 0.89]<br>(conceptual-repeat quizzes vs.<br>not quizzed)<br>1.42 [0.70, 2.13] (final test with<br>factual questions)<br>0.96 [0.28, 1.63] (final test with<br>application questions)<br>e<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>s<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*|
|Comparison Condition(s)<br>Questions on the final<br>assessment only<br>Study-study-study-study<br>(SSSS)<br>Read-generate-read-generat<br>(RGRG)<br>Re-read (RRRR)<br>Read-read while taking note<br>(R-R+N)<br>Re-read (RRR)<br>Re-study over 7 days<br>Re-study over 2 days|
|tinued)<br>Retrieval Practice<br>Intervention<br>Quizzes with<br>identical questions<br>repeated<br>on the final<br>assessment<br>Quizzes with<br>conceptually<br>related questions<br>on the final<br>assessment<br>Study-test-study-test<br>(STST)<br>Read-quiz-read-quiz<br>(RTRT)<br>Read-quiz-read<br>(RTR)<br> <br>Free recall over 7<br>days<br>Free recall over 2<br>days|
|Table 5 (con<br>Abbreviated<br>Citation<br>Bjork et al.<br>2014<br>Dirkx et al.<br>2014<br>Dobson and<br>Linderho-<br>lm2015a<br>Dobson and<br>Linderho-<br>lm2015b<br>Dobson et al.<br>2017|



Educational Psychology Review 

|l<br>r<br>-<br>)<br>m<br>Sample<br>Size<br>in Final<br>Analyses<br>159<br>70<br>117<br>214<br>338<br>129|
|---|
|Experimenta<br>Design<br>(within- o<br>b e t w e e n<br>students)<br>Asterisk (*<br>indicates<br>r a n d o <br>assignment<br>s<br>Between<br>s<br>Between<br>s<br>Between<br>s<br>Between<br>Between<br>Within|
|Course Topic<br>Research Method<br>in Psychology<br>Research Method<br>in Psychology<br>Research Method<br>in Psychology<br>Research Method<br>in Psychology<br><br>Dental Diagnosis<br>and Treatment<br>Vocabulary|
|Overall<br>Content<br>Area<br>Psychology<br>Psychology<br>Psychology<br>Psychology<br>Skills-Based|
|Education<br>Level<br>Undergraduate<br>Undergraduate<br>Undergraduate<br>Undergraduate<br>Medical<br>School|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>p<br>Numerical benefit<br>from retrieval practice*<br>Numerical benefit<br>from retrieval practice*<br>0.25 [-0.23, 0.73]<br>0.21 [-0.12, 0.55]<br>Numerical benefit<br>from retrieval practice*<br>Numerical benefit|
|Comparison Condition(s)<br> <br> <br>2 midterm exams and 2 po<br>quizzes<br>2 course exams<br>2 course exams<br>3 quizzes<br>Lessons without quizzes<br>Copyingdefinitions|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Free recall in a single<br>session<br>4 midterm exams<br>and 4 pop quizzes<br>8 course exams<br>8 course exams and<br>additional quizzes<br>6 quizzes<br>Quizzes<br>Cued recall|
|Table 5 (co<br>Abbreviated<br>Citation<br>Foss and<br>Pirozzolo<br>2017,<br>Experi-<br>ment 1<br>Foss and<br>Pirozzolo<br>2017,<br>Experi-<br>ment 2<br>Foss and<br>Pirozzolo<br>2017,<br>Experi-<br>ment 3<br>Foss and<br>Pirozzolo<br>2017,<br>Experi-<br>ment 4<br>Freda and<br>Lipp<br>2016|



#### Educational Psychology Review 

|l<br>r<br>-<br>)<br>m<br>Sample<br>Size<br>in Final<br>Analyses<br>Not<br>Re-<br>ported<br>14<br>16<br>12<br>85<br>277|
|---|
|Experimenta<br>Design<br>(within- o<br>b e t w e e n<br>students)<br>Asterisk (*<br>indicates<br>r a n d o <br>assignment<br><br>Within<br>Within<br>Within<br>Within<br>d<br>Within<br>Between*|
|Course Topic<br>Neuropsychology<br>and<br>Psychology of<br>Learning<br>Spelling<br>Spelling<br>Spelling<br>Earth Science an<br>U.S. History<br>Introduction to<br>Psychology,|
|Overall<br>Content<br>Area<br>Spelling and<br>Vocabu-<br>lary<br>e<br>Psychology<br>Spelling and<br>Vocabu-<br>lary<br>Spelling and<br>Vocabu-<br>lary<br>Spelling and<br>Vocabu-<br>lary<br>Science and<br>History<br>e<br>Psychology|
|Education<br>Level<br>Elementary<br>School<br>Undergraduat<br>Elementary<br>School<br>Elementary<br>School<br>Elementary<br>School<br>Elementary<br>School<br>Undergraduat|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>from copying definitions*<br>0.27 [0.09, 0.44]<br>0.60 [0.03, 1.18]<br>0.69 [0.14, 1.23]<br>1.61 [0.73, 2.48]<br>0.42 [0.20, 0.65]<br>0.36 [0.03, 0.69] (ungraded<br>quizzes vs. noquizzes)|
|Comparison Condition(s)<br>Textbook reading without<br>quizzes<br>Rainbow writing<br>Rainbow writing<br>Rainbow writing<br>Re-study<br>Lessons without quizzes|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Textbook reading<br>with in-class<br>quizzes<br>Quizzes<br>Quizzes<br>Quizzes<br>Cued recall using a<br>concept map<br>Graded quizzes<br>Ungradedquizzes|
|Table 5 (co<br>Abbreviated<br>Citation<br>Goossens et<br>al.2016<br>Graham<br>1999<br>Jones et al.<br>2016,<br>Experi-<br>ment 1<br>Jones et al.<br>2016,<br>Experi-<br>ment 2<br>Jones et al.<br>2016,<br>Experi-<br>ment 3<br>Karpicke et<br>al.2014,<br>Experi-<br>ment 3|



Educational Psychology Review 

|l<br>r<br>-<br>)<br>m<br>Sample<br>Size<br>in Final<br>Analyses|137<br>81<br>89<br>138<br>40<br>49|
|---|---|
|Experimenta<br>Design<br>(within- o<br>b e t w e e n<br>students)<br>Asterisk (*<br>indicates<br>r a n d o <br>assignment|Between*<br>Between*<br>Between*<br>Between*<br>Within<br>Within|
|Course Topic|Cognitive<br>Psychology,<br>and Research<br>Methods<br>Introduction to<br>Psychology<br>CPR Skills<br>CPR Skills<br>CPR Skills<br>Neurology<br>Neurology|
|Overall<br>Content<br>Area|ate<br>Psychology<br>Skills-Based<br>Skills-Based<br>Skills-Based<br>Science<br>Science|
|Education<br>Level|Undergradu<br>Medical<br>School<br>Medical<br>School<br>Medical<br>School<br>Medical<br>School<br>Medical<br>School|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size|0.28 [-0.05, 0.61] (graded quizzes<br>vs. no quizzes)<br>0.32 [-0.09, 0.72] (ungraded<br>quizzes vs. no quizzes)<br>-0.27 [-0.68, 0.14] (graded<br>quizzes vs. no quizzes)<br>Numerical benefit<br>from retrieval practice*<br>0.39 [-0.02, 0.79]<br>0.55 [0.21, 0.89]<br>0.62 [0.27, 0.96]<br>0.70 [0.38, 1.01] (quizzes with<br>self-explanation<br>vs. study with self-explanation)<br>0.48 [0.18, 0.77] (quizzes without<br>self-explanation<br>vs. study with self-explanation)<br>Numerical benefit from retrieval<br>practice<br>for remaining comparisons*|
|Comparison Condition(s)|Lessons without quizzes<br>Scenario lectures without<br>quizzes<br>Scenario lectures without<br>quizzes<br>Scenario lectures without<br>quizzes<br>Studied a review sheet<br>Studied a review sheet with<br>self-explanations<br>Studied a review sheet<br>without self-explanations|
|ntinued)<br>Retrieval Practice<br>Intervention|Graded quizzes<br>Ungraded quizzes<br>Scenario-based quiz<br>Scenario-based quiz<br>Scenario-based quiz<br>Quizzes<br>Quizzes with<br>self-explanations<br>Quizzes without<br>self-explanations|
|Table 5 (co<br>Abbreviated<br>Citation|Khanna and<br>Cortese<br>2016<br>Khanna<br>2015<br>Kromann et<br>al.2009<br>Kromann et<br>al.2010<br>Kromann et<br>al.2011<br>Larsen et al.<br>2009<br>Larsen et al.<br>2013a|



Educational Psychology Review 

|tal<br> or<br>n -<br>(*)<br> m<br><br>Sample<br>Size<br>in Final<br>Analyses<br>41<br>192<br>144<br>92<br>65<br>54|
|---|
|Experimen<br>Design<br>(within- <br>b e t w e e<br>students)<br>Asterisk <br>indicates<br>r a n d o <br>assignment<br>Within<br>Between<br>Between<br>Within<br>Within<br>Within|
|Course Topic<br>Neurology<br>Introduction to<br>Psychology<br>and<br>Psychology of<br>Learning<br><br>Statistics for<br>Psychology<br>Biology<br>Astronomy|
|Overall<br>Content<br>Area<br>Science<br><br>Psychology<br> Mathematics<br>l Science<br>l Science<br>l Science|
|Education<br>Level<br>s.<br>s.<br>Medical<br>School<br>Undergraduate<br>Undergraduate<br>Middle Schoo<br>es<br>Middle Schoo<br>Middle Schoo|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>0.80 [0.44, 1.15] (SP quiz vs.<br>study; final SP test)<br>0.69 [0.35, 1.03] (SP quiz vs.<br>study; final written test)<br>0.33 [0.02, 0.65] (written quiz v<br>study; final SP test)<br>0.72 [0.37, 1.06] (written quiz v<br>study; final written test)<br>0.47 [0.01, 0.94]<br>Numerical benefit<br>from retrieval practice*<br>Numerical benefit<br>from retrieval practice*<br>0.48 [0.22, 0.74] (immediate<br>quizzes vs. not quizzed)<br>0.89 [0.60, 1.18] (delayed quizz<br>vs. not quizzed)|
|Comparison Condition(s)<br>Studied a review sheet<br>4 course exams<br>Lessons without quizzes<br>Questions on the final<br>assessment only<br>Questions on the final<br>assessment only|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Quizzes with<br>standardized<br>patients (SP)<br>Quizzes with written<br>questions<br>Quizzes every class<br>Quizzes<br>Quizzes<br>Immediate quizzes<br>Delayed quizzes<br>Immediatequizzes|
|Table 5 (co<br>Abbreviated<br>Citation<br>Larsen et al.<br>2013b<br>Leeming<br>2002<br>Lyle and<br>Crawford<br>2011<br>McDaniel et<br>al.2011,<br>Experi-<br>ment 1<br>McDaniel et<br>al.2011,<br>Experi-<br>ment 2a|



Educational Psychology Review 

|Experimental<br>Design<br>(within- or<br>b e t w e e n -<br>students)<br>Asterisk (*)<br>indicates<br>r a n d o m<br>assignment<br>Sample<br>Size<br>in Final<br>Analyses<br>Within<br>61<br>Within<br>90<br>Within<br>45|
|---|
|Course Topic<br>Biology and<br>Chemistry<br>Biology and<br>Physics<br>Earth Science<br>Earth Science|
|Overall<br>Content<br>Area<br>l Science<br>l Science<br>l Science|
|Education<br>Level<br> <br>Middle Schoo<br>Middle Schoo<br>Middle Schoo|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>0.53 [0.25, 0.82] (immediate<br>quizzes vs. not quizzed)<br>0.58 [0.29, 0.87] (delayed quizzes<br>vs. not quizzed)<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>0.87 [0.52, 1.21] (multiple-choice<br>quizzes vs. not quizzed; final<br>test with short answer<br>questions)<br>0.48 [0.17, 0.79] (short answer<br>quizzes vs. not quizzed; final<br>test with short answer<br>questions)<br>Numerical benefit from retrieval<br>practice (multiple-choice<br>quizzes vs. notquizzed;final|
|Comparison Condition(s)<br>Questions on the final<br>assessment only<br>Questions on the final<br>assessment only<br>Questions on the final<br>assessment only<br> <br>Questions on the final<br>assessment only|
|tinued)<br>Retrieval Practice<br>Intervention<br>Delayed quizzes<br>Quizzes with<br>definition<br>questions<br>Quizzes with key<br>term questions<br>Quizzes with<br>definition<br>questions<br>Quizzes with key<br>term questions<br>Quizzes with<br>multiple-choice<br>questions<br>Quizzes with short<br>answer questions|
|Table 5 (con<br>Abbreviated<br>Citation<br>McDaniel et<br>al.2011,<br>Experi-<br>ment 2b<br>McDaniel et<br>al.2013,<br>Experi-<br>ment 1<br>McDaniel et<br>al.2013,<br>Experi-<br>ment 2<br>McDermott<br>et al.<br>2014,<br>Experi-<br>ment 1a|



Educational Psychology Review 

|Experimental<br>Design<br>(within- or<br>b e t w e e n -<br>students)<br>Asterisk (*)<br>indicates<br>r a n d o m<br>assignment<br>Sample<br>Size<br>in Final<br>Analyses<br>Within<br>45<br>Within<br>59<br>h<br>Within<br>60<br>Within<br>40|
|---|
|Course Topic<br>Biology<br>Biology and<br>Physics<br>Biology and Eart<br>Science<br>U.S. and World<br>History|
|Overall<br>Content<br>Area<br>l Science<br>l Science<br>l Science<br>History|
|Education<br>Level<br> <br>Middle Schoo<br>ot<br>Middle Schoo<br>Middle Schoo<br>High School|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>test with multiple-choice<br>questions)<br>Equivalent means for retrieval<br>practice and comparison<br>conditions (short answer<br>quizzes vs. not quizzed; final<br>test with multiple-choice<br>questions)<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>1.58 [1.19, 1.97] (quizzes vs.<br>re-study)<br>2.19 [1.71, 2.66] (quizzes vs. n<br>quizzed)<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>Numerical benefit<br>from retrievalpractice|
|Comparison Condition(s)<br>Questions on the final<br>assessment only<br>Re-study<br>Questions on the final<br>assessment only<br>Re-study<br>Questions on the final<br>assessment only<br>Questions on the final<br>assessment only|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Quizzes with<br>multiple-choice<br>questions<br>Quizzes with short<br>answer questions<br>Quizzes<br>Quizzes with<br>multiple-choice<br>questions<br>Quizzes with short<br>answer questions|
|Table 5 (co<br>Abbreviated<br>Citation<br>McDermott<br>et al.<br>2014,<br>Experi-<br>ment 1b<br>McDermott<br>et al.<br>2014,<br>Experi-<br>ment 2<br>McDermott<br>et al.<br>2014,<br>Experi-<br>ment 3<br>McDermott<br>et al.|



Educational Psychology Review 

|l<br>r<br>-<br>)<br>m<br>Sample<br>Size<br>in Final<br>Analyses<br>139<br>109<br>36<br>63<br>58|
|---|
|Experimenta<br>Design<br>(within- o<br>b e t w e e n<br>students)<br>Asterisk (*<br>indicates<br>r a n d o <br>assignment<br>Between<br>Between<br>Within<br>Within<br>Within|
|Course Topic<br>Introduction to<br>Psychology<br>Sensation and<br>Perception<br>World History<br>World History|
|Overall<br>Content<br>Area<br><br>Psychology<br><br>Psychology<br> <br>History<br> <br>History<br><br>Psychology|
|Education<br>Level<br>Undergraduate<br>Undergraduate<br>Middle School<br> <br>Middle School<br>Undergraduate|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>for all comparisons*<br>0.44 [0.07, 0.82] (freshmen and<br>sophomores)<br>-0.30 [-1.05, 0.46] (juniors and<br>seniors)<br>Numerical benefit<br>from retrieval practice<br>for all comparisons*<br>Numerical benefit<br>from retrieval practice*<br>0.83 [0.54, 1.12] (quizzes vs.<br>re-study)<br>0.96 [0.66, 1.25] (quizzes vs. not<br>quizzed)<br>No numerical benefit|
|Comparison Condition(s)<br>Lessons without quizzes<br>Lessons without quizzes<br>Questions on the final<br>assessment only<br>Re-study<br>Questions on the final<br>assessment only<br>Lessons withoutquizzes|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Quizzes with<br>multiple-choice<br>questions<br>Quizzes with short<br>answer questions<br>Quizzes (freshmen<br>and sophomores)<br>Quizzes (juniors and<br>seniors)<br>Pre-lecture quizzes<br>with matching<br>questions<br>Pre-lecture quizzes<br>with<br>fill-in-the-blank<br>questions<br>Quizzes<br>Quizzes<br>Quizzes|
|Table 5 (co<br>Abbreviated<br>Citation<br>2014,<br>Experi-<br>ment 4<br>Michaels<br>2017<br>Narloch et<br>al.2006<br>Roediger et<br>al.2011,<br>Experi-<br>ment 1<br>Roediger et<br>al.2011,<br>Experi-<br>ment 2|



Educational Psychology Review 

|l<br>r<br>-<br>)<br>m<br>Sample<br>Size<br>in Final<br>Analyses<br>226<br>209<br>98<br>84|
|---|
|Experimenta<br>Design<br>(within- o<br>b e t w e e n<br>students)<br>Asterisk (*<br>indicates<br>r a n d o <br>assignment<br>Within<br>Between<br>Between*<br>Between|
|Course Topic<br>Psychology of<br>Learning<br>Introduction to<br>Psychology<br>Developmental<br>Psychology<br>Psychology of<br>Emotions<br>Fundamentals of<br>Nursing|
|Overall<br>Content<br>Area<br>e<br>Psychology<br>e<br>Psychology<br>Psychology<br>Skills-Based|
|Education<br>Level<br>Undergraduat<br>Undergraduat<br>High School<br>Medical<br>School|
|Effect Sizes (Cohen'sd)<br>Asterisk (*) indicates<br>insufficient data to calculate<br>effect size<br>from retrieval practice*<br>0.38 [0.25, 0.52]<br>0.45 [0.17, 0.73] (final test with<br>repeated questions)<br>0.14 [-0.14, 0.42] (final test with<br>transfer questions)<br>k<br>1.54 [0.99, 2.08] (quizzes vs.<br>discussion with feedback;<br>final test with complex questions)<br>0.69 [0.20, 1.18] (quizzes vs.<br>discussion with feedback;<br>final test with factual questions)<br>1.06 [0.54, 1.59] (quizzes vs.<br>discussion without feedback;<br>final test with complex questions)<br>0.72 [0.21, 1.23] (quizzes vs.<br>discussion without feedback;<br>final test with factual questions)<br>-0.24 [-0.67, 0.19]|
|Comparison Condition(s)<br>Questions on the final<br>assessment only<br>Studied a review sheet<br>Discussion with feedback<br>Discussion without feedbac<br>Lessons without quizzes|
|ntinued)<br>Retrieval Practice<br>Intervention<br>Quizzes<br>Quizzes<br>Quizzes<br>Quizzes|
|Table 5 (co<br>Abbreviated<br>Citation<br>Saville et al.<br>2012<br>Shapiro and<br>Gordon<br>2012<br>Son and<br>Rivas<br>2016<br>Stenlund et<br>al.2017<br>Tu et al.<br>2017|



Educational Psychology Review 

|Final Test Format<br>A s t e r i s k<br>( * )<br>indicates<br>rephrased final<br>test questions<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades<br><br>Final Test Format<br>A s t e r i s k<br>( * )<br>indicates<br>rephrased final<br>test questions<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades|Multiple-choice*<br>No<br> Multiple-choice<br>and matching<br>No<br>Multiple-choice*<br>Yes<br> Multiple-choice*<br>Yes<br>Multiple-choice*<br>Yes<br>Multiple-choice*<br>Yes<br>Short answer<br>No|Free recall<br>No<br>Multiple-choice<br>No|
|---|---|---|
|Feedback<br>After<br>Retrieval<br>Practice<br>Feedback<br>After<br>Retrieval<br>Practice|Immediate<br>d<br>Immediate<br>Not<br>report-<br>ed<br>Immediate<br>d<br>None<br>Delayed<br>None|None<br>None|
|Retrieval Practice<br>Format<br>Retrieval Practice<br>Format|Multiple-choice<br>Multiple-choice an<br>matching<br>Multiple-choice<br> <br>Not Reported<br>Multiple-choice an<br>short answer<br> <br>Multiple-choice<br>Short answer|Free recall<br>Free recall|
|Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test<br>Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test|2 days<br>1 day<br>1 week<br>r (timing<br>Three exams throughout<br>the semester (timing not<br>specified)<br>3 days<br>End of the 10-week course<br>1 week|Immediate<br>Immediate|
|d<br>Retrieval Practice Timing<br>d<br>Retrieval Practice Timing|Three times within 1 week<br>)<br>Once within a single session<br>)<br>Once per week for 4 weeks<br>Twice per week throughout the semeste<br>not specified)<br>1-2 times per week for 4 weeks<br>Once every 2 weeks for 10 weeks<br>Once within a single session|Twice within a single session<br>Once within a single session|
|ed)<br>Conducted<br>in the<br>U n i t e <br>States<br>Conducted<br>in the<br>U n i t e <br>States|Yes<br>al.<br>No (Turkey<br>7<br>No<br>(Pakistan<br>7<br>Yes<br>No (The<br>Nether-<br>lands)<br> <br>Yes<br> <br>No (The<br>Nether-|lands)<br>Yes<br>Yes|
|Table 5 (continu<br>Abbreviated<br>Citation<br>Abbreviated<br>Citation|Agarwal2019,<br>Experiment 3<br>Atabek Yigit et<br>2014<br>Ayyub and<br>Mahboob201<br>Batsell et al.201<br>Bekkink et al.<br>2012<br>Bjork et al.2014<br>Dirkx et al.2014|Dobson and<br>Linderholm<br>2015a|



Educational Psychology Review 

|t<br>)<br>l<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades<br>No<br>Yes<br>Yes<br>Yes<br>Yes<br>Yes<br>Not<br>reported<br>Yes<br>Yes<br>Yes|
|---|
|Final Test Forma<br>A s t e r i s k<br>( *<br>indicates<br>rephrased fina<br>test questions<br>Free recall<br>Multiple-choice<br>and short<br>answer<br>Multiple-choice<br>and short<br>answer<br>Multiple-choice<br>and short<br>answer*<br>Short answer*<br>Simulated<br>diagnosis*<br> Cued recall<br>Multiple-choice<br>and<br>fill-in-the--<br>blank*<br> Free recall<br> Free recall|
|Feedback<br>After<br>Retrieval<br>Practice<br>None<br>None<br>None<br>None<br>None<br>Delayed<br>Immediate<br>Not<br>Report-<br>ed<br>Immediate<br>Immediate|
|Retrieval Practice<br>Format<br>Free recall<br> <br>Multiple-choice and<br>short answer<br> <br>Multiple-choice and<br>short answer<br> <br>Multiple-choice and<br>short answer<br>Short answer<br>Simulated diagnosis<br>Cued recall<br>Multiple-choice and<br>fill-in-the-blank<br>Free recall<br>Free recall|
|Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test<br>Immediate<br>End of the 15-week course<br>End of the 15-week course<br>End of the 15-week course<br>7-10 days<br>End of the 6-week course<br>1-3 days<br>End of the semester<br>1 day<br>1 day|
|d<br> d<br>Retrieval Practice Timing<br>Six times within 7 days<br>Once every 2 weeks for 15 weeks<br>Once every 2 weeks for 15 weeks<br>Once every 2 weeks for 15 weeks<br>Once every 2 weeks for 15 weeks<br>Once per week for 6 weeks<br>-<br>Six times total for 1-2 weeks<br>10 times throughout the semester (timing not<br>specified)<br>Twice within 8 days<br>Twice within 8 days|
|d)<br>Conducte<br>in the<br>U n i t e<br>States<br> Yes<br>Yes<br>Yes<br>Yes<br>Yes<br>Yes<br>No (The<br>Nether<br>lands)<br>Yes<br>Yes<br>Yes|
|Table 5 (continue<br>Abbreviated<br>Citation<br>Dobson and<br>Linderholm<br>2015b<br>Dobson et al.2017 <br>Foss and Pirozzolo<br>2017,<br>Experiment 1<br>Foss and Pirozzolo<br>2017,<br>Experiment 2<br>Foss and Pirozzolo<br>2017,<br>Experiment 3<br>Foss and Pirozzolo<br>2017,<br>Experiment 4<br>Freda and Lipp<br>2016<br>Goossens et al.<br>2016<br>Graham1999<br>Jones et al.2016,<br>Experiment 1|



Educational Psychology Review 

|Final Test Format<br>A s t e r i s k<br>( * )<br>indicates<br>rephrased final<br>test questions<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades|Free recall<br>Yes|Free recall<br>No|Multiple-choice*<br>Yes|Multiple-choice*<br>Yes|Simulated<br>diagnosis<br>No|Simulated<br>diagnosis<br>No|Simulated<br>diagnosis<br>No<br> Short answer<br>No<br> Essay*<br>No<br> Simulated<br>diagnosis<br>and a short<br>answer test*<br>No<br>No|
|---|---|---|---|---|---|---|---|
|Feedback<br>After<br>Retrieval<br>Practice|Immediate|None|Immediate|Immediate|s Immediate|s Immediate|s Immediate <br>Immediate <br>Immediate <br>s<br>Immediate <br>Immediate|
|nity<br>Retrieval Practice<br>Format|Free recall|Short answer|Multiple-choice|Multiple-choice|Simulated diagnosi|Simulated diagnosi|Simulated diagnosi<br>Short answer<br>Short answer<br>Simulated diagnosi<br>and a short<br>answer quiz<br>Short answer|
|Delay Between the<br>Last Retrieval Opportu<br>and the Final Test|1 day|Immediate|End of the semester|End of the semester|2 weeks|6 months|2 weeks<br>6 months<br>6 months<br>6 months<br>6 weeks|
|d<br>Retrieval Practice Timing|Twice within 8 days|Once within a single session|Six times throughout the semester (timing not<br>specified)|Six times throughout the semester (timing not<br>secified)|p<br>Once within a single session|Once within a single session|Once within a single session<br>Three times within a single session<br>Four times within 2 days<br>Four times within a single session|
|d)<br>Conducted<br>in the<br>U n i t e <br>States|Yes|Yes|Yes|Yes|No<br>(Den-<br>|mark)<br>No<br>(Den-<br>|mark)<br>No<br>(Den-<br>mark)<br>Yes<br>  Yes<br>  Yes<br>Yes|
|Table 5 (continue<br>Abbreviated<br>Citation|Jones et al.2016,<br>Experiment 2<br>Jones et al.2016,<br>Experiment 3|<br>Karpicke et al.<br>2014,|Experiment 3<br>Khanna and<br>Cortese2016|<br>Khanna2015|Kromann et al.<br>2009|Kromann et al.<br>2010|Kromann et al.<br>2011<br>Larsen et al.2009<br>Larsen et al.2013a<br>Larsen et al.2013b<br>Leeming2002|



Educational Psychology Review 

|t<br>)<br>l<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades<br>Yes<br>Yes|Yes|Yes|Yes<br>Yes|Yes<br>Yes|
|---|---|---|---|---|
|Final Test Forma<br>A s t e r i s k<br>( *<br>indicates<br>rephrased fina<br>test questions<br>Short answer,<br>multiple--<br>choice,<br>and<br>fill-in-the--<br>blank<br>Multiple-choice*<br> Multiple-choice|Multiple-choice|Multiple-choice|Multiple-choice*<br> Multiple-choice*|Multiple-choice<br>and short<br>answer|
|Feedback<br>After<br>Retrieval<br>Practice<br>Delayed<br>Immediate|Immediate|Immediate|Immediate <br>Immediate|d<br>Immediate <br>Immediate|
|Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test<br>Retrieval Practice<br>Format<br>mmer semester)<br>eeks (regular<br>Four exams throughout the<br>semester (timing not<br>specified)<br>Fill-in-the-blank<br>1 day<br>Multiple-choice|1 day<br>Multiple-choice|1 day<br>Multiple-choice|1 day<br>Multiple-choice<br>1 day<br>Multiple-choice|1 day<br>Multiple-choice an<br>short answer<br>1 day|
|ted<br> e d<br>Retrieval Practice Timing<br>5 times per week for 5 weeks (su<br>or 2 times per week for 12 w<br>semester)<br>Once per week for 21 weeks<br>Three times within 20 days|1-3 times within 3-8 days|1-3 times within 1-4 days|Three times within 11 days<br>Three times within 16 days|Three times within 22 days<br>Three times within 7 days|
|d)<br>Conduc<br>in the<br>U n i t<br>States<br>Yes<br>Yes|Yes|Yes|Yes<br>Yes|Yes<br>Yes|
|Table 5 (continue<br>Abbreviated<br>Citation<br>Lyle and Crawford<br>2011<br>McDaniel et al.<br>2011,|Experiment 1<br>McDaniel et al.<br>2011,|Experiment 2a<br>McDaniel et al.<br>2011|,<br>Experiment 2b<br>McDaniel et al.<br>2013,<br>Experiment 1<br>McDaniel et al.<br>2013|,<br>Experiment 2<br>McDermott et al.<br>2014,<br>Experiment 1a|



Educational Psychology Review 

|t<br>)<br>l<br>Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades<br>Yes|Yes<br>Yes<br>No<br>Yes<br>Yes<br>Yes|Yes|Yes|
|---|---|---|---|
|Final Test Forma<br>A s t e r i s k<br>( *<br>indicates<br>rephrased fina<br>test questions<br>Multiple-choice<br>and short<br>answer<br>Short answer|Multiple-choice<br>and short<br>answer*<br>Multiple-choice<br>and short<br>answer*<br>Multiple-choice<br>Multiple-choice<br>and essay*<br>Free recall<br>Multiple-choice|Multiple-choice<br>and short|answer*<br>Multiple-choice*|
|Feedback<br>After<br>Retrieval<br>Practice<br>d<br>Immediate|d<br>Immediate<br>d<br>Immediate<br>d<br>g<br>Immediate<br>d<br>Delayed<br>Immediate<br>Immediate|Immediate|Immediate|
|Retrieval Practice<br>Format<br>Multiple-choice an<br>short answer<br>Short answer|Multiple-choice an<br>short answer<br>Multiple-choice an<br>short answer<br>Multiple-choice an<br>diagram labelin<br>Fill-in-the-blank an<br>matching<br>Multiple-choice<br>Multiple-choice|Multiple-choice|Multiple-choice|
|Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test<br>1 day|2-3 days<br>1-2 days<br>Three exams throughout<br>the semester (timing not<br>specified)<br>Exams at the end of each<br>chapter (timing not<br>specified)<br>2 days<br>2 days|2 days||
|d<br>e d<br>Retrieval Practice Timing<br>Three times within 7 days|Twice within 7 days<br>Twice within 8 days<br>Once per week for 16 weeks<br>Multiple times throughout the semester (timing<br>not specified)<br>Three times within 13 days<br>Three times within 11 days|Nine times throughout the semester (timing not<br>specified)|Three timesper week for 15 weeks|
|d)<br>Conducte<br>in the<br>U n i t <br>States<br>Yes|Yes<br>Yes<br>Yes<br>  Yes<br>Yes<br>Yes|Yes|Yes|
|Table 5 (continue<br>Abbreviated<br>Citation<br>McDermott et al.<br>2014,<br>Experiment 1b<br>McDermott et al.<br>2014,|Experiment 2<br>McDermott et al.<br>2014,<br>Experiment 3<br>McDermott et al.<br>2014,<br>Experiment 4<br>Michaels2017<br>Narloch et al.2006<br>Roediger et al.<br>2011,<br>Experiment 1<br>Roediger et al.<br>2011|,<br>Experiment 2<br>Saville et al.2012||



Educational Psychology Review 

|Final Test<br>Peformance<br>C o u n t e d<br>Toward<br>Students'<br>Grades|Yes|Not<br>reported<br>Yes|
|---|---|---|
|Final Test Format<br>A s t e r i s k<br>( * )<br>indicates<br>rephrased final<br>test questions|Multiple-choice*|Short answer<br>Multiple-choice|
|Feedback<br>After<br>Retrieval<br>Practice|Immediate|Immediate<br>Immediate|
|Retrieval Practice<br>Format|Multiple-choice|Short answer<br>Multiple-choice|
|Delay Between the<br>Last Retrieval Opportunity<br>and the Final Test|Four exams throughout the<br>semester (timing not<br>specified)<br>1 week|Three exams over 4 weeks<br>End of the semester|
|Retrieval Practice Timing|1-3 times per week for 10 weeks|Twice per day for 2 days<br> Every class meeting throughout the semester<br>(timing not specified)|
|Conducted<br>in the<br>U n i t e d<br>States|Yes|No<br>(Sweden)<br>No (Taiwan)|
|iated<br>|and<br>on2012<br>d Rivas<br>|d et al.<br><br>l.2017|
|Abbrev<br>Citation|Shapiro<br>Gord<br>Son an<br>|201<br>Stenlun<br>2017<br>Tu et a|



Educational Psychology Review 

Acknowledgements We would like to thank Henry L. Roediger, III and Doug Rohrer for valuable discussions, as well four anonymous reviewers for their feedback. We also thank Tarah Collins, Jessica Bailey, Erin Eberly, Makayla Miller, Emily Glassman, and Lauren Stephen for their assistance. This project is registered on the Open Science Framework (OSF) and publicly available at http://osf.io/mz2ks. 

Author Contribution Pooja Agarwal developed the idea for this literature review. Pooja Agarwal and Ludmila Nunes developed the methodology and coding procedure. Ludmila Nunes developed the search syntax and executed the search of databases. All authors screened abstracts, Ludmila Nunes downloaded all articles that passed detailed screening, and all authors coded the articles. Ludmila Nunes calculated effect sizes and created the forest plots. Pooja Agarwal drafted the manuscript, which was edited by Ludmila Nunes and Janell Blunt. All authors have approved the submitted manuscript. 

Data Availability All data are available at http://osf.io/mz2ks 

Code Availability Syntax used for the literature search is listed in Table 1 in the manuscript. 

Declarations Because our manuscript is a literature review, human subjects approval was not required. This research is not under consideration at other journals. 

Conflict of Interest The authors declare no competing interests. 

# References 

*References with an Asterisk Indicate Studies Included in the Review 

Abel, M., & Bäuml, K. T. (2020). Would you like to learn more? Retrieval practice plus feedback can increase motivation to keep on studying. Cognition, 201, 104316. https://doi.org/10.1016/j.cognition.2020.104316. 

Adams, J. W., & Hitch, G. J. (1997). Working memory and children’s mental addition. Journal of Experimental Child Psychology, 67(1), 21–38. 

Adesope, O. O., Trevisan, D. A., & Sundararajan, N. (2017). Rethinking the use of tests: a meta-analysis of practice testing. Review of Educational Research, 87(3), 659–701. 

*Agarwal, P. K. (2019). Retrieval practice and Bloom’s taxonomy: do students need fact knowledge before higher order learning? Journal of Educational Psychology, 111, 2 189–209. 

Agarwal, P. K., & Bain, P. M. (2019). Powerful teaching: unleash the science of learning. San Francisco: JosseyBass. 

- Agarwal, P. K., Bain, P. M., & Chamberlain, R. W. (2012). The value of applied research: retrieval practice improves classroom learning and recommendations from a teacher, a principal, and a scientist. Educational Psychology Review, 24(3), 437–448. 

- Agarwal, P. K., D’Antonio, L., Roediger, H. L., McDermott, K. B., & McDaniel, M. A. (2014). Classroom-based programs of retrieval practice reduce middle school and high school students’ test anxiety. Journal of Applied Research in Memory and Cognition, 3(3), 131–139. 

Agarwal, P. K., Finley, J. R., Rose, N. S., & Roediger, H. L. (2017). Benefits from retrieval practice are greater for students with lower working memory capacity. Memory, 25(6), 764–771. 

Allen, I. E., Seaman, J., Poulin, R., & Straut, T. T. (2016). Online report card: tracking online education in the United States. Babson Survey Research Group. https://files.eric.ed.gov/fulltext/ED572777.pdf 

Anderson, C. A., Lindsay, J. J., & Bushman, B. J. (1999). Research in the psychological laboratory: truth or triviality? Current Directions in Psychological Science, 8(1), 3–9. 

*Atabek Yigit, E., Balkan Kiyici, F., & Çetinkaya, G. (2014). Evaluating the testing effect in the classroom: an effective way to retrieve learned information. Eurasian Journal of Educational Research, 54, 99–116. 

- Augusteijn, H. E., van Aert, R., & van Assen, M. A. (2019). The effect of publication bias on the Q test and assessment of heterogeneity. Psychological Methods, 24(1), 116–134. 

- *Ayyub, A., & Mahboob, U. (2017). Effectiveness of test-enhanced learning (TEL) in lectures for undergraduate medical students. Pakistan Journal of Medical Sciences, 33, 1339. 

Educational Psychology Review 

Bangert-Drowns, R. L., Kulik, J. A., & Kulik, C.-L. C. (1991). Effects of frequent classroom testing. Journal of Educational Research, 85, 89–99. *Batsell, W. R., Perry, J. L., Hanley, E., & Hostetter, A. B. (2017). Ecological validity of the testing effect: the use of daily quizzes in introductory psychology. Teaching of Psychology, 44, 18–23. Bauer, P. J. (2020). Expanding the reach of psychological science [Editorial]. Psychological Science, 31, 3–5. Becker-Blease, K. A., & Bostwick, K. C. P. (2016). Adaptive quizzing in introductory psychology: evidence of limited effectiveness. Scholarship of Teaching and Learning in Psychology, 2(1), 75–86. 

*Bekkink, M. O., Donders, R., van Muijen, G. N., & Ruiter, D. J. (2012). Challenging medical students with an interim assessment: a positive effect on formal examination score in a randomized controlled study. Advances in Health Sciences Education, 17, 27–37. 

*Bjork, E. L., Little, J. L., & Storm, B. C. (2014). Multiple-choice testing as a desirable difficulty in the classroom. Journal of Applied Research in Memory and Cognition, 3, 165–170. 

Bojnova, E. D., & Oigara, J. N. (2011). Teaching and learning with clickers: are clickers good for students. Interdisciplinary Journal of E-Learning and Learning Objects, 7, 169–184. 

Brame, C. J., & Biel, R. (2015). Test-enhanced learning: the potential for testing to promote greater learning in undergraduate science courses. CBE Life Sciences Education, 14, 1–12. 

Brown, P. C., Roediger, H. L., & McDaniel, M. A. (2014). Make it stick: the science of successful learning. Cambridge: Harvard University Press. 

Burdo, J., & O’Dwyer, L. (2015). The effectiveness of concept mapping and retrieval practice as learning strategies in an undergraduate physiology course. Advances in Physiology Education, 39, 335–340. Butler, A. C. (2010). Repeated testing produces superior transfer of learning relative to repeated studying. Journal of Experimental Psychology: Learning, Memory, and Cognition, 36, 1118–1133. Butler, A. C., & Carpenter, S. K. (2015). Separating myth from reality in education: introduction to the special issue. Educational Psychology Review, 27, 563–565. 

Butler, A. C., Marsh, E. J., Slavinsky, J. P., & Baraniuk, R. G. (2014). Integrating cognitive science and technology improves learning in a STEM classroom. Educational Psychology Review, 26(2), 331–340. Carpenter, S. K., & Agarwal, P. K. (2020). How to use spaced retrieval practice to boost learning. http://www. retrievalpractice.org Carpenter, S. K., Pashler, H., & Cepeda, N. J. (2009). Using tests to enhance 8<sup>th</sup> grade students’ retention of U.S. history facts. Applied Cognitive Psychology, 23(6), 760–771. 

Carpenter, S. K., Lund, T. J. S., Coffman, C. R., Armstrong, P. I., Lamm, M. H., & Reason, R. D. (2016). A classroom study on the relationship between student achievement and retrieval-enhanced learning. Educational Psychology Review, 28(2), 353–375. 

Carter, E. C., Schönbrodt, F. D., Gervais, W. M., & Hilgard, J. (2019). Correcting for bias in psychology: a comparison of meta-analytic methods. Advances in Methods and Practices in Psychological Science, 2(2), 115–144. 

Cohen, J. (1988). Statistical power analysis for the behavioral sciences (2nd ed.). Hillsdale: Lawrence Earlbaum Associates. 

Conway, M. A., Wang, Q., Hanyu, K., & Haque, S. (2005). A cross-cultural investigation of autobiographical memory: on the universality and cultural variation of the reminiscence bump. Journal of Cross-Cultural Psychology, 36, 739–749. Coyne, J. H., Borg, J. M., DeLuca, J., Glass, L., & Sumowski, J. F. (2015). Retrieval practice as an effective memory strategy in children and adolescents with traumatic brain injury. Archives of Physical Medicine and Rehabilitation, 96, 742–745. 

Cranney, J., Ahn, M., McKinnon, R., Morris, S., & Watts, K. (2009). The testing effect, collaborative learning, and retrieval-induced facilitation in a classroom setting. European Journal of Cognitive Psychology, 21, 919–940. 

Daniel, D. B., & Broida, J. (2004). Using web-based quizzing to improve exam performance: lessons learned. Teaching of Psychology, 31, 207–208. de Carvalho Filho, M. K. (2010). Assessing changes in performance and monitoring processes in individual and collaborative tests according to students’ metacognitive skills. European Journal of Cognitive Psychology, 22, 1107–1136. 

de Lima, N. K., & Jaeger, A. (2020). The effects of prequestions versus postquestions on memory retention in children. Journal of Applied Research in Memory and Cognition, 9, 555–563. DeLozier, S. J., & Rhodes, M. G. (2017). Flipped classrooms: a review of key ideas and recommendations for practice. Educational Psychology Review, 29, 141–151. Diaper, G. (1990). The Hawthorne effect: a fresh examination. Educational Studies, 16, 261–267. *Dirkx, K. J., Kester, L., & Kirschner, P. A. (2014). The testing effect for learning principles and procedures from texts. The Journal of Educational Research, 107, 357–364. 

Educational Psychology Review 

*Dobson, J. L., & Linderholm, T. (2015a). The effect of selected “desirable difficulties” on the ability to recall anatomy information. Anatomical Sciences Education, 8, 395–403. *Dobson, J. L., & Linderholm, T. (2015b). Self-testing promotes superior retention of anatomy and physiology information. Advances in Health Sciences Education, 20, 149–161. *Dobson, J. L., Perez, J., & Linderholm, T. (2017). Distributed retrieval practice promotes superior recall of anatomy information. Anatomical Sciences Education, 10, 339–347. Duchastel, P. C. (1979). Retention of prose materials: the effect of testing. The Journal of Education Research, 72, 299–300. Dunlosky, J., & Rawson, K. A. (Eds.) (2019). The Cambridge handbook of cognition and education. Cambridge University Press. Dunlosky, J., Rawson, K. A., Marsh, E. J., Nathan, M. J., & Willingham, D. T. (2013). Improving students’ learning with effective learning techniques: promising directions from cognitive and educational psychology. Psychological Science in the Public Interest, 14, 4–58. Eisenkraemer, R. E., Jaeger, A., & Stein, L. M. (2013). A systematic review of the testing effect in learning. Paidéia, 23, 397–406. Ekuni, R., de Souza, B. M. N., Agarwal, P. K., & Pompeia, S. (2020). A conceptual replication of survey research on study strategies in a diverse, non-WEIRD student population. Scholarship of Teaching and Learning in Psychology. https://. https://doi.org/10.1037/stl0000191. Fazio, L. K., & Marsh, E. J. (2019). Retrieval-based learning in children. Current Directions in Psychological Science, 28, 111–116. Ferguson, C. J., & Heene, M. (2012). A vast graveyard of undead theories: publication bias and psychological science’s aversion to the null. Perspectives on Psychological Science, 7, 555–561. *Foss, D. J., & Pirozzolo, J. W. (2017). Four semesters investigating frequency of testing, the testing effect, and transfer of training. Journal of Educational Psychology, 109, 1067. Francis, A. P., Wieth, M. B., Zabel, K. L., & Carr, T. H. (2020). A classroom study on the role of prior knowledge and retrieval tool in the testing effect. Psychology Learning & Teaching. Advance online publication. https://doi.org/10.1177/1475725720924872. *Freda, N. M., & Lipp, M. J. (2016). Test-enhanced learning in competence-based predoctoral orthodontics: a four-year study. Journal of Dental Education, 80, 348–354. Gates, A. I. (1917). Recitation as a factor in memorizing. Archives of Psychology, 6(40). Glover, J. A. (1989). The “testing” phenomenon: not gone but nearly forgotten. Journal of Educational Psychology, 81, 392–399. *Goossens, N. A., Camp, G., Verkoeijen, P. P., Tabbers, H. K., Bouwmeester, S., & Zwaan, R. A. (2016). Distributed practice and retrieval practice in primary school vocabulary learning: a multi-classroom study. Applied Cognitive Psychology, 30, 700–712. *Graham, R. B. (1999). Unannounced quizzes raise test scores selectively for mid-range students. Teaching of Psychology, 26, 271–273. Green, M. L., Moeller, J. J., & Spak, J. M. (2018). Test-enhanced learning in health professions education: a systematic review. Medical Teacher, 40, 337–350. Gurung, R. A. R., & Burns, K. (2019). Putting evidence‐based claims to the test: A multi‐site classroom study of retrieval practice and spaced practice. Applied Cognitive Psychology, 33, 732–743. Hartwig, M. K., & Dunlosky, J. (2012). Study strategies of college students: are self-testing and scheduling related to achievement? Psychonomic Bulletin & Review, 19, 126–134. Henrich, J., Heine, S. J., & Norenzayan, A. (2010). The weirdest people in the world? Behavioral and Brain Sciences, 33, 1–75. Jaeger, A., Eisenkraemer, R. E., & Stein, L. M. (2015). Test-enhanced learning in third-grade children. Educational Psychology, 35, 513–521. *Jones, A. C., Wardlow, L., Pan, S. C., Zepeda, C., Heyman, G. D., Dunlosky, J., & Rickard, T. C. (2016). Beyond the rainbow: retrieval practice leads to better spelling than does rainbow writing. Educational Psychology Review, 28, 385–400. Kang, S. H. K., & Pashler, H. (2014). Is the benefit of retrieval practice modulated by motivation? Journal of Applied Research in Memory and Cognition, 3(3), 183–188. Karpicke, J. D. (2012). Retrieval-based learning: active retrieval promotes meaningful learning. Current Directions in Psychological Science, 21(3), 157–163. Karpicke, J. D., & Grimaldi, P. J. (2012). Retrieval-based learning: a perspective for enhancing meaningful learning. Educational Psychology Review, 24(3), 401–418. Karpicke, J. D., Butler, A. C., & Roediger, H. L. (2009). Metacognitive strategies in student learning: do students practice retrieval when they study on their own? Memory, 17, 471–479. 

Educational Psychology Review 

*Karpicke, J. D., Blunt, J. R., Smith, M. A., & Karpicke, S. S. (2014). Retrieval-based learning: the need for guided retrieval in elementary school children. Journal of Applied Research in Memory and Cognition, 3, 198–206. Karpicke, J. D., Blunt, J. R., & Smith, M. A. (2016). Retrieval-based learning: positive effects of retrieval practice in elementary school children. Frontiers in Psychology, 7, 1–9. Kelley, K. (2007a). Methods for the behavioral, educational, and social sciences: an R package. Behavior Research Methods, 39(4), 979–984. Kelley, K. (2007b). Confidence intervals for standardized effect sizes: theory, application, and implementation. Journal of Statistical Software, 20, 1–24. Kelley, K. (2017). MBESS (version 4.0.0 and higher) [computer software and manual]. http://cran.r-project.org *Khanna, M. M. (2015). Ungraded pop quizzes: test-enhanced learning without all the anxiety. Teaching of Psychology, 42, 174–178. *Khanna, M. M., & Cortese, M. J. (2016). The benefits of quizzing in content-focused versus skills-focused courses. Scholarship of Teaching and Learning in Psychology, 2, 87, 1. 

Kibble, J. (2007). Use of unsupervised online quizzes as formative assessment in a medical physiology course: effects of incentives on student participation and performance. Advances in Physiology Education, 31, 253– 260. 

Kornell, N., Rabelo, V. C., & Klein, P. C. (2012). Tests enhance learning—compared to what? Journal of Applied Research in Memory and Cognition, 1, 257–259. *Kromann, C. B., Jensen, M. L., & Ringsted, C. (2009). The effect of testing on skills learning. Medical Education, 43, 21–27. *Kromann, C. B., Bohnstedt, C., Jensen, M. L., & Ringsted, C. (2010). The testing effect on skills learning might last 6 months. Advances in Health Sciences Education, 15, 395–401. *Kromann, C. B., Jensen, M. L., & Ringsted, C. (2011). Test-enhanced learning may be a gender-related phenomenon explained by changes in cortisol level. Medical Education, 45, 192–199. 

Kulik, J. A., & Kulik, C. C. (1988). Timing of feedback and verbal learning. Review of Educational Research, 58, 79–97. Lakens, D., Hilgard, J., & Staaks, J. (2016). On the reproducibility of meta-analyses: six practical recommendations. BMC Psychology, 4(1), 24. 

Lan, X., Legare, C. H., Ponitz, C. C., Li, S., & Morrison, F. J. (2011). Investigating the links between the subcomponents of executive function and academic achievement: a cross-cultural analysis of Chinese and American preschoolers. Journal of Experimental Child Psychology, 108(3), 677–692. *Larsen, D. P., Butler, A. C., & Roediger, H. L. (2009). Repeated testing improves long-term retention relative to repeated study: a randomised controlled trial. Medical Education, 43, 12 1174–1181. *Larsen, D. P., Butler, A. C., & Roediger, H. L. (2013a). Comparative effects of test-enhanced learning and selfexplanation on long-term retention. Medical Education, 47, 7 674–682. *Larsen, D. P., Butler, A. C., Lawson, A. L., & Roediger, H. L. (2013b). The importance of seeing the patient: test-enhanced learning with standardized patients and written tests improves clinical application of knowledge. Advances in Health Sciences Education, 18, 3, 409–425. 

*Leeming, F. C. (2002). The exam-a-day procedure improves performance in psychology classes. Teaching of Psychology, 29, 3, 210–212. Lipko-Speed, A., Dunlosky, J., & Rawson, K. A. (2014). Does testing with feedback help grade-school children learn key concepts in science? Journal of Applied Research in Memory and Cognition, 3(3), 171–176. *Lyle, K. B., & Crawford, N. A. (2011). Retrieving essential material at the end of lectures improves performance on statistics exams. Teaching of Psychology, 38, 2 94–97. Markus, H. R., & Kitayama, S. (1991). Culture and the self: implications for cognition, emotion, and motivation. Psychological Review, 98(2), 224–253. 

*McDaniel, M. A., Agarwal, P. K., Huelser, B. J., McDermott, K. B., & Roediger, H. L. (2011). Test-enhanced learning in a middle school science classroom: the effects of quiz frequency and placement. Journal of Educational Psychology, 103, 2, 399-414. 

*McDaniel, M. A., Thomas, R. C., Agarwal, P. K., McDermott, K. B., & Roediger, H. L. (2013). Quizzing in middle-school science: successful transfer performance on classroom exams. Applied Cognitive Psychology, 27, 3 360–372. 

*McDermott, K. B., Agarwal, P. K., D’Antonio, L., Roediger, H. L., & McDaniel, M. A. (2014). Both multiplechoice and short-answer quizzes enhance later exam performance in middle and high school classes. Journal of Experimental Psychology: Applied, 20, 3–21. 

McLaughlin, K., & Coderre, S. (2015). The potential and conditional benefits of retrieval practice on learning. Advances in Health Sciences Education, 20(2), 321–324. 

- McShane, B. B., & Böckenholdt, U. (2020). Enriching meta-analytic models of summary data: a thought experiment and case study. Advances in Methods and Practices in Psychological Science, 3(1), 81–93. 

Educational Psychology Review 

Metcalfe, J., Kornell, N., & Finn, B. (2009). Delayed versus immediate feedback in children’s and adults’ vocabulary learning. Memory & Cognition, 37(8), 1077–1087. *Michaels, J. L. (2017). Quizzes benefit freshman and sophomore students more than junior and senior students in introductory psychology classes with noncumulative exams. Scholarship of Teaching and Learning in Psychology, 3, 4, 272–283. Minear, M., Coane, J. H., Boland, S. C., Cooney, L. H., & Albat, M. (2018). The benefits of retrieval practice depend on item difficulty and intelligence. Journal of Experimental Psychology: Learning, Memory, and Cognition, 44, 1474–1486. Moreira, B. F. T., Pinto, T. S. S., Starling, D. S. V., & Jaeger, A. (2019). Retrieval practice in classroom settings: a review of applied research. Frontiers in Psychology, 4, 1–16. Morris, C. D., Bransford, J. D., & Franks, J. J. (1977). Levels of processing versus transfer-appropriate processing. Journal of Verbal Learning and Verbal Behavior, 16(5), 519–533. Mullet, H. G., Butler, A. C., Verdin, B., von Borries, R., & Marsh, E. J. (2014). Delaying feedback promotes transfer of knowledge despite student preferences to receive feedback immediately. Journal of Applied Research in Memory and Cognition, 3(3), 222–229. Myers, G. C. (1914). Recall in relation to retention. Journal of Educational Psychology, 5(3), 119–130. *Narloch, R., Garbin, C. P., & Turnage, K. D. (2006). Benefits of prelecture quizzes. Teaching of Psychology, 33, 2 109–112. Nguyen, K., & McDaniel, M. A. (2015). Using quizzing to assist student learning in the classroom: the good, the bad, and the ugly. Teaching of Psychology, 42(1), 87–92. Niedermeyer, F. C., & Sullivan, H. J. (1972). Differential effects of individual and group testing strategies in an objectives-based instructional program. Journal of Educational Measurement, 9(3), 199–204. Nunes, L. D., & Karpicke, J. D. (2015). Retrieval-based learning: research at the interface between cognitive science and education. In R. A. Scott & S. M. Kosslyn (Eds.), Emerging trends in the social and behavioral sciences (pp. 1–16). Inc: John Wiley & Sons. O’Donnell, C. L. (2008). Defining, conceptualizing, and measuring fidelity of implementation and its relationship to outcomes in K–12 curriculum intervention research. Review of Educational Research, 78(1), 33–84. OECD (2020). Education at a glance: educational attainment and labour-force status. https://data.oecd.org/eduatt/ population-with-tertiary-education.htm Open Science Framework. (2020). Center for Open Science. http://cos.io/osf Pachai, A. A., Acai, A., LoGiudice, A. B., & Kim, J. A. (2016). The mind that wanders: challenges and potential – benefits of mind wandering in education. Scholarship of Teaching and Learning in Psychology, 2(2), 134 146. Pan. S. C., & Agarwal, P. K. (2020). Retrieval practice and transfer of learning: fostering students’ application of knowledge. http://www.retrievalpractice.org Pan, S. C., & Rickard, T. C. (2018). Transfer of test-enhanced learning: meta-analytic review and synthesis. Psychonomic Bulletin, 144(7), 710–756. Paradis, E., & Sutkin, G. (2017). Beyond a good story: from Hawthorne effect to reactivity in health professions education research. Medical Education, 51(1), 31–39. Pyc, M. A., Agarwal, P. K., & Roediger, H. L. (2014). Test-enhanced learning. Chapter in Benassi, V. A. ,Overson, C. E. & Hakala, C. M. (Eds.), Applying science of learning in education: Infusing psychological science into the curriculum. APA Society for the Teaching of Psychology. Racsmány, M., Szőllősi, A., & Bencze, D. (2018). Retrieval practice makes procedure from remembering: an automatization account of the testing effect. Journal of Experimental Psychology: Learning, Memory, and Cognition, 44, 157–166. Rad, M. S., Martingano, A. J., & Ginges, J. (2018). Toward a psychology of Homo sapiens: making psychological science more representative of the human population. Proceedings of the National Academy of Sciences, 115, 11401–11405. Rawson, K. A., Dunlosky, J., & Sciartelli, S. M. (2013). The power of successive relearning: improving performance on course exams and long-term retention. Educational Psychology Review, 25(4), 523–548. Roediger, H. L., & Butler, A. C. (2011). The critical role of retrieval practice in long-term retention. Trends in Cognitive Sciences, 15(1), 20–27. Roediger, H. L., & Karpicke, J. D. (2006a). The power of testing memory: basic research and implications for educational practice. Perspectives on Psychological Science, 1(3), 181–210. Roediger, H. L., & Karpicke, J. D. (2006b). Test-enhanced learning: taking memory tests improves long-term retention. Psychological Science, 17(3), 249–255. *Roediger, H. L., Agarwal, P. K., McDaniel, M. A., & McDermott, K. B. (2011). Test-enhanced learning in the classroom: long-term improvements from quizzing. Journal of Experimental Psychology: Applied, 17, 4 382–395. 

Educational Psychology Review 

Rohrer, D., Dedrick, R. F., Hartwig, M. K., & Cheung, C.-N. (2020). A randomized controlled trial of interleaved mathematics practice. Journal of Educational Psychology, 112(1), 40–52. 

Rowland, C. A. (2014). The effect of testing versus restudy on retention: a meta-analytic review of the testing effect. Psychological Bulletin, 140(6), 1432–1463. *Saville, B. K., Pope, D., Lovaas, P., & Williams, J. (2012). Interteaching and the testing effect: a systematic replication. Teaching of Psychology, 39, 4, 280–283. Schwieren, J., Barenberg, J., & Dutke, S. (2017). The testing effect in the psychology classroom: a meta-analytic perspective. Psychology Learning and Teaching, 16(2), 179–196. 

Segall, M. H., Campbell, D. T., & Herskovits, M. J. (1966). The influence of culture on visual perception. Indianapolis: Bobbs-Merrill. Sennhenn-Kirchner, S., Goerlich, Y., Kirchner, B., Notbohm, M., Schiekirka, S., Simmenroth, A., & Raupach, T. (2016). The effect of repeated testing vs repeated practice on skills learning in undergraduate dental education. European Journal of Dental Education, 22, e42–e47. *Shapiro, A. M., & Gordon, L. T. (2012). A controlled study of clicker-assisted memory enhancement in college classrooms. Applied Cognitive Psychology, 26, 4, 635–643. 

Simmons, J. P., Nelson, L. D., & Simonsohn, U. (2011). False-positive psychology: undisclosed flexibility in – data collection and analysis allows presenting anything as significant. Psychological Science, 22(11), 1359 1366. 

*Son, J. Y., & Rivas, M. J. (2016). Designing clicker questions to stimulate transfer. Scholarship of Teaching and Learning in Psychology, 2, 3, 193–207. Sotola, L. K., & Crede, M. (2020). Regarding class quizzes: a meta-analytic synthesis of studies on the relationship between frequent low-stakes testing and class performance. Educational Psychology Review. https://doi.org/10.1007/s10648-020-09563-9. 

Spitzer, H. F. (1939). Studies in retention. Journal of Educational Psychology, 30(9), 641–656. 

*Stenlund, T., Jönsson, F. U., & Jonsson, B. (2017). Group discussions and test-enhanced learning: individual learning outcomes and personality characteristics. Educational Psychology, 37, 2, 145–156. 

Tipton, E., Pustejovsky, J. E., & Ahmadi, H. (2019). Current practices in meta-regression in psychology, education, and medicine. Research Synthesis Methods, 10(2), 180–194. *Tu, Y. C., Lin, Y. J., Lee, J. W., & Fan, L. W. (2017). Effects of didactic instruction and test-enhanced learning in a nursing review course. Journal of Nursing Education, 56, 11, 683–687. 

Tweed, R. G., & Lehman, D. R. (2002). Learning considered within a cultural context: confucian and Socratic approaches. American Psychologist, 57(2), 89–99. van Egmond, M. C., Kühnen, U., & Li, J. (2013). Mind and virtue: the meaning of learning, a matter of culture? Learning, Culture and Social Interaction, 2(3), 208–216. Viveiros, J., Sethares, K., & Shapiro, A. (2017). Repeated recall as an intervention to improve memory performance in heart failure patients. European Journal of Cardiovascular Nursing, 16(8), 724–732. Vojdanoska, M., Cranney, J., & Newell, B. R. (2010). The testing effect: the role of feedback and collaboration in a tertiary classroom setting. Applied Cognitive Psychology, 24(8), 1183–1195. 

Weinstein, Y., Nunes, L. K., & Karpicke, J. D. (2016). On the placement of practice questions during study. Journal of Experimental Psychology: Applied, 22(1), 72–84. 

Weinstein, Y., Madan, C. R., & Sumeracki, M. A. (2018). Teaching the science of learning. Cognitive Research: Principles and Implications, 3, 2. Wiklund-Hörnqvist, C., Jonsson, B., & Nyberg, L. (2014). Strengthening concept learning by repeated testing. Scandinavian Journal of Psychology, 55(1), 10–16. Zotero. (2020). Corporation for Digital Scholarship. http://www.zotero.org 

Publisher’s Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

### Affiliations 

### Pooja K. Agarwal<sup>1</sup> & Ludmila D. Nunes<sup>2</sup> & Janell R. Blunt<sup>3</sup> 

- 1 Berklee College of Music, Boston, MA, USA 

- 2 Association for Psychological Science, West Lafayette, Washington, DC, USA 

- 3 Anderson University, Anderson, IN, USA 

