




MAAP Research Journal Page 1

Tracer Study on the Graduates of the Maritime Academy of Asia
and the Pacific, Class 2015-2019


Caroline D. Balila, Administrative Officer of the Dean of Academics
caroline.dacwag@maap.edu.ph

## Mary Ann D. Melitante, Dean’s Staff
maryann.melitante@maap.edu.ph


Research Priority Area: Academe-Maritime Industry Related Topics



## Abstract

Tracing graduates is a vital part of the quality process of an academic institution. It provides relevant
information  on  the  institution's  implementation  of  academic  quality  policies  by  serving  as  one  of  its
feedback mechanisms. This study primarily aimed to continually monitor the licensing and employment
status of the Maritime Academy of Asia and the Pacific (MAAP) graduates and evaluate the relevance
of  the  learning  packages  offered  to  the  same  alumni.  Using  the  Graduate  Tracer  Survey  (GTS),
graduates from 2015 to 2019 were asked their licensure examination results, employment status, their
current  rank  on  board  if  they  are  active  seafarers,  and  their  perception  on  the  relevance  of  the
curriculum to their current work. Descriptive statistics such as frequency counts and weighted mean
were  used  to  treat  data.  Data  showed  that  most  of  those  who  responded  to  the  survey  are  active
seafarers, while a number have explored other careers. Moreover, most of those active seafarers are
junior  officers.  Meanwhile,  most  of  those  who  responded  to  the  survey  on  the  relevance  of  the
curriculum to their current work perceived the courses they took in the academy as relevant. Findings
resulted  in  the  recommendations  to  improve the  communication  between  the  Alumni  Office  of  the
Academy and the graduates, to continually evaluate the course offerings to address the changing needs
of the maritime profession and other related careers, and to find ways to make the MAAP graduates
more competitive in the global market.

Keywords: competence, continual improvement, curriculum relevance, employment


## 1. Introduction

Background of the Study. The Maritime Academy of Asia and the Pacific (MAAP) as
a maritime higher education institution offers scholarship to those aspiring to work at sea after
graduation. Notably, seafaring has become an attractive profession with the high wage as the
main reason for its attractiveness (Baum- Talmor, 2020), together with free travel around the
world, flexibility and extended vacation (International Labour Organization, 2019).

Even during the pandemic caused by Corona Virus, the demand for Filipino seafarers by
foreign  ship  owners  remained  high  (Torib,  2020).  Even  before  the  pandemic,  there  was  a
projection  of  big  growth  in  the  Philippine  economy  because  of  the  maritime  industry (The
Manila Times, 2018). The employment opportunities resulting from this high demand and its
contribution to the Philippine economy put maritime institutions that produce seafarers in the
## F-020
## Issue 0 Rev. 2
## 30 March 2022
## MARITIME ACADEMY OF ASIA AND THE PACIFIC
## KAMAYA POINT
Associated Marine Officers’ and Seamen’s Union of the Philippines – PTGWO - ITF
## Kamaya Point, Brgy. Alas-asin, Mariveles, Bataan




MAAP Research Journal Page 2

limelight. They need to address the needs of shipping companies while meeting the standards
set by the STCW Convention.

With other higher education institutions offering maritime courses here in the Philippines
and abroad, and with the recent trends and developments in shipping, MAAP must continue to
deliver  updated  and  world-class  education  and  training  to  its  students  to keep  its  graduate
competitive in the shipping industry.

One of the effective practices in checking the quality of education and training delivered
by an institution is the conduct of tracer studies, which focuses on determining the employment
status of the graduates and the relevance of the curriculum offered to them in the global market.
A tracer study provides data on the statuses of the graduates of an educational institution and
gives feedback  on  the  curricular  offerings  of  that  institution.  Academic  institutions  need  to
equip the students to meet the demands of prospective employers through the education and
training,  or  competencies  (Karteka  et  al.,  2019)  that  they  provide  to  and  develop  in  their
students (Albina & Sumagaysay, 2020; Aclan et al., 2018).

Statement of the Problem. Two tracer studies have been conducted on the graduates of
MAAP,  covering  the  first  10  batches  of  alumni  from  the  programs  Bachelor  of  Science  in
Marine Engineering and Bachelor of Science in Marine Transportation. This present study was
conducted  to  continually  trace  the  graduates  of  the  Academy.  Specifically, the  following
questions were  addressed:
-  How  may  the  MARINA  licensure  examination  of  MAAP  2015-2019  alumni  be
described?
- How may the employment status of the Bachelor of Science in Marine Transportation
(BSMT) graduates of MAAP be described in terms of (a) class and (b) nature of work?
- How  may  the  employment status  of  the  Bachelor  of  Science  in  Marine  Engineering
(BSMarE) graduates of MAAP be described in terms of (a) class and (b) nature of work?
- How may the ascension to the ranks of the BSMT graduates be described?
- How may the ascension to the ranks of the BSMarE graduates be described?
- How do the MAAP graduates perceive the relevance of the courses offered to them to
their current work?

Review of Related Literature. The conduct of a tracer study is part of every higher
educational institution’s procedures. Following are some graduate tracer studies conducted
abroad and here in the Philippines.

Hasibuan  et  al.  (2022)  conducted  a  tracer  study  on  the  graduates  of  Medan  State
University  in  Indonesia  to  determine  the  employment  status  of  their  graduates.  Using
questionnaires, the researchers found out that most of their alumni had found work within six
months  after  graduation  and  were  found  to  possess  both  hard  and  soft  skills  needed  in  the
workplace.

Another tracer study conducted in another university in Indonesia was that of Andari et
al.  (2021),  who  looked  into  the  employment  status  and  the  waiting  time  of  Educational
Management graduates in 2019 and 2020. With closed and open-ended questionnaire, the study
found  that  more  than  half  of  the  graduates  were  employed  within  0  to  18  months  after
graduation while the others either were enrolled in graduate studies or did not have a job yet.
Moreover,  the  jobs  of  most  of  these  graduates  were  highly  suitable for  the  program  they
finished.




MAAP Research Journal Page 3

In one maritime school here in the Philippines, Gruspe-Taberdo et al. (2021) focused
on the employment status and the career path of their alumnae, together with their experiences
about  their  being  women  and  their  perception  on  the  relevance  of  the  curriculum  to  their
profession.  The  study  found  that  the  26  alumna-respondents were  all  officers-in-charge
licensed  and  were  employed  either  in  the  Philippine  Coast  Guard  or  in  international  sailing
vessels. The curriculum was also perceived to be relevant to their work. In addition, the school
taught them important values in their work. Finally, the graduates shared that they experienced
gender discrimination in their workplace.

Cornillez  Jr.  et  al.  (2021)  traced  their  teacher  education  graduates  and  found  their
respondents employed in the region within six months after graduation. Further, the graduates
appreciated the relevance of their program curriculum, most specifically the general education
courses and the practicum. Regarding skills, the same respondents highlighted the importance
of communication, interpersonal and confidence skills in the workplace. Salary was also noted
as a determining factor in moving from one job to another.

Another  tracer  study  in  Indonesia  was  conducted  by  Ramaditya  and  Effendi  (2020).
The  researchers  surveyed  the  graduates  of  Indonesian  College  of  Economics  and  found  that
most of them were employed while the others were either studying again, entered into business,
worked  and  studied  simultaneously,  or  had  no  work.  The  same  research  mentioned  the
importance  of  matching  the  study  programs  with  the  demands  of  the  workplace  and  the
maintenance of connection between the graduates and their former lecturers and other alumni
for a better chance of landing a job.

Aiming to get the perception of graduates on the relevance of the Bachelor of Science
in Mathematics program, as well as to ascertain the strengths and weaknesses of the program,
Kalaw (2019) used a survey to gather her data. Results showed that the program was very much
instrumental in their attainment of relevant skills, through the very effective quality of teaching
delivered to them. The same respondents suggested enhancement of the curriculum to meet the
growing and expanding demands of the real world of work.

In  Ethiopia,  Fenta  et  al.  (2019)  analyzed  the  employment  status  of  the  graduates  of
Bahir Dar University and the relevance of the curriculum to the job placement of the graduates.
Using  descriptive  and  inferential  statistics,  the  researchers  found  that  majority  of  the
respondents landed in jobs related to their program one to six months after graduation. Also,
college grade point average, preferred field of study and the number of companies contacted
had  a  significant  relationship  to  the  employment  of  the graduates.  The  study  suggested
collaboration between the university and government agencies to ensure that the required skills
by the labour market are developed and acquired by the graduates.

Cuadra et al. (2019) had graduates from different colleges in a state university as their
respondents. From the sample, most of the respondents reported that they were employed in
the  fields  related  to  their  degrees  as  regulars  and  that  they  landed  their job  through
recommendations  from  people  they  knew.  Also,  the  graduates  identified  communication,
human relations, critical  thinking, problem-solving, and information technology skills as the
topmost developed skills in the university and most relevantly required in the workplace. For
their  recommendations,  the  researchers  suggested  revisiting  and  enhancing  the  curricula,
together  with  qualifying  instructors,  updating  laboratory  equipment,  renovating  classrooms,
and expanding support programs.




MAAP Research Journal Page 4

Another  tracer  study  conducted  in  a  maritime  school  was  undertaken  by  Gonzales
(2019).  The  study  found  that  all  the  young  marine  transportation  and  marine  engineering
graduates  surveyed  were  employed,  and  most  of  them  worked  in  container  vessels  with  an
income  between  P50,000  to  P69,999.  The  participants  identified  human  relations  and
communication  skills  as  the  most  relevant  skills  acquired  from  their  school.  Specific  to
programs,  marine  transportation  graduates  highlighted  the  importance  of  navigation  and
shipboard training, while the marine engineering graduates specified Electro and Automation
as very relevant courses.

The studies mentioned above have focused on different variables, with some similar to
the  variables  of  the  present  study  and  others  different.  As  the  most  common  focus  of  tracer
studies,  all  the  previous  research  mentioned  here  looked  at  the  employment  status  of  the
graduates  and  the  skills  relevant  to  their  workplace.  These  areas  were  also  included  in  the
present study. However, there are also some differences. For instance, Gonzales's (2019) study
included the income bracket of maritime school graduates, but this paper did not delve into that
area. This present study also described the promotion of Filipino seafarers/maritime graduates
to ranks. This area was not covered by the previous researches reviewed.

## 2. Methods

The  data  gathered  in  this  paper  are  primarily  quantitative  in  nature,  with  descriptive
explanations; hence, the study is descriptive-quantitative. The primary means of gathering data
was the graduate tracer survey, in Google form, sent by the Alumni Office of the Academy to
the graduates of MAAP. These graduates were reached via emails, messengers and FB groups.
The class chancellors and the fleet commanders were also specifically requested to get in touch
with their classmates and ask them to answer the survey form.

The graduate tracer survey form was composed mainly of two parts. The first part asked
for  the  profile  of  the  graduates,  their  personal,  educational  and  professional  profiles.  The
second part inquired about the relevance of the knowledge and skills imparted by the Academy
to the current work of the alumni.

The  survey  respondents  were  the  MAAP  alumni  who  graduated  in  2015,  2016,  2017,
2018 and 2019. For marine transportation, there were 134 out of 207 (64.73%) for Class 2015,
133 out of 172 (77.33) for Class 2016, 133 out of 184 (72.28%) for Class 2017, 160 out of 170
(94.12%)  for Class 2018, and 131 out of 146  (89.73%) for Class 2019. Overall, 691 marine
transportation  graduates  responded.  For  marine  engineering,  there  were  124 out  of  199
(62.31%) for Class 2015, 85 out of 164 (51.83%) for Class 2016, 121 out of 191 (63.35%) for
Class 2017, 176 out of 194 (90.72%) for Class 2018, and 169 out of 185 (91.35%) for Class
- Overall, 675 marine engineering graduates answered the survey.   For the question on
curriculum relevance, only 90 alumni responded.  The   data   gathered   from   the   graduate
tracer survey were treated using frequency counts and percentages. These were then tabulated
for presentation and analysis.

## 3. Results

Based  on  the  data  gathered  through  the  survey,  the  following  are  the  tabulated
presentation  and  data  analyses.  Table  1  presents  the  employment  status  of  the  Bachelor  of
Science in Marine Transportation (BSMT) graduates of the Maritime Academy of Asia and the
Pacific (MAAP).




MAAP Research Journal Page 5

License of MAAP 2015-2019 Alumni
The Alumni Office requested from the Maritime Industry Authority (MARINA) for the
official results of the board examinations of the MAAP graduates. Table 1 summarizes the data
gathered.

For Bachelor of Science in Marine Transportation graduates, 78.61% (691/879) of the
graduates were already licensed, with 565 having Officer-in-Charge of the Navigational Watch
(OIC-NW) license and 126 having already acquired their management licenses, either as chief
officers or as masters.

Table 1. MARINA Licensure Examination Result of MAAP 2015-2019 Alumni

For the marine engineering graduates, 72.34% (675/933) were already licensed, with
627  licensed  as  Officer-in-Charge  of  the  Engine  Watchkeeping (OIC-EW)  and  48  as
management level licensed.

Employment Status of BSMT Class 2015-2019 Graduates

Table 2 summarizes the  data on employment of the Marine Transportation graduates
from 2015 to 2019. There were 879 graduates in total but only 691 alumni responded to the
survey.

Table 2. Employment Status of BSMT Class 2015-2019 Graduates
## BSMT TOTAL
## GRADUATES
## ACTIVE
## SEAFARERS
## IN-ACTIVE
## 2015 207 134 73
## 2016 172 133 39
## 2017 184 133 51
## 2018 170 160 10
## 2019 146 131 15
## TOTAL 879 691 188

As can be seen from the table, the class of 2015 had the highest number of graduates
and  the  class  of  2019  the  lowest.  Out  of  879  alumni, 691 or  78.61% of  the  total  number  of
graduates responded  that  they  were still  active  seafarers  while  188 could  not  be  determined
whether they were still in seafaring or had ventured into other lines of work. Looking further
## Class
## BSMT BSMARE
## OVERALL
## TOTAL
# of
## Grad.
## OIC MGMT
# of
## Grad.
## OIC MGMT
## 2015
## 207
## 104
## 30 199 110 14
## 406
## 2016
## 172
## 103
## 30 164 80 5
## 336
## 2017
## 184
## 73
## 60 191 100 21
## 375
## 2018 170 156 4 194 170 6 364
## 2019 146 129 2 185 167 2 331
## TOTAL 879 565 126 933 627 48 1812




MAAP Research Journal Page 6

into details, the class of 2018 recorded the highest sea employment percentage of 94.12, while
the class of 2015 had the lowest (64.73).

Employment Status of BSMarE Class 2015-2019 Graduates

Table  3  summarizes  the  employment  data  for  the  Marine  Engineering  graduates  of
MAAP from 2015 to 2019. Out of 933 graduates, 646 responded to be working at sea while
287 could  not  be  determined  whether  they  were  still  active  seafarers  or  they  explored other
lines of work.

Table 3. Employment Status of BSMarE Class 2015-2019 Graduates
BSMarE TOTAL
## GRADUATES
## ACTIVE
## SEAFARERS
## IN-ACTIVE
## 2015 199 124 75
## 2016 164 85 79
## 2017 191 100 91
## 2018 194 170 24
## 2019 185 167 18
## TOTAL 933 646 287

Considering  the  employment  of  each  class  or  batch,  the  Class  of 2019 recorded  the
highest sea employment percentage (90.27) while the Class of 2016 had the lowest at 51.83. In
total, 69.24% of the graduates responded to be gainfully employed in seafaring while the rest
of the graduates did not respond to the survey.

Ascension to the Ranks of BSMT Graduates

Table  4  shows  the  current  rank  on  board  of  the marine  transportation alumni  of  the
Academy.  As  gleaned  from  the  table,  one  alumnus  had  overall  command  of  the  ship,  while
most of the other alumni were third officers. No one had held the position of chief officer as of
the time of the survey. Notably, while many respondents said they were active seafarers, they
did not specify their ranks on board.

Table 4. Ascension to the Rank of BSMT Graduates
## RANK ON BOARD
## BS MARINE TRANSPORTATION

## 2015 2016 2017 2018 2019 TOTAL
## Master 0 1 0 0 0 1
## Chief Officer 0 0 0 0 0 0
## 2nd Officer 14 1 4 4 0 23
## 3rd Officer 52 41 42 30 22 187
## Junior 3rd Officer 8 17 3 4 1 33
## Deck Ratings 20 22 19 19 12 92
## Not Specified 7 21 23 21 32 104
## TOTAL 101 103 91 78 67 440




MAAP Research Journal Page 7

Ascension to the Ranks of BSMarE Graduates

Table 5 presents the current ranks on board of the Marine Engineering graduates from
2015- 2019. As of the time of the survey, no one was a chief engineer yet. The highest rank
held on board was second engineer or first assistant engineer. Most of the respondents were
engine ratings while a good number of them did not specify their ranks on board.

Table 5. Ascension to the Ranks of the BSMarE Graduates
## RANK ON BOARD
## BS MARINE ENGINEERING

## 2015 2016 2017 2018 2019 TOTAL
## Chief Engineer 0 0 0 0 0 0
## 2nd Engineer 1 0 0 0 0 1
## 3rd Engineer 19 7 15 1 5 47
## 4th Engineer 30 21 16 15 3 85
## Junior 3
rd
## Engineer 20 21 6 11 2 60
## Engine Ratings 41 31 33 22 42 169
## Not Specified 2 14 18 26 54 114
## TOTAL 113 94 88 75 106 476

Relevance of the Curriculum as Perceived by the MAAP Graduates
The  alumni  were  asked  to  rate  the  relevance  of  the  curriculum  offered  by  MAAP  to
their current work. Their responses are shown in Table 6 below.

Table 6. Relevance of the Curriculum to the Current Work of MAAP Graduates
Class Mean SD Descriptive Equivalent
2015 4.6 0.763762616 Very relevant
2016 4.57 0.534522484 Very relevant
## 2017 4.18 0.52859414 Relevant
2018 4.56 0.506369684 Very relevant
## 2019 4.36 0.497245158 Relevant
## Average 4.45 0.566099 Relevant
## Legend
## 4.50-5.00  Very Relevant
## 3.50- 4.49  Relevant
## 2.50- 3.49  Undecided
## 1.50- 2.49  Somewhat Relevant
## 1.00- 1.49  Not Relevant

In general, the MAAP alumni respondents perceived the curriculum offered by MAAP
to be relevant to their current work as indicated by the overall mean of 4.45. Taken by Class,
the members of Class 2015, 2016 and 2018 perceived the curriculum to be very relevant while
Classes 2017 and 2019 deemed the curriculum relevant.


## 4. Discussion
__________________________________________________________________________________________
This paper has presented data based on the responses of the MAAP graduates. Half of
those Marine Transportation graduates and almost half of the Marine Engineering graduates




MAAP Research Journal Page 8

who responded reported being currently employed, with most still active in seafaring. Relevant
to  this,  the  study  of Garcia  et  al. (2017)  on  the  first  10  batches  of  marine  transportation
graduates of the Academy found out that all of their respondents were employed with 49% of
them  active  in  seafaring,  40%  were  on  sea-based  and  maritime  land-based  jobs  while  11%
reported to be in maritime training centers or institutions. For the marine engineering graduates,
Mendoza  et  al. (2017)  reported  that  95%  of  their respondents  were  active  in  seafaring  and
others were working both at sea and on land.

The International Labour Organization (2019) identified factors that affect the decision
of seafarers to stay at sea. Some of these  factors  are the working environment, working and
living  conditions, internet  access,  social  and  medical  care,  age  and  technological  systems  of
the ship, career paths for seafarers by the shipping company, the culture of the organization,
and salary, among others.

In terms of the rank on board at the time of the survey, the findings of this study on which
most of the active seafarers- respondents are working as ratings or junior officers, are similar
to the findings of Garcia et al. (2017) and Mendoza et al. (2017). The findings indicate that it
takes more than five years before the graduates of MAAP are promoted to management-level
positions on board. The Maritime Industry Authority (2022) also noted that not many Filipino
seafarers, despite being certificated as junior or management level officers, take the positions
of being officers on board.

For education and training, quality takes precedence. While the graduates perceived the
curriculum offered by the Academy to be relevant to their field of work, it is important for the
Academy to update the curriculum and upgrade training facilities as necessary. To exemplify,
Maghoromi (2023) mentioned that technology has become indispensable and therefore should
also be contextually adopted by maritime education and training institutions and integrated in
the curriculum, proactively addressing its limitations and encumbrances.

As for the population of the study, it is notable that the respondents did not reach the total
number of graduates. Different factors could have led to this response rate. For one, during the
time of data gathering, many of the graduates were on board and did not have a strong internet
connection to enable them to open the link and answer. In addition, they could be busy and did
not have spare time to answer the survey. Those who have ventured in other works could have
been occupied with their own endeavors to have spare time or just chose not to participate in
the  survey.  On  the  part  of  the  Alumni  Office  of  the  Academy,  better  and  more  effective
communication and connection with the graduates may have to be planned and carried out to
keep the Academy updated with the career path of the said graduates.

-  Conclusions and Recommendations

The study's data showed that most of the graduate respondents were still working at sea,
while a few opted to try other opportunities. Of those who were active seafarers, very few held
management-level  positions  on  board.  Most  were  still  either  junior  officers  or  ratings.  The
alumni rated the curriculum offered by MAAP as relevant to their current work.

The findings of this study resulted in the following recommendations: for future research
to determine factors that affect the decision of MAAP graduates to stay or leave the seafaring
profession; for future researchers to assess areas of the curriculum that need improvement or




MAAP Research Journal Page 9

re-calibration; and for the Alumni Office to think of more effective ways to keep in touch with
the graduates thereby increasing the response rate in the graduate tracer survey.

## 6. Acknowledgements

The researchers would like to thank the  Alumni  Office of the  Academy for providing the
data needed to complete this study. The Dean of Academics and the Management also deserve
recognition for their continued support and encouragement to the faculty and staff to conduct
research.

## 7. References

Aclan, E., Saban, G., Fameronag, J., & Francisco, R. (2018). Tracer study of AUP BEED and BSED
graduates from 2012-2016. Journal of Education, Psychology, and Humanities (JEPH), 1 (1).
http://web1.aup.edu.ph/urc/wp-content/uploads/2018/03/02-JEPH-Tracer-study-of-AUP-BEEd-
and-BSEd-graduates-from-2012-2016.pdf
Albina, A., & Sumagaysay, L. (2020). Employability tracer study of Information technology
Education graduates from a state university in the Philippines. Social Sciences & Humanities
Open, 2 (2020). https://doi.org/10.1016/j.ssaho.2020.100055
Andari, S., Setiawan, A. C., Windasari, & Rifqi, A. (2021). Educational management graduates: A
tracer study from Universitas Negeri Surabaya, Indonesia. International Journal of Recent
Educatioal Research, 2 (6). https://journal.ia-education.com/index.php/ijorer
Baum-Talmor P. (2021) Careers at sea: Exploring seafarer motivations and aspirations. In: Gekara
V.O., Sampson H. (eds.). The World of the Seafarer. WMU Studies in Maritime Affairs, 9.
Springer, Cham. https://doi.org/10.1007/978-3-030-49825-2_5
Cornillez Jr., E., Caminoc, S., Basas, B., Militante Jr., B., & Paler, R. (2021). Tracer study of teacher
education graduates of the Eastern Visayas State University- Tanauan Campus, Philippines.
European Journal of Education and Pedagogy, 2 (3). DOI:
http://dx.doi.org/10.24018/ejedu.2021.2.3.143
Cuadra, L. J., Aure, M. R. K. L., & Gonzaga, G. L. (2019). The use of tracer study in improving
undergraduate programs in the university. Asia Pacific Higher Education Research Journal, 6
(1). https://po.pnuresearchportal.org/ejournal/index.php/apherj/article/view/1315/409
Fenta, H., Asnakew, Z., Debele, P., Nigatu, S., & Muhaba, A. (2019). Analysis of supply side factors
influencing employability of new graduates: A tracer study of Bahir Dar University graduates.
The Journal of Teaching and Learning for Graduate Employability, 10 (2).
https://ojs.deakin.edu.au/index.php/jtlge/
Garcia, R., Vergara, J., & Lansang, J. Jr. (2017). Graduate tracer study of the Bachelor of Science in
Marine Transportation at the Maritime Academy of Asia and the Pacific. MAAP Research
Journal, 1. http://maap.edu.ph/research/1/MAAP-RESEARCH-JOURNAL-MAY-2017-
VOLUME1-PAPERS.pdf
Gonzales, A. A. (2019). Tracer study of maritime graduates of one private academic institution in the
Philippines from 2012-2017. Asia Pacific Journal of Maritime Education, 5. www.apjmr.com
Gruspe-Taberdo, A., Paraggua, V., Alvarez, M., Acuavera, R., & Pasa, G. (2021). Employability of
female graduates in a quasi-military maritime higher education institution: Towards gender
equality in the maritime industry. JPAIR Multidisciplinary Research, 45. DOI:
https://doi.org/10.7719/jpair.v45il/756
Hasibuan, A., Silaban, S., Lubis, F., & Prayogo, R. (2022). Tracer study exploration of Medan State
University graduates. Advances in Economics, Business and Management Research, 204.
https://doi.org/10.2991/aebmr.k.220104.011
International Labour Organization (2019). Recruitment and retention of seafarers and the promotion
of opportunities for women seafarers. https://www.ilo.org/wcmsp5/groups/public/---
ed_dialogue/---sector/documents/meetingdocument/wcms_664163.pdf




MAAP Research Journal Page 10

Kalaw, M. (2019). Tracer study of Bachelor of Science in Mathematics. International Journal of
Evaluation and Research in Education (IJERE), 8 (3). DOI: 10.11591/ijere.v8i3.17343
Kartika, A., Pujosusanto, A., Suwarno, S., & Ridwan, A. (2019). The correlation between tracer study
and curriculum relevance. Advances in Social Science, Education and Humanities Research,
- DOI: 10.2991/soshec-19.2019.54
Maghoromi, B. (2023). Impact of emerging technologies on maritime education and training: A
phenomenological study [Dissertation, World Maritime University].
https://commons.wmu.se/cgi/viewcontent.cgi?article=3256&context=all_dissertations
Maritime Industry Authority (2022). Core program 4: Promotion of highly skilled and competitive
Filipino maritime workforce. https://marina.gov.ph/wp-content/uploads/2022/06/Core-
Program-4-.-Promotion-of-Highly-Skilled-and-Competitive-Filipino-Maritime-Workforce.pdf
Mendoza, J., Dacwag, C., & Poncardas, K. (2017). Tracing Bachelor of Science in Marine
Engineering Graduates of the Maritime Academy of Asia and the Pacific. MAAP Research
Journal, 1. http://maap.edu.ph/research/1/MAAP-RESEARCH-JOURNAL-MAY-2017-
VOLUME1-PAPERS.pdf
Ramaditya, M., & Effendi, S. (2020). Tracer study of alumni profiles and STEI contribution to
competence of graduates at the workplace. Advances in Economics, Business and Management
Research, 132. http://creativecommons.org/licenses/by-nc/4.0/
The Manila Times (2018). Maritime to triple contribution to economy.
https://www.manilatimes.net/2018/12/25/business/maritime-business/maritime-to-triple-
contribution-to-economy/487351
Torib, Y. (2020). Global demand for PH seafarers still high. The Manila Times.
https://www.manilatimes.net/2020/10/12/122nd-anniversary/global-demand-for-ph-seafarers-
still-high/779284

























