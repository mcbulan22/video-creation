

Why use learning outcomes in higher education?
Exploring the grounds for academic resistance
and reclaiming the value of unexpected learning
## Anton Havnes
## 1
&Tine Sophie Prøitz
## 2,3
Received: 3 March 2015 /Accepted: 19 June 2016
## #
Springer Science+Business Media New York 2016
AbstractLearning outcomes are now mandated in higher education courses across
Europe. However, their impact on teaching and student learning is both uncertain and
an issue for debate. In this paper, we explore (1) what is meant by learning outcomes in
diverse contexts and (2) whether policy and practice governing learning outcomes
accord with developments in learning theories, especially regarding sociocultural
approaches that have drawn significant interest since the 1990s (Engeström1987  ;
Lave and Wenger1991). Shepard’s(Educational Researcher, 29(7), 4–14, 2000)
publication is particularly salient to our examination due to her identification of an
emerging paradigm to assist in the understanding of the relationships among teaching,
learning and assessment. Employing recent work on conceptualisations of learning
outcomes and a four-quadrant taxonomy (Prøitz inEducational Assessment, Evaluation
and Accountability, 22(2), 119–137,2010  , 2014  ), we discuss relevant learning theory
approaches. This article is a conceptual investigation exploring the grounds for the
assumption that learning can be predefined in terms of (expected) outcomes. Specifi-
cally, we discuss this assumption from the perspective of recent developments in
learning theories. We argue that introducing learning outcomes predominantly for
policy and management purposes may actually weaken the learning outcomes’poten-
tial to direct teaching and learning and to improve the quality of both.
## Educ Asse Eval Acc
DOI 10.1007/s11092-016-9243-z
*Anton Havnes
anton.havnes@hioa.no
## Tine Sophie Prøitz
Tine.Proitz@hbv.no
## 1
Centre for the Study of Professions, Oslo and Akershus University College of Applied Sciences,
PO Box 4, St. Olavs pl., 0130 Oslo, Norway
## 2
University College of Southeast Norway, PO Box 4, 3199 Borre, Norway
## 3
NIFU Nordic Institute for Studies in Innovation, Research and Education, PO Box 2815 Tøyen,
## 0608 Oslo, Norway

KeywordsLearning outcomes
## .
Learning theory
## .
Qualification frameworks
## .
## Assessment
## .
Curriculum alignment
## 1 Introduction
In many ways, the implementation of the European Qualifications Framework (EQF) is
a marker of new ways of governing education and novel approaches to curriculum
development, teaching, learning and assessment. This endeavour was already under-
way. Initiated primarily by the Declaration Bologna (1999   ), it involved European
higher education institutions in a far-reaching process of rewriting curricula in terms
of learning outcomes (LOs), extending the impact down to the programme and module
levels, with‘[t]he overall aim [...] to improve the efficiency and effectiveness of higher
education in Europe’(Kennedy et al.2007  ,p.2).
A European Commission report on improving the quality of teaching and learning in
Europe’s higher education institutions argues that the Bologna Process has meant:
a complete change of [...the European...] higher education system and [a] higher
education mind-set [...]. Today, there is a far-reaching—at least
rhetorical—consensus that academic teaching should put the student at the centre
by defining clear learning outcomes for the different programmes, courses and
modules, and by attaching particular importance to counselling, monitoring and
interactive modes of teaching (European Commission2013  ,p.32).
Under these terms, the implementation of LOs is at the core of a broad initiative for
international quality improvement. The double intention of changing higher education
systems and the mindset associated with teaching and learning practices addresses
higher education institutions at two levels—(1) governance, management and quality
control and (2) course design, teaching and learning. The implementation of LOs is a
central aspect of a policy initiative, as well as a pedagogical undertaking. As such, LOs
address diverse agentive positions, including policymakers at the national level, quality
assurance agencies, institutional leaders, programme leaders, classroom teachers,
clinical/placement mentors and students. The implementation of LOs is attributed to
multiple purposes and might be ascribed different meanings in the contexts of these
diverse agentive positions. The use of LOs is therefore dubious, with reference to this
article’s title—Who uses learning outcomes (and for what purpose)? A consensus about
LOs risks masking the complexities and potential tensions inherent in the concept
(Purser2003  ).
In this article, we explore the understanding of LOs in the context of teaching and
learning, bringing theoretical perspectives on learning to the foreground. However,
there is no universally shared, research-based understanding or conceptualisation of
learning. We have distinguished among three main sets of approaches to learning:
behaviourist, cognitive and sociocultural/contextual theories. How LOs can be demon-
strated and learned may be stated differently across these approaches. We question if
there is or can be a shared understanding of how to state what students are expected to
learn or have learned. Learning outcomes would have to be articulated in observable,
behavioural terms from a behaviourist perspective, in cognitive and meta-cognitive
## Educ Asse Eval Acc

terms from a cognitive perspective and in participatory terms from a sociocultural
perspective. To come to terms with the status of LOs in education, there is a need to
explore the notion of LOs from diverse perspectives, as well as the various functions
attributed to them in educational systems. We consider it particularly essential to
address existing theories on learning that challenge the seemingly dominant under-
standing of LOs in European higher education policies (e.g. European Commission
2013  ) from the perspective of recent developments in theorising learning, assessment
and the mutual relationship between learning and assessment that have emerged over
the last 20–25 years (e.g. Biggs1996  ; Birenbaum et al.2006  ). For the process of
improving the quality of higher education, it is vital to critically explore the relationship
between theories of learning and concepts of LOs. Our article contributes to the
understanding of the tensions among LOs as tools serving both pedagogical and policy
purposes. From the varying perspectives of research on learning, our paper also
demonstrates how LOs can be understood in diverse, potentially conflicting ways.
We elaborate on some core dilemmas inherent in the idea that what students will
learn can be specified and made explicit prior to the process of learning. After briefly
situating these dilemmas in earlier research on LOs, we raise two research questions
(see the next section). We synthesise and discuss the challenges in conceptualising and
implementing LOs, including the tensions among the disparate intentions that these
LOs are intended to accomplish, the policy to transform higher education and pedagogy
and the course design to improve student learning. Next, we explore the challenges in
stating LOs prior to the learning process from the perspectives of sociocultural and
contextual learning theories and dialogical and self-regulated learning. These view-
points have gained increasing interest over the last 25 years—which we refer to as
recent developments.
2 Dilemmas about explicit learning outcomes
Kennedy et al. (2007  )defineLOsas‘clear statements of what the learner is expected to
achieve and how he or she is expected to demonstrate that achievement’(p. 6). Their
definition is clearly valued as it is also presented in theBologna Handbook(European
University Association2006) and joins a long list of similar definitions used in
documents to support the implementation of LO-oriented approaches. However, this
definition contrasts with the arguments in other types of LO literature in which related
issues are often discussed and problematised for being too limited, technical, rational
and oriented towards purposes of managerialism rather than of teaching and learning
(e.g. Au2011   ; Hargreaves and Moore2000  ;HusseyandSmith2008  ; Prøitz2015  ). The
definition of Kennedy et al. (2007  ) emphasises theoutcomesof learning rather than its
process. Nonetheless and paradoxically in some ways, the idea that the criterion of
competence is what someone candodownplays the importance of how the person
arrives at this competence. Two basic premises follow from this definition. First, it
assumes that student learning can be made explicit and, once acquired by the learner,
canbedemonstratedby‘doing’in some precise meaning of the term. Second, once
made explicit, learning can be understandable for students prior to (and/or independent
of) the learning process. In this paper, we are left with the following key questions: For
whom are LOs written—for students or for teachers? To whom are they clear?
## Educ Asse Eval Acc

Furthermore, some multilayered concepts and intricate skills might not be easily
clarified since making them explicit might hamper learning.
The idea that LOs matter the most and the claim that students should know
what is expected of them are both intuitively meaningful. These concepts also
align with developments in research on assessment and the relationship between
assessment and learning, dated by Shepard (2000) from 1990 onwards (e.g. Biggs
1996; Black and Wiliam1998; Ramsden1992/2003). Nevertheless, in examining
central aspects of learning in relation to well-known traits of LOs, several di-
lemmas seem to persist, to which we now turn. Examples include the following
issues:
&Unexpected learning: This is inevitable as a potential alternative outcome, for
instance, students coming up with ideas, solutions or questions that shed new light
on fields of knowledge or practice (Bateson1972  ; Biesta2010  ;Eisner1979  ). Such
unexpected contributions should be appreciated but cannot be fully stated ahead of
the learning process.
&Abstraction: In line with Bateson (1972  ), some knowledge may be difficult to
specify due to their level of abstraction (e.g. independence or creativity). At one
level, a student may demonstrate accomplishment according to expectations, while
having ideas about the learned topic that question its relevance, for example. Even
when LOs are clearly stated, what students actually learn is uncertain due to the
unfolding nature of learning. Furthermore, expertise might imply explicit knowl-
edge becoming implicit and beyond elaboration (Dreyfus and Dreyfus1986;
Engeström1987  ;Nonaka1994  ). An expert may therefore be unable to explain
precisely what is learned at an early stage of learning in a discipline or a profession.
&Contestability: Most LOs address dominant knowledge, which needs to be gener-
ally challenged (Popper1959) and particularly so in higher education where
emphasising uncertainty is a core value. The focus on prescribed LOs might risk
being in conflict with the epistemic culture (Knorr Cetina1999  )ofhighereduca-
tion. Questioning established‘truth’is a key dimension of higher education culture.
&Meta-level learning: Explicit formulations of curricula, LOs and didactic practice
often overlook more or less hidden aspects of teaching, learning and assessment
(for instance) in terms of the hidden curricula (Snyder1971  ) or peer-mediated
socialisation within the student role (Havnes2008  ). When striving to achieve a
clearly stated LO, students may learn about themselves as learners, potentially
forming an identity and developing ideas about the learning context. All of these
are LOs that are neither stated nor regarded as guiding the learning process. Of
course, if they are stated, they form a basis for potentially new subjects of meta-
level learning.
Attending to these dilemmas does not imply that it is impossible or meaningless to
make explicit what students are expected to achieve and how they should demonstrate
what they have learned. However, there are reasons for questioning the idea that what
students are expected to learn—and will be able to demonstrate—canbeprescribedin
advance and in a way that they can comprehend prior to their own learning. Finally, we
could question if prescribed LOs, at least in some cases, might foster compliance rather
than critical, analytical thinking.
## Educ Asse Eval Acc

By way of contrast, the literature also includes strong critics (e.g. Allais2012;
Allan1996;Brady1996; Hussey and Smith2003,2008; James and Brown2005;
Lassnigg2012;SmytheandDow1998; Young and Allais2011). Although these
contributions take varying perspectives and focus on different issues, they can be
described as multiple warnings against the application of a too narrowly defined
andrestrictedLOconceptingoverningeducation.Criticsalsowarnagainstthe
danger of using LOs in ways that can be more technical and rationalistic than
productive in education.
With this range of opinions as a backdrop, our primary research questions are as
follows:
-  What is meant by LOs in diverse contexts of discourse, and how have these ideas
emerged?
-  How do LO policy and practice accord with recent developments in the theorising
of learning?
The next section addresses the first question. We start with a brief review of the
LO literature, addressing its history, as well as disparities in conceptualisations and
attribution of meaning to LOs. Then, we address the challenges of implementing
LOs in higher education due to the conflicting ways of understanding them across
policy and pedagogical frames of reference. Our main interest in this aspect is to
explore the potential conflicts inherent in the multitude of interests and functions
that LOs are expected to serve—focusing on policy and pedagogy as interpretive
positions.
Next, we address the second question. We discuss the theorising of learning that
challenges the idea of making learning explicit and stated prior to the learning
process—with an emphasis on valuing unexpected learning. By explaining the tensions
inherent in theLO conceptin terms of being attributed meaning as both a policy/
management tool and a pedagogical tool, we shed new light on the challenges of
implementing LOs in higher education.
3 History of learning outcomes
The term‘learning outcome’is closely linked to the history of another highly relevant
term in the field of curriculum development—‘teaching and learning objective’(Allan
1996  ;Burke1995  ; Eisner2005  ; Ewell2005  ;Jessup1995  ). The fact that the two terms
are often interconnected in the literature makes it difficult to distinguish between them
(Allan1996  ). The development of the LO concept is described as a linear process,
starting with the objectives movement and continuing through the mastery learning
theories before ending up with the current, outcome-based education (OBE) movement
(King and Evans1991  ; Prøitz2010  ; Spady and Marshall1991  ). Here, we briefly
address the American and European approaches, followed by putting the students in
the centre, which was emphasised by cognitive psychologists (e.g. Zimmerman and
Schunk2001  ) and educational developers (e.g. Ramsden1992  /2003) and later included
in the European higher education policy (European Commission2013  ; Kennedy et al.
## 2007  ).
## Educ Asse Eval Acc

4 Outcome-based education movement
There are OBE advocates in the United Kingdom (UK) (e.g. Jessup1995  ) and the
United States of America (USA) (e.g. Spady1988  , 1994  ; Spady and Marshall1991  ).
Those favouring OBE claim that it is applicable to all forms of learning, accessible to
far more individuals, efficient and cost-effective. It is also flexible since learning
objectives are specified as outcomes independent of traditional learning and assessment
processes, thus allowing different modes, contexts and time scales of learning (Jessup
## 1995  ,p.36).
The origins of OBE can be traced to several key ideas in American education
(Furman1994), including Tyler’s(1950)Basic Principles of Curriculum and
Instruction, the principles of mastery learning inspired by Bloom et al.’s(1956)
taxonomy and Mager’s(1975) work on behavioural objectives, as well as a move-
ment towards criterion-referenced assessment as described by Glaser (1963)(see
also Furman1994;KingandEvans1991). These ideas have been fed into a
favourable social context in the USA, under the pressure of providing evidence of
student achievement and accountability (Brady1996;KingandEvans1991). The
initial popularity of OBE in the USA has been explained by the fact that it seems to
offer something for everyone, as politicians, business people, community leaders
and educators can relate to exit outcomes. Moreover, OBE may be effective in
coupling control and autonomy within a decentralised logic of steering (King and
Evans1991). It affords central-level authority by setting exit outcomes and simul-
taneously giving educational institutions the autonomy to decide how to achieve
these outcomes (King and Evans1991).
5 European approaches
The European discussion on LOs post-dates its American counterpart (Lassnigg2012  )
and is closely related to the implementation of, first, the EQF and, subsequently, the
National Qualifications Framework (NQF). The European discussion can be viewed as
building on the qualification frameworks developed in the UK in the 1980s; in turn,
these reflected concerns about future workforce competence (Burke1995   ;Melton
1996  ; Young2003  ). In the European context, a qualification framework is considered
a major new policy device in governing education and training (Lassnigg2012).
However, the emphasis on LO in Europe has also been grounded in a pedagogical
rationale—a growing focus on LOs harmonised with the increasing concentration on
learning and the call for integrating teaching, learning and assessment. Many educa-
tional researchers have highlighted the LOs’formative function of providing guidance
and direction in student learning (Ramsden1992  , 2003). For instance, the notion of
constructive alignment (Biggs1996  ; Birenbaum et al.2006  ; Shepard2000  )isbasedon
the fundamental idea that assessment drives learning. Stressing the need to develop an
integrated assessment system, Birenbaum et al. (2006  ) call for more emphasis on
assessment for learning (AfL) and assessment as an integral part of curriculum design
and practice. As assessment research has become linked to a constructivist paradigm,
the understanding of learning as‘an active process of mental construction and sense
making’(Shepard2000  , p. 6) has been foregrounded.
## Educ Asse Eval Acc

These approaches underscore the need to embed assessment structures and practices
in a conceptualisation of learning as‘part of the learning process’(Shepard2000  ,p.
10). Gielen et al. (2003  , p. 51) are among the advocates of another appeal to involve
‘students as active partners in the assessment process’. This also addresses the need to
embed assessment in the learning and teaching processes. These ideas are also
recognisable in the policy-oriented literature focusing on implementation. For instance,
according to Kennedy et al. (2007  ,p.19),‘there is a dynamic equilibrium between
teaching strategies on one side and learning outcomes and assessment on the other
side’.
6 Learning outcomes: student learning in the centre
In the European context, the interest in LOs has been particularly linked to construc-
tivist approaches to learning, underpinned by an increasing concern for student
approaches to learning (Biggs1996;Martonetal.1984; Ramsden1992/2003),
alongside a growing awareness of assessment’s impact on student learning (Biggs
1996;ResnickandResnick1992).Educationaldevelopers,particularlythosebasedin
the UK, have taken an active role in transforming teaching to align it with a construc-
tivist approach to learning. One such measure is the development of descriptors to
inform students about what they are expected to learn (e.g. Baume2009;Goslingand
Moon2002). Educational developers’efforts have been in line with previous calls by
Jessup (1995)andSpady(1988)totreatLOsas‘part of transforming and
democratising higher education by enabling it to become more open, flexible, and
responsive to student needs’(Gosling2001, p. 273). Since working with LOs requires
specification of the desired outcomes a priori to the design of the educational pro-
gramme, using them encourages curriculum development that involves a reversal of
more content-based practices (Furman1994; Killen2000;Spady1988). Particularly,
using LOs to steer curriculum design requires alignment among three elements of the
curriculum—intended LOs, learning and teaching activities and assessment methods
(Biggs1996). This model of constructive alignment underscores the importance of
coherence among assessment, teaching and learning at both programme and practice
levels (Biggs1996; Birenbaum et al.2006). This alignment with a constructivist
approach to learning creates a fundamental pedagogical dilemma. On one hand,
students need guidance about what they are expected to learn and what is
emphasised in assessment. On the other hand, a fundamental assumption in the
constructivist paradigm is that what students learn is based on their own learning
activities. The fact that students take control of their own learning has been associated
with this pedagogical approach to LOs, which also implies some level of flexibility in
the appraisal of their achievements. For instance, Black and Wiliam (2009,p.18)
argue,‘The aims of any instruction are usually a combination of aims specific to the
subject and aims directed to improving learning skills. For many teachers, the former
are explicit and the latter only implicit. The formative practices [...]reflectvery
generalprinciplesoflearning,notablysocialconstructivismandmeta-cognition’.The
constructivist approach emphasises developing the learning capacity of students, as
well as subject-specific aims. However, meta-learning, such as‘learning to learn’,
requires subject-specific learning (Bateson1972).
## Educ Asse Eval Acc

7 Conceptualising learning outcomes: contrasting perspectives on learning
The previous sections have described the evolution of thinking about LOs and their
various influences on pedagogy, policy and curriculum development over several
decades and across continents. Here, we turn to recent work on the concept of LOs
and a model for different conceptualisations of LOs as discussed by Prøitz (2010  ).
Prøitz grounds the model (Fig.1)onGagné’s(1974  ) and Eisner’s(1979  )discussions
about the LO concept as useful for instructional design and planning. Gagné has been
recognised as a behaviourist (Burke1995), while Eisner has been considered a
pragmatist and social constructivist (Allan1996  ). Hence, Gagné and Eisner represent
two perspectives on learning that are accompanied by different views on LOs (Prøitz
## 2015  ).
Gagné (1974  ) and Eisner (1979   ) have both made key contributions to the LO
discussion. According to Gagné, an LO‘makes possible a refined understanding of
the learning process and thus permits a drawing of relatively precise implications for
the design of instruction’(1974  , p. 51). In contrast, Eisner views LOs as‘essentially
what one ends up with, intended or not, after some form of engagement’(1979  ,p.101).
Gagné is concerned with instructional design and interested in the learning required to
accomplish tasks involving planning and sequencing. On the other hand, Eisner pays
attention to the curriculum’s role in learning. Describing the‘trichotomy of outcomes’,
he argues that LOs are partly dependent on the student, the subject matter and the
teacher (1979  ). According to Eisner, the result is an inability to sort all learning into
prespecified LOs. Both Gagné and Eisner are sympathetic to LOs although they use
divergent conceptual frameworks, which illustrate the deviating character and poten-
tially conflicting conceptual landscape in which LOs are applied and attributed mean-
ing. Particularly, LOs are positively associated with diverse conceptualisations of
learning, assessment and curriculum design (to which we will return).
Gagné’s(1974) and Eisner’s(1979) different theoretical perspectives represent
inherent tensions in approaches to LOs. In Eisner’s view, LOs are characterised as
emerging, process-oriented and open-ended, with limited measurability. In Gagne’s
Fig. 1Conceptualisations of learning outcomes (Prøitz2014   )
## Educ Asse Eval Acc

opinion, LOs are characterised as results oriented, predefined, full-ended and measur-
able. These tensions are illustrated by the horizontal axis in Fig.1.
Adding another level of complexity, the relevant literature also describes different
conceptualisations of the purpose of LOs. These conceptualisations can have an
internal focus, serving as tools for educational and instructional planning, curriculum
development and teaching and learning processes, which dominate the educational
development approach. Alternatively, such conceptualisations can have an external
focus, where they can be used for measuring effectiveness and accountability, which
is predominant in the policy approach. The vertical dimension in Fig.1 illustrates
potential tensions between a policy-oriented approach (which emphasises governance
and accountability) and a pedagogical approach. The result is a four-quadrant matrix
combining learning and purpose orientations. Thus, a multilayered set of tensions is
generated in the conceptualisation and application of LOs.
In this paper, we primarily focus on the learning orientation dimension (the horizontal
axis), particularly the internal dilemma about the diverse conceptualisations. However, it
is also worth considering how the policy purposes may drive the educational aspects and
functions of assessment in a particular direction. In other words, as the policy perspec-
tive is applied to transforming education, the conceptualisations of LOs in the context of
educational practice may be pushed to align with the policy purposes of LOs.
When mapped according to learning and purpose orientations, the range of
conceptualisations identified in the LO literature illustrates various competing
understandings. Figure2 illustrates tensions in the scholarly literature concerning the
definitional knowledge about LOs. In a literature review, Prøitz (2014  ) exposes diverse
forms of bias in approaches to LOs, based on the definitions used. The majority of
authors address the discussion on instructional planning, curriculum development and
learning, with European (especially the UK) scholars framing LOs more in the process-
oriented, open-ended dimension than their US colleagues. These contributions largely
deal with the issue from the perspective of how to integrate LOs in teaching, learning
and assessment at programme and module levels, that is, integrated in the curriculum
design and the daily practices of teachers and students.
Not surprisingly, authors tackling LOs from a policy perspective tend to prioritise
predefined, full-ended definitions. Forgovernance and accountability purposes, the precise,
predefined and full-ended LO model provides a basis for outcome-oriented, comparable
indicators across institutions and over time. The implementation of LOs in many European
countries is highly driven by policy. Diverse LO rationalities meet in these processes.
For instance, when educational developers are involved in implementing the policy-
oriented version, problems may occur. Their approach to LOs may typically be in the
upper-left quadrant of Fig.1 and will conflict with the premises of the lower-right
quadrant, on which the policy perspective is largely based.
In a recent article, Handal et al. (2014  ) explore how educational developers in
Norway and Sweden have engaged in implementing the EQF in educational
programmes. They argue that when academics become involved in reformulating
curricula in terms of an LO rationale, an expected reaction would be a combination
of compliance and resistance. These authors find that the policy perspective‘reduces
the complexity of the situation’(Handal et al.2014  , p. 22). This context implies a
decrease in the complexity of the LO concept. As argued earlier, educational developers
tend to be sympathetic to explaining to students what is expected of them and at the
## Educ Asse Eval Acc

same time hold on to the LO concept at some level of open-endedness. Situated in the
academic culture of higher education, they are also inclined to value the autonomy of
teaching, which also accounts for student learning to some extent.
Handal et al. (2014  ) find that in assisting with the implementation of the LO model,
education developers do not execute the task as a technical exercise (p. 23); instead,
they interpret and translate the policy agenda and protect and attempt to preserve the
complexity of the educational setting. They argue in line with Stensaker’s(2008  )point
that educational policy implementation at the institutional and departmental levels
implies‘interpretation and translation’and‘creative implementation of public policy’
(p. 426). They attribute their own meanings and understandings to the termlearning
outcome.
Fig. 2Matrix of learning orientation and purpose orientation (N= 33) in definitions of learning
outcomes (Prøitz2010   )
## Educ Asse Eval Acc

More broadly, the LO model implementation in higher education might confront
disciplinary epistemic cultures (Knorr Cetina1999  ) and notions of learning in the
disciplines and professions that conflict with the idea of prescribed, full-ended LOs.
Such concepts dominate the policy approach but might seem reasonable in the gover-
nance and accountability context (Prøitz2014  , 2015  ).
Implementing LOs in education implies a return of the ideas that were largely
developed in the context of critical analyses of dominant educational practices—but
now with weighty policy connotations. When the implementation reaches the academic
staff members who are mainly concerned about student learning and disciplinary and
professional standards, the dilemmas inherent in conceptualising LOs surface. From the
perspective of research on learning and assessment, the LO model is both appreciated
and challenged. The policy and educational contexts are loosely coupled systems. They
rest on diverse frames of reference, meaning-making codes and values. For instance,
compliance is a positive term in the policy implementation system but disputed in an
educational system.
In contrast to Handal et al. (2014  ), Caspersen and Frølich (2016  ) find that institu-
tional leaders in Norwegian higher education accept the EQF and perceive it as a timely
and needed device to improve the quality of teaching and learning. It illustrates the
manifold dimensions of LOs and inherent dilemmas about them as pedagogical and
policy concepts. As LOs are intended to serve many purposes and attributed diverse
meanings by a wide range of agentive positions, an interpretation of LOs within one
frame of reference risks being meaningless or problematic within another frame of
reference. The dilemmas seem to emerge at the level of implementation in the institu-
tional context—when policy intentions reach educational practice. As stated in the
European Commission (2013  ) report, there may well be‘far-reaching—at least rhetor-
ical—consensus’about LOs putting the student in the centre of the educational process.
When ideas that are grounded in pedagogical initiatives return to academics as policy
imperatives, the contested nature of LOs is masked, and the agreement might be
rhetorical only. The contested nature of LOs can be further discussed by exploring
diverse ways of conceptualising learning processes and outcomes.
8 Learning outcomes and theories of learning
Greeno et al. (1996  ) classify theories of learning under three categories—behaviourist,
cognitive and situative (sociocultural) theories—each shaping the premises about
teaching and assessment differently. A behaviourist approach to LOs implies a quan-
titative measurement of skills and knowledge. Its judgements are applied in a particular
sequence—first, judging a broad set of knowledge components and their competence
levels individually and then creating an overall profile in terms of‘how much of the
domain a student has acquired’(Greeno et al.1996  , p. 37). The rationale is that
competence is demonstrated through the accumulation of sets of components of
information and skill(s), each representing a building block in a complex configuration
of professional competence. Compared to the behaviourist paradigm, scholars adopting
a cognitive approach emphasise conceptual understanding and reasoning across a wider
spectrum of knowledge and skill components. A focus on multiple ways of learning
that present challenges to the Westernised view of intelligence can also be expected.
## Educ Asse Eval Acc

For example, Gardner’s(1983  ) concept of multiple intelligence might be used to further
support this viewpoint. While the behaviourist approach emphasises testing a wide
range of components, the cognitive approach highlights assessment through the anal-
ysis of complex tasks. The third paradigm, the sociocultural approach, further expands
the perspective in that individual competence is framed as an aspect of an activity
system within which the person learns. The sociocultural focus would be on participa-
tion in social practice rather than on the individual learner’s characteristics. Sociocul-
tural learning implies socialising or enculturation in communities of practice and in the
process, adopting their social, cognitive and material practices and potentially
transforming social practices. However, this does not exclude the perspective on the
individual. The subjective aspect of learning is also essential. For instance, a core
feature of human functioning within a social structure is the capacity to alter the
situation in which the person finds oneself, which again might change the affordances
for the individual (Gibson1986  ). Such an agentive approach to learning emphasises
learner opportunities to shape their own engagement in learning, create learning
conditions and enhance their own learning.
Shepard (2000  ) concludes that the dominant approach to assessment is grounded in
the behaviourist paradigm. The question becomes whether or not elements of the
behaviourist approach to LOs are indeed identifiable in the European higher education
context. For instance, in their LO literature review using Bloom’staxonomy(Bloom
et al.1956  ), Kennedy et al. (2007  ) present an extensive list of examples, all at a general
level. However, if LOs are able to inform students about what they are expected to do,
as well as guide teachers in terms of what to emphasise, this would imply creating LOs
that are explicit, detailed and concrete. This requirement applies to all LOs at the
programme, module and session levels (Kennedy et al.2007  , p. 5), which is obviously
challenging. The next paragraph outlines how detailed explicitness might conflict with
recent developments in how learning is conceptualised.
For an example of how using detailed, concrete and explicit LOs might cut across
concepts about learning, we turn to Biesta’s(2010  )notionof‘learnification’.This
refers to the tendency to restrict education through the application of LOs with an
emphasis on student qualification.‘Socialisation’, defined as learners becomingBpart
of particular social, cultural, and political‘orders’^, is neglected (Biesta2010  ,p.20).
The same risk applies to what Biesta calls‘subjectification’, referring to an essential
aspect of education that‘allow[s] those educated to become more autonomous and
independent in their thinking and acting’(p. 21). Biesta’s point is that educational
quality builds on the combination of qualification, socialisation and subjectification in
all subject areas. To paraphrase Biesta (2010  , p. 7), it could be asked whether too much
attention is paid to qualification and LOs and too little to what learning is for (the
purpose orientation in Fig.1), beyond meeting preset standards.
In Vygotsky (1962  , 1978  ), we find another learning theorist whose framing implies
that an LO—or even learning itself—is not the ultimate goal. Emphasising learning as a
precursor to development, Vygotsky (1978  ) introduced the now well-known concept of
thezone of proximal development. It describes the manner in which participation in
problem solving under adult guidance and/or in collaboration with more capable peers
serves as a forerunner to a child’s development. Reframing this notion for higher
education, interpersonal problem solving shows that attaining LOs is a forerunner of
astudent
## ’s
professional or disciplinary development.
## Educ Asse Eval Acc

In a series of studies on the development of scientific concepts in childhood,
Vygotsky (1962) addresses the relationship between instruction and development.
Although he uses the termpsychological investigations, these studies are relevant to
assessment. Particularly, he finds that assessment could make an impact on children’s
progress if (instead of just stating their current level of development) it is used to inform
future teaching and learning initiatives. A key idea in Vygotsky’stheoryoflearningand
development is that a phenomenon at one point in time must be understood from the
perspective of its development. For instance, a student’s here-and-now achievement is a
temporary state and should be explored as a process, including attention to direction
and the potential for further learning and development. Defined in this way, assessment
serves to determine the student’s actual developmental stage and to clarify his or her
potential for further learning.
Vygotsky (1962) distinguishes between learning and development while
underscoring the interaction between these processes, a distinction that Black and
Wiliam (2009  ) and Havnes (2013  ) also emphasise in the context of assessment (for
an elaboration on Vygotsky’s differentiation between learning and development, see
Chaiklin2003  ). While learning is specific, development concerns‘the whole child [or
student], as an integral person, not a particular skill or the meeting of an assessment
criterion or a specific predefined learning outcome’(Vygotsky1978  ,p.46).Inthis
regard, learning specific skills is a prerequisite for development. Learning‘creates the
zone of proximal development [...]. [L]earning is not development [...] [but] a
necessary and universal aspect of the process of developing culturally organized,
specifically human, psychological functions’(Vygotsky1978  ,p.90).
Vygotsky’s distinction between learning and development is essential to this analy-
sis. For instance, professional education leads to the development of professional
competence. It implies being included in a community of professional practice and
gaining trust from society and the public to act independently as a professional.
Becoming a professional involves securing a position in society, depending on who a
person is as a professional, not just on the skills that one possesses or the knowledge
that one can demonstrate. For instance, for a patient undergoing surgery, agreeing to do
so implies an act of trust. For a surgeon, performing an operation implies an act of
responsibility. Learning skills and solving problems are both steps towards the devel-
opment of the whole person. In reframing Chaiklin’s(2003  , p. 43) insights to align
them with the higher education context, the development of professional expertise is
not mainly concerned with the improvement of a skill or with any particular task. It also
relates to [students’professional] development, which, in turn, brings the integrative
aspect of higher education into focus. A parallel in higher education research can be
found in Pascarella and Terenzini’s(2005  ) extensive work, which places considerable
emphasis on identity and personal development as outcomes of higher education.
In line with these ideas, Wertsch (1998  ) refers to studies of identity development
among Estonian students after the Soviet empire’s collapse (see Tulviste and Wertsch
1994   ). Wertsch distinguishes between‘mastery’and‘appropriation’of conceptual
knowledge, in relation to Estonian history in this case. While mastery is characterised
by‘learning how to do’(pp. 46–53), appropriation implies‘making something one
## ’s
ow
n’(pp. 53–58). Two implications follow. On one hand, mastery may occur without
appropriation. In Wertsch’s example, Estonian students are able to demonstrate detailed
knowledge about the Soviet version of Estonian history but do not trust or appropriate
## Educ Asse Eval Acc

it. On the other hand, they appropriate the Estonian version of the same events but
cannot demonstrate detailed knowledge about these. Similarly, in a study involving
first-year students taking an introductory course in philosophy, Havnes (2008  )finds
that academic learning goes beyond curricular learning. The philosophy students
demonstrate knowledge‘beyond’that expressed in the syllabus—their‘extra’learning
is mainly at a meta-level of knowing that is consistently linked to their curricular
knowledge. Havnes concludes that meta-knowing‘could only be reached through
knowing the curriculum’(2008  ,p.201).InBiesta’s(2010  )terms,Havnes’findings
imply that qualification or achievement in accordance with LOs is not a separate
process but could also be interdependent with socialisation and subjectification.
To further complicate the issue, in a study of post-secondary education, Torrance
(2007  ) addresses the danger of structuring assessment in an overly narrow manner. He
concludes that assessment procedures and processes completely dominate the teaching
and learning experience in the vocational programmes under his consideration. The
extensive use of explicit assessment criteria and follow-up in supervision and feedback
might bring about an approach to teaching and learning wherebyB‘[c]riteria compli-
ance’[would] replace learning^(Torrance2007  , p. 282). The extensive use of LOs and
assessment criteria might risk resetting the horizon of learning or situate learning in the
context of passing tests or achieving specific LOs, instead of perceiving these as
milestones in an expanded qualification process.
Likewise, Engeström (1987  ) takes as his starting point‘the futility of learning’(pp. 21–
26), especially in relation to the commonly shared notion that places problem solving as the
highest and most cognitively advanced type of learning. He states,‘The problem is that
problemsolvingandstructuringareessentiallyreactiveformsoflearning.Bothpresupposea
given context which presents the individual with a pre-set learning task’(p. 1). He distin-
guishes between learning the‘given new’(i.e. what is known to someone other than the
learner) and the‘created new’(i.e. what is historically new) (Engeström1987,p.174).
Although higher education entails learning the‘given new’to a great extent, Engeström
frames the primary learning problem as learning the‘created new’. This might be the case in
higher education where, by and large, students’learning potentially expands beyond
academic, professional and social standards. However, expansion does not happen in a
vacuum.Presetandpredictivestandards,expressedthroughLOsandassessmentcriteria,are
necessarystepstowards‘creatednew’goals.
## Inotherwords,learningthe‘givennew’andthe
‘created new’is intertwined.
We find a parallel approach in Bateson’s(1972  ) theory of learning and communi-
cation. Instead of preset goals, he regards‘direction’and‘values’as more appropriate
concepts in understanding learning, looking forB‘direction’and‘value’in the chosen
act rather than in defined goals^(p. 162). He argues that learning can include‘free will,
predestination, responsibility, constructiveness, passivity, dominance, etc. [..., which
are] all, in some sense, by-products of the learning process’(pp. 164–165). This
viewpoint may imply not only achieving expected LOs but also valuing the by-
products of learning as equal to the preset and predicted outcomes, even when they
take another form or oppose the expected LOs.
Another key point in Bateson’s(1972  ) conceptualisation is the distinction among
diverse levels of learning. In brief, learning specifics is one level, while learning to cope
with the former is another. For instance, students may learn to perform according to a
specified, prescribed LO and simultaneously come to terms with learning to learn in
## Educ Asse Eval Acc

conformance to listed LOs. Students may (and often will) learn that achieving LOs is a
particular challenge and a competence in itself; students learn to become students.
Moreover, teacher-students learn to become student-teachers, and students of engineer-
ing learn to come to terms with mastering engineering subjects. In Bateson’s terminol-
ogy, these two modes of learning are labelled learning I (the preset learning) and
learning II (learning to learn).
When confronted with the arguments of Bateson (1972  ), Biesta (2010  ), Vygotsky
(1962  , 1978  )andWertsch(1998  ), trusting in preset LOs in their specific, descriptive and
full-ended form becomes problematic. Moreover, depending on how it is applied—
particularly regarding the degree to which a policy perspective is imposed on the
pedagogical application of LOs—the very nature of learning, its emergence through
active participation in disciplinary and professional activities, risks being given less
priority and attention. In its extreme, a predefined, full-ended version of LOs that is
prioritised in the policy-oriented literature might foster reactive learning, that is, stu-
dents’compliance with preset standards, instead of becoming part of a professional or
disciplinary community in which breaking new ground is a key value. While compli-
ance might be valued from a policy/governance perspective, from a learning/academic
perspective, not only recognising but also going beyond conforming to dominant
standards are appreciated. From these perspectives, the point is not to argue for or
against LOs but to call for a critical approach to how these are and should be used—in
various contexts, for diverse purposes and at different levels and sectors of education.
## 9 Conclusion
While transparency and students’understanding of disciplinary and professional stan-
dards are key aspects of any curriculum, our paper illustrates the more problematic
features of applying LOs that are expected to be full-ended and predefined. From a
learning perspective, it might be insufficient for students to simply perform according
to expectations because they might comply without appropriation. There is a need in
education to transcend the declaration of explicit LOs and assessment criteria. None-
theless, learning without explicit expectations could potentially lead to learning by trial
and error. It would require time-consuming guesswork by using hidden or implicit cues
to figure out what matters and/or what is expected.
Despitethedilemmaselaboratedabove,theLOmovementandtheories oflearningcome
together in foregrounding learning and in placing student achievement in a primary position
in the educational process. As a result, feedback becomes a core mechanism in understand-
ing and promoting learning. Learning outcomes clearly direct teaching and students’
learning activities, opening the way for feedback and dialogue between and among teachers
and students. Moreover, LOs can support internal dialogue and enhance self-assessment.
Our paper indicates that introducing LOs solely for purposes of managerialism,
efficiency, benchmarking and control of student learning may weaken the functions of
LOs that can otherwise provide direction to teaching and learning processes. The
essential qualities of the initial initiative of using LOs for the purpose of directing
teaching and learning activities seem to have been diminished in the policy discourse
on LOs. The value of the processes of working with LOs in teaching and learning
seems to be under-communicated as a consequence of the shift from teaching and
## Educ Asse Eval Acc

learning practices to the use of LOs as policy devices to support mobility, assure
accountability and promote political initiatives. From a policy perspective, LOs con-
stitute a system‘from above’. As a result and probably unintentionally, the behaviourist
approach to LOs can be claimed to have gained ground, leading to competence
conceptualised as‘to-do’achievements that can be specified and observed. The only
factors that count are those that can be operationalised.
There is the danger that the nature of policymaking, recognised as the need to
simplify concepts in order to build uniform systems and achieve unity in decision
making (Prøitz2015  ), might lead to the loss of the essential aspects and values inherent
in working with LOs. Oversimplification of learning processes, combined with per-
suasive and urgent political purposes, can have a significant impact on education
development. Nevertheless, complexity is not easily overridden. When academics in
institutions and departments apply the LO concept in curriculum development, course
design and teaching practices, the complexity of LOs is commonly reintroduced, and
the contested nature of knowledge and learning surfaces again.
ThisdiscussionhasprimarilyfocusedonthehorizontalaxisinFig.1,thatis,the diverse
interpretations of LOs as linked to different perspectives and understandings of learning.
To understand how LOs serve various purposes, the vertical dimension—the relationship
between a policy and pedagogy as potentially conflicting frames of reference—should be
included. In the European and broader contexts, LOs in higher education, as well as in
general education, are profoundly linked to political interests and agendas.
This article has demonstrated the ambiguity of the LO concept from the perspective
of learning theories, along with the challenges of implementing LOs in teaching and
learning cultures of higher education. This somewhat vague LO concept is attributed
diverse meanings and potentials as it is taken to encompass various purposes and to
serve the agendas of both policy and pedagogy. Further research is needed to focus on
what types of LOs might give sound directions to teaching and learning processes in the
policy-pressured landscape of higher education, that is, to emphasise the pedagogical
aspects of the LO concept. It is particularly essential to address the relationships
between conceptualisations of learning and the LO concept.
Compliance with ethical standards
Conflict of interestThe authors declare that they have no conflict of interest (financial or non-financial).
The analysis is theoretical and does not include informants.
## References
Allais, S. (2012). Claims vs. practicalities: lessons about using learning outcomes.Journal of Education and
Work, 25(3), 331–354. doi:10.1080/13639080.2012.687570.
Allan, J. (1996). Learning outcomes in higher education.Studies in Higher Education, 21(1), 93–108.
doi:  10.1080/03075079612331381487.
Au, W. (2011). Teaching under the new Taylorism: high-stakes testing and the standardization of the 21st
century curriculum.Journal of Curriculum Studies, 43(1), 25–45.
Bateson, G. (1972).Steps to an ecology of mind: collected essays in anthropology, psychiatry, evolution, and
epistemology. Chicago: University of Chicago Press.
Baume, D. (2009).Writing and using good learning outcomes. Leeds: Leeds Metropolitan University.
Biesta, G. J. J. (2010).Good education in an age of measurement. London: Paradigm Publishers.
Biggs, J. (1996). Enhancing teaching through constructive alignment.Higher Education, 32(3), 347–364.
## Educ Asse Eval Acc

Birenbaum, M., Breuer, K., Cascallar, E., Dochy, F., Ridgeway, J., Wiesemes, R., & Nickmans, G. (2006). A
learning integrated assessment system.Educational Research Review, 1(1), 61–67.
Black, P., & Wiliam, D. (1998). Assessment and classroom learning.Assessment in Education, 5(1), 7–75.
Black, & Wiliam. (2009). Developing the theory of formative assessment.Educational Assessment,
Evaluation and Accountability, 21(1), 5–31.
Bloom, B. S., Englehart, M. D., Furst, E. J., Hill, W. H., & Krathwohl, D. R. (1956).Taxonomy of educational
objectives. Handbook 1: cognitive domain. New York: David McKay.
Brady, L. (1996). Outcome-based education: a critique.Curriculum Journal, 7(1), 5–16.
Burke, J. (1995).Outcomes, learning and the curriculum. Implications for NVQs, GNVQs and other
qualifications. London: The Falmer.
Caspersen, J., & Frølich, N. (2015). Managing learning outcomes. Leadership practices and old modes of new
governance in higher education. In E. Reale & E. Primeri (Eds.),Universities in transition. Shifting
institutional and organizational boundaries(pp. 187–202). Rotterdam: Sense.
Chaiklin, S. (2003). The zone of proximal development in Vygotsky’s analysis of learning and instruction. In
A. Kozulin, V. Finsia, C. A. Ageyev, & S. M. Miller (Eds.),Vygostky’s educational theory in cultural
context(pp. 39–64). Cambridge: Cambridge University Press.
Declaration, B. (1999). The Bologna Declaration of 19 June 1999. Joint Declaration of the European Ministers
of Education.European Union, Brussels, available at:www.bologna-berlin2003.de/pdf/bologna_
declaration.pdf.
Dreyfus, H., & Dreyfus, S. (1986).Mind over machine. New York: Basic Books.
Eisner,E.W.(1979).The education imagination. On the design and evaluation of school programs.New
## York: Macmillan.
Eisner,E.W.(2005).Reimagining schools: the selected works of Elliot W. Eisner. London: Routledge.
Engeström, Y. (1987).Learning by expanding. Helsinki: Orienta-Konsultit.
European Commission. (2013). Improving the quality of teaching and learning in Europe’s higher education
institutions (High Level Group on the Modernisation of Higher Education). Report to the European
## Commission, June 2013.
European University Association. (2006). EUA Bologna handbook: making Bologna work. In E. Froment
(Ed.). Raabe.
Ewell, P. (2005). Applying learning outcomes to higher education: an overview. Paper prepared for the Hong
Kong University Grants Committee. National Center for Higher Education Management Systems.
Furman, G. C. (1994). Outcomes-based education and accountability.Education and Urban Society, 26(4),
## 417–437.
Gagné, R. M. (1974).Learning for instruction. Hinsdale: Dryden Press.
Gardner, H. (1983).Frames of mind: the theory of multiple intelligences.NewYork:BasicBooks.
Gibson, J. J. (1986).The ecological approach to visual perception. Hillsdale: Lawrence Erlbaum.
Gielen, S., Dochy, F., & Dierick, S. (2003). Evaluating the consequential validity of new modes of assessment:
the influence of assessment on learning, including pre-, post-, and true assessment effects. In M. Segers, F.
Dochy, & E. Cascallar (Eds.),Optimising new modes of assessment: in search of qualities and standards
## (pp. 37–54). Dordrecht: Kluwer Academic Press.
Glaser, R. (1963). Instructional technology and the measurement of learning outcomes.American
## Psychologist, 18,519–521
## .
Gosling, D. (2001). Lost opportunity: what a credit framework would have added to the national qualification
framework.Higher Education Quarterly, 55(3), 270–284.
Gosling, D., & Moon, J. (2002).How to use learning outcomes and assessment criteria. London: SEEC.
Greeno, J. G., Collins, A. M., & Resnick, L. B. (1996). Cognition and learning. In D. Berliner & R. Calfee
(Eds.),Handbook of educational psychology(pp. 15–46). New York: Macmillan.
Handal, G., Lycke, K. H., Mårensson, K., Roxå, T., Skodvin, A., & Solbrekke, T. D. (2014). The role of
academic developers in transforming Bologna regulations to a national and institutional context.
International Journal for Academic Development, 19(1), 12–25.
Hargreaves, A., & Moore, S. (2000). Educational outcomes, modern and postmodern interpretations: response
to Smyth and Dow.British Journal of Sociology of Education, 21(1), 27–42.
Havnes, A. (2008). Peer mediation beyond the curriculum.Studies in Higher Education, 33(2), 193–204.
Havnes, A. (2013). Assessment in higher education—a CHAT perspective. In G. Wells & A. Edwards (Eds.),
Pedagogy in higher education: a cultural historical analysis(pp. 84–104). Cambridge: Cambridge
## University Press.
Hussey, S., & Smith, P. (2003). The uses of learning outcomes.Teaching in Higher Education, 8(3), 357–368.
Hussey, S., & Smith, P. (2008). Learning outcomes. A conceptual analysis.Teaching in Higher Education,
## 13(1), 107–115.
## Educ Asse Eval Acc

James, B., & Brown, S. (2005). Grasping the TLRP nettle: preliminary analysis and some enduring issues
surrounding the improvement of learning outcomes.Curriculum Journal, 16(1), 7–30.
Jessup, G. (1995). Outcome based qualifications and the implications for learning. In J. H. Burke (Ed.),
Outcomes, learning and the curriculum—implications for NVQs, GNVQs and other qualifications(pp.
## 33–54). London: Taylor & Francis.
Kennedy, D., Hyland, Á., & Ryan, N. (2007).Writing and using learning outcomes: a practical guide.Cork:
## University College Cork.
Killen, R. (2000). Outcomes-based education: principles and possibilities (unpublished manuscript).
University of Newcastle.http://drjj.uitm.edu.my.
King, J. A., & Evans, K. M. (1991). Can we achieve outcome-based education?Educational Leadership,
## 49(2), 73–75.
Knorr Cetina, K. (1999).Epistemic cultures: how the sciences make knowledge. Cambridge: Harvard
## University Press.
Lassnigg, L. (2012).‘Lost in translation’: learning outcomes and the governance of education.Journal of
Education and Work, 25(3), 299–330.
Mager, R. F. (1975).Preparing objectives for instruction. Belmont: Fearon.
Marton, F., Hounsell, S., & Entwistle, N. (1984).The experience of learning. Edinburgh: Scottish Academic
## Press.
Melton, R. (1996). Learning outcomes for higher education: some key issues.British Journal of Educational
## Studies, 44(4), 409–425.
Nonaka, I. (1994). A dynamic theory of knowledge creation.Organization Science, 5(1), 14–37.
Pascarella, E. T., & Terenzini, P. T. (2005).How college affects students: a third decade of research(Vol. 2).
San Francisco: Jossey-Bass.
Popper, K. (1959).The logic of scientific discovery. London: Routledge.
Prøitz, T. S. (2010). Learning outcomes—what are they? Who defines them? When and where are they
defined?Educational Assessment, Evaluation and Accountability, 22(2), 119–137.
Prøitz, T. S. (2014). Conceptualisations of learning outcomes—an explorative study of policymakers, teachers
and scholars. PhD thesis, Series of dissertations submitted to the Faculty of Educational Sciences,
University of Oslo, No. 194.
Prøitz, T. S. (2015). Learning outcomes as a key concept in policy documents throughout policy changes.
Scandinavian Journal of Educational Research, 59(3), 275–296. doi:10.1080/00313831.2014.904418.
Purser, L. (2003). Report on Council of Europe seminar on recognition issues in the Bologna Process, Lisbon,
April 2002. In S. Bergan (Ed.),Recognition issues in the Bologna Process(pp. 23–30). Strasbourg:
Council of Europe Publishing.
Ramsden, P. (1992/2003).Learning to teach in higher education. London: Routledge.
Resnick, L. B., & Resnick, D. P. (1992). Assessing the thinking curriculum: new tools for educational reform.
In B. Gifford & M. C. O’Connor (Eds.),Changing Assessments: alternative views of aptitude, achieve-
ment and instruction.
Boston, MA: Kluwer Academic Publishers.
Shepard, L. (2000). The role of assessment in a learning culture.Educational Researcher, 29(7), 4–14.
Smythe, J., & Dow, A. (1998). What’s wrong with outcomes? Spotter planes, action plans and steerage of the
educational workplace.British Journal of Sociology of Education, 19(3), 291–302.
Snyder, B. R. (1971).The hidden curriculum. New York: Knoph.
Spady, W. G. (1988). Organizing for results: the basis of authentic restructuring and reform.Educational
## Leadership, 46(2), 4–8.
Spady, W. G. (1994).Outcome-based education. Critical issues and answers. Arlington: American
Association of School Administrators.
Spady, W. G., & Marshall, K. J. (1991). Beyond traditional outcome-based education.Educational
## Leadership, 49(2), 67–72.
Stensaker, B. (2008). Endringsarbeid i høyere utdanning: nye konfliktlinjer og nye muligheter [Working
towards change in higher education: new lines of conflict and new possibilities].Norsk Pedagogisk
## Tidsskrift, 6,417–426.
Torrance, H. (2007). Assessment as learning? How the use of explicit learning objectives, assessment criteria
and feedback in post-secondary education and training can come to dominate learning.Assessment in
## Education: Principles, Policy & Practice, 14(3), 281–294.
Tulviste, P., & Wertsch, J. V. (1994). Official and unofficial histories: the case of Estonia.JournalofNarrative
and Life History, 4(4), 311–329.
Tyler, R. W. (1950).Basic principles of curriculum and instruction. Chicago: University of Chicago Press.
Vygotsky, L. S. (1962).Thought and language. E. Hanfmann & G. Vakar (Eds. and trans.). Cambridge: MIT
## Press.
## Educ Asse Eval Acc

Vygotsky, L. S. (1978).Mind in society. The development of higher psychological processes.InM.Cole,V.
John-Steiner, S. Scribner, & E. Souberman (Eds.). Cambridge: Cambridge University Press.
Wertsch, J. V. (1998).Mind as action. Oxford: Oxford University Press.
Young, M. F. D. (2003). National qualification frameworks as a global phenomenon: a comparative perspec-
tive.Journal of Education and Work, 16(3), 223–237.
Young,M.,&Allais,S.D2011]. The shift to outcomes based frameworks. Key problems from a critical
perspective.Austrian Open Access Journal of Adult Education, 14, 03/1–03/10.
http://erwachsenenbildung.at/magazin/11-14/meb11-14.pdf.
Zimmerman, B. J., & Schunk, D. H. (Eds.). (2001).Self-regulated learning and academic achievement.
Theoretical perspectives(2nd ed.). London: Lawrence Erlbaum Associates.
## Educ Asse Eval Acc