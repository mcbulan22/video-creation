"""html_engine: draws a scene written in HTML, using the Chrome (or Edge) already installed on the computer.

The page is rendered as a TRANSPARENT layer. The engine still draws the look's background, the top and bottom bars, the fades,
the scene-change flourish and the sound, so HTML scenes and Python scenes sit side by side in one video.

Nothing to download: Playwright (a small Python package, installed by setup) drives your own Chrome or Edge.
Set VS_CHROME=/path/to/browser to use a different Chromium-based browser.

Used by build_video.py and contact_sheet.py. You normally never call it yourself:  python studio.py doctor  tests it.
"""
import atexit, base64, json, os, pathlib, re, shutil, sys, tempfile, urllib.parse
import skia

HERE = os.path.dirname(os.path.abspath(__file__))
PACK = os.path.abspath(os.path.join(HERE, ".."))
RT = os.path.join(PACK, "html_runtime")
_PW = _BR = None
_PAGES = {}                                    # scene index -> (page, errors), at most two kept
_LAST = {}                                     # scene index -> (fingerprint, last picture)
_TMP = None
_B64 = {}
INSTALL_HELP = ("The HTML engine needs Google Chrome (or Microsoft Edge) and the 'playwright' Python package.\n"
                "  - Install Chrome from https://www.google.com/chrome/ (Windows already has Edge).\n"
                "  - Then run setup once more:  python studio.py setup   (it installs playwright; no browser is downloaded)\n"
                "  - Using another Chromium browser? Set VS_CHROME to its program file.\n"
                "Python scenes still work without it.")


def _b64(path):
    if path not in _B64: _B64[path] = base64.b64encode(open(path, "rb").read()).decode("ascii")
    return _B64[path]


def _args():
    a = ["--force-color-profile=srgb", "--font-render-hinting=none", "--hide-scrollbars", "--allow-file-access-from-files",
         "--disable-background-timer-throttling", "--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows"]
    if sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0: a.append("--no-sandbox")
    return a


def _launch():
    """Start the browser once per process. Order: VS_CHROME, Chrome, Edge, a Playwright-installed Chromium."""
    global _PW, _BR
    if _BR is not None: return _BR
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise RuntimeError("The 'playwright' package is not installed.\n" + INSTALL_HELP)
    if os.environ.get("VS_HTML_TEST_NOBROWSER") == "1": raise RuntimeError("No usable Chrome or Edge was found (simulated for testing).\n" + INSTALL_HELP)   # test hook
    _PW = sync_playwright().start(); tried = []
    tries = []
    if os.environ.get("VS_CHROME"): tries.append(("VS_CHROME", dict(executable_path=os.environ["VS_CHROME"])))
    tries += [("Google Chrome", dict(channel="chrome")), ("Microsoft Edge", dict(channel="msedge")), ("Chromium", {})]
    for name, kw in tries:
        try:
            _BR = _PW.chromium.launch(headless=True, args=_args(), **kw); _BR._vs_name = name; break
        except Exception as e:
            tried.append(f"{name}: {str(e).splitlines()[0][:120]}")
    if _BR is None:
        try: _PW.stop()
        except Exception: pass
        _PW = None
        raise RuntimeError("No usable Chrome or Edge was found.\n  tried -> " + "\n  tried -> ".join(tried) + "\n" + INSTALL_HELP)
    atexit.register(close)
    return _BR


def close():
    global _PW, _BR, _TMP
    for page, _ in list(_PAGES.values()):
        try: page.context.close()
        except Exception: pass
    _PAGES.clear(); _LAST.clear()
    try:
        if _BR: _BR.close()
    except Exception: pass
    try:
        if _PW: _PW.stop()
    except Exception: pass
    _BR = _PW = None
    if _TMP: shutil.rmtree(_TMP, ignore_errors=True)
    _TMP = None


def browser_name():
    return getattr(_launch(), "_vs_name", "browser")


# ------------------------------------------------------------------ page assembly
def _theme_css(E):
    TH = E.TH; css = [":root{"]
    for k, v in E.C.items(): css.append(f"--{k}:{v};")
    for k, stem in TH.fonts.items(): css.append(f"--font-{k}:'VS-{k}';")
    css.append(f"--font-num:'VS-{getattr(TH, 'num_w', 'b') if getattr(TH, 'num_w', 'b') in TH.fonts else 'b'}';")          # the look's font for figures (lining numerals)
    table = [TH.ease(i / 48.0) for i in range(49)]
    css.append("--ease:linear(" + ",".join(f"{v:.4f}" for v in table) + ");")
    dark = _luma(E.C["bg1"]) < 0.45
    card = getattr(TH, "card_css", "") or (
        f"--card-fill:{E.C['card']};--card-border:2px solid {E.C['edge']};--card-radius:24px;"
        f"--card-shadow:0 16px 36px rgba(0,0,0,{0.40 if dark else 0.14});")
    css.append(card); css.append("}")
    for k, stem in TH.fonts.items():
        css.append(f"@font-face{{font-family:'VS-{k}';src:url(data:font/ttf;base64,{_b64(E._font_path(stem))}) format('truetype');font-weight:100 900;font-style:normal;}}")
    for name, fn in (("VS-Mono", "JetBrainsMono-Regular.woff2"), ):
        css.append(f"@font-face{{font-family:'{name}';src:url(data:font/woff2;base64,{_b64(os.path.join(RT, 'fonts', fn))}) format('woff2');font-weight:100 900;}}")
    return "\n".join(css)


def _luma(hexc):
    h = hexc.lstrip("#"); r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)); return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _katex_css():
    css = open(os.path.join(RT, "katex", "katex.min.css"), encoding="utf-8").read()
    return re.sub(r"url\(fonts/([^)]+)\)", lambda m: f"url(data:font/woff2;base64,{_b64(os.path.join(RT, 'katex', 'fonts', m.group(1)))})", css)


def build_html(E, src_path, cfg):
    """The author's HTML with the runtime injected at the top of <head>."""
    html = open(src_path, encoding="utf-8").read(); base = os.path.dirname(os.path.abspath(src_path)).replace("\\", "/")
    if not base.startswith("/"): base = "/" + base
    inj = [f'<base href="file://{urllib.parse.quote(base, safe="/:")}/">', f"<script>window.__VS_CFG={json.dumps(cfg)};</script>", f"<style id='vs-theme'>{_theme_css(E)}\n:root{{--dur:{cfg['dur']}s;" + "".join(f"--b{k}:{b}s;" for k, b in enumerate(cfg['beats'])) + "}</style>",
           f"<style id='vs-base'>{open(os.path.join(RT, 'vs.css'), encoding='utf-8').read()}</style>"]
    if re.search(r"data-tex|VS\.tex|katex", html, re.I):
        inj.append(f"<style id='vs-katex'>{_katex_css()}</style>"); inj.append(f"<script>{open(os.path.join(RT, 'katex', 'katex.min.js'), encoding='utf-8').read()}</script>")
    inj.append(f"<script>{open(os.path.join(RT, 'vs.js'), encoding='utf-8').read()}</script>")
    block = "\n".join(inj)
    m = re.search(r"<head[^>]*>", html, re.I)
    if m: return html[:m.end()] + "\n" + block + html[m.end():]
    m = re.search(r"<html[^>]*>", html, re.I)
    if m: return html[:m.end()] + "<head>" + block + "</head>" + html[m.end():]
    return "<!doctype html><html><head><meta charset='utf-8'>" + block + "</head><body>" + html + "</body></html>"


def scene_config(E, sc):
    TH = E.TH
    return dict(beats=[round(b, 4) for b in sc["bs"]], dur=round(sc["dur"], 4), palette=dict(E.C), fonts=dict(TH.fonts), theme=getattr(TH, "name", ""),
                ease=[round(TH.ease(i / 48.0), 5) for i in range(49)], dur_scale=TH.dur_scale, stagger_scale=TH.stagger_scale,
                scene=sc["i"] + 1, chapter=sc["s"]["chapter"], W=E.W, H=E.H)


def _tmpdir():
    global _TMP
    if _TMP is None: _TMP = tempfile.mkdtemp(prefix="vs_html_")
    return _TMP


def _open_page(E, key, src_path, cfg):
    br = _launch()
    while len(_PAGES) >= 2:                                                    # keep memory small: at most two scenes open per process
        k0 = next(iter(_PAGES)); pg, _ = _PAGES.pop(k0); _LAST.pop(k0, None)
        try: pg.context.close()
        except Exception: pass
    ctx = br.new_context(viewport={"width": E.W, "height": E.H}, device_scale_factor=E.SCALE)
    page = ctx.new_page(); page.set_default_timeout(45000); errs = []
    page.on("pageerror", lambda e: errs.append(f"JavaScript error: {e}"))
    page.on("console", lambda m: errs.append(f"console: {m.text}") if m.type == "error" else None)
    tmp = os.path.join(_tmpdir(), f"scene_{key}.html")
    open(tmp, "w", encoding="utf-8").write(build_html(E, src_path, cfg))
    page.goto(pathlib.Path(tmp).as_uri())
    page.evaluate("window.__vsWhenReady()")
    if any(x.startswith("JavaScript error") for x in errs):
        raise RuntimeError(f"HTML scene {cfg['scene']} ({os.path.basename(src_path)}) has a script problem: " + "; ".join(errs[:3]))
    _PAGES[key] = (page, errs)
    return page


def layer(E, tl, i, t):
    """A skia.Image of the HTML layer of scene i at scene-time t (transparent where the page draws nothing)."""
    sc = tl[i]; key = i
    if key not in _PAGES: _open_page(E, key, sc["s"]["html_path"], scene_config(E, sc))
    page, errs = _PAGES[key]
    sig = page.evaluate("t => window.__vsSeek(t)", float(t))
    last = _LAST.get(key)
    if last and last[0] == sig: return last[1]                                  # nothing on the page changed since the previous frame
    png = page.screenshot(type="png", omit_background=True)
    img = skia.Image.MakeFromEncoded(skia.Data.MakeWithCopy(png))
    if img is None: raise RuntimeError(f"HTML scene {i + 1}: the browser returned no picture")
    _LAST[key] = (sig, img)
    return img


def scene_warnings(i):
    """Messages the page printed to the console (for example an image that could not be found)."""
    return [m for m in _PAGES.get(i, (None, []))[1] if not m.startswith("JavaScript")]


# ------------------------------------------------------------------ self test (python studio.py doctor)
def selftest(E=None):
    """Draws html_runtime/selftest.html once. Returns (ok, message)."""
    try:
        if E is None:
            sys.path.insert(0, HERE); import engine as E
        sc = dict(i=0, bs=[0.0, 0.6, 1.2], dur=3.0, s=dict(chapter="SELF TEST", html_path=os.path.join(RT, "selftest.html")))
        old = E.SCALE; E.SCALE = 0.5
        try:
            img = layer(E, [sc], 0, 2.5)
            px = img.toarray(colorType=skia.kRGBA_8888_ColorType); h, w = px.shape[:2]
            opaque = int((px[:, :, 3] > 200).sum()); clear = int((px[:, :, 3] == 0).sum())
        finally: E.SCALE = old
        if opaque < 2000: return False, "the test page drew almost nothing (fonts or scripts failed to load)"
        if clear < w * h * 0.3: return False, "the page is not transparent (the layer would cover the background)"
        return True, f"{browser_name()} drew a transparent {w}x{h} layer ({100 * opaque // (w * h)}% covered)"
    except Exception as e:
        return False, str(e).strip().splitlines()[0][:300] if str(e).strip() else repr(e)
    finally:
        close()


if __name__ == "__main__":
    ok, msg = selftest(); print(("OK   " if ok else "FAIL ") + msg); sys.exit(0 if ok else 1)
