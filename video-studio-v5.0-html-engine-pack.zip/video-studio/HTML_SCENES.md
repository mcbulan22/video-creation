# HTML scenes (v5): the engine can draw a scene with a web page, scene by scene

One video, two engines. Each scene is drawn by whichever is better; the video, the commands, the narration, the sound and the look stay the same.

| Use HTML for | Use Python for |
|---|---|
| Tables, rubrics, matrices, long wrapping text, lists of criteria | Motion graphics: particles, flow fields, morphs, camera moves |
| Equations (real mathematical typesetting) | Charts that build and count up (S.bars, S.ring, S.linechart ...) |
| Code, formulas and UI mockups (windows, forms, typing) | Icons drawing themselves, text effects, custom Skia drawing |
| Anything that is naturally a web layout | Scenes that must render fast |

**How they fit together.** An HTML scene is drawn by your own Chrome (or Edge) as a transparent layer. The engine still draws the look's background, the top and bottom bars,
the fades, the scene-change flourish and the sound, so the two kinds of scene match. Nothing is downloaded: setup installs a small Python helper (`playwright`) and uses the browser already on your computer.

## In scenes.py
```python
@scene("RUBRIC", ["Narration beat 0.", "Narration beat 1.", "Narration beat 2."], html="html/rubric.html")
def s_rubric(S): pass                      # the page draws this scene; the function stays empty
@scene("RESULTS", [...], html="html/stats.html", fallback=True)
def s_results(S): ...                      # fallback=True: this Python drawing is used instead when Chrome is missing (or with --no-html)
```
The path is relative to the scenes file. Keep pages in `inbox/html/`. Starter pages: `html_templates/` (rubric_table, equation_steps, window_code, stat_cards). Full example: `examples/html_example.py`.

## Writing a page
Write ordinary HTML. The engine adds the look's colours, fonts, easing and card style, plus the narration timing. You never link anything.
```html
<!doctype html><html><head><meta charset="utf-8"></head><body><div class="stage">
  <h1 class="title" data-anim="rise" data-beat="0">A heading</h1>
  <div class="card" data-anim="pop" data-beat="1">Appears when narration beat 1 starts</div>
  <ul data-anim="rise" data-beat="2" data-stagger="0.15"><li>one</li><li>two</li></ul>      <!-- children arrive one by one -->
  <span class="big accent" data-count="1250" data-beat="3" data-dur="1.4">0</span>           <!-- counts up -->
  <div class="eq" data-tex="E = mc^2" data-anim="fade" data-beat="3"></div>                     <!-- equation -->
</div></body></html>
```
- **Timing**: `data-beat="k"` = start when beat k's narration starts; `data-delay` (seconds after), `data-dur` (seconds), `data-stagger` (on a parent: children one after another).
- **Animations** (`data-anim`): fade, rise, pop, zoom, slide-l, slide-r, wipe, grow-x, grow-y, draw (SVG strokes draw themselves).  `data-count` (number counts up; `data-decimals`, `data-prefix`, `data-suffix`), `data-type="text"` (typewriter), `data-tex="..."` (KaTeX equation).
- **Classes**: `stage` (the safe area, about 1640 x 830 px), `title`, `h2`, `sub`, `mute`, `accent`, `accent2`, `sky`, `good`, `bad`, `card`, `row`, `col`, `grid g2|g3|g4`, `grow`, `center`, `pill`, `big`, `b`, `m`, `bar` (with `<i style="width:70%">`), `table.vs`, `window` (with `.bar-top` and `.body`), `pre.code`, `code`.
- **Colours and fonts** are variables, so every look restyles the page: `var(--white)` (text), `--mute`, `--teal` (main accent), `--amber`, `--sky`, `--red`, `--green`, `--edge`, `--card`, `--bg1`, `--dark`; fonts `var(--font-b)` (bold), `--font-m`, `--font-r`, `--font-l`; `--card-fill`, `--card-border`, `--card-radius`, `--card-shadow`; easing `var(--ease)`.
- **Your own animation**: normal CSS keyframes, started by a beat: `animation: myframes .6s var(--ease) both; animation-delay: var(--b2);`  (`--b2` = start of beat 2, `--dur` = scene length).
- **Your own script**: `VS.onSeek((t) => { ... })` runs for any moment `t` (scene seconds); also `VS.p(beat, dur, delay)` (same progress and easing the Python tools use), `VS.beats`, `VS.palette`, `VS.clamp`, `VS.lerp`, `VS.fmt`. Canvas and SVG drawing in onSeek is fine.
- **Images**: files next to the page or in `inbox/` (relative paths). No web links.

## Rules
1. **A page must be a pure function of time.** Do not use real-time timers, `requestAnimationFrame` loops, `fetch`, video or audio, or CSS `transition`. Use `data-anim`, CSS keyframes with `animation-delay`, or `VS.onSeek`.
2. **No internet resources** (no CDN scripts, web fonts or remote images): the video must render offline and identically every time.
3. Body text 26 px or larger; stay inside `.stage`; no more than about 7 items per scene.
4. If your page uses `VS.onSeek`, every frame is captured (slower). Pages that only use `data-anim` and CSS keyframes skip frames where nothing changes.
5. HTML scenes get no motion blur (the `cinema` and `ultra` blur applies to Python scenes).

## Speed, honestly
HTML scenes render slower than Python scenes because every frame is a browser screenshot. In my test environment (no graphics card), a 10-second HTML scene at 720p took roughly 20 to 40 seconds to render with 3 browsers,
and 1080p will be slower. Your computer may be faster or slower. Tips: draft first (`--draft`); `--html-workers 5` on a strong computer (each browser uses about 300 MB);
prefer Python for scenes that are mostly motion.

## Check it works on your computer
`python studio.py doctor` (or `doctor.bat`) tests it in a few seconds: `[OK] HTML scenes: Google Chrome drew a transparent layer`.
Preview any page without rendering the video: `python scripts/contact_sheet.py inbox/scenes.py --out output/qa`.

## If something goes wrong
- *"No usable Chrome or Edge was found"*: install Google Chrome (https://www.google.com/chrome/); Windows already has Edge. Then run setup again.
  Different browser or location? Set `VS_CHROME`:  Mac `export VS_CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"`  Windows `set VS_CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe`
- *A managed or locked PC blocks it*: use `--no-html`. Scenes with `fallback=True` use their Python drawing; the others need the browser, and the build says which.
- *A script problem in a page*: the build stops and names the scene and the error.
- *Text looks different from the Python scenes*: both use the same bundled fonts; if you see a different font, the page set its own `font-family`; use `var(--font-r)` and friends.
