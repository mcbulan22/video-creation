/* vs.js: the runtime every HTML scene gets automatically (you do not link it).  Seekable: the page is drawn for any moment on request.
   window.VS  t (scene seconds) · beats (start time of each narration beat) · dur · palette · p(k,dur,delay) · ease(x) · onSeek(fn) · tex(el,src) · clamp · lerp · fmt
   Declarative animation (no JS needed):
     <div data-anim="rise" data-beat="1" data-delay="0.1" data-dur="0.6">        starts when narration beat 1 starts
     <ul data-anim="rise" data-beat="2" data-stagger="0.12">...</ul>              children arrive one after another
     data-anim: fade rise pop zoom slide-l slide-r wipe grow-x grow-y draw        (draw = SVG strokes drawing themselves)
     <span data-count="1250" data-beat="3" data-dur="1.4" data-decimals="0" data-prefix="" data-suffix="%">   number counts up
     <span data-type="Typed text" data-beat="1">                                  typewriter
     <div data-tex="E = mc^2" data-beat="1" data-anim="rise">                     KaTeX equation
   Rules: pure functions of time (no real-time timers, no fetch, no transitions; use animations or onSeek). */
(function () {
  const cfg = window.__VS_CFG || {beats: [0], dur: 10, palette: {}, ease: [0, 1], dur_scale: 1, stagger_scale: 1};
  const VS = window.VS = {cfg, t: 0, beats: cfg.beats, dur: cfg.dur, palette: cfg.palette, W: 1920, H: 1080, cbs: []};
  VS.clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  VS.lerp = (a, b, t) => a + (b - a) * t;
  VS.ease = function (x) {
    const tb = cfg.ease, n = tb.length - 1; if (x <= 0) return 0; if (x >= 1) return tb[n];
    const f = x * n, i = Math.floor(f); return tb[i] + (tb[i + 1] - tb[i]) * (f - i);
  };
  VS.p = function (k, dur = 0.55, delay = 0) {
    if (k >= VS.beats.length) return 0;
    return VS.ease((VS.t - VS.beats[k] - delay * cfg.stagger_scale) / (dur * cfg.dur_scale));
  };
  VS.beat = k => VS.beats[Math.min(k, VS.beats.length - 1)];
  VS.onSeek = fn => { VS.custom = true; VS.cbs.push(fn); };      // your own callback: every frame is captured (the engine cannot tell what changed)
  VS._dyn = [];
  VS.fmt = function (v, decimals = 0, prefix = '', suffix = '') {
    return prefix + v.toLocaleString('en-US', {minimumFractionDigits: decimals, maximumFractionDigits: decimals}) + suffix;
  };
  VS.tex = function (el, src, opts) {
    if (!window.katex) { el.textContent = src; return; }
    window.katex.render(src, el, Object.assign({throwOnError: false, trust: true, displayMode: true, strict: 'ignore'}, opts || {}));
  };
  function timing(el, inherit) {
    const g = (n, d) => el.hasAttribute(n) ? parseFloat(el.getAttribute(n)) : d;
    return {beat: g('data-beat', inherit ? inherit.beat : 0), delay: g('data-delay', 0), dur: g('data-dur', inherit ? inherit.dur : 0.6)};
  }
  function animate(el, name, tm, extraDelay) {
    const start = VS.beat(tm.beat) + (tm.delay + (extraDelay || 0)) * cfg.stagger_scale;
    el.style.animationName = 'vs-' + name; el.style.animationDuration = (tm.dur * cfg.dur_scale) + 's'; el.style.animationDelay = start + 's';
    if (name === 'draw') {
      const shapes = el.matches && el.matches('path,line,circle,rect,polyline,polygon,ellipse') ? [el] : Array.from(el.querySelectorAll('path,line,circle,rect,polyline,polygon,ellipse'));
      shapes.forEach(s => { s.setAttribute('pathLength', '1'); s.style.strokeDasharray = '1'; s.style.animationName = 'vs-draw'; s.style.animationDuration = (tm.dur * cfg.dur_scale) + 's'; s.style.animationDelay = start + 's'; s.style.animationFillMode = 'both'; s.style.animationTimingFunction = 'var(--ease)'; s.style.animationPlayState = 'paused'; });
      el.style.animationName = 'none';
    }
  }
  function setup() {
    if (VS.ready) return; VS.ready = true;
    document.querySelectorAll('[data-anim]').forEach(el => {
      const name = el.getAttribute('data-anim'), tm = timing(el);
      if (el.hasAttribute('data-stagger')) {
        const st = parseFloat(el.getAttribute('data-stagger'));
        Array.from(el.children).forEach((ch, i) => { ch.setAttribute('data-anim-child', name); animate(ch, name, timing(ch, tm), i * st); });
      } else animate(el, name, tm, 0);
    });
    document.querySelectorAll('[data-tex]').forEach(el => VS.tex(el, el.getAttribute('data-tex')));
    const counters = Array.from(document.querySelectorAll('[data-count]')).map(el => ({el, v: parseFloat(el.getAttribute('data-count')), tm: timing(el, {beat: 0, dur: 1.4}),
      dec: parseInt(el.getAttribute('data-decimals') || '0'), pre: el.getAttribute('data-prefix') || '', suf: el.getAttribute('data-suffix') || ''}));
    const typers = Array.from(document.querySelectorAll('[data-type]')).map(el => ({el, text: el.getAttribute('data-type'), tm: timing(el, {beat: 0, dur: 1.2})}));
    counters.forEach(c => VS._dyn.push(c.el)); typers.forEach(c => VS._dyn.push(c.el));
    VS.cbs.push(() => {
      counters.forEach(c => { const q = VS.clamp(VS.p(c.tm.beat, c.tm.dur, c.tm.delay)); c.el.textContent = VS.fmt(c.v * q, c.dec, c.pre, c.suf); c.el.style.opacity = q > 0 ? 1 : 0; });
      typers.forEach(c => { const q = VS.clamp(VS.p(c.tm.beat, c.tm.dur, c.tm.delay)); c.el.textContent = c.text.slice(0, Math.round(c.text.length * q)); });
    });
    window.__vsReadyFlag = true;
  }
  window.__vsSeek = function (t) {
    VS.t = t; document.documentElement.style.setProperty('--t', t);
    document.getAnimations().forEach(a => { try { a.pause(); a.currentTime = t * 1000; } catch (e) {} });
    for (const f of VS.cbs) f(t, VS);
    if (VS.custom) return 't' + t;                                   // cannot tell: always capture
    const sig = [];                                                  // otherwise: a fingerprint of everything that can change, so identical frames are not captured twice
    for (const a of document.getAnimations()) { const ct = a.effect && a.effect.getComputedTiming(); sig.push(ct && ct.progress != null ? ct.progress.toFixed(4) : 'n'); }
    for (const el of VS._dyn) sig.push(el.textContent);
    return sig.join('|');
  };
  window.__vsWhenReady = async function () {
    if (document.readyState === 'loading') await new Promise(r => document.addEventListener('DOMContentLoaded', r));
    setup(); if (document.fonts && document.fonts.ready) await document.fonts.ready; return true;
  };
  if (document.readyState !== 'loading') setup(); else document.addEventListener('DOMContentLoaded', setup);
})();
