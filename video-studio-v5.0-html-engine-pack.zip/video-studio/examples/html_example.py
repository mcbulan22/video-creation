"""HTML scenes example: Python and HTML scenes in ONE video. Render:  sh make.sh --scenes examples/html_example.py --draft   (PC: make.bat ...)
Scenes 2-4 are drawn by web pages (see html_templates/), scene 5 has a Python fallback that is used when Chrome is not available.
Everything else (background, bars, fades, scene changes, sound) comes from the same engine, so the scenes match.   Read HTML_SCENES.md"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
from engine import *

THEME = "aurora"
DECK_TITLE = "HTML scenes demo"
HT = "../html_templates/"          # the starter pages; copy one into inbox/html/ and edit it for your own video


@scene("TITLE", [
    "This video mixes two engines.",
    "Python draws the motion graphics, and web pages draw tables, equations and code.",
], sky=True)
def s_title(S):
    S.glow(960, 300, 420, "teal", 0.18, S.p(0, 1.2))
    S.grad_text("Two engines", 960, 300, 132, ("teal", "amber"), "b", "c", S.p(0, 1.0), shimmer=True)
    S.kinetic("One video, scene by scene the better tool", 960, 392, 46, "mute", "m", "c", S.p(1, 0.9), mode="blur")
    S.ship(960, 640 - 34, 0.85, "dark", S.p(1, 0.8))


@scene("TABLES", [
    "A web page lays out a rubric by itself, however long the wording is.",
    "Rows arrive one after another, and the weights count up.",
    "Then the column that matters is shaded.",
    "Example content, to be replaced with your own criteria.",
], html=HT + "rubric_table.html")
def s_table(S): pass


@scene("EQUATIONS", [
    "Equations are typeset with real mathematical notation.",
    "Item difficulty is the share of candidates who answered correctly.",
    "Discrimination compares the upper and lower groups.",
    "And reliability asks whether the items measure one thing consistently.",
], html=HT + "equation_steps.html")
def s_eq(S): pass


@scene("CODE AND UI", [
    "A window mockup can show a formula being typed.",
    "The formula counts everyone at or above the pass mark.",
    "And the answer fills in beside it.",
    "These are example values for illustration.",
], html=HT + "window_code.html")
def s_code(S): pass


@scene("FALLBACK", [
    "This scene has a web page and a Python version.",
    "If Chrome is missing, the Python version is used and the video still renders.",
], html=HT + "stat_cards.html", fallback=True)
def s_stat(S):
    S.text("The results at a glance", 960, 215, 62, "white", "b", "c", S.p(0), maxw=1600)
    for i, (v, lab, col, unit) in enumerate([(1250, "Cadets assessed", "teal", ""), (98, "Items validated", "green", "%"), (24, "Exam sessions", "amber", "")]):
        S.stat(v, lab, 150 + i * 580, 380, 500, 300, S.p(1, 0.6, 0.15 * i), col, "{:,.0f}", unit, None, S.p(1, 1.4, 0.15 * i))
    S.text("Example data", 960, 800, 30, "mute", "m", "c", S.p(1, 0.6, 0.5))
