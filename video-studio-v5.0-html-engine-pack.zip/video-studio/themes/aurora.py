"""AURORA: modern dark glass. Drifting colour glow, frosted cards, gradient and kinetic headings, light-sweep scene changes."""
import math, random
import skia
import engine as E
import motion_kit as K
from engine import Theme, hexc, C, W, H

VIOLET = "#8B5CF6"
HZ = 640
_EXPO = E.bezier(0.2, 1.4, 0.3, 1)          # fast launch, long soft landing, a 5% settle


def _specks():
    rnd = random.Random(9)
    return [(rnd.random() * W, rnd.random() * H, rnd.uniform(1.2, 3.2), rnd.uniform(6, 22), rnd.random() * 6.28) for _ in range(46)]
_SP = _specks()


class Aurora(Theme):
    name = "aurora"
    label = "Aurora: dark glass, drifting colour glow, gradient + kinetic headings, light-sweep transitions"
    palette = dict(bg1="#070A1A", bg2="#0F1436", card="#141A3C", edge="#4352A0", white="#F5F7FF", mute="#9CA8D6",
                   teal="#3DE8C8", amber="#FFB36B", red="#FF5C8A", green="#4ADE80", sky="#6AA8FF", dark="#050716")
    fonts = dict(l="Inter-Light", r="Inter-Regular", m="Inter-Medium", b="Inter-Bold")
    pop = 0.04; slide_in = 70; slide_out = 60; push = 0.025; transition_dur = 0.85; glow_mult = 1.3
    reveal = "words"; kin_mode = "rise"; kin_min = 52
    card_css = ("--card-fill:linear-gradient(135deg,rgba(255,255,255,.13),rgba(255,255,255,.045));--card-border:1.6px solid rgba(255,255,255,.28);"
                "--card-radius:28px;--card-shadow:0 16px 40px rgba(0,0,0,.42);")
    personality = "Fluid-modern: expo-out launch, words rise from masks, glass cards settle"
    dur_scale = 0.9; dy_scale = 0.8; stagger_scale = 0.35; fade_out_scale = 0.7; text_lag = 1.15; parallax = 0.22
    def ease(self, x): return _EXPO(x)

    # ---- backgrounds
    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, H)], [hexc(C["bg2"]), hexc(C["bg1"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        v = skia.Paint(); v.setShader(skia.GradientShader.MakeRadial(skia.Point(W / 2, H / 2), 1300, [hexc("#000000", 0), hexc("#000000", .55)], [.5, 1]))
        c.drawRect(skia.Rect.MakeWH(W, H), v)

    def fx(self, c, T):
        for cx, cy, r, col, a in [(W * (.16 + .07 * math.sin(.17 * T)), H * (.22 + .09 * math.cos(.13 * T)), 760, VIOLET, .30),
                                  (W * (.84 + .06 * math.cos(.14 * T)), H * (.78 + .07 * math.sin(.16 * T)), 820, C["teal"], .18),
                                  (W * (.55 + .10 * math.sin(.09 * T + 1)), H * (.95 + .04 * math.cos(.2 * T)), 700, C["sky"], .22),
                                  (W * (.72 + .05 * math.cos(.1 * T)), H * (.08 + .05 * math.sin(.12 * T)), 520, C["red"], .10)]:
            pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(col, a), hexc(col, 0)], [0, 1]))
            c.drawCircle(cx, cy, r, pt)
        for x0, y0, r, v, ph in _SP:                                       # drifting light specks
            y = (y0 - T * v) % (H + 80) - 40; x = x0 + 18 * math.sin(.4 * T + ph); tw = .35 + .35 * math.sin(1.2 * T + ph)
            c.drawCircle(x, y, r * 3.2, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .05 * tw)))
            c.drawCircle(x, y, r, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .45 * tw)))

    def hero_bg(self, c, T):
        E.draw_bg(c); self.fx(c, T)
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(W / 2, 360), 640, [hexc(C["teal"], .16), hexc(C["teal"], 0)], [0, 1]))
        c.drawCircle(W / 2, 360, 640, g)
        for k, (rad, sp, col) in enumerate([(300, .16, "teal"), (430, -.11, "sky"), (570, .07, "red")]):          # orbit rings with riders
            ang = T * sp * 2 * math.pi
            for j in range(18):
                a0 = j * 2 * math.pi / 18 + ang; pa = skia.Path()
                pa.addArc(skia.Rect.MakeXYWH(W / 2 - rad, 380 - rad * .55, 2 * rad, 2 * rad * .55), math.degrees(a0), 8.0)
                st = skia.Paint(AntiAlias=True, Color=hexc(C[col], .28)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2); c.drawPath(pa, st)
            rx, ry = W / 2 + rad * math.cos(ang * 3), 380 + rad * .55 * math.sin(ang * 3)
            c.drawCircle(rx, ry, 14, E.blur_paint(col, .9, 7)); c.drawCircle(rx, ry, 5, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF")))
        fl = skia.Paint(); fl.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ), skia.Point(0, H)], [hexc(C["sky"], .20), hexc(C["bg1"], .0)]))
        c.drawRect(skia.Rect.MakeXYWH(0, HZ, W, H - HZ), fl)                # glassy "sea" below the horizon
        hz = skia.Paint(); hz.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, 0)], [hexc(C["teal"], 0), hexc(C["teal"], .95), hexc(VIOLET, .95), hexc(C["teal"], 0)], [0, .35, .65, 1]))
        c.drawRect(skia.Rect.MakeXYWH(0, HZ - 1, W, 3), hz); c.drawRect(skia.Rect.MakeXYWH(0, HZ - 6, W, 12), self._soft(hz))
        for k in range(6):
            pa = skia.Path(); y0 = HZ + 34 + k * 46; pa.moveTo(0, y0)
            for xx in range(0, W + 8, 8): pa.lineTo(xx, y0 + (4 + k) * math.sin(xx / (90 + 20 * k) + T * (.6 + .12 * k) + k))
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .22 - .03 * k)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2.5); c.drawPath(pa, st)

    @staticmethod
    def _soft(p):
        p2 = skia.Paint(p); p2.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, 9)); return p2

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 5 * math.sin(1.1 * ctx.t)
        c.save(); c.translate(cx, cy + (1 - p) * 30 + bob); c.rotate(1.2 * math.sin(.8 * ctx.t)); c.scale(sc, sc)
        gp = skia.Paint(AntiAlias=True); gp.setShader(skia.GradientShader.MakeLinear([skia.Point(-170, -95), skia.Point(170, 55)], [hexc("#12183A", pp), hexc("#2B3680", pp)]))
        c.drawPath(g["hull"], gp)
        for k in ("cabin", "bridge", "funnel"):
            x, y, w, h, r = g[k]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, gp)
        rim = skia.Paint(AntiAlias=True); rim.setShader(skia.GradientShader.MakeLinear([skia.Point(-170, 0), skia.Point(170, 0)], [hexc(C["teal"], pp), hexc(VIOLET, pp)]))
        rim.setStyle(skia.Paint.kStroke_Style); rim.setStrokeWidth(4); rim.setStrokeJoin(skia.Paint.kRound_Join)
        c.drawPath(g["hull"], E.blur_paint("teal", .5 * pp, 8, 7)); c.drawPath(g["hull"], rim)
        for k in ("cabin", "bridge", "funnel"):
            x, y, w, h, r = g[k]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, rim)
        for x, y, w, h in g["windows"]: c.drawRect(skia.Rect.MakeXYWH(x, y, w, h), ctx.paint("amber", .95 * pp))
        c.restore(); return True

    # ---- cards: frosted glass with a gradient edge and a soft shadow
    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0); L, T, R, B = rect.left(), rect.top(), rect.right(), rect.bottom()
        if fill:
            E.soft_shadow(c, rect, r, dy=16, sigma=20, color="#000000", a=.42 * pp)
            tint = C.get(fill, fill); accent = fill not in ("card", "bg1", "bg2", "dark")
            gp = skia.Paint(AntiAlias=True)
            top, bot = (hexc(tint, .30 * pp * fa), hexc(tint, .12 * pp * fa)) if accent else (hexc("#FFFFFF", .13 * pp * fa), hexc("#FFFFFF", .045 * pp * fa))
            gp.setShader(skia.GradientShader.MakeLinear([skia.Point(L, T), skia.Point(R, B)], [top, bot])); c.drawRoundRect(rect, r, r, gp)
            if rect.height() >= 70:
                hl = skia.Paint(AntiAlias=True); hl.setShader(skia.GradientShader.MakeLinear([skia.Point(L, 0), skia.Point(R, 0)], [hexc("#FFFFFF", 0), hexc("#FFFFFF", .45 * pp), hexc("#FFFFFF", 0)], [0, .5, 1]))
                hl.setStrokeWidth(2); c.drawLine(L + r, T + 1.5, R - r, T + 1.5, hl)          # light catching the top edge
        if stroke:
            if stroke == "edge" or not fill:
                bp = skia.Paint(AntiAlias=True); bp.setStyle(skia.Paint.kStroke_Style); bp.setStrokeWidth(max(1.6, sw * .6))
                bp.setShader(skia.GradientShader.MakeLinear([skia.Point(L, T), skia.Point(R, B)], [hexc("#FFFFFF", .42 * pp), hexc(C["edge"], .35 * pp), hexc("#FFFFFF", .10 * pp)], [0, .5, 1]))
                if dash: bp.setPathEffect(skia.DashPathEffect.Make(dash, 0))
                c.drawRoundRect(rect, r, r, bp)
            else:
                c.drawRoundRect(rect, r, r, E.blur_paint(stroke, .5 * pp, 9, sw + 2)); c.drawRoundRect(rect, r, r, ctx.paint(stroke, pp, max(2, sw * .8), dash))

    def after_text(self, ctx, info, size, color, p):
        pass

    # ---- chrome: chapter chip, counter, gradient progress line
    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        c = ch.c; f = E.font("m", 22); tw = f.measureText(chapter.upper())
        c.drawRoundRect(skia.Rect.MakeXYWH(62, 40, tw + 62, 44), 22, 22, ch.paint("white", .07 * a)); c.drawRoundRect(skia.Rect.MakeXYWH(62, 40, tw + 62, 44), 22, 22, ch.paint("white", .22 * a, 1.5))
        c.drawCircle(86, 62, 12, E.blur_paint("teal", .9 * a, 6)); c.drawCircle(86, 62, 5, ch.paint("teal", a))
        ch.text(chapter.upper(), 108, 70, 22, "white", "m", "l", a * .9, _rev=False, _deco=False)
        ch.text(f"{i + 1:02d} / {n:02d}", W - 70, 70, 24, "mute", "m", "r", a * .85, _rev=False, _deco=False)
        ch.text(deck, 70, 1036, 20, "mute", "m", "l", .6 * foot_a, _rev=False, _deco=False)
        c.drawRoundRect(skia.Rect.MakeXYWH(70, 1054, W - 140, 5), 2.5, 2.5, ch.paint("white", .10 * a))
        fw = (W - 140) * (i + 1) / n; gp = skia.Paint(AntiAlias=True)
        gp.setShader(skia.GradientShader.MakeLinear([skia.Point(70, 0), skia.Point(70 + max(fw, 2), 0)], [hexc(C["teal"], a), hexc(VIOLET, a)]))
        c.drawRoundRect(skia.Rect.MakeXYWH(70, 1054, fw, 5), 2.5, 2.5, gp)

    def transition(self, c, t, sc):
        K.tr_wipe(c, t, [VIOLET, C["sky"], C["teal"]], dur=0.7, skew=150, lag=0.07)


THEME = Aurora()
