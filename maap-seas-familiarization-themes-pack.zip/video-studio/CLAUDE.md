# Instructions for Claude Code (read this first)

This folder makes narrated motion-graphics videos. The scenes file is ready-made in `inbox/scenes.py`.
**Do NOT rewrite scenes.py or the files in scripts/.** Only run the commands below and report what happens.

## Commands (run from this folder)
- First time only: `sh setup_mac.sh`
- Quick test: `sh make.sh --draft`
- Final: `sh make.sh`
- With the user's own recordings (folder `my_voice`, names listed in `narration_script.txt`): `sh make.sh --own-voice`
- Picture only: `sh render.sh --draft`
- Slow Mac: add `--fx off`
- Music: `inbox/music.mp3` is used automatically, or `sh make.sh --music pad`
- Another voice: `sh make.sh --voice-name Daniel` (list: `say -v '?'`)

## Result
`output/final_with_audio.mp4` (also `full_video_with_captions.mp4`, `script_cues.srt`, `output/qa/` review sheets).

## If something fails
Show the last 15 lines of the error in plain words, fix only the obvious cause (missing ffmpeg: `brew install ffmpeg`; missing `.venv`: `sh setup_mac.sh`; missing recordings: tell the user the file names printed), then re-run. If a scene looks wrong, tell the user to ask Claude chat to fix `inbox/scenes.py`.
