# Themes

A theme is one small Python file in the `themes/` folder. It decides how everything looks and moves.
Your scenes (`inbox/scenes.py`) do not change: the same script renders in any theme.

## Using a theme
    sh make.sh --theme playful          final video in that look
    sh make.sh --theme playful --draft  quick 720p test
    sh make.sh --list-themes
    sh preview_themes.sh                stills of every look (output/theme_preview/overview.png)
    sh preview_themes.sh techno         stills of one look only (every scene, 4 sheets)

No `--theme` = **clean**. You can also pin a look inside a scenes file by adding a line `THEME = "formal"`
near the top of `inbox/scenes.py` (the `--theme` option still wins when you give it).

## The six looks
| Theme | Feel | Motion | Title scene |
|---|---|---|---|
| clean (default) | light, neutral, soft shadows, one blue accent | gentle, small settle | pulsing rings over a pale sea, flat ship |
| ocean | the original deep-sea blues | drifting light, rising particles | sunrise horizon, then the camera dives underwater |
| techno | dark, neon cyan and magenta, HUD brackets | snappy, typewriter text, scan lines | synthwave sun and neon grid floor, neon ship |
| classroom | chalkboard in a wooden frame, handwriting | boxes draw themselves, chalk dust | chalk doodles: sun, cloud, stars, waves, chalk ship |
| formal | ivory paper, navy and gold, serif type | slow fades, no bounce | compass-rose watermark, gold rule, navy ship |
| playful | bright colours, sticker cards | big bounces, confetti, floating shapes | smiling sun, clouds, cartoon ship that rocks |

Notes
- Only **ocean** has the dive-underwater transition and its splash sound. Other looks use their own scene changes.
- Colour names in scenes are **roles**, not literal colours: `white` = main text, `teal` = main accent, `amber` = second accent,
  `card` / `edge` = card fill / border. Each theme sets what those mean, so light themes still get dark text.
- Fonts used (all open-licence, in `fonts/`, licences in `fonts/licenses/`): Poppins, Inter, Chakra Petch, Kalam, Lora, Playfair Display, Fredoka.

## Make your own look
1. Copy `themes/clean.py` to `themes/mylook.py`.
2. Change the `palette`, the `fonts` (names of files in `fonts/`, without `.ttf`), and the motion numbers
   (`overshoot` = bounce, `dur_scale` = speed, `dy_scale` = slide distance, `pop` = grow-in).
3. Optional hooks you can override: `background`, `fx` (animated background), `hero_bg` (title scene),
   `draw_card`, `after_text` (heading decoration), `ship`, `chrome` (chapter / page number / footer), `transition`.
4. Test: `sh preview_themes.sh mylook`, then `sh make.sh --theme mylook --draft`.
Keep the first line of the file a one-line description: it is shown by `--list-themes`.
