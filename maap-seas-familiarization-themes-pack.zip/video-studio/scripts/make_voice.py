#!/usr/bin/env python3
"""Create one voice clip per beat (so the video can be timed EXACTLY to the voice).

  python make_voice.py inbox/scenes.py --out output/voice [--engine mac] [--voice Samantha] [--rate 170]

Engines:
  mac   - the built-in macOS `say` command (free, offline). Better voices: System Settings > Accessibility >
          Spoken Content > System Voice > Manage Voices, download an "Enhanced" or "Premium" one, then pass its name.
          List voices with:  say -v '?'
  fake  - silent placeholder tones of the right length (only for testing the pipeline)
Writes OUT/s01_b01.wav ... and OUT/durations.json.
"""
import argparse, importlib.util, json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E

def load(path):
    spec = importlib.util.spec_from_file_location("deck_scenes", path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m

def dur(path):
    return float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).decode().strip())

EXTS = [".wav", ".m4a", ".mp3", ".aiff", ".aif", ".caf", ".aac", ".flac", ".ogg", ".mp4"]

def own(a):
    """Use YOUR recordings: one file per beat named s01_b01.wav, s01_b02.wav ... (any common audio format).
    Each file is converted to WAV, silence at the start/end is trimmed, and the loudness is evened out."""
    missing, res = [], {}
    for i, s in enumerate(E.SCENES):
        for k in range(len(s["beats"])):
            stem = f"s{i+1:02d}_b{k+1:02d}"
            src = next((os.path.join(a.src, stem + e) for e in EXTS + [x.upper() for x in EXTS] if os.path.exists(os.path.join(a.src, stem + e))), None)
            if not src: missing.append(stem); continue
            wav = os.path.join(a.out, stem + ".wav")
            trim = "silenceremove=start_periods=1:start_threshold=-48dB:start_silence=0.05"
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-af",
                            f"{trim},areverse,{trim},areverse,aresample=44100,loudnorm=I=-16:TP=-1.5:LRA=11,aresample=44100", "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
            res[f"{i},{k}"] = dur(wav); print(f"{stem}: {res[f'{i},{k}']:.1f}s", flush=True)
    if missing:
        print("\nMISSING recordings in folder '%s':" % a.src)
        for m in missing: print("  ", m)
        print("Record these (see narration_script.txt for the words), save them with exactly these names, and run again.")
        sys.exit(1)
    json.dump(res, open(os.path.join(a.out, "durations.json"), "w"), indent=1)
    print(f"your voice: total {sum(res.values()):.0f}s -> {os.path.join(a.out, 'durations.json')}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenes"); ap.add_argument("--out", required=True)
    ap.add_argument("--engine", choices=["mac", "own", "fake"], default="mac")
    ap.add_argument("--src", default="my_voice", help="folder with YOUR recordings (engine own)")
    ap.add_argument("--voice", default="Samantha"); ap.add_argument("--rate", type=int, default=170)
    a = ap.parse_args()
    load(a.scenes); os.makedirs(a.out, exist_ok=True); res = {}
    if a.engine == "own":
        return own(a)
    for i, s in enumerate(E.SCENES):
        for k, text in enumerate(s["beats"]):
            wav = os.path.join(a.out, f"s{i+1:02d}_b{k+1:02d}.wav")
            if a.engine == "mac":
                tmp = wav + ".aiff"
                subprocess.run(["say", "-v", a.voice, "-r", str(a.rate), "-o", tmp, "--", text], check=True, stdin=subprocess.DEVNULL)
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
                os.remove(tmp)
            else:
                d = len(text.split()) / 2.6
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"sine=f=220:d={d:.2f}",
                                "-af", "volume=0.05", "-ar", "44100", "-ac", "1", wav], check=True, stdin=subprocess.DEVNULL)
            res[f"{i},{k}"] = dur(wav)
            print(f"scene {i+1} beat {k+1}: {res[f'{i},{k}']:.1f}s", flush=True)
    json.dump(res, open(os.path.join(a.out, "durations.json"), "w"), indent=1)
    print(f"voice total {sum(res.values()):.0f}s -> {os.path.join(a.out, 'durations.json')}")

if __name__ == "__main__":
    main()
