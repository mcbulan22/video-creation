# video-studio v3 - themes (six looks), voice, sound, horizon title + dive-in

## NEW in v3: choose a look
Same scenes, same narration, six designs. The default is **clean**. Pick another only when you want to:

    sh make.sh --theme ocean        the original look: deep-sea blues, sunrise horizon, dive underwater
    sh make.sh --theme techno       dark neon grid, glowing HUD cards, typewriter text, synthwave title
    sh make.sh --theme classroom    chalkboard, handwriting, hand-drawn boxes and chalk doodles
    sh make.sh --theme formal       ivory and navy with gold rules, serif type, calm fades
    sh make.sh --theme playful      bright colours, bouncy pop-ins, sticker cards, confetti, cartoon ship
    sh make.sh --list-themes        list them
    sh preview_themes.sh            see ALL looks as still images in under a minute (output/theme_preview/overview.png)

Add `--draft` to any of them for a quick 720p test. `reference/theme_overview.png` shows what each look is like.
More detail, and how to make your own look: see THEMES.md.

IMPORTANT: the default look changed from ocean to clean. To get exactly what you rendered before, use `--theme ocean`.

## What's in this pack
- Narrated video in one command: picture + voice-over + whoosh/splash sounds + optional music (ducks under the voice).
- NEW: the title scene is a sunrise **horizon**; at its end the camera **dives into the sea** (bubbles, light rays, splash sound) and the rest of the deck plays underwater.
- NEW: **your own voice**: record per-beat clips, run `sh make.sh --own-voice`.
- `narration_script.txt` lists every beat with the file name to record under. It is rebuilt every time you run make.sh.
- The finished Class 2030 deck (12 scenes, about 3 minutes) is in `inbox/scenes.py`.

## Install (once)
(v3 adds a `themes` folder and extra fonts: copy the WHOLE pack over your folder, do not pick files.)
1. Unzip the pack. Drag everything inside its `video-studio` folder into your existing `video-studio` folder.
2. Choose **Replace** for each item. Keep your hidden `.venv` folder (the pack doesn't contain one).
   Do NOT replace the whole `scripts` folder with a partial one: always use the complete pack.
3. No new setup is needed.

## Make the video
Terminal: type `cd ` (with a space), drag your `video-studio` folder into the window, press Enter. Then:

    sh make.sh --draft        quick test (720p)
    sh make.sh                final 1080p
    sh make.sh --fx off       faster, calmer background (the dive still plays)

Result: `output/final_with_audio.mp4`.

## Use your own voice
1. Open `narration_script.txt`. Each line starts with a file name such as `[s02_b01]`, followed by the exact words.
2. Record each beat as its own file with that name. Quiet room, phone 20-30 cm from your mouth, natural pace.
   WAV, M4A (iPhone Voice Memos), MP3 and AIFF all work.
3. Put all the files in the `my_voice` folder (23 files for the Class 2030 deck).
4. Run `sh make.sh --own-voice`. If any file is missing, it tells you exactly which ones.
Tip: re-recording one line? Replace just that file and run again.

## Options
- Music: save a royalty-free MP3 as `inbox/music.mp3` (picked up automatically), or `sh make.sh --music pad`.
- Logo: save `logo.png` in `inbox/`; it appears on the title scene (top right).
- Other Mac voice: `sh make.sh --voice-name Daniel`. Better voices: System Settings > Accessibility > Spoken Content > System Voice > Manage Voices.
- Silent picture only: `sh render.sh --draft`.

## Using Claude Code (optional)
Run `ollama launch claude` in the folder and paste the text from `CLAUDE_CODE_PROMPT.txt`. The plain commands above cost no credits.

## A new video
Use `CHAT_PROMPT.md` in Claude chat. Put the new `scenes.py` into `inbox/` and run `sh make.sh --draft`.
For a horizon-and-dive title, the first scene is written with `sky=True` (see CHAT_PROMPT.md).
