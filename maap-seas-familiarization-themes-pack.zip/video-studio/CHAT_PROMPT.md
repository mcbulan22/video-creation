# Prompt to paste into Claude chat (with the scene-video-studio skill) for a NEW video
(Attach the video-studio pack zip you already have, so Claude uses the same engine.)

Use the scene-video-studio skill. Make a new scenes.py for my video-studio v2 pack from the material I attach.
- About ___ minutes, about 12 scenes, audience: ___.
- Beat text = the exact narration (read aloud by a computer voice or by me).
- Scene 1 = horizon title (sky=True) that dives into the sea; the rest are underwater scenes.
- Use S.num count-ups, S.glow and springy reveals. Check every scene for overlapping or overflowing text.
- Deliver the full pack as a zip (scenes.py + narration_script.txt + the engine), not a rendered video.
