"""CLEAN (default): light, neutral and calm. Soft shadows, one blue accent, gentle motion.
A safe choice for any audience."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H

HZ = 650          # waterline of the title scene


class Clean(Theme):
    name = "clean"
    label = "Clean (default): light and neutral, soft shadows, one blue accent"
    palette = dict(bg1="#F8FAFC", bg2="#E9EEF6", card="#FFFFFF", edge="#D3DBE6", white="#18212F", mute="#667386",
                   teal="#2563EB", amber="#C96A00", red="#DC3F4D", green="#17A05B", sky="#7AA7F7", dark="#0F1A2B")
    fonts = dict(l="Inter-Light", r="Inter-Regular", m="Inter-Medium", b="Inter-Bold")
    overshoot = 0.6; dy_scale = 0.8; pop = 0.03; slide_in = 60; slide_out = 50; push = 0.02

    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        dot = skia.Paint(AntiAlias=True, Color=hexc(C["edge"], .55))
        for gx in range(24, W, 48):
            for gy in range(24, H, 48): c.drawCircle(gx, gy, 1.5, dot)

    def fx(self, c, T):
        for cx, cy, r, col, a in [(W * (.14 + .06 * math.sin(.12 * T)), H * (.22 + .08 * math.cos(.10 * T)), 720, "teal", .07),
                                  (W * (.88 + .05 * math.cos(.09 * T)), H * (.80 + .06 * math.sin(.13 * T)), 780, "amber", .05),
                                  (W * (.60 + .08 * math.sin(.07 * T + 1)), H * (.08 + .04 * math.cos(.16 * T)), 520, "sky", .08)]:
            pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(C[col], a), hexc(C[col], 0)], [0, 1]))
            c.drawCircle(cx, cy, r, pt)
        rnd = random.Random(3)
        for k in range(9):
            x0, y0, v, rad, ph = rnd.random() * W, rnd.random() * H, rnd.uniform(8, 20), rnd.uniform(14, 44), rnd.random() * 6.28
            y = (y0 - T * v) % (H + 120) - 60; x = x0 + 16 * math.sin(.3 * T + ph)
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .10)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2)
            c.drawCircle(x, y, rad, st)

    def hero_bg(self, c, T):
        c.drawImage(E.bg_image(), 0, 0)
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(960, 330), 780, [hexc(C["teal"], .10), hexc(C["teal"], 0)], [0, 1]))
        c.drawCircle(960, 330, 780, g)
        for k in range(4):                                         # slow pulsing rings
            u = ((T * 0.12) + k / 4.0) % 1.0; rad = 200 + u * 620
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .16 * (1 - u))); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2)
            c.drawCircle(960, HZ - 20, rad, st)
        sea = skia.Paint(); sea.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ), skia.Point(0, H)], [hexc("#DCE7FB"), hexc("#BFD2F5")]))
        c.drawRect(skia.Rect.MakeXYWH(0, HZ, W, H - HZ), sea)
        for k in range(4):
            pa = skia.Path(); y0 = HZ + 2 + k * 70; pa.moveTo(0, y0)
            for xx in range(0, W + 8, 8): pa.lineTo(xx, y0 + (4 + k) * math.sin(xx / (80 + 15 * k) + T * (.6 + .12 * k) + k))
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .30 - .06 * k)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(3)
            c.drawPath(pa, st)

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 5 * math.sin(1.1 * ctx.t)
        c.drawOval(skia.Rect.MakeXYWH(cx - 190 * sc, cy + 55 * sc + 10, 380 * sc, 16), ctx.paint("teal", .12 * pp))
        c.save(); c.translate(cx, cy + (1 - p) * 30 + bob); c.scale(sc, sc)
        c.drawPath(g["hull"], ctx.paint("teal", pp))
        for key, col in (("cabin", "#EAF1FE"), ("bridge", "#C9DAFB"), ("funnel", "amber")):
            x, y, w, h, r = g[key]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ctx.paint(col, pp))
        for x, y, w, h in g["windows"]: c.drawRect(skia.Rect.MakeXYWH(x, y, w, h), ctx.paint("teal", pp))
        c.restore(); return True

    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0)
        if fill:
            E.soft_shadow(c, rect, r, 0, 8, 12, "#1B2A41", .10 * pp * fa)
            c.drawRoundRect(rect, r, r, ctx.paint(fill, p * fa))
        if stroke: c.drawRoundRect(rect, r, r, ctx.paint(stroke, p, min(sw, 2.0) if stroke == "edge" else sw, dash))

    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 80:                                       # short accent bar under headings
            xx, yy, tw = info[-1]; q = max(0.0, min(1.0, p)); cx = xx + tw / 2
            ctx.c.drawRoundRect(skia.Rect.MakeXYWH(cx - 48 * q, yy + 24, 96 * q, 6), 3, 3, ctx.paint("teal", q))

    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        Theme.chrome(self, ch, chapter, i, n, deck, a, foot_a)
        ch.c.drawRoundRect(skia.Rect.MakeXYWH(70, 1070, W - 140, 4), 2, 2, ch.paint("edge", .6 * a))          # progress bar
        ch.c.drawRoundRect(skia.Rect.MakeXYWH(70, 1070, (W - 140) * (i + 1) / n, 4), 2, 2, ch.paint("teal", .9 * a))

    def transition(self, c, t, sc):
        x = -520 + (W + 520) * E.ease(t / 0.75); sp = skia.Paint()
        sp.setShader(skia.GradientShader.MakeLinear([skia.Point(x, 0), skia.Point(x + 520, 0)], [hexc(C["teal"], 0), hexc(C["teal"], .9)]))
        c.drawRect(skia.Rect.MakeXYWH(x, 0, 520, 5), sp)


THEME = Clean()
