"""CLASSROOM: a chalkboard. Hand-drawn chalk boxes that draw themselves, handwriting font, doodles on the title board."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H
from _common import rrect_points, line_points, arc_points, wobble, stroke_poly

HZ = 650


class Classroom(Theme):
    name = "classroom"
    label = "Classroom: chalkboard, handwriting, hand-drawn boxes and chalk doodles"
    palette = dict(bg1="#1E3A33", bg2="#2B4C42", card="#294A40", edge="#B9CFC4", white="#F6F7F1", mute="#A8C0B5",
                   teal="#FFD95A", amber="#FF9FB0", red="#FF7A7A", green="#9BE8A9", sky="#8FCBFF", dark="#17302A")
    fonts = dict(l="Kalam-Light", r="Kalam-Regular", m="Kalam-Regular", b="Kalam-Bold")
    overshoot = 0.9; dy_scale = 1.0; pop = 0.04; slide_in = 70; slide_out = 60; push = 0.02; transition_dur = 0.9

    # ---------------------------------------------------------------- backgrounds
    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, H)], [hexc(C["bg1"]), hexc(C["bg2"]), hexc(C["bg1"])], [0, .55, 1]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        rnd = random.Random(9)
        for _ in range(16):                                            # chalk smudges
            x, y, r = rnd.random() * W, rnd.random() * H, rnd.uniform(180, 480)
            g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(x, y), r, [hexc("#FFFFFF", .04), hexc("#FFFFFF", 0)], [0, 1]))
            c.drawCircle(x, y, r, g)
        for _ in range(7):                                             # eraser sweeps
            c.save(); c.translate(rnd.random() * W, rnd.random() * H); c.rotate(rnd.uniform(-25, 25))
            c.drawRoundRect(skia.Rect.MakeXYWH(-300, -34, 600, 68), 34, 34, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .022))); c.restore()
        fr = 24                                                        # wooden frame
        wood = skia.Paint(AntiAlias=True); wood.setStyle(skia.Paint.kStroke_Style); wood.setStrokeWidth(fr)
        wood.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(W, H)], [hexc("#A27243"), hexc("#7B5129"), hexc("#A27243")], [0, .5, 1]))
        c.drawRect(skia.Rect.MakeXYWH(fr / 2, fr / 2, W - fr, H - fr), wood)
        for inset, col, a, wd in ((fr + 2, "#000000", .38, 4), (fr, "#FFFFFF", .16, 1.5)):
            st = skia.Paint(AntiAlias=True, Color=hexc(col, a)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(wd)
            c.drawRect(skia.Rect.MakeXYWH(inset, inset, W - 2 * inset, H - 2 * inset), st)

    def fx(self, c, T):
        rnd = random.Random(14)
        for _ in range(46):                                            # drifting chalk dust
            x0, y0, v, r, ph = rnd.random() * W, rnd.random() * H, rnd.uniform(6, 18), rnd.uniform(1, 3.2), rnd.random() * 6.28
            y = (y0 - T * v) % (H + 40) - 20; x = x0 + 22 * math.sin(.35 * T + ph)
            c.drawCircle(x, y, r, skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", .10 + .08 * math.sin(T + ph))))

    def _doodle(self, c, pts, color, wd, frac, seed, amp=1.6):
        for k, (a, w2) in enumerate(((1.0, wd), (.45, wd * .6))):
            st = skia.Paint(AntiAlias=True, Color=hexc(C.get(color, color), a)); st.setStyle(skia.Paint.kStroke_Style)
            st.setStrokeWidth(w2); st.setStrokeCap(skia.Paint.kRound_Cap); st.setStrokeJoin(skia.Paint.kRound_Join)
            stroke_poly(c, wobble(pts, amp + k * 1.2, seed + k * 31), st, frac)

    def hero_bg(self, c, T):
        c.drawImage(E.bg_image(), 0, 0)
        for x, y, v, ph in ((260, 150, 1, 0), (1450, 330, 1.3, 1.5), (1700, 560, .8, 3), (170, 500, 1.1, 4.5), (1180, 130, .9, 2)):
            pass
        k = lambda d, dur: E.ease((T - d) / dur)
        # sun
        sc_ = k(.2, 1.0); self._doodle(c, arc_points(1590, 190, 68, 0, 6.4), "teal", 5, sc_, 3)
        for j in range(12):
            a = j * math.pi / 6
            self._doodle(c, line_points(1590 + 92 * math.cos(a), 190 + 92 * math.sin(a), 1590 + 128 * math.cos(a), 190 + 128 * math.sin(a), 8), "teal", 5, k(.7 + j * .04, .35), 40 + j)
        # cloud
        pts = []
        for cx, r in ((250, 30), (312, 46), (376, 34)): pts += arc_points(cx, 190 - r + 28, r, math.pi, 2 * math.pi, 9)
        pts += line_points(410, 218, 220, 218, 9)
        self._doodle(c, pts, "sky", 5, k(.6, 1.3), 77)
        # stars
        for n, (sx, sy, sr) in enumerate(((1280, 120, 20), (520, 100, 16), (120, 380, 18), (1760, 400, 16), (1000, 90, 14))):
            pa = []
            for q in range(6):
                a = -math.pi / 2 + q * 4 * math.pi / 5; pa.append((sx + sr * math.cos(a), sy + sr * math.sin(a)))
            self._doodle(c, pa, "teal", 4, k(1.0 + n * .2, .6), 90 + n, 1.0)
        # horizon + waves
        self._doodle(c, line_points(70, HZ, W - 70, HZ, 16), "sky", 5, k(1.2, 1.2), 5, 2.4)
        for j, y0 in enumerate((705, 752, 799)):
            wave = [(x, y0 + 8 * math.sin(x / 26.0 + j)) for x in range(90, W - 90, 10)]
            self._doodle(c, wave, "sky", 4, k(1.6 + j * .25, 1.4), 20 + j, 1.0)

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 3 * math.sin(1.0 * ctx.t)
        c.save(); c.translate(cx, cy + (1 - p) * 30 + bob); c.scale(sc, sc)
        hull = [(-170, 0), (170, 0), (130, 55), (-135, 55), (-170, 0)]
        def boxpts(b): x, y, w, h, r = b; return rrect_points(x, y, w, h, r, 10)
        for j in range(9):                                              # chalk shading on the hull
            x = -150 + j * 34; ctx.c.drawLine(x, 8, x - 14, 48, ctx.paint("white", .30 * pp, 3))
        fun = g["funnel"]; c.drawRoundRect(skia.Rect.MakeXYWH(fun[0], fun[1], fun[2], fun[3]), 4, 4, ctx.paint("teal", .85 * pp))
        def stroke(pts, col, wd, seed):
            for k2, (a, w2, amp) in enumerate(((1.0, wd, 1.5), (.45, wd * .6, 2.8))):
                st = skia.Paint(AntiAlias=True, Color=hexc(C.get(col, col), a * pp)); st.setStyle(skia.Paint.kStroke_Style)
                st.setStrokeWidth(w2); st.setStrokeCap(skia.Paint.kRound_Cap); st.setStrokeJoin(skia.Paint.kRound_Join)
                stroke_poly(c, wobble(pts, amp, seed + k2 * 17, .05), st)
        pts_h = []
        for a, b in zip(hull[:-1], hull[1:]): pts_h += line_points(a[0], a[1], b[0], b[1], 10)
        stroke(pts_h, "white", 5, 1)
        for n, key in enumerate(("cabin", "bridge", "funnel")): stroke(boxpts(g[key]), "white" if key != "funnel" else "teal", 4.5, 10 + n)
        for x, y, w, h in g["windows"]: c.drawCircle(x + w / 2, y + h / 2, 6, ctx.paint("sky", pp, 3.5))
        c.restore(); return True

    # ---------------------------------------------------------------- pieces
    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0)
        if fill: c.drawRoundRect(rect, r, r, ctx.paint(fill, pp * fa * .9))
        if stroke:
            x, y, w, h = rect.left(), rect.top(), rect.width(), rect.height()
            seed = int(x * 7 + getattr(ctx, "card_y", y) * 13 + w * 3 + h) & 0xFFFF
            base = rrect_points(x, y, w, h, r, 14); frac = min(1.0, p * 1.1)
            for k, (amp, al, wd) in enumerate(((1.7, 1.0, sw + 1.0), (2.8, .5, sw * .7))):
                st = skia.Paint(AntiAlias=True, Color=hexc(C.get(stroke, stroke), pp * al)); st.setStyle(skia.Paint.kStroke_Style)
                st.setStrokeWidth(wd); st.setStrokeCap(skia.Paint.kRound_Cap); st.setStrokeJoin(skia.Paint.kRound_Join)
                stroke_poly(c, wobble(base, amp, seed + k * 77), st, frac)

    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 80:
            xx, yy, tw = info[-1]; frac = max(0.0, min(1.0, p)); y = yy + 20
            pts = line_points(xx - 8, y, xx + tw + 8, y + 3, 10)
            for k, (a, wd, amp) in enumerate(((1.0, 5, 1.6), (.45, 3, 3.0))):
                st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], a)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(wd); st.setStrokeCap(skia.Paint.kRound_Cap)
                stroke_poly(ctx.c, wobble(pts, amp, 200 + k * 13, .05), st, frac)

    KEEP = {"MAAP", "SEAS", "SEB", "COA", "CCA", "MAAP-SEAS", "MFR", "PSG"}
    SMALL = {"is", "of", "a", "an", "the", "and", "to", "in", "with", "for", "on", "or"}
    def _title_case(self, s):
        out = []
        for k, w in enumerate(s.replace(",", "").split()):
            out.append(w if w.upper() in self.KEEP else (w.lower() if k and w.lower() in self.SMALL else w.capitalize()))
        return " ".join(out)

    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        ch.text(self._title_case(chapter), 72, 74, 28, "teal", "b", "l", a * .95, _rev=False, _deco=False)
        ch.text(f"{i+1} / {n}", W - 72, 74, 28, "mute", "m", "r", a * .9, _rev=False, _deco=False)
        ch.text(deck, 72, 1046, 22, "mute", "m", "l", .7 * foot_a, _rev=False, _deco=False)

    def transition(self, c, t, sc):
        x = -460 + (W + 920) * E.ease(t / 0.85); a = 1 - E.ease(t / 0.9) * .6
        sm = skia.Paint(); sm.setShader(skia.GradientShader.MakeLinear([skia.Point(x, 0), skia.Point(x + 460, 0)], [hexc("#FFFFFF", 0), hexc("#FFFFFF", .13 * a), hexc("#FFFFFF", 0)], [0, .5, 1]))
        c.drawRect(skia.Rect.MakeXYWH(x, 30, 460, H - 60), sm)


THEME = Classroom()
