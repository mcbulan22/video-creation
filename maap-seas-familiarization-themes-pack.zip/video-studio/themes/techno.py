"""TECHNO: dark, neon and high-tech. Glowing grid, HUD-style cards, typewriter text, synthwave title scene."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H

HZ = 650


def _streams():
    rnd = random.Random(21)
    return [(30 + i * 107 + rnd.uniform(-20, 20), rnd.uniform(90, 230), rnd.uniform(90, 260), rnd.uniform(0, 1400)) for i in range(18)]
_ST = _streams()


class Techno(Theme):
    name = "techno"
    label = "Techno: dark neon grid, glowing HUD cards, typewriter text, synthwave title"
    palette = dict(bg1="#04050E", bg2="#0A1030", card="#0B1430", edge="#16809C", white="#E6F1FF", mute="#6F86B3",
                   teal="#00E5FF", amber="#FF3DCB", red="#FF4D6D", green="#39FF9C", sky="#4D7CFF", dark="#02030A")
    fonts = dict(l="ChakraPetch-Light", r="ChakraPetch-Regular", m="ChakraPetch-Medium", b="ChakraPetch-Bold")
    overshoot = 0.0; dur_scale = 0.7; dy_scale = 0.35; pop = 0.02; slide_in = 40; slide_out = 40; push = 0.02
    transition_dur = 0.9; reveal = "type"; text_glow = (7, .5, 56)

    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        for k, x in enumerate(range(0, W + 1, 64)):
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .09 if k % 4 == 0 else .045)); st.setStrokeWidth(1)
            c.drawLine(x, 0, x, H, st)
        for k, y in enumerate(range(0, H + 1, 64)):
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .09 if k % 4 == 0 else .045)); st.setStrokeWidth(1)
            c.drawLine(0, y, W, y, st)
        v = skia.Paint(); v.setShader(skia.GradientShader.MakeRadial(skia.Point(W / 2, H / 2), 1250, [hexc("#000000", 0), hexc("#000000", .6)], [.45, 1]))
        c.drawRect(skia.Rect.MakeWH(W, H), v)

    def fx(self, c, T):
        for cx, cy, r, col, a in [(W * (.18 + .06 * math.sin(.15 * T)), H * (.25 + .08 * math.cos(.11 * T)), 720, "teal", .10),
                                  (W * (.86 + .05 * math.cos(.12 * T)), H * (.82 + .06 * math.sin(.14 * T)), 800, "amber", .08)]:
            pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [hexc(C[col], a), hexc(C[col], 0)], [0, 1]))
            c.drawCircle(cx, cy, r, pt)
        y = (T * 150) % (H + 500) - 250                                # slow scan band
        sb = skia.Paint(); sb.setShader(skia.GradientShader.MakeLinear([skia.Point(0, y - 110), skia.Point(0, y + 110)],
              [hexc(C["teal"], 0), hexc(C["teal"], .07), hexc(C["teal"], 0)], [0, .5, 1]))
        c.drawRect(skia.Rect.MakeXYWH(0, y - 110, W, 220), sb)
        for x, L, v, off in _ST:                                       # falling data streams
            yy = ((T * v + off) % (H + 400)) - 200
            sp = skia.Paint(); sp.setStrokeWidth(2)
            sp.setShader(skia.GradientShader.MakeLinear([skia.Point(x, yy - L), skia.Point(x, yy)], [hexc(C["teal"], 0), hexc(C["teal"], .45)]))
            c.drawLine(x, yy - L, x, yy, sp)
            c.drawRect(skia.Rect.MakeXYWH(x - 3, yy - 3, 6, 6), skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .8)))

    def hero_bg(self, c, T):
        c.drawImage(E.bg_image(), 0, 0)
        rnd = random.Random(4)
        for _ in range(60):
            x, y = rnd.random() * W, rnd.random() * (HZ - 60); tw = .25 + .5 * (.5 + .5 * math.sin(1.4 * T + rnd.random() * 6.28))
            c.drawCircle(x, y, rnd.uniform(.8, 2.2), skia.Paint(AntiAlias=True, Color=hexc("#FFFFFF", tw * .6)))
        R = 215                                                         # half sun
        c.save(); c.clipRect(skia.Rect.MakeXYWH(0, 0, W, HZ))
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(960, HZ), 700, [hexc(C["amber"], .35), hexc(C["amber"], 0)], [0, 1]))
        c.drawCircle(960, HZ, 700, g)
        sun = skia.Paint(AntiAlias=True); sun.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ - R), skia.Point(0, HZ)], [hexc("#FFD84A"), hexc("#FF3DCB")]))
        c.drawCircle(960, HZ, R, sun)
        for k in range(7):                                              # slits
            c.drawRect(skia.Rect.MakeXYWH(960 - R, HZ - 16 - k * 26, 2 * R, 3 + k * 1.7), skia.Paint(Color=hexc(C["bg1"])))
        c.restore()
        c.drawRect(skia.Rect.MakeXYWH(0, HZ, W, H - HZ), skia.Paint(Color=hexc(C["bg1"])))
        fl = skia.Paint(); fl.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ), skia.Point(0, H)], [hexc("#12214F"), hexc(C["bg1"])]))
        c.drawRect(skia.Rect.MakeXYWH(0, HZ, W, H - HZ), fl)
        for k in range(-14, 15):                                        # perspective grid
            x = 960 + k * 190
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .38)); st.setStrokeWidth(2)
            c.drawLine(960 + k * 30, HZ, x * 1.0 + k * 40, H, st)
        for j in range(13):
            f = ((j + (T * .45) % 1.0) / 13.0); y = HZ + (H - HZ) * f ** 2.2
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .12 + .5 * f)); st.setStrokeWidth(1.5 + 2 * f)
            c.drawLine(0, y, W, y, st)
        c.drawLine(0, HZ, W, HZ, E.blur_paint("teal", .9, 6, 6)); c.drawLine(0, HZ, W, HZ, skia.Paint(AntiAlias=True, Color=hexc("#BFF8FF"), StrokeWidth=3))

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 4 * math.sin(1.3 * ctx.t)
        c.save(); c.translate(cx, cy + (1 - p) * 30 + bob); c.scale(sc, sc)
        shapes = [("hull", None)] + [(k, g[k]) for k in ("cabin", "bridge", "funnel")]
        def draw(paint):
            c.drawPath(g["hull"], paint)
        c.drawPath(g["hull"], ctx.paint("dark", .95 * pp))
        for k in ("cabin", "bridge", "funnel"):
            x, y, w, h, r = g[k]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ctx.paint("dark", .95 * pp))
        for col, keys in (("teal", ("hull", "cabin", "bridge")), ("amber", ("funnel",))):
            for glow in (True, False):
                pt = E.blur_paint(col, .85 * pp, 9, 9) if glow else ctx.paint(col, pp, 4)
                for k in keys:
                    if k == "hull": c.drawPath(g["hull"], pt)
                    else:
                        x, y, w, h, r = g[k]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, pt)
        for x, y, w, h in g["windows"]: c.drawRect(skia.Rect.MakeXYWH(x, y, w, h), ctx.paint("teal", .9 * pp))
        c.restore(); return True

    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0); col = stroke or "teal"
        if fill: c.drawRoundRect(rect, r, r, ctx.paint(fill, pp * .94 * fa))
        if stroke:
            c.drawRoundRect(rect, r, r, E.blur_paint(stroke, .5 * pp, 7, sw + 2))
            c.drawRoundRect(rect, r, r, ctx.paint(stroke, pp, max(2, sw * .8), dash))
        if fill and pp > .25 and rect.height() >= 80:                   # HUD corner brackets (skipped on short rows)
            L, o = 18, 4; l, t, rr, b = rect.left() - o, rect.top() - o, rect.right() + o, rect.bottom() + o
            br = ctx.paint("teal" if col == "edge" else col, pp, 4)
            for (x, y, dx, dy) in ((l, t, 1, 1), (rr, t, -1, 1), (l, b, 1, -1), (rr, b, -1, -1)):
                c.drawLine(x, y, x + dx * L, y, br); c.drawLine(x, y, x, y + dy * L, br)

    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 80:
            xx, yy, tw = info[-1]; q = max(0.0, min(1.0, p)); y = yy + 22
            if q > .02:
                ctx.c.drawLine(xx, y, xx + tw * q, y, E.blur_paint("teal", .8, 5, 6)); ctx.c.drawLine(xx, y, xx + tw * q, y, ctx.paint("teal", 1, 2))
                ctx.c.drawRect(skia.Rect.MakeXYWH(xx - 4, y - 4, 8, 8), ctx.paint("amber", q)); ctx.c.drawRect(skia.Rect.MakeXYWH(xx + tw * q - 4, y - 4, 8, 8), ctx.paint("amber", q))

    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        ch.text("// " + chapter, 70, 70, 24, "teal", "m", "l", a * .95, _rev=False, _deco=False)
        ch.text(f"[{i+1:02d}/{n}]", W - 70, 70, 24, "mute", "m", "r", a * .9, _rev=False, _deco=False)
        ch.text(deck.upper(), 70, 1048, 20, "mute", "m", "l", .7 * foot_a, _rev=False, _deco=False)
        ch.c.drawRect(skia.Rect.MakeXYWH(70, 1064, (W - 140) * (i + 1) / n, 3), ch.paint("teal", .9 * a))
        ch.c.drawRect(skia.Rect.MakeXYWH(70, 1064, (W - 140), 3), ch.paint("teal", .12 * a))

    def transition(self, c, t, sc):
        x = -300 + (W + 600) * E.ease(t / 0.8); a = 1 - E.ease(t / 0.9) * .5
        tr = skia.Paint(); tr.setShader(skia.GradientShader.MakeLinear([skia.Point(x - 320, 0), skia.Point(x, 0)], [hexc(C["teal"], 0), hexc(C["teal"], .22 * a)]))
        c.drawRect(skia.Rect.MakeXYWH(x - 320, 0, 320, H), tr)
        c.drawRect(skia.Rect.MakeXYWH(x - 2, 0, 4, H), skia.Paint(Color=hexc("#BFF8FF", .9 * a)))
        c.drawLine(x, 0, x, H, E.blur_paint("teal", .8 * a, 8, 10))


THEME = Techno()
