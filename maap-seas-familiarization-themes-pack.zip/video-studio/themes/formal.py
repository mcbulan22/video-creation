"""FORMAL: ivory paper, navy and gold, serif type, thin double rules, slow and quiet motion.
For official releases (CCA / MAAP)."""
import math, random
import skia
import engine as E
from engine import Theme, hexc, C, W, H

HZ = 650


def _rose(c, cx, cy, R, rot, color, a):
    """Compass rose: rings + 16-point star."""
    st = skia.Paint(AntiAlias=True, Color=hexc(color, a)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2)
    for f in (1.0, .86, .5): c.drawCircle(cx, cy, R * f, st)
    for k in range(16):
        ang = rot + k * math.pi / 8; r = R * (1.12 if k % 4 == 0 else 1.0 if k % 2 == 0 else .72)
        c.drawLine(cx, cy, cx + r * math.cos(ang), cy + r * math.sin(ang), st)


class Formal(Theme):
    name = "formal"
    label = "Formal: ivory and navy with gold rules, serif type, calm fades (for official releases)"
    palette = dict(bg1="#FBF8F1", bg2="#F0EADB", card="#FFFFFF", edge="#CBBE9B", white="#14213D", mute="#6B7285",
                   teal="#2B4B8C", amber="#A8751A", red="#B3402F", green="#2F7D52", sky="#7F98C4", dark="#14213D")
    fonts = dict(l="Lora-Regular", r="Lora-Regular", m="Lora-Medium", b="PlayfairDisplay-Bold")
    overshoot = 0.0; dur_scale = 1.3; dy_scale = 0.35; pop = 0.012; slide_in = 0; slide_out = 0; push = 0.01; transition_dur = 1.0; glow_mult = 0.2

    def background(self, c):
        pt = skia.Paint(); pt.setShader(skia.GradientShader.MakeLinear([skia.Point(0, 0), skia.Point(0, H)], [hexc(C["bg1"]), hexc(C["bg2"])]))
        c.drawRect(skia.Rect.MakeWH(W, H), pt)
        rnd = random.Random(2)
        for _ in range(260):                                           # paper fibre specks
            c.drawCircle(rnd.random() * W, rnd.random() * H, rnd.uniform(.6, 1.6), skia.Paint(AntiAlias=True, Color=hexc("#3A3320", .045)))
        for inset, a, wd in ((38, .9, 2.5), (50, .55, 1.2)):           # double gold frame
            st = skia.Paint(AntiAlias=True, Color=hexc(C["amber"], a)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(wd)
            c.drawRect(skia.Rect.MakeXYWH(inset, inset, W - 2 * inset, H - 2 * inset), st)
        for x, y in ((50, 50), (W - 50, 50), (50, H - 50), (W - 50, H - 50)):
            c.save(); c.translate(x, y); c.rotate(45); c.drawRect(skia.Rect.MakeXYWH(-7, -7, 14, 14), skia.Paint(AntiAlias=True, Color=hexc(C["amber"]))); c.restore()

    def fx(self, c, T):
        cx, cy = W * (.30 + .08 * math.sin(.07 * T)), H * (.25 + .05 * math.cos(.06 * T))
        g = skia.Paint(); g.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), 800, [hexc("#E7C979", .13), hexc("#E7C979", 0)], [0, 1]))
        c.drawCircle(cx, cy, 800, g)
        _rose(c, 1620, 800, 300, T * 0.012, C["white"], .045)

    def hero_bg(self, c, T):
        c.drawImage(E.bg_image(), 0, 0)
        _rose(c, 960, 610, 430, T * 0.012, C["white"], .06)
        sea = skia.Paint(); sea.setShader(skia.GradientShader.MakeLinear([skia.Point(0, HZ), skia.Point(0, H)], [hexc("#DDE6F2"), hexc("#C4D3E7")]))
        c.drawRect(skia.Rect.MakeXYWH(52, HZ, W - 104, H - HZ - 52), sea)
        for k in range(4):
            pa = skia.Path(); y0 = HZ + 24 + k * 62; pa.moveTo(52, y0)
            for xx in range(52, W - 51, 8): pa.lineTo(xx, y0 + (3 + k) * math.sin(xx / (95 + 15 * k) + T * (.35 + .08 * k) + k))
            st = skia.Paint(AntiAlias=True, Color=hexc(C["teal"], .25 - .04 * k)); st.setStyle(skia.Paint.kStroke_Style); st.setStrokeWidth(2); c.drawPath(pa, st)
        c.drawLine(52, HZ, W - 52, HZ, skia.Paint(AntiAlias=True, Color=hexc(C["amber"]), StrokeWidth=3))
        gp = skia.Paint(AntiAlias=True, Color=hexc(C["amber"], .9)); gp.setStrokeWidth(2)         # ornament above the title
        c.drawLine(740, 150, 920, 150, gp); c.drawLine(1000, 150, 1180, 150, gp)
        c.save(); c.translate(960, 150); c.rotate(45); c.drawRect(skia.Rect.MakeXYWH(-9, -9, 18, 18), skia.Paint(AntiAlias=True, Color=hexc(C["amber"]))); c.restore()

    def ship(self, ctx, cx, cy, sc, color, p):
        g = E.ship_geometry(); c = ctx.c; pp = min(p, 1.0); bob = 2.5 * math.sin(.8 * ctx.t)
        c.save(); c.translate(cx, cy + (1 - p) * 18 + bob); c.scale(sc, sc)
        c.drawPath(g["hull"], ctx.paint("dark", pp))
        for key in ("cabin", "bridge"):
            x, y, w, h, r = g[key]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ctx.paint("dark", pp))
        x, y, w, h, r = g["funnel"]; c.drawRoundRect(skia.Rect.MakeXYWH(x, y, w, h), r, r, ctx.paint("amber", pp))
        for x, y, w, h in g["windows"]: c.drawRect(skia.Rect.MakeXYWH(x, y, w, h), ctx.paint("bg1", pp))
        c.drawLine(-200, 59, 200, 59, ctx.paint("amber", pp, 3)); c.restore(); return True

    def draw_card(self, ctx, rect, r, fill, stroke, sw, p, fa, dash):
        c = ctx.c; pp = min(p, 1.0); rr = r * .3
        if fill:
            E.soft_shadow(c, rect, rr, 0, 6, 10, "#2A3350", .08 * pp * fa)
            c.drawRoundRect(rect, rr, rr, ctx.paint(fill, p * fa))
        if stroke:
            c.drawRoundRect(rect, rr, rr, ctx.paint(stroke, p, min(sw, 1.8), dash))
            if fill:
                inner = skia.Rect.MakeLTRB(rect.left() + 5, rect.top() + 5, rect.right() - 5, rect.bottom() - 5)
                c.drawRoundRect(inner, rr * .6, rr * .6, ctx.paint(stroke, p * .45, 1))

    def after_text(self, ctx, info, size, color, p):
        if 52 <= size <= 80:
            xx, yy, tw = info[-1]; q = max(0.0, min(1.0, p)); cx = xx + tw / 2; y = yy + 26
            gp = ctx.paint("amber", q, 2)
            ctx.c.drawLine(cx - 140 * q, y, cx - 14, y, gp) if q > .1 else None
            ctx.c.drawLine(cx + 14, y, cx + 140 * q, y, gp) if q > .1 else None
            ctx.c.save(); ctx.c.translate(cx, y); ctx.c.rotate(45)
            ctx.c.drawRect(skia.Rect.MakeXYWH(-5, -5, 10, 10), ctx.paint("amber", q)); ctx.c.restore()

    def chrome(self, ch, chapter, i, n, deck, a, foot_a):
        ch.text(chapter.upper(), 96, 94, 20, "amber", "m", "l", a * .95, _rev=False, _deco=False)
        ch.text(f"{i+1} of {n}", W - 96, 94, 20, "mute", "m", "r", a * .9, _rev=False, _deco=False)
        ch.text(deck, W / 2, 1008, 20, "mute", "m", "c", .8 * foot_a, _rev=False, _deco=False)

    def transition(self, c, t, sc):
        u = E.ease(t / 1.0); half = 900 * u; a = 1 - .6 * u
        gp = skia.Paint(AntiAlias=True, Color=hexc(C["amber"], a)); gp.setStrokeWidth(2)
        c.drawLine(W / 2 - half, 126, W / 2 + half, 126, gp)


THEME = Formal()
