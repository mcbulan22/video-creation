#!/bin/sh
# See every theme as still images (no video render, takes under a minute):
#   sh preview_themes.sh            -> output/theme_preview/overview.png  (all themes side by side)
#                                      output/theme_preview/<theme>_sheet_01.png ... (every scene, per theme)
#   sh preview_themes.sh playful    -> only that theme
cd "$(dirname "$0")"
[ -f inbox/scenes.py ] || { echo "No inbox/scenes.py found."; exit 1; }
[ -d .venv ] || { echo "Run setup first:  sh setup_mac.sh"; exit 1; }
. .venv/bin/activate
python scripts/preview_themes.py inbox/scenes.py --out output/theme_preview $@ && open output/theme_preview 2>/dev/null
