#!/bin/sh
# THE ONE COMMAND: voice + picture + sound, all together.
#   sh make.sh --draft                 quick test (720p)
#   sh make.sh                         final 1080p
#   sh make.sh --voice-name Daniel     pick another voice   (list them: say -v '?')
#   sh make.sh --music inbox/music.mp3 add your own royalty-free music (or --music pad for a soft generated bed)
#   sh make.sh --own-voice             use YOUR recordings in the my_voice folder (see narration_script.txt)
#   sh make.sh --fx off                faster render, calmer background
#   sh make.sh --theme playful         pick a look: clean (default), ocean, techno, classroom, formal, playful
#   sh make.sh --list-themes           show the available looks
#   sh preview_themes.sh               see every look as still images in seconds (no video render)
cd "$(dirname "$0")"
if [ "$1" = "--list-themes" ]; then
  echo "Available themes (use:  sh make.sh --theme NAME ):"
  for f in themes/clean.py $(ls themes/[a-z]*.py | grep -v 'themes/clean.py'); do n=$(basename "$f" .py); d=$(sed -n '1{s/^"""//;s/"""$//;p;}' "$f"); [ "$n" = clean ] && d="$d (DEFAULT)"; echo "  $n   $d"; done
  exit 0
fi
[ -f inbox/scenes.py ] || { echo "No inbox/scenes.py found."; exit 1; }
[ -d .venv ] || { echo "Run setup first:  sh setup_mac.sh"; exit 1; }
. .venv/bin/activate
VOICE=Samantha; MUSIC=""; PASS=""; OWN=0; THEME=clean
while [ $# -gt 0 ]; do
  case "$1" in
    --voice-name) VOICE="$2"; shift 2;;
    --music) MUSIC="$2"; shift 2;;
    --own-voice) OWN=1; shift;;
    --theme) THEME="$2"; shift 2;;
    *) PASS="$PASS $1"; shift;;
  esac
done
[ -f "themes/$THEME.py" ] || { echo "Unknown theme '$THEME'. Run:  sh make.sh --list-themes"; exit 1; }
[ -z "$MUSIC" ] && [ -f inbox/music.mp3 ] && MUSIC=inbox/music.mp3
python scripts/make_script.py inbox/scenes.py --out narration_script.txt >/dev/null
rm -rf output/voice
if [ "$OWN" = "1" ]; then
  echo "== 1/3 Preparing YOUR recordings (folder: my_voice) =="
  python scripts/make_voice.py inbox/scenes.py --out output/voice --engine own --src my_voice || exit 1
else
  echo "== 1/3 Recording the voice-over ($VOICE) =="
  python scripts/make_voice.py inbox/scenes.py --out output/voice --engine mac --voice "$VOICE" || exit 1
fi
echo "== 2/3 Drawing the video (theme: $THEME; a few minutes) =="
rm -rf output/clips
python scripts/build_video.py inbox/scenes.py --out output --voice output/voice/durations.json --captions --theme "$THEME" $PASS || exit 1
echo "== 3/3 Mixing the sound =="
if [ -n "$MUSIC" ]; then M="--music $MUSIC"; else M=""; fi
python scripts/mix_audio.py output/full_video_silent.mp4 output/cues.json --out output/final_with_audio.mp4 --voice-dir output/voice $M || exit 1
echo ""; echo "DONE -> output/final_with_audio.mp4"
open output 2>/dev/null
