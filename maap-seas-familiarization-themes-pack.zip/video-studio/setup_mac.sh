#!/bin/sh
# Run ONCE:  sh setup_mac.sh
cd "$(dirname "$0")"
echo "== Checking Python =="
command -v python3 >/dev/null || { echo "Python 3 missing. In Terminal run: xcode-select --install   then run this script again."; exit 1; }
echo "== Checking ffmpeg =="
if ! command -v ffmpeg >/dev/null; then
  command -v brew >/dev/null || { echo "Homebrew missing. Install it from https://brew.sh (copy the one-line command), then run this script again."; exit 1; }
  brew install ffmpeg
fi
echo "== Creating private Python environment (small, inside this folder) =="
python3 -m venv .venv
. .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet skia-python pillow
python -c "import skia; print('skia OK', skia.__version__)"
ffmpeg -version | head -1
echo ""
echo "SETUP DONE. Next: put scenes.py in the 'inbox' folder, then run:  sh render.sh --draft"
