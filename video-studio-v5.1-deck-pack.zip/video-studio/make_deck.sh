#!/bin/sh
# PowerPoint deck on a Mac: one picture slide per scene, the narration in the speaker notes.
#   sh make_deck.sh   |   sh make_deck.sh --per-beat   |   sh make_deck.sh --draft   |   sh make_deck.sh --theme formal
# (Same tool as on a Windows PC: python3 studio.py deck)
cd "$(dirname "$0")"
exec python3 studio.py deck "$@"
