# Using the pack on two computers (Mac and Windows PC)

The same folder works on a Mac, a Windows PC and Linux. You do not have to say which computer you are on:
the launcher (`studio.py`) detects it. If you want to be explicit, add `--computer mac` or `--computer windows`
(it refuses if you pick the wrong one, so you cannot mix them up by accident).

## Every command, side by side
| What you want | Mac | Windows PC |
|---|---|---|
| First-time setup (once per computer) | `sh setup_mac.sh` | double-click `setup.bat` |
| Check this computer | `python3 studio.py doctor` | double-click `doctor.bat` |
| Asks you questions, then makes the video | double-click `start.command` (or `sh start.sh`) | double-click `start.bat` |
| Quick test video (720p) | `sh make.sh --draft` | `make.bat --draft` |
| Final video | `sh make.sh` | `make.bat` |
| Pick a look | `sh make.sh --theme playful` | `make.bat --theme playful` |
| Pick a voice engine | `sh make.sh --engine edge` | `make.bat --engine edge` |
| Your own recordings | `sh make.sh --own-voice` | `make.bat --own-voice` |
| Picture only, no sound | `sh render.sh --draft` | `render.bat --draft` |
| PowerPoint deck (narration in the notes) | `sh make_deck.sh` | `make_deck.bat` |
| Deck with one slide per beat | `sh make_deck.sh --per-beat` | `make_deck.bat --per-beat` |
| Video and deck in one go | `sh make.sh --deck` | `make.bat --deck` |
| See every look as stills | `sh preview_themes.sh` | `preview_themes.bat` |
| Motion report | `sh motion_check.sh` | `motion_check.bat` |
| Measure this computer, estimate render times | `sh benchmark.sh` | `benchmark.bat` |
| Picture quality | `sh make.sh --quality smooth` | `make.bat --quality smooth` |
| List voices | `python3 studio.py voices` | `voices.bat` |
| List looks | `sh make.sh --list-themes` | `make.bat --list-themes` |
On Windows, run the `.bat` files by double-clicking (they stay open at the end) or type them in a Command Prompt opened in the folder.
Options such as `--theme`, `--quality` (draft, standard, smooth, cinema, ultra), `--draft` and `--music inbox/music.mp3` work the same on both computers. Speed and quality are explained in PERFORMANCE.md.

## First-time setup on the Windows PC (about 10 minutes)
1. Install Python 3.12 from python.org. Choose **Install for me only** (no administrator rights needed) and tick **Add python.exe to PATH**.
2. Copy the whole `video-studio` folder to the PC. A short location such as `C:\video-studio` is best (very long folder paths can break Windows).
3. Double-click `setup.bat`. When it asks to download ffmpeg, press Enter (Y). It saves ffmpeg in the `bin` folder, no installation needed.
4. Double-click `doctor.bat`. Every line should say OK.
5. Put your scenes file in `inbox`, then try `make.bat --draft`.
If the company network blocks downloads, ask IT to allow python.org, pypi.org and github.com, or use a proxy:
`setup.bat --pip-args "--proxy http://host:port"`.

## Voices differ between the computers
| Engine | Where | Notes |
|---|---|---|
| `mac` | Mac only | the built-in Mac voice (default on a Mac) |
| `windows` | Windows only | the built-in Windows voices (default on a PC); more can be added in Windows Settings > Time & language > Speech |
| `edge` | both | free online neural voice, default Philippine English (en-PH-RosaNeural). Needs internet. It uses Microsoft's online reading service through an unofficial package, so it could stop working one day. I could not test it from my side (no internet access to that service). |
| `own` | both | your own recordings in `my_voice` (see narration_script.txt) |
A video made on the Mac and one made on the PC will therefore sound different. For the same voice on both, use `--engine edge` or `--own-voice`.
List what each computer has with `voices` (or `voices --engine edge`), then choose with `--voice NAME`.

## Sharing one folder between the two computers
- Each computer creates its own private Python environment: `.venv-mac`, `.venv-windows` (a Mac's older `.venv` is still used). **Never copy these between computers**, and exclude them if you sync the folder through OneDrive, Dropbox or a USB drive.
- Do not render on both computers at the same time in the same folder. Use `--out output-pc` on one of them to keep results apart.
- Your work lives in `inbox` (scenes, music) and `my_voice`; those are safe to share.

## If something goes wrong
- Run `doctor` first. It says exactly what is missing and how to fix it.
- Windows says Python is not installed: install it as in step 1, then double-click the file again.
- "ffmpeg is missing": run `setup.bat --get-ffmpeg`, or copy `ffmpeg.exe` and `ffprobe.exe` into `bin`.
- Slow on the PC: use `--workers 2` (fewer processor cores) or `--fx off`, and try `--draft` first.
- Send me the `doctor` output and the last lines of the error and I can tell you the fix.

## What has and has not been tested
Tested end to end on Linux (a third kind of computer): setup, doctor, voice, drawing, captions and sound mix produced a finished video.
Tested by simulation only: the Windows path handling, the Windows voice and ffmpeg-download commands, and the question-and-answer mode.
Not tested on a real Windows PC or Mac with this version. The drawing, motion, themes and sound are identical code on all computers. Please run `doctor` on the PC first and tell me what it shows.

## HTML scenes need Chrome or Edge (optional)
Scenes drawn with web pages use the Google Chrome (or, on Windows, Microsoft Edge) that is already installed. `doctor` shows whether it works. Python scenes never need it. Details: HTML_SCENES.md.
