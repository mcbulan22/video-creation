# PowerPoint deck with the narration in the speaker notes (new in v5.1)

One scenes file now gives you two things: the narrated video AND a PowerPoint deck. Each slide is one scene as a full-slide picture;
the speaker notes of that slide hold the exact narration of the scene (the same words the voice reads).

## Commands
| What you want | Mac | Windows PC |
|---|---|---|
| Deck only (no video needed first) | `sh make_deck.sh` | `make_deck.bat` |
| Quick, smaller pictures (720p) | `sh make_deck.sh --draft` | `make_deck.bat --draft` |
| One slide per beat instead of per scene | `sh make_deck.sh --per-beat` | `make_deck.bat --per-beat` |
| Another look | `sh make_deck.sh --theme formal` | `make_deck.bat --theme formal` |
| Video and deck in one go | `sh make.sh --deck` | `make.bat --deck` |

Result: `output/deck_with_notes.pptx`. The first run installs a small helper (`python-pptx`, free) by itself; no new setup step is needed
even if you set the pack up with an older version. `sh start.command` / `start.bat` now also asks whether you want the deck.

## What you get
- **One slide per scene** (default): the fully built picture of the scene; notes = all beats of the scene, one paragraph per beat.
- **`--per-beat`**: one slide per beat. The picture shows the scene as it looks when that beat has finished, and the notes hold only that beat.
  Useful when you present live and want to click through the build-up.
- The picture is drawn by the same engine and look as the video, without any video being rendered. HTML scenes need Chrome or Edge (same as the video);
  scenes with a Python fallback use it when no browser is found.
- Each slide title (visible in the outline and slide navigator) is "number. chapter". The picture covers the title, and the picture has alternative text for screen readers.
- Pictures are drawn without the drifting light and slow camera push of the video, so nothing is cropped or blurred. Add `--fx on` to keep them.

## Good to know
- The slides are pictures, so text and numbers are not editable in PowerPoint. To change them, edit `inbox/scenes.py` (or ask Claude) and run the command again.
- Video motion (reveals, morphs, sounds) is not in the deck: it is the finished state of each scene. `--per-beat` shows the build-up in steps.
- The notes are exactly the beat text, so they stay identical to the narration: the numbers are checked against `inbox/facts.md` before the deck is drawn (`output/facts_report.txt`).
- If the deck is open in PowerPoint, close it before running the command again (Windows locks open files).
- `--only 1-4,7` makes a deck of selected scenes; `--height 1440` or `2160` gives sharper pictures and a larger file.
