---
name: "scene-video-studio"
description: "Build scene-by-scene narrated explainer videos and motion-graphics presentations as a ready-to-render pack (scenes.py + narration script) that the user renders on their own Mac or Windows PC, plus a PowerPoint deck with the narration in the speaker notes. Use for video, explainer, motion graphics, video presentation, narrated slides or a deck-with-notes request."
---

# Scene Video Studio (v5.1: pack workflow, video + PowerPoint deck)

Claude writes **scenes as code** (a pure function of time). The user's computer renders them. The deliverable is a COMPLETE pack zip, never a rendered video.
Each pack makes two things from the same `inbox/scenes.py`: the narrated video and a PowerPoint deck (one picture slide per scene, the narration in the speaker notes).

## The pack's docs beat this file
The user's pack (newest `video-studio-v*.zip` in the project files; else download the sample pack named in the project) carries newer docs than this skill. Unzip it, read them, and follow them when they differ:
CLAUDE.md, KIT.md, FREEFORM.md, HTML_SCENES.md, SOUND_AND_QA.md, BRIEF_AND_FACTS.md, DECK.md, reference/anti-generic.md.
Never deliver a partial pack: always the whole folder (a partial `scripts/` once deleted engine files).

## Rules of engagement
- Free tools only: no paid services or APIs, no web links inside the video.
- The user renders, Claude does not. Cheap checks only: Python syntax check of scenes.py and any new code, `python scripts/check_facts.py inbox/scenes.py inbox/facts.md` (text only), and confirming every referenced file exists. Contact sheets or a draft render only if the user writes "verify". Never claim a test on the user's computer; say what was checked and what was not.
- Edit only `inbox/` files and `narration_script.txt` when building a video. Do not modify `scripts/`, `themes/` or the engine unless the user asks to revise the pack itself (then change the minimum, add new files, and update every README it touches).
- Keep Mac AND Windows working: everything goes through `studio.py`; `.bat` files are ASCII with CRLF.

## Workflow (in this order)
1. **Brief**: at most five questions, only what the material does not answer (audience, the one takeaway, length (default about 3 min), where it is shown, mood). The user CHOOSES the look: clean, ocean, techno, classroom, formal, playful, aurora, editorial, or freeform with mood words. Never pick it for them.
2. **Facts**: write `inbox/brief.md` and `inbox/facts.md` (every number, name, date and claim copied exactly, with source and verified / UNVERIFIED). Never invent, estimate or round. Show both and wait for corrections.
3. **Plan**: table of scene | single point | engine (Python or HTML) | why | main effect.
4. **Build** `inbox/scenes.py` (+ `inbox/html/*.html`, `inbox/fonts/` if needed). One hero idea per scene, at most three effect types per video, beat text = exact narration (12 to 25 words, about 150 words a minute, readable as speaker notes), body text 26 px or larger, at most 7 items, nothing near the edge. Figures live in a module-level `FIGURES` block; made-up numbers are labelled "Example data" on screen. Use palette roles, not hex colours. HTML for tables, rubrics, matrices, long text, equations, code, UI mockups; Python for motion graphics, charts, icons, morphs, camera, text effects. Icons only from the pack's lists.
5. **Deliver** the whole pack zip (no `output/`, `.venv*`, `__pycache__`). Then a SHORT message: what is inside, commands, what to open first (`output/qa_report.txt`, `output/facts_report.txt`, `output/qa/`, and the deck), what to confirm, honest limits.

## Commands the user runs
| | Mac | Windows PC |
|---|---|---|
| setup (once) | `sh setup_mac.sh` | `setup.bat` |
| test video | `sh make.sh --draft` | `make.bat --draft` |
| final video | `sh make.sh` | `make.bat` |
| PowerPoint deck | `sh make_deck.sh` (`--per-beat` = one slide per beat) | `make_deck.bat` |
| video + deck | `sh make.sh --deck` | `make.bat --deck` |

## PowerPoint deck (DECK.md)
`make_deck` draws each scene's finished state with the same engine and look (no video render needed) and writes `output/deck_with_notes.pptx` with python-pptx (installed by itself on first use). Notes = the exact beat text. The slides are pictures: not editable in PowerPoint; changes go through `inbox/scenes.py`. HTML scenes need Chrome or Edge, or a Python fallback. If the user wants editable native slides, that is a separate design job built from `facts.md`, not this exporter.

## Fixes
When the user reports a problem, edit `inbox/` files only and send a small patch zip with just the changed files and where to put them. Do not re-print unchanged files. Videos longer than about 4 minutes: build in parts that share one look.

## Pitfalls already hit
- ffmpeg may hang on `areverse` directly followed by `loudnorm`; insert `aresample=44100`.
- The ffmpeg `subtitles` filter fails with quoted paths on macOS: run it inside the output folder with relative names. The captioned copy must never fail the build.
- Do not use `S.p` values above 1 as widths without `min(p, 1)`. Poppins has no arrow glyph: use `S.arrow`.
- Render time grows with effects: suggest `--fx off` or `--draft` on slow computers.
