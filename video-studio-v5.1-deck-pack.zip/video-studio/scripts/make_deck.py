#!/usr/bin/env python3
"""Make a PowerPoint deck from the scenes file: one picture slide per scene, the narration in the slide's speaker notes.

  python make_deck.py inbox/scenes.py --out output [--theme NAME] [--per-beat] [--height 1080] [--fx off]
                      [--only 3,7] [--name deck_with_notes.pptx]

The pictures come from the same engine and the same look as the video (each scene fully built), so no video has to be
rendered first. Every slide is one full-slide picture. The speaker notes hold the exact beat text of that scene, which is
also what the voice-over says.
  --per-beat   one slide per beat instead of one per scene (the picture as it looks when that beat ends; notes = that beat)
  --fx on      keep the drifting light and slow camera push of the video (default off: a clean, un-zoomed picture)
Needs the python-pptx package (studio.py installs it by itself the first time you run the deck command).
"""
import argparse, importlib.util, io, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E


def load_scenes(path):
    spec = importlib.util.spec_from_file_location("deck_scenes", path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def final_time(sc):
    """Just before the scene fades out: everything has been revealed (same moment the QA contact sheets use)."""
    return max(0.2, sc["dur"] - 0.9 - (E.DIVE if E.is_sky(sc["s"]) else 0))


def beat_time(sc, k, t_final):
    """The moment a beat has finished building."""
    end = (sc["bs"][k + 1] - 0.05) if k + 1 < len(sc["bs"]) else t_final
    return max(0.1, min(end, t_final))


def main():
    ap = argparse.ArgumentParser(description="PowerPoint deck with the narration in the speaker notes")
    ap.add_argument("scenes"); ap.add_argument("--out", default="output")
    ap.add_argument("--name", default="deck_with_notes.pptx", help="file name of the deck (default deck_with_notes.pptx)")
    ap.add_argument("--theme", help="look to use (default: THEME in the scenes file, else clean)")
    ap.add_argument("--per-beat", action="store_true", help="one slide per beat instead of one per scene")
    ap.add_argument("--height", type=int, default=1080, choices=[720, 1080, 1440, 2160], help="picture height in pixels (default 1080)")
    ap.add_argument("--fx", choices=["on", "off"], default="off", help="off (default) = clean, un-zoomed pictures; on = as in the video")
    ap.add_argument("--only", help="scene numbers to include, e.g. 1-4,7")
    ap.add_argument("--wps", type=float, default=2.45)
    a = ap.parse_args()

    try:
        from pptx import Presentation
        from pptx.util import Emu
    except ImportError:
        sys.exit("The 'python-pptx' package is missing. Run:  python studio.py deck   (it installs the package by itself)\n"
                 "or inside this pack's private environment:  pip install python-pptx")

    m = load_scenes(a.scenes)
    E.set_theme(a.theme or getattr(m, "THEME", None) or "clean")
    deck = getattr(m, "DECK_TITLE", E.DECK_TITLE)
    E.FX = a.fx == "on"; E.SCALE = a.height / 1080.0
    tl, _ = E.build_timeline(E.SCENES, a.wps)

    HE = None
    if any(sc["s"].get("html_path") for sc in tl):
        import html_engine
        ok, msg = html_engine.selftest()
        if ok: HE = html_engine
        else:                                                           # no browser: scenes with a Python fallback use it
            print("HTML engine NOT available: " + msg, flush=True)
            os.environ["VS_NO_HTML"] = "1"; E.SCENES.clear(); m = load_scenes(a.scenes)
            tl, _ = E.build_timeline(E.SCENES, a.wps)
            stuck = [i + 1 for i, sc in enumerate(tl) if sc["s"].get("html_path")]
            if stuck:
                sys.exit(f"Scene(s) {stuck} are HTML scenes without a Python fallback and no browser was found, so their slides cannot be drawn.\n"
                         + html_engine.INSTALL_HELP)

    def shot(i, t):
        layer = HE.layer(E, tl, i, t) if HE and tl[i]["s"].get("html_path") else None
        return E.png_bytes(E.render_frame(tl, i, t, deck, html_layer=layer))

    if a.only:
        idx = []
        for part in a.only.split(","):
            if "-" in part:
                lo, hi = part.split("-"); idx += list(range(int(lo) - 1, int(hi)))
            else:
                idx.append(int(part) - 1)
        idx = [i for i in idx if 0 <= i < len(tl)]
    else:
        idx = list(range(len(tl)))
    if not idx: sys.exit("No scenes selected.")

    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)       # 16:9, 13.333 x 7.5 inches
    layout = prs.slide_layouts[5]                                        # "Title Only": the title feeds the outline and screen readers; the picture covers it
    prs.core_properties.title = deck
    prs.core_properties.subject = "Slides drawn from the narrated video; the narration is in the speaker notes"

    def add_slide(png, title, notes, alt):
        s = prs.slides.add_slide(layout)
        if s.shapes.title is not None: s.shapes.title.text = title
        pic = s.shapes.add_picture(io.BytesIO(png), 0, 0, width=prs.slide_width, height=prs.slide_height)   # added last = on top of the title
        pic.name = "Slide picture"
        try: pic._element.nvPicPr.cNvPr.set("descr", alt[:600])          # alternative text for screen readers
        except Exception: pass
        s.notes_slide.notes_text_frame.text = notes

    n_slides, n_words = 0, 0
    for i in idx:
        sc = tl[i]; beats = sc["s"]["beats"]; chapter = str(sc["s"]["chapter"]).title(); tf = final_time(sc)
        if a.per_beat:
            for k, b in enumerate(beats):
                add_slide(shot(i, beat_time(sc, k, tf)), f"{i + 1}.{k + 1} {chapter}", b, f"{chapter}. {b}")
                n_slides += 1; n_words += len(b.split())
        else:
            text = "\n\n".join(beats)
            add_slide(shot(i, tf), f"{i + 1}. {chapter}", text, f"{chapter}. {text}")
            n_slides += 1; n_words += len(text.split())
        print(f"scene {i + 1}/{len(tl)}: {len(beats)} beat(s) -> slide{'s' if a.per_beat and len(beats) > 1 else ''}", flush=True)

    os.makedirs(a.out, exist_ok=True)
    path = os.path.join(a.out, a.name)
    try:
        prs.save(path)
    except PermissionError:
        sys.exit(f"Could not write {path}. If the deck is open in PowerPoint, close it and run again.")
    mb = os.path.getsize(path) / 1e6
    print(f"DECK: {path}  ({n_slides} slides, {n_words} words of narration in the notes, {mb:.1f} MB)", flush=True)


if __name__ == "__main__":
    main()
