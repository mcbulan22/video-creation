# Third-party material shipped in this pack

| Item | Licence | Where |
|---|---|---|
| Lucide icons (1,903 icons, converted to drawing data) | ISC (with MIT notice for the Feather-derived icons) | scripts/lucide_icons.json, LICENSE-lucide.txt |
| KaTeX 0.19 (equation typesetting for HTML scenes) | MIT | html_runtime/katex/ (LICENSE-katex.txt) |
| JetBrains Mono (code font for HTML scenes) | SIL Open Font License 1.1 | html_runtime/fonts/ (LICENSE-JetBrainsMono-OFL.txt) |
| Bundled fonts (Inter, Poppins, Lora, Playfair Display, Chakra Petch, Kalam, Fredoka) | SIL Open Font License | fonts/ |
| Python packages installed by setup: skia-python (BSD), pillow (HPND), edge-tts (LGPL, optional), playwright (Apache-2.0), python-pptx (MIT, installed the first time you make a deck) | as listed | your private environment |

Playwright only controls a browser that is already on your computer; nothing is downloaded by the HTML engine.
