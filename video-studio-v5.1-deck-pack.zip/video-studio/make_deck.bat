@echo off
rem PowerPoint deck on Windows: one picture slide per scene, the narration in the speaker notes.   make_deck.bat   or   make_deck.bat --per-beat   or   make_deck.bat --draft
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
set "PY="
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% studio.py deck %*
set "RC=%ERRORLEVEL%"
echo %cmdcmdline% | find /i "%~nx0" >nul && pause
exit /b %RC%
:nopython
echo.
echo Python is not installed on this computer.
echo Install Python 3.12 from https://www.python.org/downloads/
echo   - choose "Install for me only" (no administrator rights needed)
echo   - tick "Add python.exe to PATH" on the first screen
echo Then double-click this file again.
pause
exit /b 1
