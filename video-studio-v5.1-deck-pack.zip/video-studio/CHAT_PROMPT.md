# Prompt to paste into Claude chat (with the scene-video-studio skill) for a NEW video
(Attach the video-studio pack zip you already have, so Claude uses the same engine.)

## Step 0: brief and facts, BEFORE any scenes
Use the scene-video-studio skill, and work in this order:
1. Ask me at most five questions, only for what you cannot read from my material (audience, the one takeaway, length, look or mood, where it will be shown). Fill the rest of `inbox/brief_TEMPLATE.md` yourself.
2. Write two files for me to review: `brief.md` (the director's brief) and `facts.md` (one line per number, name, date or claim that will appear, each with its source and verified / UNVERIFIED, format in `inbox/facts_TEMPLATE.md`).
   Take every fact from my material. Never invent, estimate or round a number. Show me both and wait for my corrections.
3. Only then write `scenes.py`. Every number on screen or in the narration must be in facts.md. Made-up numbers are allowed only in a scene that says "Example data" on screen. Cite fact ids in code comments (`# F3`). Keep every figure that reaches the screen through a loop or variable in a module-level `FIGURES = {...}` block so `python studio.py facts` can check it.
4. Read `reference/anti-generic.md` first and follow it. Name each scene's single point in one sentence.

## Step 0.5: choose the engine for each scene (v5)
Show me a short plan table before writing code: scene | what it says | engine (Python or HTML) | why. HTML for tables, rubrics, matrices, long wrapping text, equations, code and UI mockups; Python for motion graphics, charts, particles, morphs and effects. Read HTML_SCENES.md.
Write each HTML page to `inbox/html/<name>.html` and use `@scene(..., html="html/<name>.html")`; add `fallback=True` with a simple Python drawing only where that is easy.

## Step 1: the scenes
- About ___ minutes, about ___ scenes, audience: ___ (from the brief).
- Beat text = the exact narration (read aloud by a computer voice or by me).
- Scene 1 = a title scene. Use `sky=True` (horizon that dives into the sea) only with the ocean look; other looks have their own title backdrop.
- Use S.num count-ups, S.glow and reveals that suit the chosen look. Check every scene for overlapping or overflowing text.
- Deliver the full pack as a zip (inbox/scenes.py + inbox/brief.md + inbox/facts.md + narration_script.txt + the engine), not a rendered video. Before delivering, run `python studio.py facts` and report anything it flags.
- Sound (SOUND_AND_QA.md): effects are automatic. Use `sfx="off"` on a scene to silence its pops, or `sfx=[(beat, offset, "chime")]` for specific cues. After a draft, ask the user to run `python studio.py qa` and share `output/qa_report.txt`; for important videos suggest the CRITIC_PROMPT.md independent review.
- Freeform mode (FREEFORM.md): when the user asks for "freeform", "custom" or "something unique", write a deck-specific look with set_look, scene hooks (bg / fg / trans / live),
  the fx toolbox, S.text_anim and S.svg. All effects must be pure functions of time. Keep one hero effect per scene and stay inside the performance budgets.
- Icons: S.icon works with the 28 built-in names and all 1,900 Lucide icons. Lucide renames icons between versions, so use only names from `reference/icons-by-topic.md`, `reference/lucide-icon-names.txt`, or `python scripts/find_icon.py <word>`.
- Easing per element: `S.p(beat, dur, delay, ease="spring_snappy")` (spring_gentle / snappy / bouncy / wobbly / stiff / slow, exact physics). Cameras: `with fx.camera(S.c, *fx.cam(S.t, [(0, (1.0, 960, 540)), (6, (1.2, 1100, 500))])):` zooms evenly.
- Motion Kit (KIT.md): use it. Kinetic or gradient titles, S.icon on every card row, S.stat / S.ring / S.bars / S.linechart for any numbers, S.flow for processes,
  S.morph_shape or S.morph_text for one change-over-time moment per video, S.spotlight to focus the key point, S.burst on the final scene. Spread over beats.
- Themes: the pack has eight looks (v4 adds aurora and editorial) (clean default, ocean, techno, classroom, formal, playful, aurora, editorial) chosen with `--theme`. Write scenes that work in all of them:
  use the colour roles (white = text, teal = accent, amber = second accent), no hard-coded colours, no delay longer than 0.3 s per item
  (themes tighten cascades), put the hero element on the first beat, and check contact sheets for at least clean and one dark theme.
- Motion rules are in MOTION.md. Run the motion report before delivering and mention any WARN.
- The pack runs on a Mac and on a Windows PC through `studio.py`; scenes must not depend on the computer (no absolute paths, no OS-specific fonts or commands). The user may render on either machine.

## Deliverable (v5.1): video AND PowerPoint deck
- The same scenes file also makes a PowerPoint deck: one picture slide per scene, the narration in the speaker notes (DECK.md). Nothing extra to write; write beats that read well aloud AND as speaker notes (12 to 25 words each).
- Tell the user both commands: video (`sh make.sh --draft`, then `sh make.sh`; PC `make.bat`) and deck (`sh make_deck.sh`; PC `make_deck.bat`), or both at once with `--deck`. Mention `--per-beat` for one slide per beat.
- Say plainly that the slides are pictures (not editable) and that the deck was not opened or tested on the user's computer unless it was.
