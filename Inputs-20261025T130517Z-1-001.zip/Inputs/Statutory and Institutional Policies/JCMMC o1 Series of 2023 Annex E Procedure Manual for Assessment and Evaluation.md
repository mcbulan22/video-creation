ANNEX E — Procedures Manual for Assessment and Evaluation
of Competences for the BSMT and BSMarE Programs

PREFACE
r

By

virtue

of

Commission

En

Banc

(CEB)

Resolution No. 657-2022, the Commission on Higher

Education,

approved

this

Procedures

Manual for

Assessment and Evaluation of Competences of the

Bachelor of Science in Marine Transportation (BSMT)
and

',

Bachelor

(BSMarE)

of

Science

in

Marine

This

in

recognition

Courses.

Philippines’

need

to

is

produce

globally

Engineering

of

the

competent

Filipino seafarers, grounded on the requirements of

the International Convention on the Standards of

Training, Certification and Watchkeeping (STCW) for
seafarers, 1978, as amended.

The formulation of this Manual serves as a testament of the Commission’s steadfast
commitment to its Constitutional mandate to protect, foster and promote the right of all

citizens to quality education. CHED, per Republic Act 7722, otherwise known as the Higher
Education Act of 1994, assumes the lead role in ensuring the enhancement of knowledge,
skills, values and attitudes of maritime students, thus, honing them to acquire the attributes
reflective of the Filipino brand of seafarers being the shipowners’ choice to man their
vessels in both local and international merchant marine fleets. In fact, the International
Chamber of Shipping (ICS) and the Baltic and International Maritime Council (BIMCO)
published in the ICS Workforce Report 2021 that the Philippines is the top supplier of
competent and qualified officers and ratings.

it is therefore expected that through this Manual which will serve as a guide to
faculty members when they assess Maritime students on whether they attain the program

educational objectives, graduates of BSMT will produce competent Officers in Charge of a
Navigational Watch on seagoing ships of 500 gross tonnage or more while graduates of
BSMarE program will produce competent Officers in Charge of an Engineering Watch in a
manned engine-room or as designated duty engineer in a periodically unmanned engineroom on seagoing ships powered by main propulsion machinery of 750 KW or more,
adaptive to change, proficient in English and Filipino, and always abreast with
developments in Maritime practice.

The Maritime Higher Education Institutions (MHEls) in the country will greatly

benefit from this document as they will be guided in strengthening the implementation of
outcomes-based education. Ultimately, the results of this initiative will serve as a continuing
legacy of sustaining the quality of future Filipino seafarers.

J. PROSPERO E?DE VERA Way

Chairman

He

COMISSION ON HIGHER EDUCATION



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

TABLE OF CONTENTS

Sec.
A

Topic

Page
No.

1. Introduction and Statement of Purpose

01]

2. OBE Principles Applied in Assessment and Evaluation

01

B | 3. Scope of the Manual

02

4. Assessment and Evaluation

02

5. Framework of Assessment Process (Diagnostic-Formative-Summative)

02

6. Assessment Procedures/Processes and Persons In-Charge

GS

6.1 Diagnostic Test/Assessment
6.2 Assessment for Student Learning (Formative Assessment)
6.3 Assessment of Student Learning (Summative Assessment)
6.4 Qualifications and Tasks of the Course Assessor
6.5 Onboard Training Assessment

03
03
03
04
04

6.6 Comprehensive Assessment/Examination
7. The Table of Specifications
7.1 Table of Specifications for Assessment of Cognitive Learning

05
05
06

Outcomes

D

7.2 Table of Specifications for Assessment of Psychomotor Learning

07

Outcomes

7.3 Table of Specifications for Assessment of Affective Learning

08

Outcomes

F

F

G

8. The Assessment Plan
9. Assessment Standard and Criteria
10. Assessment Instrument/Tool
10.1 How to develop the assessment instrument starting from the LO and

09
1]
11
12

using taxonomies
10.2 Table of Outcomes Assessment (TOA)
10.3 Assessment Tools for the Post-Onboard Assessment (POA)
10.4 Assessment Tools for the Comprehensive Assessment/Examination
11. Rubrics
12. Assessing Evidences gathered from the assessment
13. Checking Constructive Alignment
14. The Marking/Scoring and Grading System
15. Analyzing and Interpreting Results for Evaluation and Decision Making
15.1 Assessment of Outcomes of Various Courses of the Program

12
14
14
14
1S
15
15
16

15.2 Assessment of OBT

15.3 Comprehensive Assessment

H | 16. Definition of Terms

16

Annexes

A - The Bloom's Wheel

B —- Watchkeeping Duties Performed On Board
C - STCW-Required Competences of BSMT and BSMarE Programs
|

D —- Taxonomies of Learning Outcomes
E-Item Analysis
F — Parallel Test Items

G-— Content Validity and Construct Alignment
H — The Rosenberg Self-Esteem Scale
SAM

Page 1

22"22 — Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

|-— Table of Outcomes Assessment

jJ—Competency Attributes for BSMT, BSMarE Cognitive Course Outcomes
Assessment

K — Rubrics

L — Guidelines for the Grading System

aos icy,

he

Sa

.

Page 2

MPeversion 2022.11.16
~~) ~

¥

aN

aod

=

SS

°



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Al. INTRODUCTION AND STATEMENT OF PURPOSE

This manual intends to guide the Maritime Higher Education Institution

(MHEl)

in its

responsibility to design and develop, review and verify, validate and approve its theoretical

and practical assessment tools for all Course Outcomes defined in the course specifications
(JCMMC 01, s. 2022, Art Vil, Sec.16). It serves the purpose of consolidating all essential
elements of assessment and evaluation and unifying their interpretations and applications in
the light of establishing a common and standard way of structuring the examination and
assessment system in accordance with the regulatory requirements (Art VII, Sec.18).
This Manual uses the following regulations for its framework:

1. STICW Convention ‘78, as amended, specifically the STCW Code for the required
competences and standard of evaluation

2. JCMMC 01, s. 2022 and its Related Annexes and JCMMC 03, s. 2022, Annex E4 for the
required standard to be met in the development and conduct of the standard course
packages and assessment

3. CMO 46, s.2012 for the deployment of Outcomes Based Education approach in curriculum
design, course deliveries, and assessment

After assessment, the student's performance will be evaluated in order to ascertain the
competency the student has acquired from his education and training, or the lack of it which
signals the need for reinforcing his prior knowledge and skills.
For quality control, the MHEI is advised to include its Competence Assessment Systemin
Quality Standard System (JCMMC 01, section 19 and 20).

its

For MHEls who are using Flexible Learning, provisions for online / blended assessment is
optional if resources for such are available. Otherwise, face-to-face assessment using paper
and pen materials will be required.

A2. OBE PRINCIPLES APPLIED IN ASSESSMENT AND EVALUATION

Outcomes-Based Assessment (OBA) requires the MHEI to identify what the students will be
able to do after completing a course or a program. In the context of the maritime education
programs, these matters pertaining to “what the students will be able to do” refer to the
competences required in the amended STCW. Evidences should be gathered to
attest/prove such acquired and developed abilities. After evaluating the adequacy of
evidences, decision will be made whether the student has attained the competence or not
by virtue of student's manifestation/demonstration of the required standard of competence.
Basically, the application of the OBE principles will be checked by answering the following
questions:

1. How will each learning be assessed to generate the evidence/s of student's relevant
learning?

2.

What standard or criteria will be used to evaluate the evidence/s?

on MCy

PNY

SON

Page |

Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

B3. SCOPE

This Manual covers assessment and evaluation of all outcomes to be achieved in the
completion of the BS Marine Transportation and BS Marine Engineering programs, with
reference to their respective competency map, including those that are to be covered by
the Onboard Training (OBT) Program.

Since the implementation of the OBT is in collaboration with the manning companies who
have deployed the students on board, details of student's performance assessment during
OBT will be in accordance with the approved Training Record Book (TRB). Guidance on how
the post-OBT assessment and evaluation will be carried out, and the Comprehensive/
Validating/Exit Examination that will be given to students prior to graduation are included in
this Manual.

C4. ASSESSMENT AND EVALUATION
Assessment refers to the verification of competency of students necessary to enhance
the learning process and is critical to certifying the competence of the students (JCMMC
Ol, s. 2022, sec. 2.2).
Assessment

of Competence refers to the process of collecting

evidence through

theoretical examination and practical assessment of the knowledge, understanding and

proficiency gained from one or more

of the following: approved education and

training; approved training ship experience; approved simulator training; approved

laboratory equipment training; approved in service, and making judgment on whether
competency has been achieved (JCMMC 01, s. 2022, sec. 2.3).
Evaluation refers to the process of making judgment on the compliance of the MHEl

and the maritime education program being applied for approval with the pertinent
standards and requirements prescribed by the Maritime Administration and the CHED in
accordance with the STCW Convention, 1978, as amended (JCMMC 01, s. 2022, sec.
2.19).

Evaluation of learning outcomes is attained after assessing the competency of a student,

and making judgment of all the collected required evidences so as to lead to a decision
of whether or not he has achieved competency (JCMMC 01, s. 2022, sec. 2.3).

C5. FRAMEWORK OF ASSESSMENT PROCESSES (2-STEPS)

Tergered
Learning
Outcome

1. Intended
Learning
Outcome (ILO)

Assessment
Method

Formative

Assessment Tool

When fo give

Depends on action verb of the
ILO; short test, practice/

During/After
course delivery

performance test, oral test,
essay test

OMe,

STA

Page 2

version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

2. Course
Outcome (CO)

Summative

Depends on action verb of the

After the course

CO; long test, performance

delivery related to

test, oral test, essay test

it/towards the end

of the course

Cé. ASSESSMENT PROCEDURES/PROCESSES AND PERSONS IN-CHARGE
6.1 Diagnostic Test/Assessment (optional)

This type of assessment is focused on the prior/previous-learning or current knowledge of
students related to the lesson of the course. Results of this test show the strength or weakness

of student's knowledge/skill/ability, and may be used by the Faculty/Instructor to identify the
scope of the lesson where the spiral approach will be used to strengthen the underpinning
knowledge required in the course. For this reason, Diagnostic Assessment/Test is best
administered before the start of the course.
The Diagnostic Test may be given using any assessment tool that covers the outcomes to be
checked for stock/previous knowledge such as the MCQ, completion test, or any other
objective test. The entrance examination of an MHEl may be considered serving the purpose
of diagnostic assessment if such test has been appropriately prepared and validated.

6.2 Assessment for Student Learning (Formative Assessment)

During and or after course delivery, the Faculty/Instructor will give a formative assessment to
his students to find out if the students have learned the intended learning outcome (ILO) of
the lesson/s by giving a short test or a quiz such as a completion test, true or false test, multiple
choice test, matching type test, computation/calculation test, essay test, oral test, or an
exercise/practical test. The specific type of assessment tool to be used depends on the
action verb of the ILO. For quick reference and guidance on this matter, refer to Bloom's
Wheel (Annex A).

Results of formative assessment are used to determine if the student needs reinforcement
after the lesson. If results turned out to be below acceptance value/standard, re-teaching
the

specific

concerned

lesson

or

allowing

the

student

to

practice

more

the

exercise/drill/activity where he is weak will be necessary before checking him again for
another formative assessment. This may be repeated so as to ensure that the student has
learned the lesson/s. Results of formative assessment may be given credit for a grade
depending on the MHEI’s Grading and Quality Systems.

6.3 Assessment of Student Learning (Summative Assessment)
After the course delivery or towards the end of the course, whichever is the best time-frame
to catch the student's retention of learning the course outcome (CO), the designated
Course Assessor or his duly authorized and trained Faculty/Instructor shall administer the
summative assessment to find out if the student has achieved the CO. Such assessment may
be given in the form of any of the following tests, singly or in combination, depending on the
action verb of the CO: multiple choice questions (MCQ), computation/calculation test,
essay test, oral test, or a practical/performance test. Reference can be made to the Bloom's
Wheel (Annex A) for other types of assessment tools that match the action verb used in the

GO:
soe,

eS

xX

Page 3

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

6.4 Qualifications and Tasks of the Course Assessor

The MHEl shall ensure that the course outcome and related competency assessment are
prepared, managed, and conducted by a designated Assessor, the latter task may be
delegated to an instructor / invigilator / proctor with Assessor's training for courses/classes
not assigned to him for teaching with the following qualifications:

a.

have an appropriate level of knowledge and understanding of the competence to
be assessed;

b.

be qualified in the task for which the assessment is being made;

c.

have undergone training in the following:
1. Training Course for Instructors (IMO Model Course 6.09)

2. Assessment, Examination and Certification of Seafarers (IMO Model
Course 3.12)

3. Train the Simulator Trainer and Assessor Course (IMO Model Course 6.10), or
an approved training course for Simulator Instructors and Assessors by the
Maritime Administration for those assessing competence using simulators;

d.

gained practical experience as assistant to an experienced assessor for at least one
semester;

e.

gained practical assessment experience on the particular type of simulator of the
Institution under the supervision and to the satisfaction of an experienced assessor for
assessments involving the use of simulators.

The following tasks shall be assigned and performed by the Course Assessor:
a. Spearhead the design, development and enhancement of assessment tools;
b. Ensure reliability and validity of assessment tools;

c. Administer or delegate to his invigilators the conduct of examination/assessment;

d. Evaluate the validity of assessment tools and other related instruments to serve as basis
for enhancement of assessment process;

e. Assess the course outcomes of classes not assigned to him for teaching.
In view of the number of students to be assessed and the time-frame of assessment which
may be scheduled simultaneously across different sections of students, the following
considerations may be undertaken:

a. Any school personnel may be designated as proctor for the administration of
theoretical/written assessment under the supervision of a qualified assessor.

b. Faculty of a technical course for which he/she is qualified may be designated as
invigilator/ proctor for the administration of practical / oral assessment of the laboratory
/ technical course under the supervision of a qualified assessor.

6.5 Onboard Training (OBT) Assessment

Pre-requisite to OBT assessment is that 70% of the applicable tasks written in the TRB must have
been done by the student on board. Otherwise, the MHEI should send back fo the ship the
said concerned student so as to complete his OBT tasks.

The Post-OBT Assessment (POA) is given by the designated office and assessor/s of the MHEI
after completion of the 12-month OBT or 36 months actual work on board which have been
set as equivalent to the required OBT without using a TRB. The student must have performed
the tasks required of him as per his approved-Training Record Book (TRB).
oo
f AP:

Page 4
Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Upon completion of OBT and reporting to the MHEI, the Assessor should carry out the
following steps:

1. Validate the OBT documents submitted by the student to check authenticity;
2.1 For completers of 12-month OBT, identify the tasks performed, as shown in the TRB, if
each task has been signed by designated authority

2.2 For applicants of 36-month equivalency to OBT, check the sea service records if
watchkeeping duties were performed on board (refer to Annex B)
3. Create assessment tool/s (written, practical, oral) from the tasks performed onboard;
4. Create minimum of three (3) complete assessment tools of competences per Function;
5. Administer the written, practical, and oral assessment.

6.6 Comprehensive Assessment/Examination
Every BSMT and BSMarE student shall be required to pass an assessment of competences

acquired prior to conferment of the degree (JCMMC

O01, s. 2022, Sec. 21). These

competences are with reference to the amended STCW (Annex C).

The comprehensive assessment shall be given to a student who has completed the entire
curriculum of the program. The scope of this assessment covers the minimum requirements
of the STCW Competency Map addressed by the curriculum and the OBT. To avoid
redundancy, and cover as much outcomes attained during the OBT, test items covered in
the POA will not be included in the comprehensive assessment.

D7. THE TABLE OF SPECIFICATIONS

(Kinds, How to Develop, How to Use in Developing the Assessment Tools)

The Table of Specifications (ToS) is a tool used to design an assessment or test or exam and
ensures the coverage of ALL learning outcomes (ILOs and COs). Take note that the CO can
be developed/attained by the student as he achieves the ILOs. Therefore, in the process of
using the ToS, the formative assessment is done first before the summative assessment.
The uses of the ToS are the following:

e

Categorize the LOs to be assessed by the learning domain that has been developed
during the course deliveries. The kinds of ToS are as follows:

> ToS for Cognitive Learning is used for the assessment of knowledge and intellectual skills
> ToS for Psychomotor Learning is used for assessing the skills developed
> ToS for Affective Learning is used for assessing the behavior and attitude developed in
the course

e

Ensure that a fair and representative sampling of questions/exercises/activities/ scenarios
are covered in the assessment tool (AT) according to the LOs that will be measured;
e Provide the assessor and faculty with evidence that the AT has content validity and that it
covers what should be covered;

e

For purposes of developing the ToS and assessment ifems/tools, the Bloom's Wheel (Annex
A) presents a@ comprehensive application for assessment of both Cognitive and
Psychomotor Learning. Annex D may also be used as it presents the three (3) taxonomies
of learning outcomes.

Le

{Se
“Saye

Page 5

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

7.1 Table of Specifications for Assessment of Cognitive Learning Outcomes
(Ref: Bloom, et.al., 1990)

Covers both formative and summative assessment of knowledge which is translated in
terms of intellectual behavior;

Includes recall or recognition of specific facts, procedural patterns, and concepts that
serve in the development of intellectual abilities and skills;

Categories of assessing cognitive learning start from the simplest to the most complex;
Application of OBE principles can be shown from the third category up to the highest level;
To have an adequate number of valid test items per learning/course outcome, it is
recommended to construct at least 3 parallel valid test items which may be used for the
assessment periods of prelim, midterm, and final, or for other purposes such as developing
a test bank after passing item analysis (refer to Annex E for the mechanics of Item Analysis);
Parallel test items are different test items in terms of test construct/structure/format but
covers the same learning outcome and content (refer to Annex F for samples of parallel
test items);

Valid test item means that the test item's content (what it is about) and how the item is
constructed will indeed measure the learning outcome (refer to Annex G on how to
validate test items);

This ToS is prepared by the Faculty/Instructor and Assessor of the course.

Sample of ToS for Assessment of Cognitive Learning Outcomes
TABLE OF SPECIFICATIONS FOR COGNITIVE LEARNING OF THERMODYNAMICS
STCW Competence to be assessed: Plan and schedule operations
Levels
of Intellectual Learning
sda

oe

Tovi

"P|

Total No. of

Remembering Understanding | Apphing | Anahning | Evaluating | Creating | tems |

%of
Items

Apply principles
of
(01 thermodynamics in solving

problems relating to heat
balance of the various cycles
Explain the mechanisms of heat

U0 1.1 transfer and identify examples
and applications

Calculate parameters involving

ILO 1.2\the three mechanisms of heat
transfer
Explain the principles of heat

ILO 2..\transfer, quantity of heat, and
heat capacity

ino 2.2| Explain the process in
measuring heat capacity

Total No. of tems

%of tems

a

Page 6
Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Steps on How to Develop the ToS for Assessment of Cognitive Learning Outcomes
hs Copy the Course Outcomes followed by the Intended Learning Outcomes of the course
from the Annex C of the Standard Package of the course.
2. From the Detailed Teaching Syllabus (DTS), copy the topic that corresponds to each of the

ILO and CO.
3. Analyze the action verb, the condition setting, and standard written in the CO to identify

the category/level of learning behavior in the ToS that will be used in developing the
Assessment Tool.

For example, ILO 1.1 action verb is “explain.” The category level of this verb is “Analyzing.”
Assign at least 3 assessment/test items and write their number accordingly under the
chosen learning behavior.

. After completing the requirements for all COs and ILOs, complete the required statistics of
the last two rows and last two columns of the ToS.
e Total no. of items in the column is determined simply by counting the number of test
items written within the same row.

¢ Total no. of items in the 2°9 to the last row below the table is determined by counting
the number of test items written within the same column.

e % of Items in the last column is determined by dividing the total no. of items per row by
the overall total no. of items multiplied by 100.

e % of Items in the last row is determined by dividing the total no. of items per column by
the overall total no. of items multiplied by 100.

7.2 Table of Specifications for Assessment of Psychomotor Learning Outcomes
(Ref: Simpson, 1972)

Covers both formative and summative assessment of physical movement, coordination,
and use of the motor skill areas of learning;

Development of these skills requires practice;
Skill developed may be measured in terms of speed, precision, distance, procedure or
techniques in execution (depends on the ILO/CO);
Categories of learning are listed from the simplest behavior to the most complex;
To have an adequate number of valid test scenarios per learning/course outcome, it is
recommended to construct at least 3 parallel valid test scenarios which may be used for
the assessment periods of prelim, midterm, and final, or for other purposes such as rework
or resit;

Parallel test scenarios are different test situations but cover the same learning outcome
and required condition;

Valid test scenario means that the parameters, conditions, and calculated/ anticipated
results of using the assessment tool will indeed measure the targeted learning outcome;
This ToS is prepared by the Faculty/Instructor and Assessor of the course.

ac rome,

i

[AMD

Page 7

owe

Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

Sample of ToS for Assessment of Psychomotor Learning Outcomes
TABLE OF SPECIFICATIONS FOR PSYCHOMOTOR LEARNING OF SEAM 1
STCW Competence to be assessed:

A-ll/1. F1.C7 Use the IMO Standard Marine Communication Phrases and the English language in written and oral form
A-li/1. F1.C8 Transmit and receive information by visual signalling
A-li/5. F3.C1 Contribute to the safe operation of deck equipment and machinery
A-li/5. F3.C2 Apply occupational health and safety precautions
A-ll/5. F4.C1 Contribute to shipboard maintenance and repair

;

Statement of Outcome

P

Topic

Perception Set

i
Guided

Total No. of Items

% of tems

Steps on How to Develop the ToS for Assessment of Psychomotor Learning Outcomes
r Copy the Course Outcomes followed by the Intended Learning Outcomes of the course
from the Annex C of the Standard Package of the course.
2. From the DTS, copy the topic that corresponds to each of the ILO.
os Analyze the action verb, the condition setting, and standard written in the CO to identify
which category/level of skill learned/developed in the TOS will be used in developing the
Assessment Tool.

. Assign at least 3 assessment scenarios and write their number/code accordingly under the
chosen skill learning behavior.

. After completing the requirements for all COs and ILOs, complete the required statistics of
the last two rows and last two columns of the TOS.

7.3 Table of Specifications for Assessment of Affective Learning Outcomes
(Ref: Krathwohl, Bloom, Masia, 1973)

Covers the assessment of student's manner in which he deals with things, people, and his
environment emotionally such as feelings, values, appreciation, enthusiasm, motivation,
and attitudes;

Assessment of this learning requires keen observation and consistency;
Categories of learning are listed from the simplest behavior to the most complex;
To have an adequate number of valid assessment scenarios per learning outcome, it is
recommended to set at least 3 parallel valid scenarios to establish the consistency of
learning outcome;

Valid test scenario means that the parameters, conditions, and calculated/anticipated
results of using the AT will indeed measure the targeted learning outcome;
This ToS is prepared by the Faculty/Instructor and Assessor of the course.

P

Page 8

SRI.
KOE

>:

2

"ee
-

—

Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

Sample of ToS for Assessment of Affective Learning Outcomes
TABLE OF SPECIFICATIONS FOR AFFECTIVE LEARNING OF THE COURSE:
Competence:

| Statement of Outcome

Topic

Levels of Behavior Development

iolNo-cll

%el

Receiving | Responding to Valuing | Organization Internalizing Activities Achaia5|
Phenomena | Phenomena

Values

ed

ieee

|

Total No. of Activities

% of Activities

Steps on How to Develop the ToS for Assessment of Affective Learning Outcomes
Pb

Copy the Course Outcomes followed by the Intended Learning Outcomes of the course
from the Annex C of the Standard Package of the course.

2. From the DTS, copy the topic that correspond to each of the ILO.
3; Analyze the action verb, the condition setting, and standard written in the CO to identify

which category/level of behavior development in the ToS will be used in developing the
Assessment Tool.

. Assign at least 3 assessment scenarios and write their number/code accordingly under the
chosen level of behavior development.

After completing the requirements for all COs and ILOs, complete the required statistics of
the last two rows and last two columns of the ToS.
Suggested Methods of Assessing the Affective Learning Outcomes
I. Faculty/Instructor Observation — can be unstructured by note-taking as in diary keeping,

describing student behavior like an anecdotal record; or structured observation by using
checklist, rating scale, or rubrics

. Student Self-Report — using interview or questionnaire where student expresses his
responses (refer to Annex H for a sample)
Peer Rating — by asking students to assess their classmate’s behavior using checklist, rating
scale, or rubrics

E8. THE ASSESSMENT PLAN

An assessment plan is an outline that includes all relevant portions of an assessment, tying
together each step of an assessment in consideration of the context in which the
assessment will occur;

Presents the consolidated summary of assessment to be carried out in a course and will
be cross-referred when developing and preparing the various assessment tools;
Assessment Method refers to the philosophical or pedagogical approach to assessment
such as written or practical assessment, formative or summative assessment;
Assessment Tools (ATs) are used for different assessment methods and are more specific.
ATs determine how to gather the evidence/s that will measure the ILO/CO competence
(e.g. Observation, Interview, Poster, Essay, Performance Test/Exam, Rubrics, etc.);

oiling
MK.

Page 9
Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Assessment Activities or assessment tasks are what we find inside the AT. These are the
ways that will be used to generate the evidence/s (e.g. Role Play, FGD, Oral Reporting,
Performance Test, etc.};

Evidences are proof/s that should be gathered and kept as such will support the results of
assessment (e.g. Observation Sheets, Checklist, Interview Questions, Journal, Rubrics, etc.)
Evidences of outcomes refer to specific attributes or characteristics expressed/
demonstrated by the student as indicators of his attainment of the ILO/CO;
Prepared by the Assessor of the Course.

Sample Template of an Assessment Guide/Plan
Assessment Guide/Plian

Course Code-Descriptive Title:
_
STCW Complied:

_

Competence for Assessment: _

KUPs:

Course Year Level:

:

Sem/AY:

Statements of | Domain of | Assessment
Outcome

Learning

Standard

Assessment| Assessment|Assessment
Criteria

Method

Tools

List of

Evidence/s

Steps in Developing an Assessment Plan
lL. Write the Course Outcome followed by its Intended Learning Outcomes;
a Analyze the Outcome and identify the domain of learning (cognitive/psychomotor/

affective) where it belongs;
3. Write the Assessment Standard to be used in accepting the outcome of assessment. The

assessment standard can be extracted from the statement of the LO, otherwise, refer to
column 4 of the respective Table of Competences of the STCW Code that is being
complied by the LO.

Analyze the standard and identify the assessment criteria (qualities, characteristics, and
aspects of assessment task that will be used to measure the attainment of the learning/
course outcome)

. Analyze

the

statement

of

outcome

and

determine

the

assessment

method

(formative/summative) to be used
. Analyze the statement of outcome and determine the assessment tool/s to be used and
the evidences that will be generated from using the assessment tools. The evidences are

the positive indicators or characteristics or attributes of the outcome of learning that is
being assessed.

Implement the plan in accordance with the course deliveries and assessment schedules.

Page 10
TH

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

E9. ASSESSMENT STANDARD AND CRITERIA
Assessment Standard

*

Specifies the criteria for determining proficiency;

*

States the characteristics or condition of outcome/s that will be accepted as indicative of
the presence of required knowledge, understanding, and proficiency;

*

Can be sourced from the Table of Competences of the amended STCW Code.

Assessment Criteria

¢ Qualities, characteristics, and aspects of assessment task that will be used to measure the
attainment of the learning/course outcome vis-a-vis the assessment standard

E10. ASSESSMENT INSTRUMENT/TOOL

An Assessment Tool is the same as Assessment Instrument. It refers to the documented
activities/tasks that have been developed to support the assessment method, and is used to
collect the evidence of student's competence (refer to the outer-most circle of Bloom's
Wheel in Annex A for more examples).

The assessment tool to be used in an assessment process/schedule depends on the purpose

and or outcome of assessment being targeted. The following are some common examples
of assessment tools aside from Annex A where you can see many other examples:
1. Case Studies
7. Multiple Choice Questions
13. Infographics
2. Problem Solving
8. Oral Test
14. Reports
3. Computer-Based Assessment
9. Assignment/Homework
15. Term Paper
4. Essays
10. Presentations
16. Portfolios
5.
Diaries
11. Project-Based
6.
Practical/Performance Test
12. Reflection Paper
The following table shows some samples of learning outcomes and the corresponding
assessment tools that can be used to assessed them:
Categories of Learning Outcomes (from the ToS)
and LOs to be assessed
1.

Thinking critically and making judgments:

Develop

Suggested Samples of
Assessment Tools to be used

Essay Test, Journals, Debate

arguments, Reflect...

2.

Solving problems and developing plans: Identify root

Scenarios Analysis, Group Work, Case Study,

cause, Analyze the data...

Focus Group Discussion

3. Performing procedures and demonstrating techniques:
Compute, Use equipment...

4. Managing

and_

developing

oneself:

Work

cooperatively, Work independently...
5.

Accessing

and

managing

Role

Play,

Poster-making,

Simulation,

Demonstration

information:

Portfolios,

Contract

Development,

Constructing Agreements
Research,

Annotated Bibliography, Project-Based

Organize data...

6.

Demonstrating knowledge and understanding: Recall,

Any Objective type of test, Essays

Describe...

7.

Designing. Creating, performing: Visualize, Produce...

Presentation (oral or written), Project-Based

8.

Communicating: Elaborate, Connect

Presentation (oral or written), Observation
ditties:

PNY Dye

Soy

Page11

Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

10.1 How to develop the assessment instrument/tool starting from the LO

—

and using taxonomies

. Identify the evidence/s of the LO to be assessed.

. Write the questions/test items or tasks for performance/practical test that will generate the
answer/evidence of the LO. Use the learning domain (ToS), where the evidence belongs
and can be generated/produced, for your guidance.
Take note that the ToS suggested three(3) test items/tasks per ILO/CO. Writing parallel

e

e

test items/tasks (Annex F) will be applied in completing the 3 test items/tasks, and it is
advised to consider writing test items/tasks that will use higher level of learning in the
taxonomy (refer to the ToS of the concerned learning domain).
Likewise, when writing the test item/task, be guided by the pointers on how to construct
properly the test item/task.

. Write the answer key for scoring purposes. This will be composed of sample answer/s for
each test item/task.

e

For computational test items, writing the solution may be considered as part of the
answer.

e

For performance/practical test, several aspects of evidence of learning such as
procedure, safety, characteristics of outcome, etc. may be considered in writing the
rubric that will be used in scoring the results of performance/practical assessment.
Write clear, simple, and complete instructions for students to follow when answering the
test/performing the task.

Submit the assessment instrument/tool to trial for face validity prior to actual use. For this
purpose, use at least three (3) Faculty/Instructor who will validate the instrument/test by
checking its content and construct alignment against the statement of the ILO/CO (Annex
G).

. For variation of assessment tools, the outermost circle of Bloom's Wheel (Annex A) can be
used as a source and reference.

10.2 The Table of Outcomes Assessment (TOA)
The TOA is a comprehensive documentation of a practical or performance assessment. The
TOA can also be used as a template for practical exercises of students. In doing this, the
student's learning of the skill to be developed becomes more thorough as the activity
involves the integration of all aspects of learning that should be acquired by the student in
one setting of an activity/task.

To construct the TOA, the following template and parts are described below (for completed
sample of a TOA, refer to Annex |):
TABLE OF OUTCOMES ASSESSMENT

Template for Practical Exercise

Elements

Description

Course

Encode here the Course Descriptive Title

Practical Exercise

Refers to the descriptive name of the scenario which is related to the learning

Title

outcome.

2

Page 12

as ry:
5

wy
"cz

-

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

STCW Competence | Encode here the specific competence covered by the course and addressed by

Addressed

the practical exercise

KUP Addressed

Encode here the specific KUP under the competence addressed by the activity

Course Outcome

Addressed
Learning Outcomes

Refers to the learning outcomes provided in the course syllabus as prescribed
in the Standardized Course Packages.

Encode here the specific activity required of the student through an outcome

Task

statement compose of a) Condition, b) Performance. C) Standards.

Pre-requisite

D

Encode here the CO under the course addressed by the activity

ana
‘

Encode here any requirements needed prior to the practical activity.

Refers to the estimated time in the execution of the exercise for each phase to

complete the entire scenario. (Familiarization, Briefing, activity, debriefing)

A
Venue/Equipment

Encode here, the location where the activity will be held and the equipment

Training Equipment

Refers to the specifications of the specific equipment within a system that will

Particulars

be used in the practical exercises.

Scenario

Refers to the script or outline of the activities

Initial Condition

that will be used.

Refers to the starting state of the equipment/environment, at which the
student will use as starting point in performing the given task.

Failure state

Refer to the conditions by which the exercise will be prematurely terminated

Student’s Actions

Refers to the activities the student is expected to undertake while undergoing
:
:
the practical exercise.

Refers to the description of the quality of student’s performance in

Performance

Criteria:

accordance with the learning outcome.

As per STCW Code Column 4 (Minimum SPAR or Safety, Procedural and
Results)

Safety: deviation from standard

Performance

Procedural: deviation from standard

Standard: SPAR
Results: deviation from standard
Note: this is the end state

Page 13

atlGy

MN

*

Version 2022.11.16



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

10.3 Assessment Tools for the Post-OBT Assessment (POA)

Assessment Tools for POA can be in the form of written, practical, and or oral test. Aside from
the purpose of validating the veracity of the tasks performed on board, as shown in the TRB,
the POA also intends to assess the student’s attainment of the critical tasks for certain
competences specified in the amended STCW.

In creating the AT for the POA, the Onboard Training Supervisor (OTS) will:
1. Create assessment tools for the written, practical, and oral assessment of the tasks
performed onboard by the students;

2. Create minimum of three (3) complete assessment tools of competences per Function;
3. Write the test items/tasks of the AT, following the steps for test development on page 10;
4, Administer the written, practical, and oral assessment.

10.4 Assessment Tools for the Comprehensive Assessment/Examination

The designated Assessor of the MHEI shall develop the ATs for this written assessment that will
cover all professional courses and OBT of the BSMT and BSMarE programs. For the OBT
component of the examination, parallel test items of the ATs for the POA will be used so as
to avoid redundancy. The types of test items to be developed depend on the action verbs
to be used in assessing the required competences.

Since the Comprehensive Examination is focused on the assessment of Competences

addressed by the professional courses of the BSMT and the BSMarE programs, Annex J
presents the Competency Attributes that can serve as guide for developing its assessment
tools. Likewise, the Bloom's taxonomy for intellectual learning may also be used in
constructing the ToS and assessment tools for the written comprehensive examination.

E11. THE RUBRICS

The rubric is a scoring tool that is used when assessing the performance output/outcome
more objectively by using criteria which are indicative of the required standard, and
indicators that describe the characteristics of outcome per criterion. A range of scores or
fixed markings are given for Assessor's quantitative interpretation of results. For samples of
rubrics, refer to Annex K.

The kinds of rubric are differentiated by their uses:

1. Analytic Rubric is used when:

*

Several Faculty/Instructors are collectively assessing student work output; descriptions
promote consistent scoring

*

Outside people will be examining rubric scores; used when substantial feedback to
students or faculty is desired

*

Profiles of specific strengths/weaknesses of the student are desired

2. Holistic Rubric is used when:

*
*

There is no single correct answer/response to a task (e.g. a creative work)
The focus is on overall quality, proficiency, or understanding of a specific content or
Skills

*

The assessment is summative

*

So many students are going to be assessed (e.g. 100 or more work outputs)
wm

OR,

“Say!
=

¥ *

Page

14

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

E12. ASSESSING EVIDENCES

Evidences of attainment of ILOs and COs are in documented proof/s that should be
gathered and kept as such will support the results of assessment (e.g. Observation Sheets,
Checklist, Interview Questions, Daily Journal, Rubrics, etc.). Basically, the evidences being
referred here are the concrete and actual manifestation of the characteristics or abilities
that prove the achievement of the LOs.

F13. CHECKING CONSTRUCTIVE ALIGNMENT

Teaching and assessment must be designed and implemented fo align with the learning
outcomes. Hence, when we teach or do an assessment, the valid question to check
alignment is “Are we on the same page as where the leaming oufcomes are?”
e Constructive alignment is an Outcomes-Based approach to teaching in which the LOs
that students are intending to achieve are defined before teaching begins;
e Teaching and assessment methods are then designed to best achieve those outcomes
and to assess the standard at which they have been achieved (Biggs, 2014);
e Assessment is marked against criteria with reference to the outcomes (Spady, 1994);
e Inconstructive alignment, assessment is aligned to the LOs/COs and students construct
knowledge and skills through the teaching and learning experiences they gained from
the learning activities;

e

The focus in constructive alignment is on WHAT AND HOW STUDENTS LEARN, rather than
on the topic the teacher teaches.

Steps in Designing Constructively Aligned Teaching and Assessment
1. Describe the course and or learning outcomes in the form of a standard that students

are to attain using appropriate learning verbs; use the Bloom’s Wheel (Annex A) for your

guidance;

2. Create the learning environment that is likely to bring about the learning outcomes
through teaching and learning activities that will translate the LOs into work outputs
whose characteristics indicate the attainment of the LOs.
3. Use assessment tasks to enable you to measure and judge if and how well student's

4.

performances meet the LOs;

Develop grading criteria or rubrics for judging the quality of student's performance.

G14. THE MARKING/SCORING AND GRADING SYSTEM

e Marking or scoring is assigning point/s to student’s correct answer, the number of points
depend on the processing of learning used by the student to arrive at the correct answer;
e

MHEI does not use transmutation of scores when computing for student grades;

e

Percentage (%) equivalent of score is taken and used to represent the grade; an example
is a grade of 80 if student gets 8 correct answers from a 10-item test multiplied by 100;
e MHEI’s Grading System may consider 60% as “passed” or even higher depending on the
MHEI's Quality Standard System;

e The interpretation of assessment results in terms of evaluation of student performance
expressed in equivalent grade is within the responsibility of the course's faculty;
e For equivalency of MHEls grading system, refer to Annex L of the JCMMC 01, s. 2022;
Page 15
Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

e The components of a grade for scholastic performance depend on the policy of the
school for its grading system;

e

Annex lL recommends a grading system that is worth adopting if in case the MHEI would
like to rationalize further its current grading system.

G15. ANALYZING AND INTERPRETING RESULTS FOR EVALUATION/DECISION MAKING

Guidelines to be used in Evaluating Results and Decision Making
|. Summative Assessment of Outcomes of Various Courses of the Program
e For NGEC courses, passing is not less than 60% or may be higher depending on the
policy of the MHEI on the grading and promotion system;

e

For Professional/Technical Courses, passing grade across all courses of both BSMT and
BSMarE program is at least 75%.

ll. Assessment of Outcomes of OBT for 12-month or 36-month equivalence
In any of the following assessment modalities, the passing standard is the same:
e

Written — passing is 75%

e

Practical - passing is 75%

e

Oral - passing is 75%

In the case of 36-month OBT completer, the concerned student-seafarer will be assessed
based on his ability to perform the required competences per function and
watchkeeping duties done on board.

lll. Outcomes of Comprehensive Assessment

The passing standard for comprehensive assessment is 75%, regardless of the form (written,
practical, oral) in which the assessment is given

H16. DEFINITION OF TERMS

Affective Learning Outcome refers to learning that involves attitudes, motivation, and values.

Cognitive Learning Outcome refers to learning that is associated with knowledge of facts,
processes, and other intellectual indicators of learning.

Construct Validity is attained when the test measures the outcome that is intended to be
measured.

Content Validity is attained when the test fully represents the topics to be measured.
Course Outcome refers to the clear statement of a learning outcome articulated from the
competences of the STCW code, that has a verb that sets the condition (situation under
which the behavior is to occur) and the required standard (criteria of acceptable level of
performance) that would enable the learners / students to perform task, function, or role after
completion of collective related lessons.

Page 16

attiten,

XEKM

Oa

‘at
a

x

Version 2022.11.16
<



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Criterion Validity is attained when the results accurately measure the concrete outcome they
are designed to measure.

Face Validity is about whether a test appears to measure what it is supposed to measure. It
is concerned with whether a measure seems relevant and appropriate for what it is assessing

on the surface. To achieve face validity, the measure should be:
e

Clearly relevant for what it is measuring

e

Appropriate for the participants

e

Adequate for its purpose

Grade represents the result of evaluation of student’s quality of work or performance; a
measure of student’s proficiency level in attaining the course outcome.

Grade Point Average (GPA) is a number representing the average value of the accumulated
final number of units earned in courses over time. More commonly called the GPA, a student's
grade point average is calculated by adding up all final grades that have been multiplied

by their respective number of units and dividing the sum by the total number of units.

Excluded from obtaining the GPA are the following courses: National Service Training
Program, Basic Training, comprehensive exam results, and others of similar nature.
Invigilator is an examination proctor delegated by the qualified Assessor to administer an
assessment on his/her behalf, wno ensures the proper conduct of assessment, and supervises
the assessment in accordance with the MHEI's quality procedures.

Learning Outcome refers to the clear statement that has a verb, content, context and some

cases a condition, and standard that signifies what the learners / students are expected to
know, understand, and do as a result of learning experiences after the lesson (JCMMC 01,
§. 2022, Art Il, Sec. 2.21).

Outcomes-Based Assessment refers to the assessment of evidences of competences
focused on knowledge, skills and behaviors that are standard-and criterion- referenced in
the STCW code.

Professional Courses refer to the technical courses of the entire maritime program for marine
transportation and marine engineering.

Psychomotor Learning Outcome refers to learning that deals with physical movement,

coordination, and uses of the motor skills in which their development requires practice, and
is measured in terms of soeed, accuracy, distance, procedures, techniques, and other
criteria / metrics.

Raw Score refers to the basic score on any test which is simply the number of questions a
learner / student answered correcily.
Rubric is an evaluation tool or set of guidelines used to promote the consistent application of

learning standards and outcomes, and measures their attainment against a consistent set of
criteria.

Scholastic Performance, also known as academic standing is based upon student progress

towards successful completion of the courses and the program; measured in terms of grade
point average (GPA) and course completion. Subjective and irelevant criteria such as
=

Page 17

AM

Version 2022.11.16

=

=

v

:

s

et

Cem:

wT

<

——-

<



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

attendance, extra-curricular activities, and similar others are not considered as metrics of
scholastic performance.

£

ee

ee

Page 18

Version 2022.11.16



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX A

WOU

aeT

THE BLOOM'S WHEEL

Simulation

Analyze Research
Case Study

‘ ‘Ompay;Son

The Bloom's Wheel has three (3) layers of circles/wheels which are identified and used as follows:
1. Innermost circle shows the categories of learning behavior that will be assessed from the
simplest/ lowest to the highest level namely, Remembering, Understanding, Applying,
Analyzing, Evaluating, and Creating. Take note that the Outcomes-Based Assessment aims
to cover higher levels of thinking skills and therefore higher levels of assessment that start

Mys

+

|
Page
mr

.

ys
-

>o——.
.

o~

>
»

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

from Applying to Creating. Be reminded that in the highest category (Creating),
assessment at this level covers all other categories lower than Creating. This connotes that
when a student has “produced” a project piece for example, the student is able to do it
because he has “evaluated” the essential components that should be used after
“analyzing” the function of each component and the advantages of “applying” the
working principles which he “understood” and after having “known” the scope. Hence,
when writing test items/tasks aligned with the learning outcomes, the Assessor/Faculty
need not necessarily use only the action verb of the LO. This is mostly appreciated when
an assessment scenario is created and several test items/tasks can be written to cover
many LOs of the course. Likewise, this approach also challenges the student to make use
of his higher thinking skills which consequently expands his knowledge and learming.
2. The 2"4 layer of the circle/wheel names substantial quantity of various action verbs that
can be used in writing the test items/tasks which correspond to a particular category of
learning outcome. Such organized listing of action veros do not mean exclusivity are there
are also other action verbs that may belong to any of the categories cited in the innermost
wheel.

3. The 3rd layer which is the outermost level of the wheel suggests a variety of assessment
tools that can be used per category of the learning outcome.

Take note that the same Bloom’s Wheel can be used in formulating learning outcomes.

Analysis of the competences expected to be developed after studying a Course will guide the
course developers in writing the learning outcomes to be processed during course deliveries.
Likewise, analysis of the competences will also guide the assessor in checking the construct
alignment of the learning outcomes as the latter will identify the characteristics/attrioutes of
the outcomes to be assessed and the necessary evidences indicative of attaining the learning
outcome.

FA
,

?

ew!
Se.
o——_
.

~~

Page 2
Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX B

WATCHKEEPING DUTIES PERFORMED ON BOARD

Onboard Training of BS Marine Transportation Student
Function 1: Navigation at the Operational Level
Cl
C2
C3
C4
C5
Cé
C7
C8

Plan and conduct a passage and determine position
Maintain a safe navigational watch
Use of RADAR and ARPA for the safety of navigation
Use of ECDIS to maintain safety of navigation
Respond to emergencies
Respond to a distress signal at sea
Use the IMO SMCP and use English
Transmit and receive information by visual signaling

C9

Maneuver the ship

Onboard Training of BS Marine Engineering Student
Function 1: Marine Engineering at the Operational Level
Cl
C2
C3

C4
C5

Maintain a safe engineering watch
Use English in oral and written form
Use internal communications systems

Operate main and auxiliary machinery and associated control systems
Operate fuel, lubrication, ballast and pumping systems and other
associated control systems

<oLMer

ERM

Page |

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX C

STCW-REQUIRED COMPETENCES OF THE BSMT AND BSMarE PROGRAMS

Bachelor of Science in Marine Transportation Program

Function 1: Navigation at the Operational Level
Cl
Plan and conduct a passage and determine position
C2 Maintain a safe navigational watch

C3

Use of RADAR and ARPA for the safety of navigation

C4
C5
C6
C7
C8

Use of ECDIS to maintain safety of navigation
Respond to emergencies
Respond toa distress signal at sea
Use the IMO SMCP and use English
Transmit and receive information by visual signaling

C9

Maneuver the ship

Function 2: Cargo Handling and Stowage at the Operational Level

C10 Monitor the loading, stowage, securing and care during the voyage and the
unloading of cargoes

C11 Inspect and report defects and damage to cargo spaces, hatch covers and
ballast tanks

Function 3: Controlling of Operation of the Ship and Care for Persons on board aft the
Operational Level

C12 Ensure compliance with pollution prevention requirements
C13
C14
C15
C16
C17
C18
C19

Maintain seaworthiness of the ship
Prevent, control and fight fires on board
Operate life-saving appliances
Apply medical first aid on board ship

Monitor compliance with legislative requirements
Application of leadership and team working skills
Contribute to safety of personnel and ship

Bachelor of Science in Marine Engineering Program

Function 1: Marine Engineering at the Operational Level
Maintain a safe engineering watch
C1
Use English in oral and written form
C2.
C3

Use internal communications systems

C4
C5

Operate main and auxiliary machinery and associated control systems
Operate fuel, lubrication, ballast and pumping systems and other
associated control systems

Function 2. Electrical, Electronic and Control Engineering
Operate electrical, electronic and control systems
Cé
|
Page

OCH,

$

aS

xe

oe

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

C7

Maintenance and repair of electronics and electrical equipment

Function 3. Maintenance and Repair at the Operational Level

C8

Appropriate use of hand tools, machine tools and measuring instruments for
fabrication and repair on board

C9

Maintenance and repair of shipboard machinery and equipment

Function 4. Controlling of Operation of the Ship and Care for Persons on Board at the
Operational Level

Ensure compliance with pollutionprevention requirements
Maintain seaworthiness of the ship
Prevent, control and fight fires on board
Operate life-saving appliances
Apply medical first aid on board ship
Monitor compliance with legislative requirements
Application of leadership and team working skills
Contribute to safety of personnel and ship

1:

ac* Cy,

WS:
Bes

4s

C10
C11
C12
C13
C14
C15
C16
C17

st

Page 2
Version 2022.11.13



TAXONOMIES OF LEARNING OUTCOMES
= Learning Taxonomies
=

Used as ways to describe the different kinds of learning behaviors

=

Cognitive Domain involves knowledge and the
intellectual skills (Bloom, 1956; Bloom, et.al 1990)
=

development

of

Includes recall or recognition of specific facts, procedural patterns,
and concepts that serve in the development of intellectual abilities
and skills

=

Categories of cognitive processes start from the simplest to the

=

The first one must normally be mastered before the next one can
take place

=

Application of OBE principles can be shown from the third category
up to the highest level

most complex

o > Cue,
"

4s

TD. o,

= he



TABLE OF SPECIFICATIONS FOR COGNITIVE LEARNING
Cognitive Learning
Refers to the mental skills (knowledge) developed in the learner through the

various activities of the course delivery

Used often times with the lecture component of a course

May cover both formative and summative assessment of knowledge which is
translated in terms of intellectual behavior

To have an adequate number of valid test items per learning/course outcome,
it is recommended to construct at least
3 parallel valid test items which may be
used for the assessment periods of prelim, midterm, and final

Parallel test items are different test items in terms of type of test used but serve
the same purpose (learning outcome) and cover the same content

Valid test item means that the test item’s content (what it is about) and how the
item is constructed will indeed measure the learning/course outcome



COGNITIVE DOMAIN (Bloom, et al, 1990)
CATEGORY

EXAMPLES

KEY WORDS

*Recite Rule 14 of COLREG.
*Quote the gas pressure from
memory to Officer On-Duty.
*Narrate the safety rules.

Define, describe, identify,

Comprehending the meaning,
translation, interpolation, and
interpretation of instructions

*Rewrite the principles of
OBE.
*Explain in own words the
steps for performing Crude Oil

and problems.

Washing...

Comprehend, convert, defend,
distinguish, estimate, explain,
extend, generalize, give an
example, infer, interpret,
paraphrase, predict, rewrite,
summarize, translate

REMEMBERING
Recall or retrieve previous

learned information

UNDERSTANDING

*Translate an equation into a

label, list, match, name,
outline, recall, recognize,
reproduce, select, state

computer spreadsheet

APPLYING

*Use the manual for proper

Apply, change, compute,

Use a concept in a new

construct, demonstrate,

Situation or unprompted use

outlining of steps for
maintenance of the Main

of an abstraction; apply what

Engine.

was learned in the classroom
into novel situations in the

*Apply the Laws of Newton

operate, predict, prepare,
produce, relate, show, solve,

involved in the given scenario.

use

discover, manipulate, modify,



COGNITIVE DOMAIN (Bloom, et al, 1990)
CATEGORY
ANALYZING
Separates material or
concepts into component
parts so that its organizational
structure may be understood;
distinguishes facts from
inferences

EVALUATING
Make judgments about the
value of ideas or materials.

ON ams
*Troubleshoot a piece of
equipment by using logical
deduction.

*Recognize logical fallacies in
reasoning.

*Gather information from the
incident and identify the root
cause of failure.

*Select the most effective

KEY WORDS
Analyze, break down,
compare, contrast, diagram,
deconstruct, differentiate,
discriminate, distinguish,
identify, illustrate, infer,
outline, relate, select,
separate

Appraise, compare, conclude,
contrast, criticize, critique,
solution.
defend, describe,
*Relate your gathered
discriminate, evaluate, explain,
information with your own
observations and describe the interpret, justify, relate,
Summarize, support,
probable cause.
*Explain and justify the new
budget.



COGNITIVE DOMAIN (Bloom, et al, 1990)
CATEGORY

parts together to forma
whole, with emphasis

problem.

Categorize, combine, compile,
compose, create, devise,
design, generate, modify,
organize, plan, rearrange,
reconstruct, relate, reorganize,
revise, rewrite, summarize, tell,

*Revise the process to

write

improve the outcome.

sy

Build a structure or pattern
from diverse elements; put

*Write a process manual.
*Design a machine to
perform a specific task.
*Integrate training from
several sources to solve a

KEY WORDS

M 7:
Kg

CREATING

EXAMPLES



TAXONOMIES OF LEARNING OUTCOMES

= Psychomotor Domain (Simpson, 1972)
= Includes physical movement, coordination, and use of the motor- skill
areas

= Development of these skills requires practice

= Skill developed may be measured in terms of speed, precision, distance,

procedure or techniques in execution (depend on the learning/course

outcome)

= Categories are listed from the simplest behavior to the most complex

~

vt.



PSYCHOMOTOR DOMAIN (Simpson, 1972)
CATEGORY
PERCEPTION (AWARENESS)
Ability to use sensory cues to
guide motor activity; ranges
from sensory stimulation
through cue selection to

translation

SET

EXAMPLES

KEY WORDS

*Adjust the height of the forks
on a forklift by comparing
where the forks are in relation

Choose, describe, detect,
differentiate, distinguish,
identify, isolate, relate, select

to the pallet.

*Describe the message sent
by the Morse Code.
*Act upon a sequence of
steps in a disassembling
process.
*Recognize one's abilities and

Readiness to act, includes
mental, physical, and
emotional sets. These 3 are
dispositions that predetermine limitations.
*Display donning the life suit
a person's response to
in case of abandoning the
different situations

(sometimes called mindsets)

Begin, display, explain, move,
proceed, react, show, state,
volunteer

ship.

This category Is related to

‘Responding to phenomena’ of

Wye

f

Te

iia\ 4

the Affective Domain.



PSYCHOMOTOR DOMAIN (Simpson, 1972)
OFAN CO)54f

EXAMPLES

The early stages in learning
complex skill that includes

*Perform a mathematical
equation as demonstrated.
*Follow instruction to build a

imitation and trial and error.

prototype model.

GUIDED RESPONSE

Adequacy of performance is

*Respond to hand signals of

achieved by practicing.

instructor while learning to

KEY WORDS
Copy, trace, follow, react,
reproduce, respond

operate a forklift.

MECHANISM (BASIC
PROFICIENCY)
This is the intermediate stage
in learning a complex skill.
Learned responses have
become habitual and the
movements can be performed
with some confidence and

proficiency,

*Use a personal computer.
*Repair a leaking pipe.
*Organize the fire and safety
drills.

Assemble, calibrate,

construct, dismantle, display,
fasten, fix, grind, heat,
manipulate, measure, mend,
mix, organize, sketch



PSYCHOMOTOR DOMAIN (Simpson, 1972)
CATEGORY

accurate, and highly
coordinated performance,

Assemble, build, calibrate,

parallel parking spot.

construct, dismantle, display,
fasten, fix, grind, heat,
manipulate, measure, mend,
mix, organize, sketch
NOTE:
Key words are the same as

*Operate a computer quickly
and accurately.

*Dismantle the equipment to
find out the direct cause of
malfunction.

requiring a minimum of energy.

adjectives that indicate that the
performance Is quicker, better,

This category includes

performing without hesitation,
and automatic performance.

ADAPTATION
Skills are well developed and
the individual can modify

movement patterns to fit
special requirements.

Mechanism but use adverbs or

more accurate, etc.

*Respond effectively to

Adapt, alter, change,

unexpected experiences.

rearrange, reorganize, revise,

*Modify instruction to meet the
needs of the crew.

variate

*Perform a task with a machine
that it was not originally intended
to do.

y

The skillful performance of
motor acts that involve complex
movement patterns. Proficiency
is indicated by a quick,

*Maneuver a car into a tight

’ thays

(EXPERT)

KEY WORDS

AA

COMPLEX OVERT RESPONSE

ga



PSYCHOMOTOR DOMAIN (Simpson, 1972)
CATEGORY

ORIGINATION
Creating new movement
patterns
to fit a particular

EXAMPLES

*Construct your theory onthe Arrange, build, combine,
prevalence of the case.
compose, construct, create,
*Develop a new and
design, initiate, make,

situation or specific problem.
comprehensive training drills
Learning outcomes emphasize to ensure compliance to
creativity based upon Ajghly — safety and health protocols.

developed skills.

KEY WORDS

originate

*Create a new SOP to prevent
near-misses and probable
accident.

2 ese:

eS



TAXONOMIES OF LEARNING OUTCOMES

= Affective Domain (Krathwohl, Bloom, Masia, 1973)
= Includes the manner in which we deal with things emotionally such as
feelings, values, appreciation, enthusiasm, motivations, and attitudes
= Categories are listed from the simplest behavior to the most complex



AFFECTIVE DOMAIN (Krathwohl, et al, 1973)
eda

CATEGORY
RECEIVING PHENOMENA

Awareness, willingness to
hear, selected attention

RESPONDING TO
PHENOMENA
Active participation on the
part of the learners; attend
and react to a particular
phenomenon. Learning
outcomes may emphasize
compliance in responding,
willingness to respond, or
satisfaction in responding

*Listens to others with
respect.

*Listens to and remembers
the name of newly introduced
members of the class.
*Participates in class
discussion.

*Gives a presentation.
*Questions new ideas,
concepts, models, etc. in
order to fully understand

KEY WORDS
Ask, choose, describe, follow,
give, hold, identify, locate,
name, point to, select, sit,
erect, reply, use

Answer, assist, aid, comply,
conform, discuss, greet, help,
label, perform, practice,
present, read, recite, report,
select, tell write

them.

*Performs the health and
safety protocols.

\

'Msys

if
4SIM,

(motivation)



AFFECTIVE DOMAIN (Krathwohl, et al, 1973)
CATEGORY

EXAMPLES

KEY WORDS

VALUING
The worth or value a person
attached to a particular
object, phenomenon of
behavior. This ranges from
simple acceptance to the

*Demonstrates belief in the
Complete, demonstrate,
democratic process.
differentiate, explain, follow,
*Is sensitive towards
form, initiate, invite, join,
individual and cultural
justify, propose, read, report,
differences (value diversity). | select, share, study, work
*Shows the ability to solve

more complex state of

problems.

commitment. Valuing is based *Proposes a plan to social
on the internalization of aset
of specified values while clues
to these values are expressed _
in the learner's overt behavior

improvement and follows
through with commitment.
Informs the Faculty on matters
that one feels strongly about.

tay

ye

»~

‘\ F/
: ‘4py
~2

if

eon

4
;4

3

”

and are often identifiable.



AFFECTIVE DOMAIN (Krathwohl, et al, 1973)
CATEGORY

Adhere, alter, arrange,
combine, compare, complete,
defend, explain, formulate,
generalize, identify, integrate,
modify, order, organize,
prepare, relate, synthesize

problems.

*Accepts professional ethical
standards.

*Creates a life plan in
harmony with abilities,

a

interests, and beliefs.
*Prioritizes time effectively to
meet the needs of the
organization, family, and self.

Aye

synthesizing values.

*Recognizes the need for
balance between various
opinions.
*Accepts responsibility for
one's behavior.
*Explains the role of
systematic planning in solving

et

Organizes values into
priorities by contrasting
different values, resolving
conflicts, between them, and
creating unique value system.
The emphasis is on
comparing, relating, and

KEY WORDS

AN

ORGANIZATION

EXAMPLES



AFFECTIVE DOMAIN (Krathwohl, et al, 1973)

concerned with the student's
general patterns of

adjustment (personal, social,
emotional)

Act, discriminate, display,

working independently.

influence, listen, modify,
perform, practice, propose,
qualify, question, revise, serve,
solve, verify

*Cooperates in group
activities/ Displays
teamwork.

*Uses an objective approach
in problem solving.

*Displays a professional
commitment to ethical
practice on a daily basis.
*Revises judgments and
changes behavior in light of
new evidence.
*Values people for what they
are, not how they look.

=

Has a value system that
controls their behavior. The
behavior is pervasive,
consistent, predictable, and
most importantly,
characteristic of the learner.
Instructional objectives are

*Shows self-reliance when

‘ye

(CHARACTERIZATION)

KEY WORDS

AQ

INTERNALIZING VALUES

EXAMPLES

is fe

CATEGORY



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

ANNEX E

ITEM ANALYSIS
What is Item Analysis?

ltem analysis (IA) is a process which examines student answers to individual test
items/questions in order to assess the quality of those items and the entire test.
Why is Item Analysis important in assessment?
IA is important in improving the test items as they will be Used again in later schedules. The

process will also eliminate the inappropriate or misleading items in a test such as those that
are very easy or very difficult. IA explores the relationship between difficulty index (Df value)
and discriminatory index (Ds) with distractor efficiency (De).
What is the significance of knowing the test item’s Df and Ds?
The Difficulty (Df) level/index of an item is simply the proportion of examinees in the

combined criterion groups that was able to answer the item correctly (Driederich, 1973).
Numerical data after computing the Df values indicate the following:
0.81 or higher0.20 to 0.80 -

average

easy

0.19 or lower -

difficult

The Discrimination (Ds) index/value of a test item indicates how well are high scorers when
compared with low scorers in each of the test items.
A high positive Ds value indicates good item discrimination. This means that almost all in
both groups are able to answer the test item.

A very easy or a very difficult item hardly yields any difference between the high and the
low groups in the sample. It means that both groups find the item difficult such that almost
none are able to answer the item correctly. Or, both groups find the item easy that almost
all members have answered correctly the test item. Both instances nearly result in zero or
very low Ds value which means no discrimination in the performance of the two groups of
examinees.

A third instance is when a negative Ds is obtained. It means that the test item discriminates
in the wrong direction and indicates that more examinees in the lower group are able to
answer the item correctly than those from the higher group. These three instances are bases
for either revising or rejecting/deleting a test item.
Ds of correct option is interpreted as:

0.40 or higher-

high

0.30 to 0.39

-

satisfactory

0.20 t0 0.29

-

marginal

0.19 or lower -

poor

How do you do an item analysis of a test?

Through the U-L (Upper-Lower) Index Method, steps are as follows:
1.

Score the test and arrange the total scores from highest to lowest.

SOBs

Oe
he

at

Page |

Version 2022.11.13



Procedures Manual for Assessment and Evaluation

N

of Competences of the BSMT and BSMarE Programs

Separate the test papers/answer sheets of the top/upper 27% and the bottom/lower

-

27% of the total scores.

Prepare a tally sheet to enter the number of cases from each group who got the answer

>

correctly in each of the test items.

Convert the tallies to frequencies and then to proportions.

ae

Compute the Df of each item by getting the average of the proportions of the 2 groups.
Compute the Ds of each item by taking the difference between the proportions of the
2 groups. Negative value means that the test item/question has low discrimination.
7. Decide whether to retain or discard or revise the question item based on two-ranged
values. Test items with Df within 0.20 to 0.80, and Ds within 0.30 to 0.80 will be retained.

ITEM ANALYSIS OF A TEST

SAMPLE CALCULATION

CO

o/-]|

M|

oO] —]|

CO] OC]
OC]

11

OC]

6

Lower 27%

Mm] afc]
CO] OP

27%

Lower 27%

CO] Hf

Lower 27%

12

0.80
0.87
0.73

0.40

3

0.20

1

0.07

13

0.07

12

0.80

13

0.87

8

0.53

CLO

27%

Lower 27%

0.27

13

CpOP

Lower 27%

0.60

OC] O]

9
2

27%

Lower 27%

Ds

Remarks

0.33

Retained

Omit

—]

&

Frequency

Level

___No. of students who answered the question item correctly (= frequency).
Given:
Total no. of students = 56

27% of 56 = 15
Upper 27% = top 15 students

Lower 27% = 15 students from below going up
Proportion:

Upper Proportion = upper frequency/no. of top students = 9/15 = 0.60

9

UP - UL = 0.60 - 0.27 = 0.33

>

Ds:

UP +LP/2=0.60 + 0.27/2=0.435

\"
eiyy.s

Df :

?

Lower Proportion = lower frequency/no.of students from below going up = 4/15 = 0.27

Page 2
Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX F

PARALLEL TEST ITEMS

What are parallel test items?

Parallel tests are different versions of a test that measures the same content areas and have
the same difficulty level but contain different sets of test items.

Parallel forms are different versions of tests or assessments that contain the same information
but only in different order. These are used to check the reliability of test and as a means of
curtailing possible cheating through potential examinees or test takers who attempt to
study, practice, or memorize the answers.

Parallel test items can also be used to constitute different sets of test (set A, set B, etc.) of
the same purpose or outcome being measured.
How to make parallel test items for an assessment?

1.
2.
3.
4.

Write roughly the same number of questions in each form.
Cover the same learning outcomes and learning skills in each form.
Keep questions almost equal in difficulty level.
Think about how to ask the same question in different ways.

Note: Subject Matter Expert (SME) who has undergone the training for IMO Model! Courses
6.09 and 3.12 is the best competent person who can write good parallel test items.
Samples for Analysis

Function 1
: Navigation at the Operational Level
Competency (C8): Transmit and receive information by visual signaling
Course
: Seam 1
Course Outcome~: Transmit and receive information by flag signaling in accordance with
the International Code of Signals.

Sample of Test Items for Formative Assessment:

Primary Test Item

: Raise the equivalent International Code of Signal for the following:
a.
b.

Pilot on Board/Duty
Divers down

c.

lamcanrying dangerous cargo

d.

Keep clear, engage in trawling

Tx

; se

Parallel Test Item 1: Interpret the meaning of the following International Code Signal flags:

K

SE

Page

|

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Parallel Test Item 2

: Draw and color-code the International Code of Signal that the vessel
needs to inform other vessels of the following situations/conditions:
a.

b.
c.
d.

Pilot on Board/Duty
Divers down
lamcanmnying dangerous cargo
Keep clear, engage in trawling

Sample Test Item for Course Outcome/Summative Assessment
Course Outcome

: Transmit and receive information by flag signaling in accordance with
the International Code of Signals.

Primary Test Item

: Demonstrate the proper procedure of communicating with a vessel in
distress using flag signaling and in accordance with the International
Code of Signals

Parallel Test |

: Arrange, in chronological order, the following steps or procedures in
transmitting and/or receiving information to/from a vessel in distress
using flag signaling and in accordance with the International Code of
Signals

(List of steps to be provided)
Parallel Test 2A

: Assuming that your ship meets Vessel Z, a vessel in distress with
damaged radio installations, describe the step-by-step procedures
that you will perform in order to establish a communication through
the flag signaling method with vessel Z.

Parallel Test 2B

: Assuming vessel Z, a vessel in distress with damaged radio installations,
transmits a message using the flag signaling method; describe the
step-by-step procedures that you will perform in order to receive and
respond to the given information.

Note:

Parallel Test 2A and 2B are to be provided as paired test items and in sequence.
The procedures that the students will provide in responding to these test items shall
be in accordance with the International Code of Signals.

KR

ay, S¥e—-

Page 2
Version 2022.11.13



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

ANNEX G

HOW TO VALIDATE THE TEST ITEMS USING CONTENT VALIDITY AND CONSTRUCT ALIGNMENT

For Assessment Tools of Cognitive Learning Outcomes

Test
Content Validity
Construct Alignment
If not, what should be
Item
Does the test item
Does the test item
revised to make the test
Number| covers the topic that is | measure the outcome to| item better?
to be assessed?
Yes

be measured
No

Yes

No

]

2
3
4

5

6
7

8
9

10

For Assessment Tools of Psychomotor Learning Outcomes

Performance
Task
Number/
Code

Content
Construct
Validity
Alignment
Does the
Does the
performance| performance
task Covers

Required Parts of the| If not, what should
Assessment Tool
be revised to make
Are the minimum
the performance
required parts*
task better?

task measure | clearly and

the topic to | the learning

completely written?

be assessed? | outcome to be
measured?

Yes

No

Yes

No

Yes

No

]

2
3
4

S.
6
7

8
9

10

x Ws
2Geny

Page |

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

*The minimum parts are the following:

A. STCW Table of Competences and KUP to be addressed
B. Course Outcome Statement and or Learning Outcome Statement
C. Purpose of the Assessment

D. Expected Outcome/s that will be attained

E. Expected Outputs as evidences of attainment of the CO/LO
F. Scenario, including the condition/s if there is any
G. Grading and Resit Policy

H. The Rubric which must contain the following parts:
1. Performance Condition
2. Performance Standards

3. Performance Criteria (ref. 4° column of the STCW Table)

Me

TBS
Aon ~¥s

Page 2

Version 2022.11.13



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

ANNEX H

THE ROSENBERG SELF-ESTEEM SCALE*

(Sample of Assessment Tool for Affective Learning Outcome)

instructions:

Below is a list of statements dealing with your general feelings about yourself. Please
indicate how strongly you agree or disagree with each statement.
1.

On the whole, | am satisfied with myself.
Strongly Agree Agree Disagree Strongly Disagree

2.

Attimes | think | am no good at all.
Strongly Agree Agree Disagree Strongly Disagree

3.

| feel that | have a number of good qualities.
Strongly Agree Agree Disagree Strongly Disagree

4.

|am able to do things as well as most other people.

Strongly Agree Agree Disagree Strongly Disagree
5.

| feel ldo not have much to be proud of.

Strongly Agree Agree Disagree Strongly Disagree
6.

| certainly feel useless at times.

Strongly Agree Agree Disagree Strongly Disagree

7.

| feel that I'm a person of worth, at least on an equal plane with others.
Strongly Agree Agree Disagree Strongly Disagree

8.

| wish | could have more respect for myself.
Strongly Agree Agree Disagree Strongly Disagree

9.

Allin all, | am inclined to feel that | ama failure.
Strongly Agree Agree Disagree Strongly Disagree

10. | take a positive attitude toward myself.

Strongly Agree Agree Disagree Strongly Disagree
Scoring:

Items 2, 5, 6, 8, 9 are reverse scored. Give “Strongly Disagree” 1 point, “Disagree” 2
points, “Agree” 3 points, and “Strongly Agree” 4 points. Sum scores for all ten items.
Keep scores on a continuous scale. Higher scores indicate higher self-esteem.

*Various versions are available in the internet

mee.

TB

Page |

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX!

TABLE OF OUTCOMES ASSESSMENT

(completed sample)

Course

Practical Exercise
Title

Sample Entries

Description

Elements

Encode here the Course

Marine electricity and Electrical Maintenance /

Descriptive Title

Electro 3 (CMO 14).

Refers to the descriptive name

of the scenario which is related

Synchronizing the Generators.

to the learning outcome.
Encode here the specific

STCW Competence | competence covered by the

Addressed

A-\lI/1. F2.C1 Operate electrical, electronic and

control system.

course and addressed by the
practical exercise

KUP Addressed

Encode here the specific KUP

1.b

under the competence

s
aring, st

:

:

l el

‘

preparing, starting, paralleling an
changing-over generators.

addressed by the activity

d

CO1: Perform pre-start up inspection, start a

Course Outcome

Encode here the CO under the

Addressed

course addressed by the activi

y

diesel generator, paralleling and changing-over
of generators in accordance with the
:

x manufacturer’s manual and established rules
and procedures.

Refers to the learning outcomes| LO1: Perform the paralleling and changing-over

,

Learning Outcomes

provided in the course syllabus

of generators taking into account the

as prescribed in the

manufacturer's recommendations, established

:

;

Standardized Course Packages. | rules and procedures.
:
sis
p
;
.
per
i
Y
Using
a
full
mission
simulator
with
the vessel at
required of the student through

Encode here the specific activi

Task

an outcome statement compose
of a) Condition, b) Performance.
C) Standards.
Encode here any requirements

Pre-requisite

needed prior to the practical
activity.

port, the student should be able to;

synchronize the vessel generating sets within
15 minutes at 440 Volts and 60 Hz frequency.

1.

Completed lecture component

2.

Completed instructor led

“Synchronizing the Generators” exercise.

3.

Student Access to equipment manuals

Refers to the estimated time in

the execution of the exercise for
entire scenario. (Familiarization,

30 minutes including briefing (15 minutes
exercise).

5

>

Briefing, activity, debriefing)

%

ay

yn

As Me

HNC S

Duration

each phase to complete the

Page
|

Version 2022.11.13



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

Encode here, the location where

Venue/Equipment

the activity will be held and the

GSO 2campus, Full mission ERS.

equipment that will be used.

1.
Refers to the specifications of

Training Equipment

the specific equipment within a

Particulars

system that will be used in the

ms

e

practical exercises.

Mechanical drive specifications

Yanmar 6EY18LW (60HZ 720 rpm)
2.

Generating sets

ABB AMG 0355BB04 DBAM, 610 KVA, 3

Phase 440
Volts, 60 Hzoe
:

3.

es

Ae

Switchgear: ABB Air Circuit Breaker 3

Phase 440 Volts, 60 Hz

F
Scenario

.

:

Refers to the script or outline of
the activities

Vessel at port and all mechanical and electrical

:
é;
sia
equipment relative to activity are already
operational except for synchronization.

Diesel generator No. 1 (DG1) rated at 440-V, 60
Refers to the starting state of

Initial Condition

Hz and 400 kW is currently connected to the

the equipment/environment, at

bus bars.

which the student will use as

Diesel generator No. 2 (DG2) with the same

starting point in performing the
given task.

ratings has been started and to be
synchronized and connected in parallel with
DG1.

1. Blackout
2. More than 2 attempts to connect at

more than 5 minutes from 12 o’clock
Failure state

Refer to the conditions by which

3. Motorization of any of the Generating

the exercise will be prematurely

sets

terminated

4. 15 minutes and not yet connected in

parallel
5. Unsafe condition brought about by
student behavior

Student's Actions

Refers to the activities the

Perform the practical activity in a safe manner,

student is expected to undertake

following procedures as stated in the

exercise.

requirements as stated in the task.

while undergoing the practical

manufacturer’s manual and meeting the

Refers to the description of the

quality of student’s performance
in accordance with the learning | STCW A-lll/1. F2.C1 Column 4: Operations are

Performance
Criteria:

outcome.

planned and carried out in accordance with

As per STCW Code Column 4

operating manuals established rules and
procedures to ensure safety of operations.

(Minimum SPAR or Safety,
Procedural and Results)

5 ee:

“Saye

Page 2

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

SAFETY

Safety: deviation from standard

1. Student PPE suitable for the activity
i.e., is he wearing slippers?
2. Behavior i.e., student does not horse
around or play with the equipment.

3.

Did not compromise his safety as well

as the equipment during the activity.
PROCEDURAL

The student performs the operations following
manufacturer standards as found in the
manual, or (Note these steps are generic, must

refer to MHEI own manual)
Enabling steps

1.
Performance

Standard: SPAR

Procedural: deviation from
standard

Switch synchronizing selector to

incoming genset

3.

Adjust voltage to required value
Adjust frequency to required value

4.

Ensure that the panel indicator is

2.

turning clockwise, adjust so that speed of
indicator is at permissible level.

Connect incoming generator to the bus
when pointer is at 12 O'clock (+- 2min)
5.

6.

Balance load between generating sets

7.

Switch genset to auto load share — End

RESULTS

a: Connected in parallel and balanced load: 15
Results: deviation from
standard

Note: this is the end state

minutes

b:

Bus Voltage: 440 Volts

c:

Bus Frequency: 60 Hz

d:

Load of genset: balance

1.

Completion of SPAR (Safety, Procedural

and Result) meets minimum STCW
Refers to the process of

assigning grade or score on the

Grading

student performance as defined
under the MHEI grading and or
scoring system

Competence performance standards

equivalent to 75 points or 75% grade.
(Passing is 75%)
2.

Every 20 seconds reduction in

completion time gets additional 1 point (10
minutes highly Comp)

3.

Every 1-volt deviation from 440 volt

deduct 2 points

SAI

2

>

Page 3

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

4.

Every 1 Hz deviation from 60 Hz deduct

2 points

5.

Maximum 100 points

Students who were ordered to stop during the

exercise for violation of protocol and or
compromised the safety of the environs and to
the equipment will get NYC or fail.
Note:

a;

Other than the Equipment particulars or specifications, this document was prepared

without utilizing any reference as is designed to be generic and must be customized at the MHEI’s
own location based on suppliers’ specification and equipment manuals.

2.

The difference between training and assessment is the action of the Instructor and the

Assessor during the activity.

3.

The exercise document should include the Names and Signatures of the following:

Developer, Review and Approving Authority.

Please see additional information below:

Minimum requirements for practical activity:

The norm by which the execution of the activity will be evaluated

.

:

(PC) This is found in STCW Code, Column 4 and lifted as attributes or elements

Basis for Grading
barhocniknice Cilteetat

that must be demonstrated.

PC1: Safety:

(S) Is the safety of the student and those around him including the environment

:

:

;

compromised?

PC2: Procedural:

PC3: Result:

Sa?

Seg

(P) Were all the steps as detailed in the manufacturer’s manual followed?

3

(R) Was the output of the activity within acceptable limits as set by the
manufacturer?

i eae St oe

Perf

;

:

PS2: Procedural:

PS3: Result:

:

(PS) The degree by which the criteria is evaluated against a certain standard
(made by who?)

ot

(S) Level of safety or degree of deviation from norm or standard.
tS.
(P) Degree of deviation from norm or standard.
(R) Degree of deviation from norm or standard.

Refers to the step-by-step activities the instructor will undertake in
administering the practical or simulator exercises.

iipstraietnn’s

otinns

a.
The instructor shall ensure that the following information are conveyed to
the students during briefing/debriefing:
1.

House rules.

2.

Description and configuration of the simulator/laboratory equipment.

3.

Operation of the simulator/laboratory equipment.
SAT:

z

A

ao S

Page

°

4

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

4.

Different scenarios related to the course.

5.

Attend to questions inherent to the familiarization of the system.

6.

Debrief the student after the activity focus on the following, what did the

student learned, what mistakes were made if any, and how to improve
performance.

b.

Demonstrate how to perform the activity meeting the requirements.

c.

During student performance, intervene as necessary to ensure

safety and acquisition of proficiency.
Refers to the step-by-step activities the assessor will undertake in administering
the practical or simulator exercises.

a.

The assessor shall ensure that the following information are conveyed to

Pp

the students during briefing:
Assessor’s Actions

House rules.

Description and configuration of the simulator/laboratory equipment.
awh

Attend to questions inherent to the familiarization of the system.

aS.

Operation of the simulator/laboratory equipment.

Informed the student of the result of performance (pass or fail).
During student performance, intervene as necessary to ensure safety.

om

ox Ney,

<~

FAN"Z5

e
Say
~~,

Page 5

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX J

DEVELOPING COGNITIVE ASSESSMENT ITEMS BASED ON ATTRIBUTES

Steps in Developing the Cognitive Assessment Items
1. Identify Course Outcome.
2. Identify what competence is addressed by the course outcome.

3.
4.
5.

Identify what criteria can be addressed by the course outcome.
Develop assessment items for each criteria identified.
Develop the rubrics for the subjective type of assessment item such as Essay

Sample:

Course: Seam |

COl1:

Transmit and receive information by flag signaling in accordance with the
International Code of Signals.

Criteria: Communication is clearly and unambiguously given and received
Communication is clear, concise and acknowledged at all times in a seamanlike
manner

Attribute: Effective Communication
Sample Assessment Items:

1.

Raise the equivalent International Cod of Signal for the following:
a. Pilot on Board/Duty
b.

Divers down

c.

|lamcarrying dangerous cargo
d. Keep clear, engage in trawling

.

meaning of the following International Code Signal flags:

5
Lebenaaarne

BFR ek

ib

SNES A

1

Version 2022.11.09

Mgct, A

Interpret th

Nye

igs DD.

2.



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

3.

Receive and Transmit via Morse code using an ALDIS Lamp the following information:
a. SOS

b. PAN

c. | NEED ASSISTANCE (V)
d. MANOVERBOARD (0)
e. DZXY (Callsign)

Competency Attributes for BSMT Cognitive Course Outcome Assessment
Table A-ll/1
OICNW

Function

A-lI/1.F1 | Navigation at the operational level
Competence

A-

Plan and conduct a passage and determine

11/1.F1.C1 | position

Criteria for evaluating competence

A-

Attribute

The information obtained | Knowledge

11/1.F1.C1.CC1 | from nautical charts and
publications is relevant,
interpreted correctly and
properly applied. All
potential navigational
hazards are accurately
identified

A-

The primary method of

Discernment

11/1.F1.C1.CC2 | fixing the ship’s position is
the most appropriate to

the prevailing
circumstances and
conditions
A-

The position is

Accuracy

11/1.F1.C1.CC3 | determined within the
limits of acceptable

instrument/system errors

A-

The reliability of the

Diligence

11/1.F1.C1.CC4 | information obtained
from the primary method
of position fixing is
checked at appropriate
intervals
2

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
A-

Calculations and

N/1.F1.C1.CC5

measurements of

Accuracy

navigational information
are accurate
A-

The charts selected are

11/1.F1.C1.CC6

the largest scale suitable

Discernment

for the area of navigation

and charts and

publications are corrected
in accordance with the

latest information
available
A-

Performance checks and

1/1.F1.C1.CC7

tests to navigation

Diligence

systems comply with
manufacturer's

recommendations and
good navigational practice
A-

Errors in magnetic and

11/1.F1.C1.CC8

gyro-compasses are

Accuracy

determined and correctly
applied to courses and
bearings
A-

The selection of the mode

11/1.F1.C1.CC9

of steering is the most

Discernment

suitable for the prevailing
weather, sea and traffic
conditions and intended
manoeuvres
A-

Measurements and

Accuracy

11/1.F1.C1.CC10

observations of weather

Discernment

conditions are accurate

and appropriate to the
passage
A-

Meteorological

W/4FI-CL.CCit

information is correctly

Application

interpreted and applied
Competence

A-

Maintain a safe navigational watch

1/1.F1.C2

Criteria for evaluating competence
A-

The conduct, handover

1/1.F1.C2.CC1

and relief of the watch

Attribute
Procedural

conforms with accepted
principles and procedures

3

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
A-

A proper look-out is

11/1.F1.C2.CC2

maintained at all times

Procedural

and in such a way as to

conform to accepted

principles and procedures
A-

Lights, shapes and sound

(1/1.F1.C2.CC3

signals conform with the

Compliance

requirements contained in
the International
Regulations for Preventing
Collisions at Sea, 1972, as

amended, and are

correctly recognized
A-

The frequency and extent

1/1.F1.C2.CC4

of monitoring of traffic,

Procedural

the ship and the

environment conform

with accepted principles
and procedures
A-

A proper record is

11/1.F1.C2.CC5

maintained of the

Record-keeping

movements and activities
relating to the navigation
of the ship
A-

11/1.F1.C2.CC6

Responsibility for the

Teamwork

safety of navigation is

clearly defined at all
times, including periods

when the master is on the
bridge and while under
pilotage
A-

Resources are allocated

11/1.F1.C2.CC7

and assigned as needed in
correct priority to perform

Discernment

necessary tasks
A-

Communication is clearly

11/1.F1.C2.CC8

and unambiguously given

Communication

and received
A-

11/1.F1.C2.CC9

Questionable decisions
and/or actions result in

Teamwork

appropriate challenge and
response
x

Effective leadership

11/1.F1.C2.CC10

behaviours are identified

Leadership

4

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
A-

Team member(s) share

N/1.F1.C2.CC11

accurate understanding of

Teamwork

current and predicted
vessel state, navigation

path, and external
environment

Competence
A-

Use of radar and ARPA to maintain safety of

11/1.F1.C3

navigation

Criteria for evaluating competence
A-

Information obtained

'1/1.F1.C3.CC1

from radar and ARPA is

Attribute
Analysis

correctly interpreted and
analysed, taking into

account the limitations of
the equipment and
prevailing circumstances
and conditions
A-

Action taken to avoid a

11/1.F1.C3.CC2

close encounter or

Compliance

collision with other
vessels is in accordance
with the International

Regulations for Preventing
Collisions at Sea, 1972, as
amended
A-

Decisions to amend

11/1.F1.C3.CC3

course and/or speed are

Procedural

both timely and in

accordance with accepted
navigation practice
A-

Adjustments made to the

II/1.F1.C3.CC4

ship’s course and speed

Discernment

maintain safety of
navigation
A-

Communication is clear,

1/1.F1.C3.CCS

concise and

Communication

acknowledged at all times
in a seamanlike manner
A:

Manoeuvring signals are

\1/1.F1.C3.CC6

made at the appropriate

Compliance

time and are in

accordance with the
International Regulations

for Preventing Collisions
at Sea, 1972, as amended
5

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
Competence

A-

Use of ECDIS to maintain the safety of

Attribute

\1/1.F1.C4 | navigation
A-

Monitors information on

Diligence

\1/1.F1.C4.CC1 | ECDIS in a manner that
contributes to safe
navigation

A-

Information obtained

Analysis

11/1.F1.C4.CC2 | from ECDIS (including

radar overlay and/or radar
tracking functions, when
fitted) is correctly
interpreted and analysed,
taking into account the
limitations of the
equipment, all connected
sensors (including radar

and AIS where interfaced),
and prevailing
circumstances and
conditions

A-

Safety of navigation is

Proficiency

\1/1.F1.C4.CC3 | maintained through
adjustments made to the
ship’s course and speed
through ECDIS- controlled

track-keeping functions
(when fitted)
A-

Communication is clear,

Communication

11/1.F1.C4.CC4 | concise and

acknowledged at all times
in a seamanlike manner
Competence

A-

Respond to emergencies

Attribute

11/1.F1.CS

A-

The type and scale of the | Knowledge

\1/1.F1.C5.CC1 | emergency is promptly
identified

A-

Initial actions and, if

Discernment

\1/1.F1.C5.CC2 | appropriate, manoeuvring
of the ship are in
accordance with

contingency plans and are
appropriate to the

urgency of the situation

6

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
and nature of the
emergency

Competence

A-

Respond to a distress signal at sea

Attribute

11/1.F1.C6

A-

The distress or emergency | Knowledge

11/1.F1.C6.CC1 | signal is immediately
recognized

A-

Contingency plans and

Compliance

\1/1.F1.C6.CC2_ | instructions in standing
orders are implemented
and complied with
Competence
A-

1/1.F1.C7

A-

English language nautical | Interpretation

11/1.F1.C7.CC1 | publications
and
messages relevant to the

safety of the ship are
correctly interpreted or
drafted

A-

Communications are clear |Communication

11/1.F1.C7.CC2 | and understood
Competence

A-

Transmit and receive information by visual | Attribute

11/1.F1.C8 | signaling

A-

Communications within

Communication

\1/1.F1.C8.CC1 | the operator’s area of
responsibility are

consistently successful
Competence

A-

Maneuver the ship

Attribute

A-

Diligence

11/1.F1.C9
Safe operating limits of

11/1.F1.C9.CC1 | ship propulsion, steering
and power systems are

not exceeded in normal
maneuvers

A-

Adjustments made tothe | Discernment

11/1.F1.C9.CC2 | ship’s course and speed to
maintain safety of
navigation

Function

~

4

Cy
ty,

are

é

oe

“ry

3

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
A-\I/1.F2

Cargo handling and stowage at the operational level
Competence

A-

Monitor the loading, stowage, securing, care during the

11/1.F2.C1

voyage and the unloading of cargoes
A-

Cargo operations are

11/1.F2.C1.CC1

carried out in accordance

Compliance

with the cargo plan or

other documents and

established safety

rules/regulations,
equipment operating

instructions and
shipboard stowage

limitations
A.

The handling of

11/1.F2.C1.CC2

dangerous, hazardous and

Compliance

harmful cargoes complies

with international
regulations and

recognized standards and

codes of safe practice
A-

Communications are

11/1.F2.C1.CC3

clear, understood and

Communication

consistently successful
Competence

A-

Inspect and report defects and damage to cargo spaces, hatch

1/1.F2.C2

covers and ballast tanks

A-

The inspections are

Procedural

11/1.F2.C2.CC1 | carried out in accordance
with laid-down

procedures, and defects
and damage are detected
and properly reported

A-

Where no defects or

Procedural

\1/1.F2.C2.CC2 | damage are detected, the
evidence from testing and
examination clearly

indicates adequate
competence in adhering

to procedures and ability
to distinguish between

normal and defective or
damaged parts of the ship
Function

A-l1/1.F3

Controlling the operation of the ship and care for persons on board at the
operational level
8

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
Competence

Ensure compliance with pollution-

A-

11/1.F3.C1

Attribute

prevention requirements
A-

Procedures for monitoring

/1.F3.C1:.CC1

shipboard operations and

Compliance

ensuring compliance with
MARPOL requirements

are fully observed
A-

Actions to ensure that a

11/1.F3.C1.CC2

positive environmental

Diligence

reputation is maintained
Competence

Maintain seaworthiness of the ship

A-

Attribute

11/1.F3.C2
A-

The stability conditions

11/1.F3.C2.CC1

comply with the IMO

Compliance

intact stability criteria

under all conditions of
loading
A-

Actions to ensure and

11/1.F3.C2.CC2

maintain the watertight

Diligence

integrity of the ship are in
accordance with accepted
practice
Competence
A-

Prevent, control and fight fires on board

Attribute

11/1.F3.C3
A-

The type and scale of the

Knowledge

11/1.F3.C3.CC1

problem is promptly

Procedural

identified and initial
actions conform with the
emergency procedure and
contingency plans for the

ship
A-

Evacuation, emergency

11/1.F3.C3.CC2

shutdown and isolation

Discernment

procedures are
appropriate to the nature

of the emergency and are
implemented promptly
A-

The order of priority and

11/1.F3.C3.CC3

the levels and time-scales

Discernment

of making reports and
informing personnel on

board are relevant to the
nature of the emergency
9
Version 2022.11.09



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs
and reflect the urgency of
the problem

Competence

A-

Operate life-saving appliances

Attribute

11/1.F3.C4
A-

Actions in responding to

11/1.F3.C4.CC1

abandon ship and survival

Discernment

situations are appropriate

to the prevailing
circumstances and

conditions and comply
with accepted safety
practices and standards
Competence

A-

Apply medical first aid on board ship

Attribute

11/1.F3.C5
‘A.

11/1.F3.C5.CC1

The identification of

Proficiency

probable cause, nature

and extent of injuries or
conditions is prompt and
treatment minimizes

immediate threat to life
Competence

A-

Monitor compliance with legislative

Attribute

11/1.F3.C6 | requirements
A-

Legislative requirements

11/1.F3.C6.CC1

relating to safety of life at

Knowledge

sea, security and
protection of the marine

environment are correctly
identified
Competence

A-

Application of leadership and teamworking

Attribute

\1/1.F3.C7 | skills
A-

The crew are allocated

11/1.F3.C7.CC1

duties and informed of

Discernment

expected standards of
work and behaviour in a
manner appropriate to

the individuals concerned
A-

Training objectives and

11/1.F3.C7.CC2

activities are based on

Application

assessment of current
10

Version 2022.11.09

a

os icy,

e,



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
competence and
capabilities and
operational requirements

A-

Operations are

Proficiency

\1/1.F3.C7.CC3_ | demonstrated to be in
accordance with

applicable rules
A-

Operations are planned

Discernment

\1/1.F3.C7.CC4 | and resources are
allocated as needed in

correct priority to perform
necessary tasks
A-

Communication is clearly | Communication

11/1.F3.C7.CC5 | and unambiguously given
and received

A-

Effective leadership

Leadership

11/1.F3.C7.CC6_ | behaviours are

demonstrated
A-

Necessary team

Teamwork

\1/1.F3.C7.CC7_ | member(s) share accurate
understanding of current
and predicted vessel

status and operational

status and external
environment

A-

Decisions are most

Discernment

\1/1.F3.C7.CC8_ | effective for the situation
Competence

A-

Contribute to the safety of personnel and

Attribute

11/1.F3.C8 | ship
A-

Appropriate safety and

Discernment

11/1.F3.C8.CC1 | protective equipment is
correctly used

A-

Procedures and safe

Procedural

11/1.F3.C8.CC2 | working practices

designed to safeguard
personnel and the ship

are observed at all times

A-

Procedures designed to

Procedural

11/1.F3.C8.CC3 | safeguard the
environment are observed

at all times

A-

Initial and follow-up

Procedural

11/1.F3.C8.CC4 | action on becoming aware
of an emergency

conforms with established
11

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

emergency response

procedures

Table A-IV/2
Specification of minimum standard of competence for GMDSS radio
operators

|

Function
A-

Radiocommunications at the operational level

IV/2.F1

Competence

Attribute

A-

\V/2.F1.C1
A-

Transmission and

Compliance

IV/2.F1.C1.CC1| reception of
communications comply
with international
regulations and
procedures and are

carried out efficiently and
effectively

A-

English language

Proficiency

\V/2.F1.C1.CC2 | messages relevant to the
safety of the ship, security
and persons on board and
protection of the marine

environment are correctly
handled
Competence

A-

Provide radio services in emergencies

Attribute

A-

Proficiency

IV/2.F1.C2

Response is carried out

\V/2.F1.C2.CC1 | efficiently and effectively

Competency Attributes for BSMarE Cognitive Course Outcome Assessment
Table A-Ill/1
oIcEW

Function

W/1.F1

Marine engineering at the operational level
Competenc
e

12

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
W/1.F1.C1

Maintain a safe engineering watch

Criteria

Attribute

Criteria | The conduct, handover and relief of the
1

Procedural

watch conforms with accepted principles and
procedures

Criteria | The frequency and extent of monitoring of
2

Procedural

engineering equipment and systems

conforms to manufacturers’
recommendations and accepted principles
and procedures, including Principles to be

observed in keeping an engineering watch
Criteria | A proper record is maintained of the

Documentation

3

movements and activities relating to the

and

ship’s engineering systems

Recordkeeping

Criteria | Resources are allocated and assigned as
4
needed in correct priority to perform
necessary tasks

Prioritization of
Tasks and
Resources

Criteria |Communication is clearly and unambiguously | Teamwork and
5
given and received
Situational
Awareness

Criteria | Questionable decisions and/or actions result | Assertiveness
6

in appropriate challenge and response

Criteria | Effective leadership behaviours are identified | Leadership
7

Criteria |Team member(s) share accurate
understanding of current and predicted
8
engine-room and associated systems state,

Teamwork and
Situational
Awareness

and of external environment
Competenc
e

1/1.F1.C2

Use English inwritten and oral form

Criteria

Attribute

Criteria | English language publications relevant to
engineering duties are correctly interpreted
1

English
proficiency

Criteria | Communications are clear and understood
2

Communicatio

Effective
n

Competenc
e

11/1.F1.C3

Use internal communication systems

Criteria |

Attribute

13

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Criteria | Transmission and reception of messages are_ | Effective

1

consistently successful

Communicatio
n

Procedural
Criteria | Communication records are complete,
2

Record Keeping

accurate and comply with statutory
requirements

Competenc
e

WI/1.F1.C4

Operate main and auxiliary machinery and associated
control systems

Criteria

Attribute

Criteria | Construction and operating mechanisms can | Understanding

1

be understood and explained with

drawings/instructions

visual

information

Criteria | Operations are planned and carried out in

Engineering

2

Compliance

accordance with operating manuals,
established rules and procedures to ensure

safety of operations and avoid pollution of
the marine environment

Criteria | Deviations from the norm are promptly
3

Analysis

identified

Criteria | The output of plant and engineering systems | Engineering

4

consistently meets requirements, including

Compliance

bridge orders relating to changes in speed
and direction

Criteria | The causes of machinery malfunctions are

5

Engineering

promptly identified and actions are designed | Compliance
to ensure the overall safety of the ship and
the plant, having regard to the prevailing
circumstances and conditions

Competenc
e

W1/1.F1.C5

Operate fuel, lubrication, ballast and other pumping systems and
associated control systems

Criteria

Attribute

Criteria | Operations are planned and carried out in

Engineering

1

Compliance

accordance with operating manuals,
established rules and procedures to ensure
safety of operations and avoid pollution of
the marine environment

Criteria | Deviations from the norm are promptly
2

Analysis

identified and appropriate action is taken

Function

HWI/1.F2 | Electrical, electronic and control engineering at the operational level
14

ys
L

My?

,

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
Competenc
e

WI/1.F2.C1

Operate electrical, electronic and control systems

Criteria

Attribute

Criteria | Operations are planned and carried out in
accordance with operating manuals,
1
established rules and procedures to ensure

Engineering
Compliance

safety of operations

Criteria | Electrical, electronic and control systems can | Understanding
visual
be understood and explained with
2
information
drawings/instructions
Competenc
e

W/1.F2.C2

Maintenance and repair of electrical and electronic
equipment

Attribute

Criteria

Criteria | Safety measures for working are appropriate | Safety
3

Criteria | Selection and use of hand tools, measuring
2

Workshop skills

instruments, and testing equipment are
appropriate and interpretation of results is
accurate

Criteria | Dismantling, inspecting, repairing and
reassembling equipment are in accordance
3
with manuals and good practice

Criteria | Reassembling and performance testing is in
accordance with manuals and good practice
4

Fabrication and
Repair
Fabrication and
Repair

Function

\I/1.F3 | Maintenance and repair at the operational level
Competenc
e

H1/1.F3.C1

Appropriate

use of hand tools, machine tools and measuring instruments for

fabrication and repair on board

Criteria

Attribute

Criteria | Identification of important parameters for
fabrication of typical ship-related
1

Fabrication and
Repair

components is appropriate

Criteria | Selection of materials is appropriate

Fabrication and

Z

Repair

Criteria | Fabrication is to designated tolerances

Fabrication and

3

Repair

15

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Criteria | Use of equipment and hand tools, machine
4

Workshop skills

tools and measuring instruments is

appropriate and safe
Competenc
e

11/1.F3.C2

Maintenance and repair of shipboard machinery and
equipment

Criteria

Attribute

Criteria | Safety procedures followed are appropriate

Safety

1

Criteria | Selection of tools and spare gear is
2

Workshop skills

appropriate

Criteria | Dismantling, inspecting, repairing and

Fabrication and

3

Repair

reassembling equipment is in accordance
with manuals and good practice

Criteria | Re-commissioning and performance testing is | Engineering

4

in accordance with manuals and good

Compliance

practice

Criteria | Selection of materials and parts is

Fabrication and

5

Repair

appropriate

Function

\11/1.F4 | Controlling the operation of the ship and care for persons on board at
the operational level
Competenc
e

WN/1.F4.C1

Ensure compliance with pollution-prevention
requirements

Criteria

Attribute

Criteria | Procedures for monitoring shipboard

Environmental,

1

operations and ensuring compliance with
MARPOL requirements are fully observed

Criteria | Actions to ensure that a positive

2

environmental reputation is maintained

Health and
Safety

Environmental,

Health and
Safety

Competenc
8

HW1/1.F4.C2

Maintain seaworthiness of the ship

Criteria

Attribute

Criteria | The stability conditions comply with the IMO_ | Ship Stability
1

intact stability criteria under all conditions of | and
loading

Construction

Criteria | Actions to ensure and maintain the

Ship Stability

2

watertight integrity of the ship are in

and

accordance with accepted practice

Construction

16

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs
Competenc
e

IN1/1.F4.C3

Prevent, control and fight fires onboard
Criteria

Attribute

Criteria | The type and scale of the problem! promptly | Emergency

1

identified and initial actions conform with the | response and
emergency procedure and contingency plans | recovery
for the ship

Criteria | Evacuation, emergency shutdown and

Emergency

2

isolation procedures are appropriate to the

response and

nature of the emergency and are

recovery

implemented promptly

Criteria | The order of priority, and the levels and
3

Emergency

time-scales of making reports and informing | response and
personnel on board, are relevant to the

recovery

nature of the emergency and reflect the
urgency of the problem
Competenc
e

I1/1.F4.C4

Operate life-saving appliances

Criteria

Attribute

Criteria | Actions in responding to abandon ship and

Survival Skills

1

survival situations are appropriate to the

prevailing circumstances and conditions and
comply with accepted safety practices and
standards
Competenc
e

HN1/1.F4.C5

Apply medical first aid on board ship

Criteria

Attribute

Criteria | Identification of probable cause, nature and
1

First Aid

extent of injuries or conditions is prompt and

treatment minimize immediate threat to life
Competenc
e

I1/1.F4.C6

Monitor compliance with legislative requirements

Criteria

Attribute

Criteria | Legislative requirements relating to safety of | Statutory

1

life at sea, security and protection of the

application

marine environment are correctly identified
Competenc
e

11/1.F4.C7

Application of leadership and team working skills

Criteria

Attribute
17

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Criteria | The crew are allocated duties and informed
1

Fit for purpose

of expected standards of work and behaviour
in a manner appropriate to the individuals
concerned

Criteria | Training objectives and activities are based
2

Fit for purpose

on assessment of current competence and
capabilities and operational requirements.

Criteria | Operations are demonstrated to be in

Statutory

3

application

accordance with applicable rules

Criteria | Operations are planned and resources are

Prioritization of

4

allocated as needed in correct priority to

Tasks and

perform necessary tasks

Resources

Criteria | Communication is clearly and unambiguously
5

given and received

Teamwork and

Situational
Awareness

Criteria | Effective leadership behaviours are
6

Leadership

demonstrated

Criteria | Necessary team member(s) share accurate

Teamwork and

7

understanding of current and predicted

Situational

vessel state and operational status and

Awareness

external environment

Criteria | Decisions are most effective for the situation | Leadership
8
Competenc
2

11/1.F4.C8

Contribute to the safety of personnel and ship

Criteria

Attribute

Criteria | Appropriate safety and protective equipment | Safety
a

is correctly used

Criteria | Procedures and safe working practices

2

are observed at all times

Criteria | Procedures designed to safeguard the
3

Environmental,

designed to safeguard personnel and the ship | Health and

environment are observed at all times

Safety

Environmental,
Health and
Safety

Criteria | Initial and follow-up actions on becoming

Emergency

4

response and

aware of an emergency conform with

established emergency response procedures | recovery

18

Version 2022.11.09



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Sample:
Course: Electro |

CO1: Apply safety measures in handling electrical components in accordance with
standard marine practices or ISM

Criteria 1: Safety measures for working are appropriate
Attribute: Safety
Assessment Items:

1.

Discuss the safety measures to be applied when checking a motor for a circulating
pump.

2.

Explain the importance of LOTO in ensuring safe handling and testing of electrical
equipment.

3.

Discuss the step by step “Golden Rule” in handling electrical systems on board.

4.

Which of the following is NOT a safety measure when working with Electrical
Machineries?

a. Do operate equipment according to the manufacturer's recommendation.

b. Do ensure all required permits and approvals are in place before commencing
any work.

c. Do Not touch live conductors for any reason or under any circumstance.
d. Do Not perform risk assessment before handling electrical systems.

19

Version 2022.11.09



Procedures Manual for Assessment and Evaluation

of Competences of the BSMT and BSMarE Programs

ANNEX K

RUBRICS

Samples of Holistic Rubric
bad Parta

PN

s points

AVETaGe = 3 points

ed

Average.

Ett tk

Yourwriting is clear and freeof
a

ea

grammar, spelling, and/or punctuation
errors.
nr
A

Your initial post provides enough
detailed supporting evidence to fully
analyze your motivational experience,
oe

eed

You link at least two key chapter
concepts to your motivational analysis
eCMU CieeS er
ie
eit ete

mmr mae te)
betel ere
member in a way that raises questions
or seeks clarification or elaborates on
ideas with concrete examples.

_ NEEDS IMPROVEMENT

CRITERIA

r

ABOVE AND BEYOND

30 / 30 | New unresolved ending is
STRUCTURE
Story ends abruptly after
Emily loses her agenda. Did / Opening paragraphs grab the reader's attention and establish the
really thought provoking
sheever find it? How did

_ context
of the story

things end for her? Did she“ The Story follows a logical plot sequence that includes some kind of
ever find more time inher _ rising action climax, falling action, and resolution

schedule?

Closing paragraph ties back to the opening and uses either the explicit,
implicit, or unresolved style

Several points of confusion,

IDEA DEVELOPMENT

20/20 | Researching this topic with a

_ See comments in margins

/ The story contains enough exposition about the characters, setting, and | survey, then including the

Not clear whether you feel
_ the problem is caused by

/The story clearly explains the “larger issue” being illustrated and
idea that this is a significant
provides enough background knowledge to help the reader understand _ issue

|

_ parents and teachers or by

situation so that no important questions are left unanswered

results, would reinforce the

the topic

the student themselves

| Lots of detail about Emily's

LANGUAGE AND CRAFT

connect to the main idea of

characters, situations, and settings

bedroom décor -does this / Uses specific descriptive language to develop relevant events,

the story?

30/30 Have you considered getting
a quote from someone else
in Emily's life? That might

/ Uses dialogue to develop a character, make a moment more vivid, or

add another layer

add variety to a scene

Uses transition words and phrases fo indicate the sequence of events
and signal shifts in time or setting
}

_ Look up dangling modifier.

_ CORRECTNESS

}

18 / 20

| You have a few of these in “ Language mechanics and conventions are correct

|

_ this piece. Some
oftheseare

| still present.

Total

98 / 100

ER.

ee:
Sse .

Page |

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

Sample of Analytic Rubric
Research Paper (Analytic Rubric)

Criteria

Adequate (50-59%)

Competent (60-69%)

Good (70-79%)

Excellent (80-100%)

Knowledge of forms,
conventions, terminology,
and strategies relative to the
importance of sources to

Demonstrates limited knowledge
of forms, conventions,
terminology, and strategies
relative to importance of sources

Demonstrates some knowledge © Demonstrates considerable
Demonstrates thorough and insightful
of forms, conventions,
knowledge of forms, conventions, knowledge of forms, conventions,
terminology, and strategies
terminology, and strategies relative terminology, and strategies relative to
_relative to importance of sources to importance of sources to subject importance of sources to subject

subject

to subject

to subject

Critical and creative thinking Uses critical and creative thinking Uses critical and creative thinking Uses critical and creative thinking

skills

skills with limited effectiveness _ skills with moderate

Communication of
information and idea

Communicates information and
idea with limited clarity

Uses critical and creative thinking skills

skills with considerable

with a high degree of effectiveness

effectiveness

effectiveness

Communicates information and
ideas with some clarity

Communicates information and = Communicates information and ideas
ideas with considerable clarity
with a high degree of clarity and with
confidence

Quality of argument and
writing

Argument is simple and
unoriginal, and the writing is
weak and inconsistent

Argument takes on a fair and
expected position, and the

Argument bridges on the complex
and original, and the writing is

Argument is complex and original, and
the writing is strong, fluid, and

Some errors in spelling and

No errors in spelling and grammar

creatively coherent

writing is moderately clear and —_ clear and coherent
coherent

Spelling and grammar

Several errors in spelling and

A few errors in spelling and

grammar

grammar

grammar

Adapted from Centre for Teaching Excellence, Appendix B: Sample Analytic Rubric ("Rubrics: Useful Assessment Tools.

asc,

‘ey

oS

P.

&

On

«,

4

ia .

“

of

coMa,

;

Page 2
Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

ANNEX L

GUIDELINES FOR THE GRADING SYSTEM

The interpretation of assessment results to come up with evaluation of student performance
in terms of a grade is within the responsibility of the concerned faculty of the course.

Results of formative assessment may form part of the grade gained by the student for
completion of intended learning outcomes (ILOs). The weight of the components of the
formative assessment will be in accordance with the MHEls grading system but should not
exceed the weight of summative assessment.

Likewise, the components of a grade for scholastic performance depend on the policy of
the MHEI for its own grading system.

For student to pass the course, all course outcomes must be successfully demonstrated.

The MHEI may opt to adopt the summative assessment results as the only source of grade for
the scholastic performance of a student. This matter should be covered by a policy and such
interpretation of results should be reflected in its Grading System and included in its Quality
Standard System.

The following is a sample that the MHEI may consider in checking the quality and standard
of its own grading system:

1. Theoretical grade (for courses with no laboratory)
Formative assessment (weight value of the grade is 30% - 40%)
¢ short examination or exercises/activities

@

Oral examinations

¢

Research works

¢ Outputs such as project, portfolio, and others
Summative assessment (weight value of the grade is 60% - 70-%)
¢

Major examination of course outcome

¢

Technical Report

@

Other outputs /outcomes

2. Laboratory grade (for courses with no lecture component)
Formative assessment (30% - 40%)

**

Exercises / drills

*

Scientific or Technical Experiments

=:

Projects

Cy

*

\

Practical Test for demonstration of competence

i 2 >

“*

Fr

Summative assessment (60% - 70-%)

|
Page

Version 2022.11.13



Procedures Manual for Assessment and Evaluation
of Competences of the BSMT and BSMarE Programs

3. Combined theoretical and laboratory grades (for courses with lecture and
laboratory components)
A. Lecture grade

Formative assessment (30% - 40%)

@ Short examination or exercises/ activities

¢ Oral examinations
¢ Research works

¢ Outputs such as project, portfolio, and others
Summative assessment (60% - 70-%)
¢ Major examination of course outcome

# Technical Report
@ Other outputs / outcomes
B.

Laboratory grade

Formative assessment (30% - 40%)

**

Exercises / drills

**

Scientific or Technical Experiments

Summative assessment (60% - 70-%)
**
*,

**

Practical Test for demonstration of competence
Projects

Page 2

Version 2022.11.13



