Academic Policy on the grading system

1. Passing requirement Course Outcome Assessment (COA)

   1. General Education Courses: 60% of 100
   2. Professional Courses: 75% of 100
2. Final Grade Weight for Lecture

   1. COA: 60%
   2. Formative: 20%
   3. Final Examination: 20%
3. Final Grade Weight for Laboratory

   1. Formative Assessment: 25%
   2. COA: 75%
4. Exemption Policy for the Final Exams. Requirements:

   1. 90% or equivalent numerical grade and above of all Course Outcomes and Formative Assessments
   2. All course outcome assessments were passed with a grade of 75% or more on the first try (No re-sits).
5. Resits for Course Outcome Assessments

   1. Two Re-sits: The first is after failure and the second is after the finals
6. Passing course grade (the final grade to pass the course)

   1. 75.00 for Professional Course to be converted as 3.0
   2. 65.00 for general education course to be converted as 3.0



