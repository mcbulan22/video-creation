Republic of the Philippines
OFFICE OF THE PRESIDENT
COMMISSION ON HIGHER EDUCATION
DEPARTMENT OF TRANSPORTATION
MARITIME INDUSTRY AUTHORITY

Lae

ws

JOINT CHED — MARINA MEMORANDUM CIRCULAR NO. 01
Series of 2023
SUBJECT: POLICIES, STANDARDS AND GUIDELINES FOR THE BACHELOR
OF SCIENCE IN MARINE TRANSPORTATION AND BACHELOR OF
SCIENCE IN MARINE ENGINEERING PROGRAMS, SERIES OF 2022,
AS AMENDED

In accordance with the pertinent provisions of Republic Act (RA) No. 7722, otherwise
known as the "Higher Education Act of 1994"; RA No. 10635 and its Implementing
Rules and Regulations (IRR) including subsequent amendments which established
the Maritime Industry Authority (MARINA) as the Single Maritime Administration
responsible for the implementation and enforcement of the 1978 International
Convention on Standards of Training, Certification and Watchkeeping for Seafarers,
as amended (STCW Convention, 1978, as amended) and International Agreements
or Covenants related thereto; Executive Order (EO) No. 63 and its IRR which further
strengthened the authority of MARINA as Single Maritime Administration and, by
virtue of CHED Commission En Banc (CEB) Resolution No. 089-2023 dated February
21, 2023, the following amendments on the Policies, Standards and Guidelines

(PSGs) for the Bachelor of Science in Marine Transportation (BSMT) and Bachelor of
Science in Marine Engineering (BSMarE) programs are hereby adopted and
promulgated.

Article |
INTRODUCTION
Section 1. Rationale and Background

This Memorandum Circular was developed in pursuit of the educational reforms that

include the enhanced basic education curriculum through K to 12, the New General
Education Curriculum, and the ongoing quality assurance system for the
development, recognition and award of qualification to the BSMT and BSMarE
graduates based on the Philippine Qualifications Framework (PQF) Level 6 and
International Standards.
Furthermore, this Memorandum Circular serves the purpose of further ensuring the

compliance of BSMT and BSMarE programs with the pertinent requirements of the
STCW Convention, 1978, as amended, making them more responsive to the needs
of the industry and thereby maintaining the global competitiveness of BSMT and
BSMarE graduates and in particular, the Filipino seafarers serving as officers in
charge of a watch for international shipping.
Page 1 of 46
w~ VIGHe.



This Memorandum Circular implements competency-based standards/outcomesbased education. It adopts the competences expected of BSMT and BSMarE
graduates as provided under the STCW Convention, 1978, as amended, regardless
of the type of Higher Education Institution (HEI) they graduated from.

Article Il

DEFINITION OF TERMS

Section 2. For purposes of this Circular, the following terms shall be construed as
follows:
2.1.

Applicant Higher Education Institution (HEI): Refers to an educational
institution, private or public, applying to operate maritime education and training
program/s.

2.2.

Assessment of Competence: Refers to the process of evaluating evidence of
competence through one or more of the methods of demonstrating competence
under Columns 3 and 4 of the competency tables of the STCW Code.

2.3.

Bachelor of Science in Marine Engineering (BSMarE): Refers to the
approved maritime education and training program prescribed by the
Commission and the Maritime Administration in compliance with the mandatory
education and training for Officers in Charge of an Engineering Watch required
by the STCW Convention, 1978, as amended.

2.4.

Bachelor of Science in Marine Transportation (BSMT): Refers to the
approved maritime education and training program prescribed by the
Commission and the Maritime Administration in compliance with the mandatory
education and training for Officers in Charge of a Navigational Watch required
by the STCW Convention, 1978, as amended.

2.5.

Carrying-capacity: Refers to the maximum number of students allowed to be
enrolled by the MHEI based on its facility and equipment taking into account,
the man-machine ratio, faculty-student ratio, laboratory hour per week, and the
maximum facility/equipment utilization per week.

2.6.

Cease-and-Desist Order: Refers to a legally enforceable order issued by the
Commission directing the concerned MHEI, without the proper authority to
operate, to cease from offering BSMT and/or BSMarE program.

2.7.

Closure of a Program: Refers to the closure of BSMT and/or BSMarE
program/s offered by an MHEI which may be voluntary or involuntary.
Voluntary closure is when the MHEI, for valid cause, on its own initiative,
chooses to close any of its programs offered through a phase-out process.

Page 2 of 46
stone,
2

OS

7



Involuntary closure is when the Commission, with the recommendation of
Maritime Administration, for just cause and after due process, orders the phaseout or outright closure of the BSMT and/or BSMarE program/s by revoking the
permit or certificate of recognition previously issued. The Commission and
Maritime Administration shall determine the grounds thereof.
2.8.

Commission: Refers to the Commission on Higher Education (CHED).

2.9.

Commission En Banc (CEB): refers to the governing and policy making body
of the Commission, vested with power and authority to set minimum standards
for programs and institutions of higher learning, including maritime higher
education institutions, upon recommendation by panel of experts, (in the case
of maritime programs, Technical Panel for Maritime Education), subject to
public hearing, and to enforce the same.

2.10.

Competence: Refers to the combination of knowledge, skills, experience and
attitude that enables an individual to perform a certain function or task. It
includes: 1) the cognitive competence involving the use of theory and concepts
as well as informal tacit experiential Knowledge; 2) functional competence,
which involves knowledge, understanding and skills necessary for the proper
performance of functions, tasks, duties and responsibilities in a workplace; and
3) personal competence involving ethical, personal and professional values.
For purposes of the BSMT and or BSMarE programs, specific cognitive and
functional competences are provided in the Tables of Standards of
Competence under the STCW Code.

2.41

Completed Classroom Instruction (CCl) for OBT: Refers to "Completed
Academic Requirements" in previously issued Circulars, pertains to the
completion of the required courses under the BSMT or BSMarE program prior
to the OBT based on the Commission and Maritime Administration approved
curriculum.

2.12.

Comprehensive Examination: Refers to a type of examination taken after the

completion of the academic and other institutional requirements, and prior to
the conferment of the degree.
2.13.

Course: Refers to components of a degree program. It is identified by a course

code, descriptive title and its outline or syllabus. It is a collection of learning
experiences within a particular subject area and organized to accomplish
particular outcomes.
2.14.

Course Package: Refers to a set of learning materials jointly developed or
enhanced, prepared, reviewed, and validated, and approved by the
Commission and Maritime Administration. It is composed of Course
Specifications, Course Outline and Timetable, and Course Syllabus.

Page 3 of 46
“

aX licy

ep

“=



2.15.

Curriculum: An aggregate of courses that are systematically and logically
arranged within the program of study to ensure achievement of prescribed
standards of competence under the STCW Convention, 1978, as amended
which covers the mandatory education and training for Officers-in-Charge for
Navigational or Engineering Watch under Section A-lI/1 and A-III/1,
respectively, and some of the knowledge and understanding under Table II/2
and III/2 of the STCW Code.

2.16.

Curriculum Map: Refers to a matrix showing how the program outcomes are
addressed by STCW-based professional courses, New General Education
Curriculum (NGEC) and mandated courses.

AEs

Degree: Refers to an academic degree conferred to students by an MHEI, upon
satisfactorily completing Maritime Education and Training Programs.

2.18.

Detailed Teaching Syllabus (DTS): Refers to a component of course package
which contains the complete course information and articulations of teaching
and learning activities prepared by the MHEI.

2.19.

Due Process: Refers to the guarantee that all legal proceedings will be fair and
that the concerned MHEI! will be given notice of the proceedings and an
opportunity to be heard before the imposition of a sanction.

2.20.

Evaluation: Refers to the process of making judgment on the compliance of
the MHEI and the Maritime Education and Training Programs being applied for
approval with the pertinent standards and requirements prescribed by the
Commission and the Maritime Administration in accordance with the STCW
Convention, 1978, as amended.

hike
ty

Examination: Refers to a formal test of a student's knowledge, understanding
and proficiency.

2.22.

Learning Outcomes: Refers to the clear statement of what the learner is
expected to know, understand, and do as a result of learning experiences after
the lesson.

2.23.

Maritime Administration: Refers to Maritime Industry Authority (MARINA).

2.24.

Maritime Education and Training Programs (METPs): Refer to the approved
education and training for Officer-in-Charge of a navigational or an engineering
watch covered under Chapter II Regulation II/1 and Chapter II Regulation III/1
of the STCW Convention, 1978, as amended, or more popularly known as the
BSMT and BSMarE programs.

Maritime Higher Education Institution (MHEI): Refers to all higher education
institutions offering METPs.

Page 4 of 46
~ rT

alin,

Py,

2.25.

e

}

‘S

¢

“
>

3

2

a
ewe

=

=



2.26.

Office of Programs and Standards Development (OPSD): An Office within
CHED which is primarily in charge of the enhancement of program quality and
standards, the development of corresponding policy guidelines; and the
achievement of transparency, accountability, expediency and integrity in the
formulation and enforcement of policies, standards and guidelines.

2.27.

Onboard Training (OBT): Refers to the mandatory seagoing service under
Regulations II/1 and III/1 of the STCW Convention, 1978, as amended.

2.28.

Outcomes-Based Education (OBE): Refers to an educational approach that
focuses and organizes the educational system around what is essential for all
learners to know, value, and be able to achieve a desired level of competence.
Once the desired results or "exit outcomes" have been determined, the
strategies, processes, techniques and means are put in place to achieve
predetermined goals. In essence, it is working backward with students as the
center of the learning-teaching milieu.

2.29.

Phase-out process: Means the gradual closure of a higher education training
program of MHEI.

2.30.

Philippine Qualifications

Framework (PQF):

Refers to the

Philippines’

system for the development, recognition and award of qualifications based on
standards of knowledge, skills and values acquired in different ways and
methods by learners and workers of the country.
2.31.

Program Educational Objectives (PEOs): Refers to broad statements that

describe the career and professional accomplishments that the program is
preparing graduates to achieve.

2.32.

Program of Study: An academic plan, which articulates the distribution of
courses per academic term, including the OBT requirement that have to be
taken by a student towards the satisfactory completion of BSMT and/or BSMarE
program.

2.33.

Program Outcomes (POs): Refers to sets of competences (related
knowledge, skills, and attitudes) that all learners are expected to demonstrate
after the completion of the curriculum or program.

2.34.

Quality Standards System (QSS): Refers to the documented policies and
procedures required by the Commission and the Maritime Administration to be
established by the MHEI in order to implement, monitor and ensure the
attainment of STCW competence standards.

2.35.

Refresher Course: Refers to the course approved by the Commission and the
Maritime Administration required to be taken and completed by a BSMT or
BSMarE student who has not yet completed the OBT requirement and/or failed
to earn the degree within six (6) years after completion of classroom instruction
under the BSMT or BSMarE program.

Page 5 of 46 acetone,

-



2.36.

Remediation: Refers to the intervention implemented by the MHEI in order to
rectify the deficiency/ies in the onboard training program, through simulation or
workshop.

2.37.

Resit: Refers to another opportunity given to any students to retake the

assessment if ever a failing score was recorded on the first try during the final
assessment of the course.
2.38.

Seagoing ship: Refers to a ship other than those which navigate exclusively in
inland waters or in waters within, or closely adjacent to, sheltered waters or
areas where port regulations apply.

2.39.

Standard of Competence: Refers to the level of proficiency to be achieved for
the proper performance of functions onboard seagoing ships in accordance
with the criteria set forth in the STCW Convention, 1978, as amended, and

incorporating prescribed standards or levels of knowledge, understanding and
demonstrated skills.
2.40.

STCW Code: Refers to the Annex of the STCW Convention which consists of
Part A (mandatory provisions to which specific reference is made in the annex
to the STCW Convention and which give, in detail, the minimum standards

required to be maintained by Parties in order to give full and complete effect to
the provisions of the STCW Convention) and Part B (Recommended guidance
to assist Parties to the STCW Convention and those involved in implementing,
applying or enforcing its measures to give the STCW Convention full and
complete effect in uniform manner).
2.41.

STCW Competence Map: Refers to a matrix showing the distribution of the
minimum standards of competence and knowledge, understanding and
proficiency (KUP) prescribed under the STCW Convention, 1978, as amended
into the particular course or courses comprising the BSMT and BSMarE
programs and the allotted class hours.

2.42.

STCW Convention: Refers to the International Convention on Standards of
Training, Certification and Watchkeeping for Seafarers, 1978, as amended,

which established the minimum standards of competence for seafarers.
2.43.

Training Record Book (TRB): Refers to the Training Record Book (TRB)

designed by the International Shipping Federation (ISF), GlobalMET or any
other entity and approved by the Maritime Administration in accordance with
the requirements of the STCW Convention, 1978, as amended.
2.44.

Transcript of Records (TOR): Refers to certified record (inventory) of a
student throughout a course of study having full enrollment history including all
courses attempted, grades earned and degrees and awards conferred.

2.45.

Unit: One credit unit is equivalent to one (1) hour lecture, or two (2) or three (3)
hours laboratory.

Page 6 of 46

+2



Article Ill

APPROVAL AND AUTHORITY TO OPERATE MARITIME EDUCATION AND
TRAINING PROGRAMS
Section 3. Approval of Maritime Education and Training Programs
All HEIs, including state universities and colleges (SUCs), local universities and

colleges (LUCs), and autonomous and deregulated HEls, intending to offer BSMT
and/or BSMarE programs shall first secure approval from the Commission before
offering and conducting the said programs.

3.1. Authority to Operate
The Authority to Operate, consisting of a Permit Phase and Recognition Phase, shall
be applied for and shall only be granted after the applicant HEI has complied with the

pertinent requirements under this Circular.
3.2.

Permit to Operate

The initial permit to operate applies only to the first and second-year levels of the
program applied for, and shall be granted only after the first and second-year level
requirements are met.

On the second year of operation of the degree program, the higher education MHEI

must apply for a permit to operate the third-year level or may apply for recognition if
the applicant MHEI has complied with all the requirements for the continuous
operation of the degree program applied for, including the onboard training
requirements.

The third-year permit to operate shall only be granted if compliance with the first and
second-year level requirements is maintained and the third-year level requirements
for the program being applied for have been complied with.
Otherwise, the permit to operate the first and second-year levels of the program
concerned shall be revoked. The affected students shall be assisted by the
concerned MHEI in transferring to other MHEls offering authorized BSMT and/or
BSMarE programs.

The specific provisions governing the processing of applications for government
permit shall be in accordance with the Revised Guidelines on Joint CHED-MARINA
evaluation and Inspection of Higher Education Applying for Government Authority to
Operate Bachelor of Science in Marine Transportation and/or Bachelor of Science in
Marine Engineering Program/s.
3.3.

Program Recognition

Consistent with the preceding paragraph, the third-year permit or recognition may be
applied for on the second year of operation with the Regional Office of the

Page 7 of 46
Yep

‘eS
ep

s

$

=

2

=
—



Commission concerned not later than the first working day of November of the
academic year prior to that for which recognition is sought.

The recognition shall only be granted when all requirements for the complete
operation of the BSMT or BSMarE program, including the provision of OBT for
students who are completing the classroom instruction prior to the grant of
recognition, have been complied with. Otherwise, the permit to operate the first,
second and third applied for recognition shall be revoked.

The specific provisions governing the processing of applications for government
recognition shall be in accordance with the Guidelines on Joint CHED-MARINA
Evaluation and Inspection of Higher Education Applying for Government Authority to
Operate Bachelor of Science in Marine Transportation and/or Bachelor of Science in
Marine Engineering Program/s.
3.4. All MHEls with existing BSMT and/or BSMarE programs authorized by the
Commission shall adhere to and comply with all the requirements under this Circular.
3.5. The offering of BSMT and/or BSMarE programs without the proper authority to
operate as provided under this Circular shall be unlawful, illegal and a prohibited act
and is a ground the issuance of Cease and Desist Order.

3.6. The permit or recognition shall be exclusive to the MHEI to which it was granted,

campus-specific, and subject to the conditions set forth therein. The permit or
recognition cannot in anyway be alienated or be subject of any contract.
3.7. BSMT and/or BSMarE programs of any MHEI that failed to comply with the
minimum requirements provided under this Circular shall be subject to closure after
due process.

3.8. Prohibition on Re-Application for Permit against MHEls with Closure Order

An MHEI which is subject to closure, either immediate or through phase-out, shall be
barred from re-applying for a period of three (3) years after the effectivity of such
Closure Order.

Upon re-application, the subject MHEI! shall ensure the program complies with the
existing Joint CHED-MARINA Policies, Standards and Guidelines, it has closed the
non-compliance/s that led to its phase out/closure and it has transferred all its students
to recognized MHEls.
All pending applications of MHEI for permit or recognition of the closed programs shall
be automatically denied without prejudice to imposition of appropriate sanctions
against MHEls’ officials in accordance with existing laws, rules and regulations.

Page 8 of 46



3.9. Evaluation of applications of HEls that operated maritime education and
training programs without Government Authority
The application of an HEI which operated the BSMT and/or BSMarE program/s without

government authority, shall be automatically denied, without prejudice to imposition of
appropriate sanctions against the concerned HEls' officials in accordance with existing
laws. This shall also warrant the issuance of a Cease-and -Desist Order.

The said institution/HEI shall also be responsible in the transfer of students to
recognized MHEls and shall be barred from applying within three (3) years after the
issuance of a Cease-and-Desist Order.

Article IV

PROGRAM AND COURSE DESIGN, REVIEW AND APPROVAL
Program Specifications
Section 4. Program Description

BSMT is a Maritime Education and Training Program that covers the mandatory

education and training for Officers in Charge of a Navigational Watch required under
Regulation II/1, Paragraph 2.5 of the STCW Convention, 1978, as amended.

In addition, some of the knowledge and understanding under Table A-II/2 are included
in the program as can be found under Annex A1.
BSMarE is a Maritime Education and Training Program that covers the mandatory
education and training for Officers in Charge of an Engineering Watch required under
Regulation Ill/1, Paragraph 2.4 of the STCW Convention, 1978, as amended.
In addition, some of the knowledge and understanding under Table A-III/2, are
included in the program as can be found under Annex A2.
4.1.

Degree Name

4.1.1. The mandatory education and training for Officers in Charge of a Navigational
Watch shall be Bachelor of Science in Marine Transportation (BSMT).
4.1.2. The mandatory education and training for Officers in Charge of an Engineering
Watch shall be Bachelor of Science in Marine Engineering (BSMarE).
4.2.

Nature of the Field of Study

4.2.1. The BSMT program shall cover the study of navigation, cargo handling and
stowage, controlling the operation of the ship and care for persons on board at the
operational level and some of the knowledge and understanding under Table A-II/2.

Page 9 of 46



4.2.2. The BSMarE program shall cover the study of marine engineering, electrical,
electronic and control engineering, maintenance and repair, controlling the operation

of the ship and care for persons on board at the operational level and some of the
knowledge and understanding under Table A-III/2 are included in the program.
4.2.3. Graduates of the recognized BSMT program are qualified to take the Maritime
Administration prescribed assessment of competence for certification as Officer in
Charge of a Navigational Watch on seagoing ships of 500 gross tonnage or more.

Graduates of the recognized BSMarE program are qualified to take the Maritime
Administration prescribed assessment of competence for certification as Officer in

Charge of an Engineering Watch on seagoing ships powered by main propulsion
machinery of 750kW propulsion power or more, subject to compliance with other
requirements thereof.
4.3.

Program Educational Objectives (PEOs)

4.3.1. As a degree program, the general program educational objectives of BSMT or
BSMatrE is to produce graduates who are competent to pursue a career or advanced
studies in a related maritime field of specialization.

4.3.2. Specifically, the BSMT program shall aim to produce competent Officers in
Charge of a Navigational Watch on seagoing ships of 500 gross tonnage or more
while the BSMarE program shall aim to produce competent Officers in Charge of an

Engineering Watch in a manned engine-room or as designated duty engineer in a
periodically unmanned engine-room on seagoing ships powered by main propulsion
machinery of 750 kW or more.
Section 5. Program Outcomes

The program outcomes for the BSMT and BSMarE programs are expressed in the
following set of learning outcomes:
5.1.

Common to all programs in all types of MHEI

Graduates of BSMT and BSMarE programs should be able to:
a.

Engage in lifelong learning and understanding to keep abreast of the
developments in maritime practice;

b.

Work independently and in multi-disciplinary and multi-cultural teams;

c.

Actin recognition and practice of professional, social, and ethical accountability
and responsibility; and

d.

Preserve and promote "Filipino historical and cultural heritage”.

Page 10 of 46

-

A

3

s

.

.

o

=
eo ~

-



5.2.

Common to the BSMT and BSMarE Programs

Graduates of BSMT and BSMarE programs should be able to:
a.

apply knowledge in mathematics, science and technology in solving problems
related to the profession and the workplace;

b.

evaluate the impact and implications of various contemporary issues in the global

c.

and social context of the profession;
use appropriate techniques, skills and modern tools in the practice of the
profession in order to remain globally competitive; and

d.

contribute to the existing body of knowledge through research or other forms of
creative discourse and innovative works.

5.3.

Specific to the Discipline

5.3.1. BSMT

A graduate of BSMT program shall be able to demonstrate the competence to perform
the functions pertaining to navigation, cargo handling and stowage, controlling the
operation of the ship and care for persons on board under Table A-lI/1 and acquire
some knowledge and understanding under Table A-II/2 of the STCW Code that are
covered by this program under Annex A1.
5.3.2. BSMarE

A graduate of BSMarE program shall be able to demonstrate the competence to
perform the functions pertaining to marine engineering, electrical, electronic and
control engineering, maintenance and repair and controlling the operation of the ship

and care for persons on board under Table A-III/1, and acquire some knowledge and
understanding under Table A-III/2 of the STCW Code that are covered by this program
under Annex A2.

5.4.

Common to a horizontal type as defined in CMO No. 46, s.2012.

Graduates of BSMT and BSMarE programs, whether from professional MHEls,
colleges or universities, are expected to demonstrate the following:
1.

Aservice orientation in one's profession.

2.

An ability to engage in various types of employment, development activities, and
public discourses, particularly in response to the needs of the community one
serves.

3.

Support "national, regional and local development plans" of the country through
participation in the generation of new Knowledge or in research and development
projects, especially those from state universities and colleges.

To further ensure the attainment of the program outcomes, MHEls shall strengthen
the conduct of capacity-building programs for faculty members and training of
students, including exposure to industries, as may be relevant.

Page 11 of 46

Soy:a
%
“20



Section 6. Performance Indicators

Performance Indicators are specific and measurable statements identifying the
performance(s) required to meet the outcome; confirmable through evidence.
MHEls shall develop the performance indicators to be achieved by the students as
per MHEI's program outcomes and may refer to Table A-II/1, Table A-II/2, Table AIV/2, Table A-III/1 and Table A-III/2 of the STCW Code whichever are applicable.
Sample Performance Indicators based on the Handbook on Typology,
Outcomes-Based Education and Institutional, Sustainability Assessment
A. MHE!

Metrics

Performance

Targets

Indicator
An attribute of the

Could include overall

The desired standards

ideal graduate could

results of licensure

such as minimum values

be their ability to

examination or

of 70% passing rate in

“apply their

employment rates of

licensure examination,

professional skills to

graduates, awards to the

80% employment rate, 1

become experts in

graduates or to the MHEI,

their areas of

or the MHEls involvement

award per year or
involvement in the

specialization and

in the development of

development of 2 local

expertise"

local and international

policies

policies
B. Program

Performance

Metrics

Targets

Completion of project or

Indicator

graduates are

undergraduate thesis

expected to "provide

geared toward problem

engineering solutions

solving that contributes to

Desired standards such
as 100% completion of
project or thesis with
70% having an impact

HEIs engineering

in the context of

professional practice,

on profession,

social, environmental

community concerns and

community or research

and ethical

research

considerations"

Page 12 of 46



C. Course

Performance

Metrics

Targets

Indicator

Students are

Pass summative

100% of students pass

expected to
demonstrate the

performance
assessment

the summative
assessment

course outcomes.

Section 7. Minimum Curriculum Standards

Pursuant to Regulation I/6 and Section A 1/6 of the STCW Convention, the curriculum
for BSMT and BSMarE programs shall be structured in accordance with Table A-II/1

and A-lll/1 of the STCW Code, respectively. For this purpose, the Commission and

the Maritime Administration developed, adopted and hereby implement the following:
a.

STCW Competence Map for BSMT and BSMarE programs (Annexes A11 and
A2) showing the distribution of the minimum standards of competence and
knowledge, understanding and proficiency (KUP) prescribed under the STCW
Convention, 1978, as amended into the particular course or courses comprising
the BSMT and BSMarE programs and the allotted class hours;

b.

Curriculum Map for BSMT and BSMarE programs (Annexes B1 and B2)
showing how the program outcomes as stated under Section 5 herein are

c.

d.

addressed by the professional courses, New General Education Curriculum
(NGEC) and mandated courses;
Course Specifications for BSMT and BSMarE Programs (Annexes C1 and
C2) showing the course title that may end with a course number to indicate the
sequential/ordinal nature of the course, a statement of the competence,
knowledge, understanding, and proficiencies (KUPs), performance, and class
hours; and
Program of Study (Annexes D1 and D2) articulating the distribution of courses

per academic term, including the OBT requirement that have to be taken by a
student towards the satisfactory completion of BSMT or BSMarE program.
Section 8. Approval and Implementation of the BSMT and BSMarE Curricula

8.1. Taking into consideration the components stipulated in Section 7 herein, the
following shall be developed by the MHE|ls and submit the same for approval by the
Commission and the Maritime Administration.
a.

Detailed Teaching Syllabus

b.

Course-Assessment and Assessment Tools

Further verification of the said course documents shall be undertaken during the Joint
CHED-MARINA evaluation and inspection, and monitoring, as applicable.

Page 13 of 46

ene
a



8.2. The MHEls shall establish policy and procedure for its own monitoring and
supervision of implementation of the approved curricula. MHElIs shall monitor the
delivery of the approved curriculum and shall ensure to keep records thereof for at

least three (3) years.

8.3. Non-compliance or deviation from the prescribed curricula shall be subject to
sanctions after due process.
8.4.

BSMT Program

The BSMT program shall have a minimum of 165 credit units consisting of the
Professional Courses, OBT, Physical activities towards health and Fitness (PathFit),
National Service Training Program (NSTP) and the General Education component
under the new General Education Curriculum.
The sequencing of the courses according to pre-requisites and co-requisites shall be
observed. The OBT in line with the requirements of the STCW Convention, 1978, as
amended shall be given a total of 40 credit units upon completion.
8.5.

BSMarE Program

The BSMarE program shall have a minimum of 176 credit units consisting of the
Professional Courses which include mechanical and electrical workshop skills training
as illustrated in the Table below, OBT, PathFit, NSTP and the General Education
component under the new General Education Curriculum.
Workshop Skills Training under the BSMarE Program
BSMarE Courses | Number of Units | Computation of
covering Workshop
Per Course
Laboratory Hours
Skills Training
Mach 1-Hand and
2 (1-4)
4 Lab. Hrs/week @
Measuring Tools
16 weeks per Sem.
2 (1-4)

Mach 3- Gas &
Electric Welding
Electro 1- Basic

64

16 weeks per Sem.
2 (1-4)

4 (3-3)

Electricity
Electro 2- Basic
Electronics
Electro 3- Marine
Electricity & Electrical
Maintenance

4 Lab. Hrs/week @
4 Lab. Hrs/week @
16 weeks per Sem.
3 Lab. Hrs/week @

64

48

16 weeks per Sem.
3 (2-3)

3 Lab. Hrs/week @
16 weeks per Sem.
6 Lab. Hrs/week @
16 weeks per Sem.

48

Maint- Maintenance
3 (2-3)
3 Lab. Hrs/week @
and Repair
16 weeks per Sem.
Total Workshop Skills Training Hours

48

5 (3-6)

96

432

Page 14 of 46

Yonyvan

Mach 2- Machining

Tools

Number of
Laboratory
Hours
64



The sequencing of the courses according to pre-requisites and co-requisites shall be
observed. The OBT in line with the requirements of the STCW Convention, 1978, as
amended shall be given a total of 40 units upon completion.
8.6.

Recommended elective Professional Courses/Topics for BSMT Program.

The MHEI may select any 2 courses/topics of the following recommended electives for

=

course development and offering:
Ship Operations and Shipyard Practice

Ship Superintendence and Chartering Practice
Ship Survey and Vetting Inspection

=OSONOAIRON

Port Management and Logistics
Trends, Issues, and Breakthroughs in the Maritime Industry
Emerging Technologies in the Maritime Industry
Data Analytics for Maritime professionals
Planned Maintenance System
Ship's Management System per IMO mission
0. Ship's Auditing System

8.7. Recommended Elective Professional Courses/Topics for BSMarE
Program

The MHEI may select any two (2) courses/topics of the following recommended
electives for course development and offering:
Ship Operations and Shipyard Practice
Oh

Ship Superintendence and Chartering Practice
Ship Survey and Vetting Inspection

a

OO

Sr Oe

Port Management and Logistics
Trends, Issues, and Breakthroughs in the Maritime Industry
Emerging Technologies in the Maritime Industry
Bridge Navigational Equipment for Marine Engineers
Data Analytics for Maritime professionals
Ship's Management System per IMO mission
0. Ship's Auditing System

8.8.

Implementation of the New General Education Curriculum

All MHEls shall strictly implement and abide by the guidance provided in the new
General Education Curriculum.

Section 9. Review and Enhancement of the Curriculum

The Commission and the Maritime Administration shall conduct a regular review of
the BSMT and BSMarE curricula to ensure continued compliance with the prevailing
STCW standards, and other relevant international covenants and national laws and
regulations, and if necessary, revise the curriculum and issue guidelines to MHEIs.
Page 15 of 46



9.1.

Review and Enhancement of the Curriculum by the MHEls

The MHEls shall also conduct a course review annually and program review on
the fifth year of the implementation. When the need arises, the prescribed
curriculum will be reviewed based on relevant national and international rules
and statutory requirements affecting maritime education and training, as well as
feedback from faculty members, students, school officials/personnel, end users
and other industry stakeholders. The policies and procedures to this effect shall

be embodied in the MHEI's Quality Standards System.
The MHEls may enhance their BSMT and/or BSMarE curricula according to and

as suited to their own context and mission, for information of the Commission.
However, changes that may affect the prescribed minimum curriculum standards
shall be subject to approval by the Commission and the Maritime Administration

prior to implementation.
9.2.

Submission of the proposed revision of the Curriculum
Any proposed revision or enhancement that may affect the prescribed minimum
curriculum standards shall be submitted in electronic and hard copies at least

one year before the intended implementation to Maritime Education Section
(MES), Division of Programs with International Conventions, Office of Programs
and Standards Development of the Commission.
The proposed revision of the curriculum shall be supported with documentary

evidence that the same is in line with and intended to enhance the standards
prescribed by the STCW Convention, 1978, as amended and other international

covenants and the needs of industry.
The submitted proposed revision or enhancement that affects the prescribed
minimum curriculum standards shall be reviewed jointly by the Commission and

the Maritime Administration for approval.

9.3.

Effectivity and Implementation of an approved revised Curriculum
A revised curriculum shall take effect and be implemented on the intended year
of

implementation

after

approval

by

the

Commission

and

the

Maritime

Administration.
Section 10. Basic Training

10.1. The Basic Training is a component of the BSMT and BSMarE programs. For this
purpose, the MHEls shall first apply and secure proper approval from the Maritime
Administration to offer the said course.
10.2. In case the MHE|Is cannot offer the Basic Training component to its BSMT and/or
BSMarE students, the concerned MHEI shall enter into a Memorandum of Agreement

Page 16 of 46

S

a

&

.
=

>



(MOA) with a Maritime Training Institution (MTI) offering an approved Basic Training

course which shall be within the region where the MHEI is located.
10.3. The concerned MHEI shall submit to the Commission the following documents

as evidence of compliance with this Circular, and shall be subject to Joint CHEDMARINA evaluation and inspection and monitoring:

1.

Copy of the Notarized Board Resolution of the concerned MHEI];

2.

Copy of the Notarized MOA;

3.

Copy of Certificate of Course Approval for Basic Training by the Maritime
Administration;
Evidence of evaluation of the MTI by the concerned MHEI showing the following:

4.

a.

Capacity to accommodate their students according to the prescribed
course intake limitation;

b.

Instructor-trainee ratio; and

c.

Equipment-trainee ratio.

10.4. In case the MTI covered by the MOA is not located within the region, the
concerned MHEI shall submit to the Commission the following documents, in addition
to the requirements in Section 10.3.
1.

2.

A written justification for such an arrangement; and

Parents' consent for concerned students attending Basic Training in MTI covered
by the MOA not located within the region.

10.5. The MOA mentioned in this Circular shall be valid at all times. In case the MOA
is terminated, the MHEI shall immediately inform the Commission and the Maritime
Administration.

10.6. In case the MHEI decides to enter into a MOA with another or additional MTI(s),
the above regulations shall apply.

10.7. The MHEls shall ensure proper arrangement, coordination supervision and
monitoring of the Basic Training for their students.

Article V
REQUIRED RESOURCES

A distinct and separate College of Maritime Education shall be established for the
operation of maritime programs. There shall be a department established for every
maritime program under the College of Maritime Education.

The College of Maritime Education shall be managed byafull-time Dean to effectively
carry out his/her functions and responsibilities. In case that the College of Maritime
Education has only one department, the Dean may serve as department head in
concurrent capacity.

Page 17 of 46



Section 11. Human Resources Management
11.1.

Qualifications of the Dean

The Dean of the College of Maritime Education may be anyone of the following:
11.1.1. Management Level Officer who has the following:
24 months of seagoing experience as *Management Level Officer;
2 years of teaching experience;
BSMT or BSMarE degree;

|

e290

Master's degree, preferably related to BSMT/ BSMarE program;
completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.
11.1.2. Management Level Officer who has the following:
12 months of seagoing experience as *Management Level Officer;

3 years of teaching experience;
1 year of supervisory experience;
BSMT or BSMarE degree;
~DQoo0®p

Master's degree, preferably related to BSMT/ BSMarE program;
completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and

completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.

©

11.1.3. Management Level Officer who has the following:
24 months of seagoing experience as **Officer in Charge
of a Watch;
5 years of teaching experience;

3 years of supervisory experience;
BSMT or BSMarE degree;
>~o920c

Master's degree, preferably related to BSMT/ BSMarE program;
completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and

completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.

Page 18 of 46
a

nv WIG,

“b.

oe

2
>

4

=

-



~DaQ29009

11.1.4. Officer in Charge of a Watch who has the following:
36 months of seagoing experience as **Officer in Charge of a Watch;
5 years of teaching experience;
3 years of supervisory experience;
BSMT or BSMarE degree;
Master's degree, preferably related to BSMT/ BSMarE program;
completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.
Notes

*Master or Chief Mate | Chief Engineer or Second Engineer

** Third Officer or Second Officer
/ Fourth Engineer or Third Engineer
11.2.

Qualifications of the Department Chair/Head

The Marine Transportation Department under the College of Maritime Education shall
be supervised by a Department Chair/Head who shall have the following
qualifications:
11.2.1. Management Level Officer who has the following:
12 months of seagoing experience as *Management Level Officer;

@

2009

3 years of teaching experience;
BSMT degree;

completed Training Course for Instructors (IMO Model Course 6.09); or
its equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration;

OR
wae Management Level Officer who has the following:

24 months of seagoing experience as **Officer in Charge of a Watch;
4 years of teaching experience;
1 year of supervisory experience;

©

~DQ29T0®9

BSMT degree;

Master's degree, preferably related to BSMT/ BSMarE program;
completed Training Course for Instructors (IMO Model Course 6.09); or
its equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.

Note:

*Master or Chief Mate / Chief Engineer or Second Engineer
** Third Officer or Second Officer | Fourth Engineer or Third Engineer

Page 19 of 46



The Marine Engineering Department under the College of Maritime Education shall
be administered by a Department Chair/Head who shall have the following
qualifications:

2079

11.2.3. Management Level Officer who has the following:
12 months of seagoing experience as *Management Level Officer;
3 years of teaching experience;
BSMarE degree;
completed Training Course for Instructors (IMO Model Course 6.09); or
its equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration;
OR

~oa2070

11.2.4. Management Level Officer who has the following:
24 months of seagoing experience as **Officer in Charge of a Watch;
4 years of teaching experience;
1 year of supervisory experience;
BSMarE degree;
Master's degree, preferably related to BSMT/ BSMarE program;
Completed Training Course for Instructors (IMO Model Course 6.09); or
its equivalent as approved by the Maritime Administration; and
Completed
Training Course on Assessment,
Examination
and
Certification of Seafarers (IMO Model Course 3.12) or its equivalent as
approved by the Maritime Administration.
Note.
*Master or Chief Mate / Chief Engineer or Second Engineer
** Third Officer or Second Officer
/ Fourth Engineer or Third Engineer
11.3.

Qualifications of Faculty Teaching Professional Courses

11.3.1. Faculty teaching professional courses in BSMT shall have the following
qualifications:

a.

**Officer in Charge of a Watch on seagoing ships of 500 gross tonnage or
more;

b.

12 months of seagoing experience as **Officer in Charge of a Watch on
seagoing ships of 500 gross tonnage or more;

c.

preferably with teaching experience;

d.
e.

BSMT degree;
completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by

f.

the Maritime Administration.

Note.
** Third Officer or Second Officer

Page 20 of 46



11.3.2. Faculty teaching professional courses in BSMarE shall have the following
qualifications:

a.

**Officer in Charge of a Watch on seagoing ships powered by main
propulsion machinery of 750 kW propulsion power or more;

b.

12 months of seagoing experience as "Officer in Charge of a Watch on
seagoing ships of 500 gross tonnage or more;
c.
preferably with teaching experience;
d. BSMarE degree;
e. completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
f.
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.
Note:
** Fourth Engineer or Third Engineer
11.3.3. Professional courses in BSMT which cover topics relating to KUPs in the
management level deck shall be taught by management level deck officer with the
following professional and academic qualifications:
a.

12 months of seagoing experience as Master or Chief Mate on seagoing
ship of 500 GT or more;

b.

preferably with teaching experience;

Cc.

BSMT degree;

d.
e.

completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime.

11.3.4. Professional courses in BSMarE which cover topics relating to KUPs in the
management level engine shall be taught by management level engineer officer or
allied faculty with the following professional and academic qualifications:
a.

Chief Engineer Officer or Second Engineer Officer on seagoing ship
powered by main propulsion machinery of 750 kW propulsion power or
more;

preferably with teaching experience;
a0

BSMarE degree;

completed Training Course for Instructors (IMO Model Course 6.09) or its
equivalent as approved by the Maritime Administration; and
completed Training Course on Assessment, Examination and Certification
of Seafarers (IMO Model Course 3.12) or its equivalent as approved by
the Maritime Administration.

Page 21 of 46



11.3.5. In addition to the qualification requirements for Faculty members teaching
Professional Courses in the preceding sections/sub-sections, faculty members
teaching courses involving the use of simulators shall have:
a.

completed the ‘Train the Simulator Trainer and Assessor Course" (IMO
Model Course 6.10) or its equivalent as approved by the Maritime
Administration;

b.
c.

gained practical operational experience on the particular type of
simulators being used by the MHEI concerned; and
completed transfer of knowledge and training provided by the simulator
supplier.

The MHEI concerned shall comply with the requirement under paragraph [b] above by
having a quality assurance process in its QSS to ensure that such faculty shall have
gained practical operation experience on the use of the particular type of simulator of
the Institution. The compliance and implementation of such a process shall be properly
documented
monitoring.
11.4.

subject

to

joint

CHED-MARINA

evaluation

and

inspection

and

Qualifications of Faculty Teaching General Education Courses

Faculty members teaching General Education Courses shall be holders of appropriate
Master's degree in his/her field of specialization.

Faculty members teaching PathFit shall be holders of a Bachelor's degree in PathFit
or Bachelor of Science in Education with major or minor in PathFit, or any other

bachelor's degree with certificate in PathFit.
11.5.

Qualifications

of

Faculty

Members

from

Allied

Fields

Teaching

Professional Courses
Registered professionals holding a Bachelor's degree in the allied fields, valid
professional license, with a Master's degree, and at least one (1) year of professional

or teaching experience may be allowed to teach the professional courses.
Additional faculty requirements and qualifications shall be provided for in the specific
course packages.
11.5.1.

Specific

Professions

and

Career

Opportunities

for

BSMT

or

BSMarE

Graduates
A graduate of BSMT program may find careers in:

Merchant Marine profession
Maritime Industry
Ship building and repair
Port operations and management

Page 22 of 46

otn

ye

(com nN

e200

Ship operations and management



a

Ship surveying and inspection

Offshore industry
Maritime Education and Training
Government

a.

Philippine Navy

Philippine Coast Guard
Maritime Industry Authority

A graduate of BSMarE program may find careers in:
Merchant Marine profession
Maritime Industry

Ship building and repair
Ship operations and management
Port operations and management

Ship surveying and inspection

.

ee

.

eee

sa*o9Q2900o

Offshore industry
Maritime Education and Training

Industrial and Commercial Establishment

Government
Philippine Navy
a

Philippine Coast Guard
Maritime Industry Authority

Allied Fields

11.5.2. The following fields shall be considered as allied to the BSMT program for
purposes of determining the qualifications of faculty:
Mechanical Engineering
Electrical Engineering

Chemical Engineering
Naval Architecture and Marine Engineering
Law
“~OM9Q00®

Meteorology
IT related fields

The following fields shall be considered as allied to the BSMarE program for purposes
of determining the qualifications of faculty:
Mechanical Engineering

Electrical Engineering

Chemical Engineering
Electronics Engineering
Industrial Engineering
a-opaoo®

Instrumentation and Control Engineering
Naval Architecture and Marine Engineering

Page 23 of 46



11.6.

h.

Law

i.

IT related fields

Qualifications of Academic Support Personnel

11.6.1. Academic Support Personnel particularly those assigned in the laboratory
must have the appropriate training on laboratory supervision and safety.
11.6.2. Laboratory safety is the responsibility of the institution. As such, the institution
shall be responsible in ensuring the proper use and maintenance, and keeping its

laboratories free from dangers and hazards. The following must be observed:
1.

All laboratory activities shall be properly and adequately supervised by a
faculty member;

2.

Students

shall

not

be

allowed

to

work

inside

the

laboratories

unsupervised; and
3.

Each

department with

laboratory/ies shall

have full-time

laboratory

technician/s with first aid training to assist instructors and maintain
laboratory facilities.

11.6.3. Records of usage of laboratory equipment shall be retained as per quality

standards system of the MHEI and a planned
established under the QSS of the MHEI.
11.7.

maintenance system shall

be

Qualifications and functions of Assessors

11.7.1. The MHEls shall ensure that the summative assessment is conducted by a

designated

Assessor

or

his

delegated

Instructor with

Assessors

training

for

courses/classes not assigned to him for teaching with the following qualifications:

a.

have an appropriate level of knowledge and

understanding of the

competence to be assessed;
b.

be qualified in the task for which the assessment is being made;

c.

have undergone training in:

-

"Training Course for Instructors" (IMO Model Course 6.09);
"Assessment, Examination and Certification of Seafarers"(IMO Model
Course 3.12); and

-

"Train the Simulator Trainer and Assessor Course" (IMO Model
Course 6.10), or an approved training course for Simulator Instructors

and Assessors by the Maritime Administration for those assessing
competence using simulators;
d.
e€.

gained practical assessment experience under the supervision of an
experienced assessor for at least one semester; and
gained practical assessment experience on the particular type of simulator
of the MHEI under the supervision and to the satisfaction of an
experienced assessor for assessments involving the use of simulators.

Page 24 of 46



11.7.2. For purposes of the required practical assessment experience, the concerned
MHEI shall have a quality assurance process in its QSS to ensure that such Assessors
shall have gained the necessary practical assessment experience involving the use of
simulators. The compliance and implementation of such processes shall be properly

documented

subject

to

joint

CHED-MARINA

evaluation

and

inspection

and

monitoring.

11.7.3. The following tasks shall be performed by the designated Assessor:

a.

Spearhead the design, development and enhancement of assessment
tools;

11.8.

b.

Ensure reliability and validity of assessment tools; and

c.

Conduct of examination/assessment

Teaching Load

The Dean and the Department Chair/Head may be allowed to handle a maximum
teaching load of not more than 12 hours a week provided that their primary duties and
responsibilities are not neglected.

A full-time faculty may be allowed a maximum teaching load of 30 contact hours per
week. However, a faculty member with a documented Very Satisfactory teaching
performance may be allowed to handle additional six (6) hours per week.
11.9.

Faculty Performance Evaluation

MHEI shall ensure that it has a faculty evaluation system involving students, selfevaluation, and supervisor covered by its QSS.

MHEls shall have a quality assurance mechanism and process which ensures that:
a.
b.

c.

11.10.

Faculty for professional courses shall be evaluated per course and
passed the lead instructor's evaluation;
Newly-hired faculty for professional courses with teaching experience
from other MHEls shall undergo assessment and evaluation; and
Newly-hired faculty for professional courses without teaching experience
shall undergo the guidance and supervision system for a period
prescribed by the MHEI.

Faculty Development

MHEls shall develop and implement a system of faculty development for professional
advancement of the faculty members.

Page 25 of 46
ee et



Article VI

STANDARDS, TEACHING METHODS AND MEDIA OF DELIVERY
Section 12. Standards of Competence

12.1. MHEls authorized to offer BSMT program shall ensure that every student thereof
shall have acquired the knowledge, understanding and skills needed to meet the
standards of competence specified in Sections A-lI/l of the STCW Code for
certification as Officer in Charge of a Navigational Watch serving on a seagoing ship
of 500 gross tonnage or more.

12.2. MHEls authorized to offer BSMarE program shall ensure that every student

thereof shall have acquired the knowledge, understanding and skills needed to meet
the standards of competence specified in Section A-lll/1 of the STCW Code for
certification as Officer in Charge of an Engineering Watch in a manned engine-room
or designated duty engineer officer in a periodically unmanned engine-room on a
seagoing ship powered by main propulsion machinery of 750 kW propulsion power or
more.

Section 13. Course Delivery (Teaching and Learning Activities)

The MHEI shall follow and adhere to the prescribed curriculum to ensure the
attainment of course outcomes.
The delivery for BSMT or BSMarE program commences by conveying the required
knowledge, understanding, skills and competences that the students must acquire
and demonstrate at the end of the program. The MHEls shall follow and adhere to the
approved structure, teaching methods and media of delivery, learning activities,
assessments, and ensure the provision and availability of necessary facilities,
equipment and other instructional support to ensure the attainment of the intended
learning outcomes and the achievement of the prescribed standards of competence
under the STCW Convention, 1978, as amended and other relevant international
covenants.

The MHEI shall ensure that practical exercises and assessment of a course are based

on the learning outcomes and ensure that all learning outcomes requiring practical
exercises are attained by the students, subject to Joint CHED-MARINA evaluation,
inspection, verification and monitoring.

The teaching-learning process shall be interactive, participatory, collaborative and
experiential emphasizing the connection between and among courses to achieve a
seamless integration towards holistic learning.

The following teaching and learning activities may be utilized in the course delivery,
but not limited to:
1.

Peer/Team Teaching

2.

Film/Video Viewing

Page 26 of 46



3.

Interactive Learning

4.

Reporting

5.

Brainstorming

6.
7.

Class Discussion (Question and Answer Technique)
Panel Discussion

8.
Focused Group Discussion
9. Workshop Activity
10. Buzz Session
11. Concept/Mind Mapping
12. Gallery Walk
13. Research Project

14. Seminar/Symposium
15. Debate
16. Study Tour
17. Other Educational Technologies

Section 14. Education and training shall be administered, monitored and supervised
in accordance with the established policies and procedures, prescribed minimum
requirements on the structure of the programs, teaching methods and media of
delivery, learning activities, assessments, and ensure the provision and availability of
necessary course materials, facilities, equipment and other instructional support to

ensure the attainment of the intended learning outcomes and the achievement of the
prescribed standards of competence under the STCW Convention, 1978, as amended
and other relevant international covenants.
Section 15. Consistent with outcomes-based education approach which allows
flexibility for the MHElIs to employ various means of delivery and as far as practicable,

MHEls shall deliver the programs, including the plan and media of delivery, in
accordance with the relevant Policies, Standards and Guidelines promulgated by the
Commission, in coordination with the Maritime Administration, on Flexible Learning.

Article VIl
EXAMINATION AND ASSESSMENT SYSTEM

Section 16. The MHEls shall design and develop, review and verify, validate and

approve their theoretical and practical assessment tools for all Course Outcomes
defined in the course specifications.

Section 17. Education and training of students shall be examined and assessed by
the MHEI's Assessor duly approved by the Department Head/Dean.
Section 18. MHEls shall establish a structured examination and assessment system.

Section 19. Recording

Records of practical exercises and assessment shall be retained for a period of at
least three (3) years and should be incorporated in the quality standards system of

Page 27 of 46



the MHEI to include, among others, maintenance of records on the finished product
or output from practical laboratory activities.
Section 20. Conferment of the Degree

The conferment of BSMT or BSMarE degree requires the following:
a.
b.
c.

Completion of academic and other institutional requirements;
Completion of the required OBT in accordance with this Circular and the STCW
Convention, 1978, as amended; and
Passing the assessment in accordance with Section 6 of Annex F.

Article VIII

FACILITIES AND EQUIPMENT FOR EDUCATION AND TRAINING
Section 21. The MHEI shall ensure that all required equipment is available to serve
their purpose for the course delivery and assessment.
Section 22. Institutional Sites and Buildings

An applicant HEI shall own its institutional sites and buildings to conform with this
Circular while existing MHEls shall be given a transition period of ten (10) years only
to own their institutional sites and buildings.
The institutional sites and buildings shall be designed and constructed in conformity
with the Fire Code and the National Building Code of the Philippines and
city/provincial ordinances. School buildings must be equipped with adequate
equipment, safety measures and procedures.
Site/Building/Room Requirements shall include the following:
a.

institutional site/lot

oF

Athletic field and/or gymnasium

Administrative Offices (General or Executive Office, Accounting, National
Service Training Program (NSTP), Guidance, and other offices)
Medical and dental clinic

Toilets/Comfort Rooms
Canteen/cafeteria
SH
semoe

Faculty room

Student lounge
Library room
Laboratory room

-AT

OBT Office

SR

Tool room

Research and Extension Office
Adequate facilities for swimming or MOA with service providers

Page 28 of 46
ox File

COMM

hawt

ey,

fi

=
*



Section 23. Classroom
The standard classroom size shall be a minimum of 48 square meters, no side of which
shall be less than 6 meters. Classrooms must be well-lighted and well-ventilated and
shall contain the necessary equipment and furniture such as but not limited to: chairs,
instructor's podium, multimedia and black/white boards.
Section 24. Library Standards

Library personnel, facilities and holdings shall conform to existing Commission
requirements for libraries which are embodied in a separate Commission issuance.

The library must maintain a collection of updated and appropriate/suitable textbooks

and references used for the core courses in the curriculum. Library resources should
complement curriculum delivery to optimize the achievement of the program outcomes
for the BSMT and BSMarE programs.
Section 25. Carrying Capacity

The student intake limitations shall be in accordance with the carrying capacity of
MHEls.

To establish the MHEIl's student intake limitation/s, MHEls shall submit to CHED
OPSD, copy furnished MARINA STCW Office, the duly accomplished and notarized
carrying capacity forms (Forms 1 to 4) as reflected in Annex G of this Circular two
months before the start of the academic year. Thereafter, no changes on the carrying
capacity shall be allowed.

All students in laboratory class shall be performing laboratory activities as scheduled
following the student to equipment ratio verifiable on records.
All MHEls shall ensure that the facilities and equipment as prescribed by this Circular
are complete and available to meet the student to equipment ratio, subject to periodic
monitoring.

All MHEls shall ensure that the number of students shall comply with the equipment
carrying capacity based on the specific course packages.
Section 26. Laboratories

26.1. Laboratory rooms shall allow space appropriate to the size of the equipment and
the number of students. It should be well-ventilated and well-lighted, contain the
specific laboratory equipment and, where appropriate, adequate water supply is
provided. The following laboratory rooms shall be made available:
26.1.1. For BSMT program

Chart plotting room

Bridge simulator covering RADAR-ARPA and ECDIS
Seamanship

d.

GMDSS (Optional)

Page 29 of 46

.

2 ow Pr Che,

3

c

u

a

YS

~

One yan

b.
c.

i

a.



26.1.2. For BSMarE program
a. Engine Simulator

b.

26.2.

Machinery Room that can house the marine engine, refrigeration, electrical
equipment, etc.

Laboratory Equipment

All laboratory equipment shall be owned by the MHEI and located within the
institutional site. There shall be sufficient number of equipment, machinery, apparatus,
supplies, tools and other materials, accessories and consumables.

26.3. The MHEI shall provide the necessary audiovisual room and facilities with
appropriate equipment in support of the teaching-learning process such as video,
sound system, multimedia projectors, and others.
26.4. "Sufficient and appropriate" means that the number of such teaching aids and
equipment shall be proportionate and adequate to the number of students enrolled in
a particular course based on the carrying capacity requirement of this Circular so as to
ensure their sufficient exposure to the equipment and attainment of the required
outcomes.

Section 27. Standards Governing the Simulators

All HEls intending to offer or MHEls offering BSMT and BSMarE programs shall
provide for their own simulator equipment required under this Circular. Such equipment
shall comply with the standards as prescribed in accordance with Regulation 1/12, and
Section A-1/12 of the STCW Convention, 1978, as amended.

Article IX
ONBOARD TRAINING

Section 28. Onboard Training (OBT) is an integral component of the maritime
education and training programs. It is a pre-requisite for the assessment of
competence required for certification as Officer in Charge of a Navigational Watch on
seagoing ships of 500 gross tonnage or more under Regulation II/1 and as Officer in
Charge of an Engineering Watch in a manned engine-room or as designated duty
engineer in a periodically unmanned engine-room on seagoing ships powered by main
propulsion machinery of 750 kW propulsion power or more under Regulation III/1 of
the STCW Convention, 1978, as amended.

Section 29. The Onboard Training and assessment of students shall be administered,
monitored and supervised by the Onboard Training Supervisor with the provisions of
Annex F, "Revised Guidelines on the Implementation of Onboard Training
Requirement"

Page 30 of 46



Section 30. Compliance with Deployment Rate Requirements

The compliance of MHEls with the deployment rate requirements shall be determined
by computing the percentage of OBT deployment based on the total number of
students who completed the classroom instruction (CCl) for OBT in a particular class.
Provided that, students who opted not to pursue or undertake the required OBT for
whatever reason, shall not be included in the computation of the percentage of
deployment. Provided further that, such students shall be required to execute a duly
notarized Affidavit of Undertaking stating clearly the reason(s) for not pursuing such
requirement. Provided finally that, the notarized Affidavit of Undertaking shall be
presented during inspection and/or monitoring activities conducted by the Maritime
Administration and the Commission.
For this purpose, MHEls shall comply with the required minimum deployment
percentage as follows:
Academic Year (AY) of
Implementation

Basis for Percentage Computation

Number

of

students

who

Completed

the

Classroom Instruction (CCl) less those who did
not opt for OBT in a particular class prior to the
Academic Year of implementation

Not less than 80%of
CCI for
AY 2022-2023 onwards

The required minimum deployment percentage above shall be complied with within a
maximum period of eighteen (18) months from the completion of classroom instruction
for OBT.

Article X

STUDENT ADMISSION AND RETENTION
Section 31. Student General Admission Requirements

MHEI shall only accept students based on their respective carrying capacities, taking
into account the number of facilities and equipment they own and faculty to student
ratio. Students intending to enroll in the BSMT or BSMarE program shall comply with
the minimum requirements for admission as follows:
31.1. Academic Qualifications: Senior High School graduate
31.2. Student Admission

The following shall be eligible for admission to the BSMT and BSMarE programs:

a.

A student who graduated from the secondary level of education, subject to
satisfaction of the following requirements of the admitting institution:
Page 31 of 46



IQ Test;
Aptitude Test;
Personality Test;

Math, Science and English Tests; and

Physical and medical fitness test, pursuant to Regulation 1/9 of the STCW
Convention 1978, as amended, to be conducted by a DOH accredited
Medical Practitioner;

A student who is transferring from an authorized maritime higher education
institution, subject to completion/satisfaction of Physical and medical fitness test,
pursuant to Regulation 1/9 of the STCW Convention 1978, as amended, to be
conducted by a DOH accredited Medical Practitioner;
A student who is transferring from a maritime higher education institution whose
programs are subjected to closure proceedings or are not authorized to be offered
to a recognized MHEI, subject to completion/satisfaction of the following
requirements:

e

Physical and medical fitness test, pursuant to Regulation 1/9 of the STCW
Convention 1978, as amended, to be conducted by a DOH accredited
Medical Practitioner;

e

Pass the written and practical assessment of prior learning (professional
courses); retake failed courses in written and practical assessment;
A student who is transferring from an authorized maritime higher education
institution whose admission standards requires new entrant on the First Year
Level only, shall abide by the institution's admission policy; and
A student coming from outside the country must be evaluated in accordance with
existing statutory and regulatory requirements prior to admission.

Assessment tool shall be developed by accepting MHEI guided by the procedures as
stipulated in AnnexE of this Circular.
Section 32. Physical and medical fitness requirements

In compliance with Regulation 1/9, Section A-I/9 of the STCW Convention, 1978, as
amended, students enrolling in the BSMT and/or BSMarE program shall satisfy the
following criteria to be considered physically and medically fit:
a.

b.

have the physical capability to fulfill all the requirements of the basic training as
required by Section A-VI/I, paragraph 2 of the STCW code;
demonstrate adequate hearing and speech to detect any audible alarms and
communicate effectively;

have no medical condition, disorder or impairment that will prevent the effective
and safe conduct of their routine and emergency duties on board the ship;
not suffering from any medical condition likely to be aggravated by service at sea
or to render the student unfit for such service; and

adhere to the minimum in-service eyesight standards set out in Table A-I/9 of the
STCW Code.

Page 32 of 46



Section 33. Student General Retention Requirements

33.1. MHEls shall establish a student retention policy duly documented in their
respective QSS to be submitted to the concerned Regional Office of the Commission.

academic delinquency;

oO

0®

33.2. A student who qualifies for enrollment shall be eligible to stay for the entire period
for which he/she is expected to complete his/her program of study in the MHEI, subject
to compliance with retention policies without prejudice to his/her right to transfer to
other MHEls in accordance with the existing rules and regulations of the Commission,
except in the following cases:

violation of rules and regulations of the MHEI:
failure to settle due tuition and other school fees, and other obligations;
sickness or disease that would prevent the student to handle the pressures of
school work or his continued presence thereat would be deleterious to other
members of the academic community; and

e.

the closure of a program by the MHEI, or the closure of the MHEI| itself.

33.3. Transfer of Student and Transfer of Credentials. A student enrolled in a higher
education institution shall be entitled to transfer to another institution, provided, that he
has no unsettled obligation to the institution, or is not under suspension by the
institution or expulsion imposed by the Commission. The higher education institution
shall provide any eligible student who applies for transfer with transfer credentials
appropriate for admission in another institution, subject to the latter's policies and
regulations on the admission of transfer students. A transfer credential must be signed
by the school Registrar, and issued not later than two (2) weeks after the filing of the
application for transfer.

33.4. Request and Transfer of School Records. In case of transfer of a student to
another institution, the admitting higher education institution shall, upon receipt of the
transfer credentials, request in writing for the complete school records or transcript of
record of the student from the institution last attended. The latter shall forward the
records directly to the former within thirty (30) days from receipt of the request. The
school records should not be given to the transfer student unless authorized in writing
by the admitting institution requesting for the records. Transfer credentials shall be
transferred by the school last attended only once to the admitting higher education
institution requesting for the said records.

33.5. The OBT shall not be considered as a substitute to the one-year residency
requirement in an MHEI for graduation.
Section 34. Guidance System

Every MHEI shall establish a guidance system described under its QSS that will
monitor the progress of the student's scholastic performance and_ personality
development.

Page 33 of 46



Section 35. Grading System
35.1.
As

Bases for Grading

MHEls shall ensure that all course outcomes shall be assessed and passed with
more weight given to the indicators of assessment standard.
The final grade or rating given to a student shall be based solely on scholastic
performance in any course/subject. Any adjustment, addition or diminution to the
final grade for co-curricular activities, attendance or misconduct shall not be
allowed.

A student who incurs absences for more than 20% of the required number of
school days for any course shall be automatically dropped from the rolls of
enrollees in the course.

Any grade given to a student may be appealed in accordance with institutional
academic processes.

Scholastic performance shall be measured and demonstrated by the following:
a.

Lecture Component
e
Written Examinations
e

Oral Examinations

e

Research works
Outputs such as project, portfolio, and others

e
b.

35.2.

Laboratory Component

e

Scientific and Technical Experiments

e

Demonstration of competences acquired

Requirements for Grading

The grading system for a student in curricular or component courses shall strictly
comply with the conditions or requirements as follows:

No provisional, conditional or temporary grade for any curricular or component
course shall be given to a student.

In case a student fails to take a final examination or submit an academic
requirement for completion of a course and that his/her scholastic performance
is not sufficient to merit a final passing grade, an institution may, consistent with
its academic policies, give the student a final grade which does not earn any
academic credit nor indicates failure such as "NC" for "No Credit" or "NG" for "No
Grade". Such a grade is permanent and cannot be subsequently changed.
Provided however, that where the failure to take the final examination, or to
submit the academic requirements, is due to excusable grounds, such as,
sickness, emergency, or accident, the student may be given an incomplete mark
or "INC". Provided further, that the institution allows special or completion

Ven An®

\

*/

CON,

ANA

X

3

’

Page 34 of 46

ve

1.



examinations, or additional time for compliance of the requirements. In no case
shall an incomplete or "INC" mark remain for more than one (1) academic year.

The institution shall set its own passing standard, which may not be lower than

50" percentile grade. MHEIs are encouraged to set a higher percentile grade for
admission and retention in order to establish quality education in maritime
programs.A higher percentile grade will be one of the criteria/indicators in order
to become autonomous/deregulated institution.
4.

The transmutation of grades shall not be allowed.

35.3.

Requirements for promotion or graduation

The promotion of a student from any curricular or Component course towards
graduation shall strictly comply with the conditions or requirements as follows:
35.3.1. Requirements for promotion

For purposes of granting the corresponding credit units towards the completion of a
course from a BSMT or BSMarE program, the student shall:
a;

be enrolled in the course under the program;

zi

have complied with institutional policies and requirements;
have demonstrated the required course outcomes as specified in the course

3

specifications; and
4.

be promoted or permitted to enroll in the next semester or year level provided the
pre-requisite and co-requisite course(s) have been complied with.

35.3.2. Requirements for Graduation

For purposes of granting the BSMT and/or BSMarE degree, the student shall have:
1
2:

completed classroom instruction;

completed

Onboard

Training and

complied

with

pertinent

validation

and

assessments;

3.

passed the comprehensive examination; and
complied with MHEl|’s policies and requirements.

Article Xl

QUALITY STANDARDS SYSTEM
Section 36. The Purpose of Quality Standards System

Consistent with the provision of STCW Regulation I/8, a documented QSS shall define
the Maritime Education and Training (MET) standards that the MHEI intends to
establish, implement, monitor and ensure the attainment of the STCW competence
standards.

Page 35 of 46



MHEls shall ensure that all the elements under this circular are adopted in their QSS.
Section 36.1. Key Elements of QSS for Maritime Higher Education MHEls
36.1.1. In applying quality standards for the education and training of students, MHEIs
shall incorporate the following key elements, but not limited to:

ONAARWN

1.

an expressed policy regarding quality and the means by which such policy is to
be implemented;
a quality system incorporating the organizational structure, responsibilities;
procedures, processes, and resources necessary for quality management;
the operational techniques and activities to ensure quality control:
systematic monitoring arrangements, including internal quality assurance;
evaluations, to ensure that all defined objectives are being achieved;
arrangements for periodic external quality evaluations; and
documented information relating to student's performance shall be retained for
at least three (3) years.

36.1.2.

In addition, the QSS of MHEls shall cover the following policies and

procedures:
it.

program and course, design, development, review, verification, validation and
approval;

2.

staff recruitment, training, qualifications, functions, development, appraisal and
promotion; There shall be faculty manual containing information and policies on:
a.

Hiring, retention, promotion and separation;

b.

Functions and responsibilities;

c.

Ranking system;

d.

Evaluation;

e.
f.

Salary rates;

g.

Code of conduct/ethical standards.

Faculty benefits; and

administration, monitoring, supervision of education and training;

examination and assessment system, including appeals, resits, and remediation;
facilities and equipment for education and training;
Oe

student admission and retention;

systematic monitoring of the scholastic performance which measures the
demonstration of acquisition of the course outcomes;

Policy on attendance and observance of holidays and unannounced holidays
including remediation and make-up classes;
onboard training;
10. feedback from students and from industry;
11. staff involvement in research and development:

12% Use and maintenance of equipment and facilities for education and training;

ia, the need to retain and maintain, for at least three (3) years, documented

information which may include documents, photos, audio and video recording
and any other similar information to demonstrate the delivery and conduct of

Page 36 of 46



approved classrooms/laboratory activities and that the learners perform the
course outcomes;
14. Policy and procedure on the standard carrying capacity computation signed by

the Head of Department and the Dean. The carrying capacity computation based
on the standard will be the basis of their registrar on the maximum number of
students to be enrolled. Additionally, MHEIs shall include in the policy and
procedure the computation of carrying capacity using carrying capacity forms
and the provision on equipment to student ratio which shall ensure that students
are given sufficient time allocated for the operation of equipment or simulators
for training or assessment;
15. Policy and procedure on the design and development, review and verification,

validation

and

approval

of

laboratory

equipment/simulator

exercises

and

assessment;
16. Policy and procedure on records keeping of the evidences/records that will

demonstrate that the laboratory equipment/simulator practical exercises and
assessments have been implemented;
Ld Policy and procedure to require students who transferred from one MHEI to

another due to programme closure or lack of approval to follow the programme
without gaps in their training to ensure that all students had met all the
programme requirements by requiring the accepting MHEls to evaluate the
curriculum where the students came from against their own to establish any gap
and use as basis of any additional training, to bring them up to the level of the
program requirements;
18. A description and inventory of education and training facilities and equipment,

including any agreements with service providers for Basic Training, swimming
pool, gymnasium;
19. The MHEI shall ensure that the information related to the following shall be

included in the Transcript of Records issued to students shall have the following
items, but not be limited to:
e

Name of the Ship

Ship's Flag or Registry
Ship's GT (500 GT or above) or kW (750 kW or above)
Duration of the On-board Training (Dates of embarkation
disembarkation)

and

20. Policy and procedure on the verification and evaluation/ assessment of the

satisfactory completion of the OBT and the six months watchkeeping duties; and
“i: Continual Improvement-specific requirements, provisions, policies pertaining to

audit and effecting any changes to ensure improvement of the system.

Vouvan®

Page 37 of 46



Article Xll
RESEARCH AND EXTENSION

Section 37. Integration of Research and Extension
In accordance with the trifold functions of higher education on instruction, research and

extension, the faculty of MHEls will undertake research and extension activities.
Students as well will also be provided opportunities for them to do research as may be
relevant to their projects and activities (e.g. formulation of a navigation plan;
formulation of a plan for the management of a marine environment, among others).

Article XIll
COMPLIANCE OF HEIS

Section 38. Using the Commission Implementation Handbook for OBE and ISA as
reference, a HEI shall develop the following items which will be submitted to the
Commission when they apply for a permit for new program:
‘ f

A complete set of institutional and program outcomes, including its proposed
additional program outcomes;

=

Proposed curriculum, and its justification, including a curriculum map;

3

Proposed performance indicators for each outcome. Proposed measurement
system for the level of attainment of each indicator;

Proposed outcomes-based syllabus for each course, arranged in sequence
following the curriculum matrix;
5. Administration, faculty, and staff profile with supporting documents;
6. Teaching assignments vis-a-vis faculty qualifications per term;
7
List of library, laboratory, and classroom facilities and equipment, with supporting
documents;
8. List of available support services, with supporting documents;
9. Proposed system of program assessment and evaluation; and
10. Proposed system of program Continuous Quality Improvement (CQI).
4.

Article XIV

EVALUATION, INSPECTION AND MONITORING

Section 39. All applicant HEIs shall be subjected to evaluation and inspection under
JCMMC 02 series of 2023. On the other hand, the conduct of monitoring of METPs
shall be governed by the JCMMC 03 series of 2023.

Section 40.

Sanctions with

respect to

Non-compliances as a

result of

monitoring

40.1. Non-compliance with the provisions of this Circular, after due process, shall
make it imperative for the Commission En Banc to impose sanction upon the
recommendation of the Technical Panel for Maritime Education.

You von’

ity
it?

:

Page 38 of 46



40.2. The imposition of sanctions for MHEls offering the BSMT and/or BSMarE
programs shall be based on the outcome of the monitoring visits or institutional
performance in the following different key areas of evaluation, thus:

TD

Program and Course Design, Review and Approval;
Required Resources;

AO

Standards, Teaching Methods and Media of Delivery;
Examination and Assessment System;

AO

Facilities and Equipment for Education and Training;
Onboard Training;

SM

Student Admission and Retention;

Quality Standards System

Basis for Sanction

Sanction

Non-compliance with program

requirements;
Outright Closure or Closure
Failure to meet the required | through Phase-Out issued by
deployment percentage based

the Commission

on the update reference Article
IX
Section 41. Sanctions with respect to MHEI's Performance in the assessment
of competence

The performance of MHEIls shall be jointly evaluated by the Commission and Maritime
Administration, which shall be measured based on the minimum passing percentage

in the assessment of competence. The result of such evaluation shall be used as
basis for possible closure of the BSMT and/or BSMarE programs.
Section 42. Conduct of Surveillance

The Maritime Administration, upon receipt of a verified complaint, shall conduct
surveillance of any maritime higher education institution offering Maritime Education
and Training Programs to further ensure that such programs are implemented in
accordance with the existing applicable law, policies, standards and guidelines issued
by the Maritime Administration and the Commission and the STCW Convention, 1978,
as amended based on the following ground:

1.

advertisement or publication of any advertisement or announcement for BSMT
and/or BSMarE programs before a permit to operate is granted by Commission;
or

2.

implementing or conducting unapproved education programs that have similar
title and/or content as any of the approved Maritime Education and Training
Programs (METPs) by Commission, tending to deceive the learner or the public
Page 39 of 46
ry

ley

eo

=
S.

re)

>



PO

that such programs are approved and compliant with STCW Convention,1978,
as amended, whether intentional or not; or
Issuance of any certificate, degree, or title relating to BSMT and/or BSMarE
programs without prior permit or authorization issued by the Commission; or
continuing to offer a phased out/closed METP; or
the operation of a branch or extension, whether locally or foreign-based, or
without prior permit or authorization issued by Commission; or
non-compliance with existing policies, standards and guidelines for BSMT and/or
BSMarE programs.

The Surveillance Report shall be endorsed by the Office of the Executive Director to
the CHED OPSD for transmittal to the TPME for appropriate action.
Section 43. Due Process

In all matters that may result in the imposition of any sanction or penalty to a higher
education institution, administrative due process shall in all instances be observed.
Section 44. Closure of Program
1.

Upon completion of the Joint CHED-MARINA monitoring activities, the Maritime
Administration shall endorse the monitoring reports through the Executive
Director of STCW Office, to the CHED-MARINA Secretariat, for inclusion to the
agenda of the Technical Panel for Maritime Education (TPME).
The TPME, upon determination on the sufficient basis for the issuance of Show
Cause Order against MHEIl, shall submit its recommendation to the CHED
Executive Director. The CHED Executive Director shall issue the corresponding
Show Cause Order. For MHEls, which were found by the TPME, to be compliant
with the PSG, shall be forwarded to the CHED, through OPSD, for confirmation
of the Commission en banc.
The MHEI shall submit an Answer within fifteen (15) calendar days from receipt
of the Order and show cause why no administrative sanction/s shall be imposed
against it.

The concerned Monitoring Team shall review the responses to the Show Cause
Order and its recommendation, within fifteen (15) calendar days from receipt of
the answer or after the lapse of the period to file an answer and shall forward to
the CHED-MARINA Secretariat, for inclusion to the agenda of the Technical
Panel for Maritime Education.
The TPME shall recommend to the CHED CEB whether sanctions will be
imposed and the corresponding sanctions.

CHED

CEB

shall

decide

whether sanctions will

be

imposed

and

the

corresponding sanctions.

Execution of the Decision of the Commission. The decision of the Commission
shall be immediately executory after fifteen (15) calendar days from receipt thereof,
unless a motion for reconsideration is seasonably filed, in which case the execution of
the decision shall be held in abeyance until the Motion for Reconsideration is resolved.

+

Page 40 of 46

nt rity

s

=

3

3

2

¥

A

a,

-

==
—

Voy vow

.



Motion for Reconsideration. A Motion for Reconsideration shall be filed with the
Commission within fifteen (15) calendar days from receipt of the decision on the basis
of any of the following grounds:

a.

Newly discovered evidence which materially affects the order, directive or
decision; or

b.

Grave errors of facts or law or serious irregularities have been committed
prejudicial to the interest of the MHEI.

The concerned Monitoring Team shall review the responses to the Motion for
Reconsideration and its recommendation and submits its recommendation to the
TPME, within fifteen (15) calendar days from receipt of the Motion and all its
supporting documents. CHED may also tap the Legal Legislative Services to review
recommendation as may be warranted by the situation.

Only one Motion for Reconsideration shall be allowed. Decision of the CHED CEB on
the Motion for Reconsideration is executory.
Effect of the Closure Order. In case of immediate closure, the Order must indicate
that the permit or recognition of the program is automatically revoked upon service of
the Closure Order. The MHEI with a Closure Order is prohibited from applying for new

permit on the program/s subject of the Order within three (3) years from the effectivity
of the said Order.
In case of Closure through Phase-out, the Order must indicate the Phase-out period
and a directive that on the last day of the Phase-out period, the permit or recognition

of the program is automatically revoked. Students who are already in the second,
third, and fourth-year levels shall be allowed to finish their study until graduation or to
transfer to other MHEls, at the option of the student(s). The MHEI will not be allowed
to accept first year students in the next academic year.
The MHEI with a Closure through Phase-out Order is prohibited from applying for new
permit on the program/s subject of the Order during the Phase-out period.
Effect of Pendency of Appeal, Petition for Review/Certiorari with the Court. The
filing and pendency of an appeal with the Office of the President (OP) or regular courts

shall not stop the execution of the decision of the Commission unless court of
competent jurisdiction issues a Restraining Order or an Injunction.
Section 45. Implementation of Closure
45.1. MHEI's Responsibility

MHEls issued Phase Out Orders. MHEls that failed to demonstrate and provide
evidence of compliance or maintaining compliance with the requirements for the
operation of the BSMT and/or BSMarE programs shall be subjected to closure
proceedings. Upon effectivity of the order implementing the closure, the concerned
MHEI shall:
Page 41 of 46



take full accountability and responsibility of any adverse effect to the students
affected by such closure without prejudice to any civil and criminal liability under
existing laws;

inform the affected students of the closure and shall advise to immediately report
to the concerned CHED Regional Office;
remain obligated to furnish the necessary credentials and records to students

affected by the closure and cause the preservation of all academic records of
students by submitting electronic copies of the same to the Regional Office of the
Commission concerned; and
submit to the Regional Office of the Commission, copy furnished the Regional
Office of the Maritime Administration the number, names, and other pertinent
information on affected students in each year level, including the MHElIs which
accepted them.
45.2. Accepting MHEls

MHEls accepting student transferees from MHEls which are issued phase out orders
shall ensure compliance with the provisions of this section:
7

establish a quality policy for the admission and retention of students, as stipulated
in the relevant provisions for Admission and Retention of Students in this circular;

2.

coordinate and cooperate with the Regional Office of the Commission and MHE|
concerned to facilitate the transfer and enrolment of affected students;
submit to the Regional Office of the Commission, copy furnished the Regional
Office of the Maritime Administration, a report demonstrating compliance with the

prescribed absorptive capacity including the capacity to comply with the required
percentage of onboard training deployment; and
submit to the Regional Office of the Commission, copy furnished the Regional
Office of the Maritime Administration, relevant information of students admitted
to the Maritime Education and Training Programs such as the number, names,
and other pertinent details on affected students in each year level.
The maximum Teaching Load for faculty teaching students affected by closure shall

be as follows, within a period of two (2) years upon acceptance of the transferees.
Enrolled Transferees

Maximum Teaching Load per
Week

20-80 students

36 hours

81-160 students

40 hours

161-320 students

44 hours

Deployment of transferred third year level students affected by closure to another
recognized MHEI shall be as follows, within a period of two (2) years upon acceptance
of the transferees.

Page 42 of 46



Enrolled
Transferees

OBT Deployment
Percentage (60%)

OBT Deployment
Percentage (80%)

20-80 students

55%

75%

81-160 students

50%

70%

161-320 students

45%

60%

The accepting MHEI shall credit courses taken based on Article X (Student Admission
and Retention).

Further, students who transferred from one MHEI to another due to program closure
or lack of approval shall be required to follow the program without gaps in their training.
To ensure that students concerned met all the program requirements, the accepting
MHEls shall evaluate the curriculum where the students came from against their own
to establish any gap and use it as basis of any additional training, if any.
45.3. Regional Office of the Commission’s Responsibilities

Upon receipt of the implementing order of the CEB, the concerned Regional Office of
the Commission shall convene the concerned MHEI, other MHEls in the area, Maritime
Administration Regional Office and representative of the students affected, to discuss
the exit plan detailing the program of assistance, as provided in this circular.
The Regional Office of the Commission shall:

1.

inform the affected students and parents of the status of the Maritime Education
and Training Programs and the assistance hereunder provided, through any
reasonable means available:

2.

3.

issue the necessary endorsement of the affected students to other recognized
MHEls that shall accept the students based on the requirements of this circular
and assist in the release of the students’ credentials from the concerned MHEI;
advise the students concerned which courses of actions are suitable for each
case, such as:

a.

third year students who have completed the Classroom Instruction — to
decide whether they will continue to pursue the maritime program or other
programs;

b.

students who will pursue the BSMT or BSMarE per existing Circular to
transfer to a recognized MHE];

c.

students who are currently undergoing onboard training or have completed
onboard training for the BSMT or BSMarE programs —to report to the
concerned CHEDRO so they can be assisted in transferring to other
recognized MHEls for graduation, subject to the Admission and Retention
policies as provided in this circular.

immediately provide a report to the Commission as to the number, names, and
other pertinent details of the affected students at each year level and the exit
plan; and
Page 43 of 46
“

ox Fife,

wee

a

2

avon

4.

eet
——

=



5.

recommend to the Commission other measures whenever necessary, such as
when the transfer of students is not feasible in cases of program closure of MHEls
in regional jurisdictions with few MHEls.

Section 46. Illegal or unauthorized operation of BSMT/BSMarE programs

Graduates and/or students of unauthorized or non-recognized BSMT or BSMarE
program shall not be accepted by the Maritime Administration to take the assessment
of competence for certification as Officer-in-charge of a Navigational Watch or Officerin-charge of an Engineering Watch. Without prejudice of the filing of any civil and
criminal liabilities, HEIs which have operated without authorization/permit shall take full
accountability and responsibility over their students and shall return all amount paid by
affected students.

Section 47. Non-applicability of Section 56, paragraph 4, sub-paragraph| of
CMO 40, Series of 2008.

The provisions under Section 56, paragraph 4, sub-paragraph 1 of CMO 40, Series of
2008 which states that "applications for permit not disapproved within the aboveprescribed period (February 28), are deemed approved" shall not apply in so far as the
grant of Permit or Recognition for BSMT and/or BSMarE programs is concerned.
Applications for permit to operate maritime programs shall only be in accordance with
the policies standards and guidelines as provided in this Joint CHED-MARINA
Memorandum Circular.

Section 48. Non-applicability of Certain Benefits of Autonomous or
Deregulated Status

All MHEls are not exempt from the regular monitoring and evaluation by the
Commission of their BSMT or BSMarE programs.

Section 49. Non-applicability of Certain Benefits of Program Accreditation
All MHEIs with levels |, II, Ill or IV program accreditation for BSMT or BSMarE are not
exempt from limited visitation, inspection and/or supervision by the Commission
supervisory personnel or representatives.
Section 50. Repealing Clause

CMO 67 series of 2017, CMO 14 series of 2018, JCMMC No. 1, series of 2022 are
hereby repealed. All other relevant issuances inconsistent with the provisions of this
Circular are hereby amended and modified accordingly.

Page 44 of 46



Section 51. Separability Clause
lf any part or provision of this Circular shall be held unconstitutional or invalid, other

provisions hereof which are not affected thereby shall continue to be in full force and
effect.

Section 52. Transitory Provisions
Students who entered as first year in the maritime program for AY 2022-2023 are
covered by JCMMC No. 01, series of 2022, and for their succeeding years shall be

covered by this Circular.
Henceforth, all students who will enroll in the maritime program for AY 2023-2024
shall be covered by this Circular.

Section 53. Effectivity Clause
This Joint Memorandum Circular shall take effect after fifteen (15) days from
publication in the Official Gazette or in a newspaper of general circulation.

Quezon City, Philippines, Feb. 212023.
Approved:

For the Commission:

J. PROSP RO E. DE VERA Ill, DPA
Chairperson

HY

Commission on Higher Education

For the Maritime Administration:

ATTY.feintee
N. RABIA

Administrator

Maritime Industry Authority

Page 45 of 46



LIST OF ANNEXES:

Annexes A1 and A2 — STCW Competence Map for BSMT and BSMarE programs
Annexes B1 and B2 — Curriculum Maps for BSMT and BSMarE programs
Annexes C1 and C2 — Course Specifications for BSMT and BSMarE Programs
Annexes D1 and D2 — Sample Programs of Study
Annex E — Procedures Manual for Assessment and Evaluation of Competences for
the BSMT and BSMArE Programs

Annex F — Revised Guidelines on the Implementation of the Approved Onboard
Training for BSMT and BSMarE Students
Annex F1 — Daily Journal for Bridge Watchkeeping Duty
Annex F2 — Daily Journal for Engine Watchkeeping Duty
Annex F3 — Onboard Training Guidance for BSMT
Annex F4 — Onboard Training Guidance for BSMarE
Annex F5a — Standard Onboard Training Agreement for Domestic Trade
Annex F5b — Standard Cadet Training Agreement on Ships Engaged in
International Voyage

Annex F6 —Certification be Issued by Manning or Shipping Company
Annex F7 — Certificate of Sea Service
Annex F8 — Crew List, IMO FAL Form 5
Annex G — Equipment Carrying Capacity
Form 1 — List of Equipment

Form 2 — Equipment Utilization Plan
Form 3 — Summary of Practical Exercises and Assessments
Form 4 — Weekly Class Schedule

Annex H1 — Minimum Required Equipment for BSMT
Annex H2 — Minimum Required Equipment for BSMarE

Page 46 of 46
ant moh,
‘ty

=

,

3

Tv

x

=



